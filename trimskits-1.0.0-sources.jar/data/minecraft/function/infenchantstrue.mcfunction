# TrimKits alpha - "infinite enchantments" mode, ON.
#
# Lets an admin stamp any enchantment onto the held item at any level,
# past the enchantment's own max (e.g. /sfmode enchant minecraft:knockback 25).
# This is what "/function infenchantstrue" runs. Note: Minecraft resource
# locations are lowercase-only, so /function names must be lowercase.
#
# Turn it back off with "/function infenchantsfalse" (vanilla caps return).
# The state lives in config/trimskits.json -> infenchants.enabled.
infenchants true
