# TrimKits alpha - "infinite enchantments" mode, OFF.
#
# Restores vanilla behaviour: each enchantment is capped at its own max
# level again (knockback 2, sharpness 5, ...).
#
# Turn it back on with "/function infenchantstrue".
# The state lives in config/trimskits.json -> infenchants.enabled.
infenchants false
