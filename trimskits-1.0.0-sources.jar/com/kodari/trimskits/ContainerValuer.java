package com.kodari.trimskits;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemContainerContents;

/**
 * Values an item by looking <em>inside</em> it.
 *
 * <p>The selling engine must never treat a full shulker box as one cheap
 * ordinary item: a box holding 64 diamonds is worth the diamonds, not the
 * shell. This walks a container's stored {@link ItemContainerContents},
 * recursively for nested containers up to a hard depth limit, and prices every
 * leaf against {@link ShopValues#sellPrice}.
 *
 * <p>Everything here is pure and side-effect free — it computes a number and a
 * plan, it never mutates the stack or the economy. The caller (the /sellgui
 * transaction) decides when to actually consume items and credit money, which
 * is what makes the transaction atomic: valuation cannot half-succeed.
 *
 * <p>Guard rails, because the input is player-controlled item data:
 * <ul>
 *   <li>Depth is capped at {@code selling.max_container_depth} so a
 *       pathological nest cannot blow the stack.</li>
 *   <li>Each level caps its total at {@code selling.max_container_value} so a
 *       crafted "everything box" cannot overflow a long.</li>
 *   <li>A blacklist and the mod's own protection rules are consulted at every
 *       level, so a renamed keepsake inside a box still counts as protected.</li>
 * </ul>
 */
final class ContainerValuer {

	/** The three ways a shulker box may be sold, straight from config. */
	enum Policy {
		/** Sell the contained items <em>and</em> the box itself, consuming both. */
		CONTENTS_AND_BOX,
		/** Sell contained items, then hand the empty box back to the player. */
		CONTENTS_ONLY,
		/** Sell only the outer box as a single item; never open it. */
		BOX_ONLY;

		/** Reads {@code selling.shulker_policy}, falling back to the safe default. */
		static Policy fromConfig() {
			String raw = Config.getString("selling.shulker_policy", "contents_and_box")
				.trim().toLowerCase(Locale.ROOT).replace('-', '_');
			return switch (raw) {
				case "contents_only", "contents" -> CONTENTS_ONLY;
				case "box_only", "box" -> BOX_ONLY;
				default -> CONTENTS_AND_BOX;
			};
		}
	}

	/**
	 * What one stack is worth and what should physically happen to it.
	 *
	 * @param value        total dollars the stack contributes
	 * @param units        how many sellable leaf items that value covers
	 * @param sellBox      whether the outer box itself should be consumed/sold
	 * @param keepBox      whether the (now emptied) box must be returned intact
	 * @param protectedUnits leaf units held back because they are protected
	 * @param ineligible   true when nothing in this stack can be sold at all
	 */
	record Valuation(long value, int units, boolean sellBox, boolean keepBox,
			long protectedUnits, boolean ineligible) {
		static final Valuation NONE = new Valuation(0, 0, false, false, 0, true);

		boolean anything() {
			return value > 0 || units > 0 || sellBox;
		}
	}

	private ContainerValuer() {
	}

	// ---- Blacklist ---------------------------------------------------------

	/** The configured blacklist as lowercase ids, parsed once per call site. */
	private static java.util.Set<String> blacklist() {
		String raw = Config.getString("selling.blacklisted_items", "");
		if (raw.isBlank()) {
			return java.util.Set.of();
		}
		java.util.Set<String> ids = new java.util.HashSet<>();
		for (String part : raw.split(",")) {
			String id = part.trim().toLowerCase(Locale.ROOT);
			if (!id.isEmpty()) {
				ids.add(id);
			}
		}
		return ids;
	}

	/** True when an item id is explicitly barred from selling. */
	static boolean isBlacklisted(Item item) {
		if (item == null) {
			return true;
		}
		java.util.Set<String> ids = blacklist();
		if (ids.isEmpty()) {
			return false;
		}
		return ids.contains(BuiltInRegistries.ITEM.getKey(item).getPath().toLowerCase(Locale.ROOT))
			|| ids.contains(BuiltInRegistries.ITEM.getKey(item).toString().toLowerCase(Locale.ROOT));
	}

	/** True when this stack is barred from ever being sold, by id or protection. */
	private static boolean barred(ItemStack stack) {
		if (stack == null || stack.isEmpty()) {
			return true;
		}
		if (isBlacklisted(stack.getItem())) {
			return true;
		}
		// A custom name marks a keepsake anywhere in the tree, box or leaf.
		return TrimKits.isProtected(stack);
	}

	// ---- Valuation ---------------------------------------------------------

	/**
	 * Prices one stack, opening containers as the configured policy allows.
	 *
	 * @param stack the stack sitting in a deposit slot
	 * @param policy how shulker boxes should be treated
	 */
	static Valuation value(ItemStack stack, Policy policy) {
		return value(stack, policy, 0);
	}

	private static Valuation value(ItemStack stack, Policy policy, int depth) {
		if (stack == null || stack.isEmpty()) {
			return Valuation.NONE;
		}
		ItemContainerContents contents = stack.get(DataComponents.CONTAINER);
		boolean isContainer = contents != null && hasAny(contents);

		// A container the policy says not to open is sold as a plain item.
		if (isContainer && (policy == Policy.BOX_ONLY || depth >= maxDepth())) {
			return leaf(stack);
		}
		if (!isContainer) {
			return leaf(stack);
		}

		// Open it: value the contents according to policy.
		return switch (policy) {
			case BOX_ONLY -> leaf(stack); // unreachable (guarded above) but explicit
			case CONTENTS_ONLY -> valueContents(contents, policy, depth, stack, false);
			case CONTENTS_AND_BOX -> {
				Valuation inner = valueContents(contents, policy, depth, stack, false);
				// The box shell itself may carry a price (usually it does not).
				Long shell = shellPrice(stack);
				if (shell != null && shell > 0) {
					yield new Valuation(Math.addExact(inner.value(), shell),
						inner.units(), true, false, inner.protectedUnits(), inner.ineligible());
				}
				yield new Valuation(inner.value(), inner.units(), true, false,
					inner.protectedUnits(), inner.ineligible());
			}
		};
	}

	private static Valuation valueContents(ItemContainerContents contents, Policy policy,
			int depth, ItemStack outer, boolean unused) {
		long total = 0;
		int units = 0;
		long protectedUnits = 0;
		long ceiling = Config.getLong("selling.max_container_value");
		boolean anyEligible = false;

		for (ItemStack inner : Compat.containerItemStream(contents).toList()) {
			if (inner.isEmpty()) {
				continue;
			}
			if (barred(inner)) {
				protectedUnits += inner.getCount();
				continue;
			}
			Valuation leafVal = value(inner, policy, depth + 1);
			if (leafVal.ineligible()) {
				protectedUnits += leafVal.protectedUnits();
				continue;
			}
			try {
				total = Math.addExact(total, leafVal.value());
			} catch (ArithmeticException overflow) {
				total = ceiling;
			}
			if (total > ceiling) {
				total = ceiling;
			}
			units += leafVal.units();
			protectedUnits += leafVal.protectedUnits();
			anyEligible = true;
		}

		if (!anyEligible && units == 0 && total == 0) {
			// Nothing inside could be sold. Under CONTENTS_ONLY the box is
			// kept; otherwise the caller still sees it as a box to handle.
			return new Valuation(0, 0, false, policy == Policy.CONTENTS_ONLY,
				protectedUnits, protectedUnits > 0);
		}
		boolean keepBox = policy == Policy.CONTENTS_ONLY;
		return new Valuation(total, units, !keepBox, keepBox, protectedUnits, false);
	}

	/** A plain (non-container) item, or a container sold as an item. */
	private static Valuation leaf(ItemStack stack) {
		if (barred(stack)) {
			return new Valuation(0, 0, false, false, stack.getCount(), true);
		}
		Long price = ShopValues.sellPrice(stack);
		if (price == null || price <= 0) {
			return new Valuation(0, 0, false, false, 0, true);
		}
		long value;
		try {
			value = Math.multiplyExact(price, (long) stack.getCount());
		} catch (ArithmeticException overflow) {
			value = Config.getLong("selling.max_container_value");
		}
		return new Valuation(value, stack.getCount(), false, false, 0, false);
	}

	/** The outer box's own item price, independent of what it holds. */
	private static Long shellPrice(ItemStack stack) {
		// Shulker shells/boxes are usually never-sell; report null so the box
		// contributes nothing on its own under CONTENTS_AND_BOX.
		Long price = ShopValues.priceOf(stack.getItem());
		if (price == null || price <= 0) {
			return null;
		}
		return price;
	}

	private static boolean hasAny(ItemContainerContents contents) {
		return contents.nonEmptyItemCopyStream().findAny().isPresent();
	}

	private static int maxDepth() {
		int depth = Config.getInt("selling.max_container_depth");
		// Even a configured 0 must allow one level, or shulkers never open.
		return Math.max(1, Math.min(depth, 8));
	}

	// ---- Reports -----------------------------------------------------------

	/** Every distinct sellable leaf item a stack would contribute, for a receipt. */
	static List<String> describeLeaves(ItemStack stack, Policy policy) {
		List<String> names = new ArrayList<>();
		collectLeaves(stack, policy, 0, names);
		return names;
	}

	private static void collectLeaves(ItemStack stack, Policy policy, int depth, List<String> into) {
		if (stack == null || stack.isEmpty()) {
			return;
		}
		ItemContainerContents contents = stack.get(DataComponents.CONTAINER);
		if (contents == null || policy == Policy.BOX_ONLY || depth >= maxDepth()) {
			if (!barred(stack)) {
				String id = BuiltInRegistries.ITEM.getKey(stack.getItem()).getPath();
				into.add(id + " x" + stack.getCount());
			}
			return;
		}
		for (ItemStack inner : Compat.containerItemStream(contents).toList()) {
			if (!inner.isEmpty()) {
				collectLeaves(inner, policy, depth + 1, into);
			}
		}
	}
}
