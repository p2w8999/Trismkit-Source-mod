package com.kodari.trimskits;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Shards - the second currency, paid out for playing rather than for selling
 * things, and spent in the shard shop on gear the money shop will not stock.
 *
 * <p>Only what has been <em>spent</em> is ever written to disk. What a player
 * has earned is derived from their statistics (mob kills, player kills, blocks
 * mined and playtime), so the two economies cannot drift apart, a duplicated
 * balance becomes impossible, and anyone who was on the server before shards
 * existed is owed their back pay the moment they next join.
 *
 * <p>The earn rates are deliberately modest and are printed by /shards, so the
 * shop stays a long-term goal rather than something a mob farm clears in an
 * evening.
 */
final class Shards {
	private static final Logger LOGGER = LoggerFactory.getLogger("trimskits");
	private static final Path DATA_FILE = Path.of("config", "trimskits-shards.properties");
	/** A version tag so a future format change can be spotted on load. */
	private static final String FORMAT = "v1";

	/** Shards handed out for every mob killed. */
	static final long PER_MOB_KILL = 2L;
	/** Shards handed out for every player killed. */
	static final long PER_PLAYER_KILL = 40L;
	/** Blocks you have to mine to earn one shard. */
	static final long BLOCKS_PER_SHARD = 25L;
	/** Seconds of playtime for one shard - ten minutes. */
	static final long SECONDS_PER_SHARD = 600L;

	/** UUID -> shards already spent. Everything else is derived from stats. */
	private static final Map<UUID, Long> SPENT = new HashMap<>();
	/**
	 * UUID -> admin adjustments from /shards give, remove and set.
	 *
	 * <p>The balance is derived (earned minus spent), so an admin cannot simply
	 * write a number: they add or subtract this offset instead. It is persisted
	 * beside what was spent, so a restart does not hand the shards back. Kept
	 * separate from {@link #SPENT} so the "earned / spent" figures the player
	 * sees never lie about what play produced.
	 */
	private static final Map<UUID, Long> BONUS = new HashMap<>();
	private static boolean loaded;
	private static boolean readable = true;

	private Shards() {
	}

	/** What play has paid out so far. Derived, never stored. */
	static long earned(UUID playerId) {
		// A running shard boost doubles everything earned while it lasts. The
		// multiplier is read here, on the derived figure, so /shards shows the
		// boosted number the shop will actually charge against.
		long multiplier = ShardBoosts.multiplier(playerId);
		return multiplier * (Math.max(0L, PlayerStats.mobKills(playerId)) * PER_MOB_KILL
			+ Math.max(0L, PlayerStats.kills(playerId)) * PER_PLAYER_KILL
			+ Math.max(0L, PlayerStats.blocksBroken(playerId)) / BLOCKS_PER_SHARD
			+ Math.max(0L, PlayerStats.playtimeSeconds(playerId)) / SECONDS_PER_SHARD);
	}

	static synchronized long spent(UUID playerId) {
		load();
		return SPENT.getOrDefault(playerId, 0L);
	}

	/** What the shop will accept right now. Never negative, never a dupe. */
	static synchronized long balance(UUID playerId) {
		return Math.max(0L, earned(playerId) - spent(playerId) + BONUS.getOrDefault(playerId, 0L));
	}

	/**
	 * Charges a purchase against the player's shards.
	 *
	 * @return null on success, or the reason it did not happen
	 */
	static synchronized String buy(UUID playerId, long price) {
		load();
		if (price <= 0) {
			return "That is not for sale.";
		}
		long have = balance(playerId);
		if (have < price) {
			return "That costs " + TrimKits.formatAmount(price) + " shards and you have "
				+ TrimKits.formatAmount(have) + ".";
		}

		long previous = spent(playerId);
		SPENT.put(playerId, previous + price);
		if (!save()) {
			// Roll the charge back rather than take shards for a purchase that
			// could not be recorded - the balance would otherwise be gone for
			// good the next time the file is written.
			SPENT.put(playerId, previous);
			return "Your shard total could not be saved. You were not charged.";
		}
		return null;
	}

	/** The earn rates, spelled out for /shards and the shop's info book. */
	static String[] rateLines() {
		return new String[] {
			PER_MOB_KILL + " for every mob you kill",
			PER_PLAYER_KILL + " for every player you kill",
			"1 for every " + BLOCKS_PER_SHARD + " blocks you mine",
			"1 for every " + (SECONDS_PER_SHARD / 60) + " minutes you play"
		};
	}

	/**
	 * Admin: adds shards on top of what the player earned.
	 *
	 * @return null on success, or the reason it did not happen
	 */
	static synchronized String adminGive(UUID playerId, long amount) {
		load();
		if (amount <= 0) {
			return "Give a positive number of shards.";
		}
		return applyBonus(playerId, BONUS.getOrDefault(playerId, 0L) + amount);
	}

	/**
	 * Admin: takes shards back. It can never take more than the player holds,
	 * so a mis-typed amount cannot push the balance below zero - the excess is
	 * simply dropped and the caller is told how much actually went.
	 *
	 * @return null on success, or the reason it did not happen
	 */
	static synchronized String adminRemove(UUID playerId, long amount) {
		load();
		if (amount <= 0) {
			return "Remove a positive number of shards.";
		}
		long have = balance(playerId);
		long taken = Math.min(have, amount);
		if (taken <= 0) {
			return "That player has no shards to remove.";
		}
		return applyBonus(playerId, BONUS.getOrDefault(playerId, 0L) - taken);
	}

	/**
	 * Admin: sets the balance to an exact figure, replacing whatever was there.
	 * The offset is solved backwards from the derived earnings so the result
	 * really is the number that was asked for.
	 *
	 * @return null on success, or the reason it did not happen
	 */
	static synchronized String adminSet(UUID playerId, long amount) {
		load();
		if (amount < 0) {
			return "A balance cannot be negative.";
		}
		// balance = max(0, earned - spent + bonus); solve for bonus.
		return applyBonus(playerId, amount - earned(playerId) + spent(playerId));
	}

	/** Writes a new offset and saves it, rolling back if the file refused. */
	private static String applyBonus(UUID playerId, long next) {
		long previous = BONUS.getOrDefault(playerId, 0L);
		BONUS.put(playerId, next);
		if (!save()) {
			BONUS.put(playerId, previous);
			return "That change could not be saved. Nothing was changed.";
		}
		return null;
	}

	/** A row of the /shards top leaderboard. */
	record Entry(UUID playerId, long balance) {
	}

	/** The richest shard balances, for /shards top. */
	static synchronized List<Entry> topBalances(int limit) {
		load();
		List<Entry> entries = new ArrayList<>();
		for (UUID playerId : PlayerStats.knownPlayers()) {
			entries.add(new Entry(playerId, balance(playerId)));
		}
		entries.sort(Comparator.comparingLong(Entry::balance).reversed());
		return entries.size() > limit ? new ArrayList<>(entries.subList(0, limit)) : entries;
	}

	/**
	 * Every player that appears in either map. A player who was only ever
	 * handed admin shards has no spend record, so saving just the spend map
	 * would silently drop their balance on the next write.
	 */
	private static synchronized Set<UUID> unionKeys() {
		Set<UUID> keys = new HashSet<>(SPENT.keySet());
		keys.addAll(BONUS.keySet());
		return keys;
	}

	private static synchronized void load() {
		if (loaded) {
			return;
		}
		loaded = true;
		if (!Files.exists(DATA_FILE)) {
			return;
		}
		Properties properties = new Properties();
		try (InputStream input = Files.newInputStream(DATA_FILE)) {
			properties.load(input);
		} catch (IOException exception) {
			readable = false;
			LOGGER.warn("Could not read {}; shard spending stays in memory only.", DATA_FILE);
			return;
		}
		for (String key : properties.stringPropertyNames()) {
			try {
				String[] fields = properties.getProperty(key).split("\\|", -1);
				if (fields.length < 2 || !FORMAT.equals(fields[0])) {
					continue;
				}
				UUID playerId = UUID.fromString(key);
				SPENT.put(playerId, Math.max(0L, Long.parseLong(fields[1])));
				// A third field carries the admin offset. Lines written before
				// /shards give existed have none, which simply reads as zero.
				if (fields.length >= 3) {
					BONUS.put(playerId, Long.parseLong(fields[2]));
				}
			} catch (RuntimeException ignored) {
				// Skip a damaged line instead of failing the whole file.
			}
		}
	}

	private static synchronized boolean save() {
		if (!readable) {
			return false;
		}
		Properties properties = new Properties();
		for (UUID playerId : unionKeys()) {
			properties.setProperty(playerId.toString(),
				FORMAT + "|" + Long.toString(SPENT.getOrDefault(playerId, 0L))
					+ "|" + Long.toString(BONUS.getOrDefault(playerId, 0L)));
		}

		Path temporaryFile = DATA_FILE.resolveSibling("trimskits-shards.tmp");
		try {
			Files.createDirectories(DATA_FILE.getParent());
			try (OutputStream output = Files.newOutputStream(temporaryFile)) {
				properties.store(output, "Trim Kits shard spending");
			}
			try {
				Files.move(temporaryFile, DATA_FILE, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
			} catch (AtomicMoveNotSupportedException exception) {
				Files.move(temporaryFile, DATA_FILE, StandardCopyOption.REPLACE_EXISTING);
			}
			return true;
		} catch (IOException exception) {
			LOGGER.warn("Could not save shard spending: {}", exception.getMessage());
			return false;
		}
	}
}
