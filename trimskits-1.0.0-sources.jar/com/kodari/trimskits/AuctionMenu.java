package com.kodari.trimskits;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;

/**
 * Donut-SMP style auction house GUI: a paginated wall of live listings. Click
 * a listing to buy it; the item goes straight to your inventory and the seller
 * is paid. Listings you own are marked and cannot be bought by yourself.
 *
 * The bottom row is the control bar: page turning, a refresh button, your
 * balance and a close button.
 */
final class AuctionMenu extends ChestMenu {
	private static final int ROWS = 6;
	private static final int SIZE = ROWS * 9;
	private static final int BAR = (ROWS - 1) * 9;

	private static final int SLOT_PREV = BAR + 0;
	private static final int SLOT_PAGE = BAR + 2;
	private static final int SLOT_REFRESH = BAR + 3;
	private static final int SLOT_BALANCE = BAR + 5;
	private static final int SLOT_CLOSE = BAR + 8;

	private final ServerPlayer owner;
	private final SimpleContainer container;
	/** Snapshot of listing ids, rebuilt on every render. */
	private final List<Integer> ids = new ArrayList<>();
	private int page;

	AuctionMenu(int containerId, Inventory inventory, ServerPlayer owner) {
		super(MenuType.GENERIC_9x6, containerId, inventory, new SimpleContainer(SIZE), ROWS);
		this.owner = owner;
		this.container = (SimpleContainer) getContainer();
		render();
	}

	/** Number of listing slots in the grid (everything above the control bar). */
	private static final int GRID = BAR;

	private int pageCount() {
		return Math.max(1, (ids.size() + GRID - 1) / GRID);
	}

	private void render() {
		for (int slot = 0; slot < SIZE; slot++) {
			container.setItem(slot, ItemStack.EMPTY);
		}

		Map<Integer, MarketData.AuctionListing> auctions = MarketData.auctions();
		ids.clear();
		auctions.keySet().stream().sorted().forEach(ids::add);

		if (page >= pageCount()) {
			page = pageCount() - 1;
		}
		if (page < 0) {
			page = 0;
		}

		int first = page * GRID;
		for (int offset = 0; offset < GRID; offset++) {
			int index = first + offset;
			if (index >= ids.size()) {
				break;
			}
			int id = ids.get(index);
			MarketData.AuctionListing listing = auctions.get(id);
			if (listing == null) {
				continue;
			}
			boolean own = listing.sellerId().equals(owner.getUUID());
			String sellerName = own ? owner.getScoreboardName() : playerName(listing.sellerId());
			ItemStack icon = ShopValues.auctionIcon(listing.stack(), listing.price(), sellerName, own);
			// Embed the auction id in the display name so the click handler can read it.
			icon.set(DataComponents.CUSTOM_NAME, Component.literal("#" + id)
				.withStyle(ChatFormatting.AQUA)
				.append(Component.literal(" " + listing.stack().getHoverName().getString())
					.withStyle(ChatFormatting.WHITE)));
			container.setItem(offset, icon);
		}

		container.setItem(SLOT_PREV, page > 0 ? icon(Items.ARROW, "Previous page", ChatFormatting.YELLOW)
			: icon(Items.STONE_BUTTON, "No previous page", ChatFormatting.DARK_GRAY));
		container.setItem(SLOT_PAGE, icon(Items.BOOK,
			"Page " + (page + 1) + " / " + pageCount() + " - " + ids.size() + " listing(s)", ChatFormatting.AQUA));
		container.setItem(SLOT_REFRESH, icon(Items.SPYGLASS, "Refresh listings", ChatFormatting.AQUA));
		container.setItem(SLOT_BALANCE, icon(Items.GOLD_INGOT,
			"Balance: $" + TrimKits.formatAmount(MarketData.balance(owner.getUUID())), ChatFormatting.GOLD));
		container.setItem(SLOT_CLOSE, icon(Items.BARRIER, "Close", ChatFormatting.RED));

		broadcastChanges();
	}

	private String playerName(java.util.UUID id) {
		MinecraftServer server = owner.level().getServer();
		ServerPlayer online = server == null ? null : server.getPlayerList().getPlayer(id);
		if (online != null) {
			return online.getScoreboardName();
		}
		String known = PlayerStats.nameOf(id);
		return (known == null || known.isBlank()) ? "Unknown" : known;
	}

	private static ItemStack icon(net.minecraft.world.item.Item item, String label, ChatFormatting color) {
		ItemStack stack = new ItemStack(item);
		if (label != null) {
			stack.set(DataComponents.CUSTOM_NAME, Component.literal(label).withStyle(color));
		}
		return stack;
	}

	@Override
	public void clicked(int slotIndex, int buttonNum, ContainerInput containerInput, Player player) {
		// Container slots are display-only; never let the vanilla handler run,
		// otherwise players could pull the icons out and dupe them.
		if (slotIndex < 0 || slotIndex >= SIZE || !(player instanceof ServerPlayer serverPlayer)) {
			return;
		}

		if (slotIndex == SLOT_CLOSE) {
			serverPlayer.closeContainer();
			return;
		}
		if (slotIndex == SLOT_REFRESH) {
			render();
			return;
		}
		if (slotIndex == SLOT_PREV && page > 0) {
			page--;
			render();
			return;
		}
		if (slotIndex == SLOT_PAGE) {
			if (page + 1 < pageCount()) {
				page++;
			} else {
				page = 0;
			}
			render();
			return;
		}
		if (slotIndex == SLOT_BALANCE) {
			return;
		}
		if (slotIndex >= GRID) {
			return;
		}

		// Grid slot: parse the auction id out of the icon and buy it.
		int index = page * GRID + slotIndex;
		if (index >= ids.size()) {
			return;
		}
		int id = ids.get(index);
		MarketData.AuctionListing before = MarketData.auctions().get(id);
		if (before == null) {
			serverPlayer.sendSystemMessage(Component.literal("That listing no longer exists."));
			render();
			return;
		}
		long price = before.price();
		MarketData.PurchaseResult result = MarketData.purchase(serverPlayer.getUUID(), id, serverPlayer.level().registryAccess());
		if (result.status() != MarketData.BuyStatus.SUCCESS) {
			serverPlayer.sendSystemMessage(Component.literal(switch (result.status()) {
				case NOT_FOUND -> "That listing no longer exists.";
				case OWN_LISTING -> "You cannot buy your own listing.";
				case INSUFFICIENT_FUNDS -> "You do not have enough money.";
				case STORAGE_ERROR -> "Could not save the purchase; no money was charged.";
				case SUCCESS -> "";
			}));
			render();
			return;
		}

		Compat.placeBack(serverPlayer.getInventory(), result.stack());
		serverPlayer.sendSystemMessage(Component.literal(
			"Bought auction #" + id + " for $" + TrimKits.formatAmount(price) + "."));
		render();
	}

	@Override
	public ItemStack quickMoveStack(Player player, int slotIndex) {
		// No shift-clicking in or out of the auction house.
		return ItemStack.EMPTY;
	}
}
