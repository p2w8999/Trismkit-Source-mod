package com.kodari.trimskits;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.Registry;
import net.minecraft.core.RegistryAccess;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.enchantment.ItemEnchantments;

/**
 * What the shard shop stocks: end-game gear, the liquidation tools, and every
 * custom enchant book, paid for in shards rather than money.
 *
 * <p>Shards are earned by killing, mining and playing, so this shop is the
 * reward for actually using the server instead of for grinding the sell menu.
 * The gear is built from the same pre-enchanted netherite the kits use, so a
 * bought sword is identical to the one a kit hands out.
 */
final class ShardShop {
	/** One thing for sale: a name, a price in shards, and the exact stack handed over. */
	record Offer(String name, long shards, ItemStack stack) {
		boolean affordable(long balance) {
			return balance >= shards;
		}
	}

	private ShardShop() {
	}

	/** Builds the catalogue. Cheap enough to rebuild whenever the GUI opens. */
	static List<Offer> offers(RegistryAccess registries) {
		Registry<Enchantment> enchantments = registries.lookupOrThrow(Registries.ENCHANTMENT);
		List<Offer> offers = new ArrayList<>();

		// Weapons and tools - identical to the kit versions.
		List<ItemStack> tools = TrimKits.preEnchantedNetheriteTools(enchantments);
		add(offers, "Netherite Sword", 700, pick(tools, Items.NETHERITE_SWORD));
		add(offers, "Netherite Pickaxe", 650, pick(tools, Items.NETHERITE_PICKAXE));
		add(offers, "Netherite Axe", 600, pick(tools, Items.NETHERITE_AXE));
		add(offers, "Netherite Shovel", 350, pick(tools, Items.NETHERITE_SHOVEL));

		// Liquidation tools: mine a box, keep the box, take the money. The
		// ability lives in the lore line, which an anvil rename cannot forge.
		add(offers, "Sell Axe", 500, SellTools.sellAxe(pick(tools, Items.NETHERITE_AXE)));
		add(offers, "Sell Pick", 500, SellTools.sellPick(pick(tools, Items.NETHERITE_PICKAXE)));
		if (Config.getBoolean("selltools.shovel_enabled")) {
			add(offers, "Sell Shovel", 450, SellTools.sellShovel(pick(tools, Items.NETHERITE_SHOVEL)));
		}
		if (Config.getBoolean("selltools.wand_enabled")) {
			add(offers, "Sell Wand", 600, SellTools.sellWand(new ItemStack(Items.BLAZE_ROD)));
		}
		if (Config.getBoolean("economy.auto_sell_totem_enabled")) {
			add(offers, "Auto-Sell Totem", 750,
				SellTools.autoSellTotem(new ItemStack(Items.TOTEM_OF_UNDYING)));
		}
		if (Config.getBoolean("selltools.pouch_enabled")) {
			add(offers, "Sell Pouch", 300, SellTools.sellPouch(new ItemStack(Items.LEATHER)));
		}

		// Armour.
		List<ItemStack> armour = TrimKits.preEnchantedNetheriteArmor(enchantments);
		add(offers, "Netherite Helmet", 400, pick(armour, Items.NETHERITE_HELMET));
		add(offers, "Netherite Chestplate", 450, pick(armour, Items.NETHERITE_CHESTPLATE));
		add(offers, "Netherite Leggings", 450, pick(armour, Items.NETHERITE_LEGGINGS));
		add(offers, "Netherite Boots", 400, pick(armour, Items.NETHERITE_BOOTS));

		// Getting around, and staying alive.
		add(offers, "Elytra", 550, enchantedElytra(enchantments));
		add(offers, "Firework Rockets x64", 40, new ItemStack(Items.FIREWORK_ROCKET, 64));
		add(offers, "Totem of Undying", 60, new ItemStack(Items.TOTEM_OF_UNDYING));
		add(offers, "Enchanted Golden Apples x4", 300, new ItemStack(Items.ENCHANTED_GOLDEN_APPLE, 4));
		add(offers, "Golden Carrots x64", 80, new ItemStack(Items.GOLDEN_CARROT, 64));
		add(offers, "Ender Pearls x16", 120, new ItemStack(Items.ENDER_PEARL, 16));

		// A flutter: keys open into a weighted roll of prizes, and a boost
		// doubles what play pays out for an hour. Both are bought with shards
		// so they reward time spent rather than money spent.
		if (Config.getBoolean("economy.crate_keys_enabled")) {
			add(offers, "Crate Key", 200, CrateKeys.key());
		}
		if (Config.getBoolean("economy.shard_boosts_enabled")) {
			ItemStack boost = new ItemStack(Items.AMETHYST_SHARD);
			boost.set(net.minecraft.core.component.DataComponents.CUSTOM_NAME,
				net.minecraft.network.chat.Component.literal("Shard Boost (1h x"
					+ ShardBoosts.BOOST_MULTIPLIER + ")")
					.withStyle(net.minecraft.ChatFormatting.LIGHT_PURPLE));
			boost.set(net.minecraft.core.component.DataComponents.LORE,
				new net.minecraft.world.item.component.ItemLore(java.util.List.of(
					net.minecraft.network.chat.Component.literal("Buy this to activate it,")
						.withStyle(net.minecraft.ChatFormatting.YELLOW),
					net.minecraft.network.chat.Component.literal("or use /boost buy.")
						.withStyle(net.minecraft.ChatFormatting.GRAY))));
			add(offers, "Shard Boost (1h)", ShardBoosts.BOOST_PRICE, boost);
		}

		// A small seasonal shelf, rotated by the month, so the shop has
		// something that is only ever there for a while.
		seasonalOffers(offers, enchantments);

		// Blocks and kit for building.
		add(offers, "Shulker Box", 250, new ItemStack(Items.SHULKER_BOX));
		add(offers, "Beacon", 350, new ItemStack(Items.BEACON));
		add(offers, "Netherite Ingots x2", 350, new ItemStack(Items.NETHERITE_INGOT, 2));
		add(offers, "Diamond Blocks x16", 250, new ItemStack(Items.DIAMOND_BLOCK, 16));
		add(offers, "Netherite Upgrade Template", 300, new ItemStack(Items.NETHERITE_UPGRADE_SMITHING_TEMPLATE));

		// Every custom enchant at its top level, so any tool can be upgraded -
		// not only the six pieces of gear the money shop sells.
		for (CustomEnchants.Type type : CustomEnchants.Type.values()) {
			add(offers, type.displayName() + " Book", 350,
				CustomEnchants.book(type, type.maxLevel()));
		}
		return offers;
	}

	private static void add(List<Offer> offers, String name, long shards, ItemStack stack) {
		// A stack that could not be built would be air, and selling air would
		// charge shards for nothing.
		if (stack == null || stack.isEmpty()) {
			return;
		}
		offers.add(new Offer(name, shards, stack));
	}

	/**
	 * Adds a couple of themed items chosen by the current month. They are
	 * ordinary items at themed prices - the point is not rarity but that the
	 * shelf is never quite the same twice, which gives a returning player
	 * something to notice.
	 */
	private static void seasonalOffers(List<Offer> offers, Registry<Enchantment> enchantments) {
		int month = java.time.LocalDate.now().getMonthValue();
		switch (month) {
			case 1 -> { // January: the year begins, rewards a fresh start.
				add(offers, "New Year Bundle", 150, new ItemStack(Items.FIREWORK_ROCKET, 64));
				add(offers, "Golden Carrots x64", 60, new ItemStack(Items.GOLDEN_CARROT, 64));
			}
			case 2 -> { // February.
				add(offers, "Sweet Berries x64", 30, new ItemStack(Items.SWEET_BERRIES, 64));
				add(offers, "Enchanted Golden Apple", 90, new ItemStack(Items.ENCHANTED_GOLDEN_APPLE));
			}
			case 3, 4, 5 -> { // Spring: building season.
				add(offers, "Bone Meal x64", 25, new ItemStack(Items.BONE_MEAL, 64));
				add(offers, "Diamond Blocks x8", 130, new ItemStack(Items.DIAMOND_BLOCK, 8));
			}
			case 6, 7, 8 -> { // Summer: the flying season.
				add(offers, "Firework Rockets x64", 30, new ItemStack(Items.FIREWORK_ROCKET, 64));
				add(offers, "Elytra", 500, enchantedElytra(enchantments));
			}
			case 9, 10 -> { // Autumn, running into the spooky month.
				add(offers, "Pumpkins x64", 20, new ItemStack(Items.PUMPKIN, 64));
				add(offers, "Ender Pearls x16", 100, new ItemStack(Items.ENDER_PEARL, 16));
			}
			case 11 -> { // November.
				add(offers, "Totem of Undying", 50, new ItemStack(Items.TOTEM_OF_UNDYING));
				add(offers, "Beacon", 300, new ItemStack(Items.BEACON));
			}
			case 12 -> { // December: the generous month.
				add(offers, "Enchanted Golden Apples x4", 240, new ItemStack(Items.ENCHANTED_GOLDEN_APPLE, 4));
				add(offers, "Netherite Ingots x2", 300, new ItemStack(Items.NETHERITE_INGOT, 2));
			}
			default -> {
			}
		}
	}

	/** Pulls one item out of a mixed list, so the order of the list cannot matter. */
	private static ItemStack pick(List<ItemStack> stacks, Item item) {
		for (ItemStack stack : stacks) {
			if (stack.getItem() == item) {
				return stack;
			}
		}
		return ItemStack.EMPTY;
	}

	/** An elytra that does not burn through its durability on the first flight. */
	private static ItemStack enchantedElytra(Registry<Enchantment> enchantments) {
		ItemStack elytra = new ItemStack(Items.ELYTRA);
		ItemEnchantments.Mutable applied = new ItemEnchantments.Mutable(ItemEnchantments.EMPTY);
		applied.set(enchantments.get(Enchantments.UNBREAKING).orElseThrow(), 3);
		applied.set(enchantments.get(Enchantments.MENDING).orElseThrow(), 1);
		elytra.set(DataComponents.ENCHANTMENTS, applied.toImmutable());
		return elytra;
	}
}
