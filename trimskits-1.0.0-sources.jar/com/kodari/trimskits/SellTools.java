package com.kodari.trimskits;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.ItemLore;
import net.minecraft.world.level.block.BarrelBlock;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.ShulkerBoxBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/**
 * The shard shop's liquidation tools: a Sell Axe for chests, a Sell Pick for
 * shulker boxes, a Sell Shovel for barrels and hoppers, a Sell Wand that
 * reaches any container without walking over, and an Auto-Sell Totem that
 * quietly empties your inventory while you fight.
 *
 * <p>Mine a matching box while holding its tool and the break is cancelled on
 * purpose: every stack the shop prices is sold on the spot - straight to the
 * miner's balance - and the box stays standing, so a base chest doubles as a
 * sell station. Renamed keepsakes and anything the shop will not price
 * (another shulker, say) are left inside, exactly like "sell everything" in
 * the sell menu, and no stack is removed until the balance has accepted the
 * money, so a failed save can never eat items.
 *
 * <p>Every liquidation costs the tool a point of durability (configurable,
 * and free when set to zero), so the tools are a convenience with a running
 * price rather than a permanent replacement for the sell menu.
 *
 * <p>Under the hood these are the kit's pre-enchanted netherite tools, so
 * they chop and mine normally. What marks them is a lore line - and lore
 * cannot be forged with an anvil the way a name can.
 */
final class SellTools {
	/** The lore line marking a Sell Axe; detection matches this exact text. */
	static final String AXE_HINT = "Mine a chest to sell its contents.";
	/** The lore line marking a Sell Pick. */
	static final String PICK_HINT = "Mine a shulker box to sell its contents.";
	/** The lore line marking a Sell Shovel. */
	static final String SHOVEL_HINT = "Mine a barrel or hopper to sell its contents.";
	/** The lore line marking a Sell Wand: right-click, no mining at all. */
	static final String WAND_HINT = "Right-click a container to sell its contents.";
	/** The lore line marking an Auto-Sell Totem. */
	static final String TOTEM_HINT = "Sells priced drops from your inventory.";
	/** The lore line marking a Sell Pouch: a portable /sell all. */
	static final String POUCH_HINT = "Right-click to sell your whole inventory.";

	/** Slots an auto-sell totem leaves alone, so gear is never sold by mistake. */
	private static final int HOTBAR_SLOTS = 9;
	/** How often a held totem sweeps the inventory, in server ticks (5s). */
	private static final int TOTEM_INTERVAL_TICKS = 100;

	private SellTools() {
	}

	/** Turns the shop's netherite axe into a Sell Axe. */
	static ItemStack sellAxe(ItemStack base) {
		return marked(base, "Sell Axe", AXE_HINT, "The chest itself stays intact.");
	}

	/** Turns the shop's netherite pickaxe into a Sell Pick. */
	static ItemStack sellPick(ItemStack base) {
		return marked(base, "Sell Pick", PICK_HINT, "The shulker box itself stays intact.");
	}

	/** Turns the shop's netherite shovel into a Sell Shovel. */
	static ItemStack sellShovel(ItemStack base) {
		return marked(base, "Sell Shovel", SHOVEL_HINT, "The barrel itself stays intact.");
	}

	/** A wand that sells into any container it is waved at, from arm's length. */
	static ItemStack sellWand(ItemStack base) {
		return marked(base, "Sell Wand", WAND_HINT, "Right-click a chest, barrel, hopper or shulker.");
	}

	/** A totem that empties priced drops out of your inventory as you play. */
	static ItemStack autoSellTotem(ItemStack base) {
		ItemStack stack = marked(base, "Auto-Sell Totem", TOTEM_HINT, "Hotbar and armour are never touched.");
		return stack;
	}

	/** A pouch that sells everything sellable in the player's inventory. */
	static ItemStack sellPouch(ItemStack base) {
		return marked(base, "Sell Pouch", POUCH_HINT, "A portable /sell all, in your hand.");
	}

	private static ItemStack marked(ItemStack base, String name, String hint, String promise) {
		ItemStack stack = base.copy();
		stack.set(DataComponents.CUSTOM_NAME, Component.literal(name).withStyle(ChatFormatting.GOLD));
		// Append rather than overwrite: whatever lore the base came with stays.
		List<Component> lines = new ArrayList<>();
		ItemLore lore = stack.get(DataComponents.LORE);
		if (lore != null) {
			lines.addAll(lore.lines());
		}
		lines.add(Component.literal(hint).withStyle(ChatFormatting.YELLOW));
		lines.add(Component.literal(promise).withStyle(ChatFormatting.GRAY));
		stack.set(DataComponents.LORE, new ItemLore(lines));
		return stack;
	}

	static boolean isSellAxe(ItemStack stack) {
		return hasLore(stack, AXE_HINT);
	}

	static boolean isSellPick(ItemStack stack) {
		return hasLore(stack, PICK_HINT);
	}

	static boolean isSellShovel(ItemStack stack) {
		return hasLore(stack, SHOVEL_HINT);
	}

	static boolean isSellWand(ItemStack stack) {
		return hasLore(stack, WAND_HINT);
	}

	static boolean isAutoSellTotem(ItemStack stack) {
		return hasLore(stack, TOTEM_HINT);
	}

	static boolean isSellPouch(ItemStack stack) {
		return hasLore(stack, POUCH_HINT);
	}

	/** True for any of the liquidation tools, used by the sell-everything guard. */
	static boolean isAnySellTool(ItemStack stack) {
		return isSellAxe(stack) || isSellPick(stack) || isSellShovel(stack)
			|| isSellWand(stack) || isAutoSellTotem(stack) || isSellPouch(stack);
	}

	private static boolean hasLore(ItemStack stack, String line) {
		if (stack == null || stack.isEmpty()) {
			return false;
		}
		ItemLore lore = stack.get(DataComponents.LORE);
		if (lore == null) {
			return false;
		}
		for (Component component : lore.lines()) {
			if (line.equals(component.getString())) {
				return true;
			}
		}
		return false;
	}

	/** How much durability one liquidation costs; zero when configured free. */
	private static int durabilityCost() {
		return Math.max(0, Config.getInt("selltools.durability_cost"));
	}

	/** Wears the tool down, and reports whether it broke doing so. */
	private static boolean wear(ServerPlayer player, ItemStack tool) {
		int cost = durabilityCost();
		if (cost <= 0 || tool.isEmpty()) {
			return false;
		}
		int before = tool.getCount();
		tool.hurtAndBreak(cost, player, InteractionHand.MAIN_HAND);
		// A tool that reaches zero durability is removed from the stack by the
		// game; the count dropping is how the caller learns it snapped.
		return tool.isEmpty() || tool.getCount() < before || tool.getDamageValue() >= tool.getMaxDamage();
	}

	/**
	 * Sells the box's contents when the right tool meets the right box.
	 *
	 * <p>Called from {@code PlayerBlockBreakEvents.BEFORE}, where a false
	 * return cancels the break. A match always cancels - the tool's whole
	 * promise is that the box never breaks in its hands - but only a sale
	 * talks: whacking an already-empty box does nothing and says nothing, so
	 * holding the button down (which re-fires the attempt) cannot flood chat.
	 *
	 * @return true when the break must be cancelled (the box stays put)
	 */
	static boolean liquidateOnMine(ServerPlayer player, BlockState state, BlockEntity blockEntity) {
		ItemStack held = player.getMainHandItem();
		String box;
		if (isSellAxe(held) && state.getBlock() instanceof ChestBlock) {
			box = "chest";
		} else if (isSellPick(held) && state.getBlock() instanceof ShulkerBoxBlock) {
			box = "shulker box";
		} else if (isSellShovel(held) && state.getBlock() instanceof BarrelBlock) {
			box = "barrel";
		} else {
			return false; // wrong tool or wrong box: break as usual
		}
		if (!(blockEntity instanceof Container container)) {
			return false; // no inventory to sell (ender chests have none)
		}
		if (liquidate(player, container, box)) {
			if (wear(player, held)) {
				player.sendSystemMessage(Component.literal("Your " + box + " seller broke."));
			}
		}
		// A match always keeps the box, sale or not - that is the tool's promise.
		return true;
	}

	/**
	 * The Sell Wand's version of the above: no mining, so no break to cancel.
	 * Right-click any container and its priced contents are sold from where
	 * the player stands.
	 *
	 * @return true when the wand was aimed at something it can sell
	 */
	static boolean liquidateWithWand(ServerPlayer player, Container container, String box) {
		ItemStack held = player.getMainHandItem();
		if (!isSellWand(held)) {
			return false;
		}
		liquidate(player, container, box);
		if (wear(player, held)) {
			player.sendSystemMessage(Component.literal("Your Sell Wand broke."));
		}
		return true;
	}

	/**
	 * Prices everything in the container; only once the money is banked are
	 * the stacks removed. Emptying a container slot never shifts the other
	 * slots, so the recorded indices stay valid for the second pass.
	 *
	 * @return true when something was actually sold
	 */
	private static boolean liquidate(ServerPlayer player, Container container, String box) {
		long total = 0;
		long units = 0;
		long kept = 0;
		List<Integer> sellSlots = new ArrayList<>();
		for (int slot = 0; slot < container.getContainerSize(); slot++) {
			ItemStack stack = container.getItem(slot);
			if (stack.isEmpty()) {
				continue;
			}
			Long worth = ShopValues.sellPrice(stack);
			if (worth == null || worth <= 0 || TrimKits.isProtected(stack)) {
				kept += stack.getCount();
				continue;
			}
			try {
				long stackWorth = Math.multiplyExact(worth, (long) stack.getCount());
				total = Math.addExact(total, stackWorth);
			} catch (ArithmeticException exception) {
				kept += stack.getCount();
				continue;
			}
			units += stack.getCount();
			sellSlots.add(slot);
		}

		if (total > 0) {
			if (!MarketData.credit(player.getUUID(), total, player.level().registryAccess())) {
				player.sendSystemMessage(Component.literal(
					"Your balance could not be updated - nothing was sold and the "
						+ box + " is untouched."));
				return false;
			}
			for (int slot : sellSlots) {
				container.removeItem(slot, container.getItem(slot).getCount());
			}
			PlayerStats.recordItemsSold(player.getUUID(), units);
			Ledger.record(player.getUUID(), total, "sell-" + box, units + " item(s)");
			player.sendSystemMessage(Component.literal(
				"Sold " + TrimKits.formatAmount(units) + " item(s) from the " + box
					+ " for $" + TrimKits.formatAmount(total) + "."));
			if (kept > 0) {
				player.sendSystemMessage(Component.literal(
					"Left " + TrimKits.formatAmount(kept)
						+ " item(s) inside - renamed keepsakes or not sold by the shop."));
			}
		}
		return total > 0;
	}

	/**
	 * The auto-sell totem's sweep. Runs on a timer for anyone carrying one:
	 * every priced, unprotected stack outside the hotbar is sold and vanishes,
	 * while gear, tools and anything renamed stay exactly where it is. The
	 * hotbar is sacred - a player mid-fight should never find their sword sold
	 * out from under them by a stray cobble in slot ten.
	 *
	 * @return the dollar amount sold, zero when there was nothing to do
	 */
	static long sweepInventory(ServerPlayer player) {
		if (!Config.getBoolean("economy.auto_sell_totem_enabled")) {
			return 0;
		}
		boolean present = false;
		var inventory = player.getInventory();
		for (int slot = 0; slot < inventory.getContainerSize(); slot++) {
			if (isAutoSellTotem(inventory.getItem(slot))) {
				present = true;
				break;
			}
		}
		if (!present) {
			return 0;
		}
		long total = 0;
		int units = 0;
		// Slots 9..36 are the main inventory: below the hotbar, above armour.
		for (int slot = HOTBAR_SLOTS; slot < inventory.getContainerSize(); slot++) {
			ItemStack stack = inventory.getItem(slot);
			if (stack.isEmpty() || TrimKits.isProtected(stack)) {
				continue;
			}
			Long worth = ShopValues.sellPrice(stack);
			if (worth == null || worth <= 0) {
				continue;
			}
			try {
				total = Math.addExact(total, Math.multiplyExact(worth, (long) stack.getCount()));
			} catch (ArithmeticException exception) {
				continue;
			}
			units += stack.getCount();
			inventory.setItem(slot, ItemStack.EMPTY);
		}
		if (total <= 0) {
			return 0;
		}
		if (!MarketData.credit(player.getUUID(), total, player.level().registryAccess())) {
			// The stacks are already gone; pay what is owed and say so loudly
			// rather than pretend the sweep never happened.
			player.sendSystemMessage(Component.literal(
				"Auto-sell could not save your balance - report this, $" 
					+ TrimKits.formatAmount(total) + " may be missing."));
			return 0;
		}
		PlayerStats.recordItemsSold(player.getUUID(), units);
		Ledger.record(player.getUUID(), total, "sell-auto", units + " item(s)");
		player.sendSystemMessage(Component.literal(
			"Auto-sold " + TrimKits.formatAmount(units) + " item(s) for $"
				+ TrimKits.formatAmount(total) + "."));
		syncInventory(player);
		return total;
	}

	/**
	 * The Sell Pouch's effect: a one-shot "sell everything sellable I am
	 * carrying". Unlike the totem this takes the whole inventory including the
	 * hotbar, because the player asked for it deliberately - but it still
	 * respects the protection rules, so a renamed keepsake is never touched.
	 *
	 * @return the dollar amount sold, zero when there was nothing to do
	 */
	static long liquidateInventory(ServerPlayer player) {
		var inventory = player.getInventory();
		long total = 0;
		int units = 0;
		for (int slot = 0; slot < inventory.getContainerSize(); slot++) {
			ItemStack stack = inventory.getItem(slot);
			// The pouch never sells itself, or another sell tool.
			if (stack.isEmpty() || isAnySellTool(stack) || TrimKits.isProtected(stack)) {
				continue;
			}
			Long worth = ShopValues.sellPrice(stack);
			if (worth == null || worth <= 0) {
				continue;
			}
			try {
				total = Math.addExact(total, Math.multiplyExact(worth, (long) stack.getCount()));
			} catch (ArithmeticException exception) {
				continue;
			}
			units += stack.getCount();
			inventory.setItem(slot, ItemStack.EMPTY);
		}
		if (total <= 0) {
			return 0;
		}
		if (!MarketData.credit(player.getUUID(), total, player.level().registryAccess())) {
			player.sendSystemMessage(Component.literal(
				"Your balance could not be updated - nothing was sold."));
			return 0;
		}
		PlayerStats.recordItemsSold(player.getUUID(), units);
		Ledger.record(player.getUUID(), total, "sell-pouch", units + " item(s)");
		syncInventory(player);
		return total;
	}

	/** How often the totem sweep runs, for the tick handler to schedule on. */
	static int totemIntervalTicks() {
		return TOTEM_INTERVAL_TICKS;
	}

	/** Pushes a changed inventory back to the client. */
	private static void syncInventory(ServerPlayer player) {
		player.inventoryMenu.broadcastChanges();
	}
}
