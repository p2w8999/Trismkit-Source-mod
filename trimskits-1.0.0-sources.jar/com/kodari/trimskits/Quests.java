package com.kodari.trimskits;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Daily and weekly quests: kill, mine, sell or play for a shard reward.
 *
 * <p>Progress is event-driven - the same hooks that feed the stats sidebar
 * push it here - so a quest measures what you did <em>this</em> period, not a
 * lifetime total. Each period has a key (the day number, or the ISO week);
 * when it rolls over, every player's progress and claims for that period are
 * simply forgotten, and the fresh quests start again. Nothing needs a
 * midnight job: the key is computed on read.
 *
 * <p>Rewards are shards, paid through {@link Shards#adminGive} so they sit on
 * top of earned shards rather than inside them, and the /shards breakdown
 * keeps calling them a bonus - which is exactly what a quest payout is.
 */
final class Quests {
	private static final Logger LOGGER = LoggerFactory.getLogger("trimskits");
	private static final Path DATA_FILE = Path.of("config", "trimskits-quests.properties");

	/** What a quest counts. */
	enum Goal { MOB_KILLS, PLAYER_KILLS, BLOCKS, ITEMS_SOLD, PLAYTIME_MINUTES }

	/** How often a quest resets. */
	enum Period { DAILY, WEEKLY }

	/** One quest: what to do, how much, and what it pays. */
	record Quest(String id, String description, Period period, Goal goal, long target, long shards) {
	}

	/** The catalogue. Long enough to give every kind of player something. */
	static final List<Quest> QUESTS = List.of(
		new Quest("mob10", "Kill 10 mobs", Period.DAILY, Goal.MOB_KILLS, 10, 20),
		new Quest("mob50", "Kill 50 mobs", Period.WEEKLY, Goal.MOB_KILLS, 50, 150),
		new Quest("pvp1", "Kill a player", Period.DAILY, Goal.PLAYER_KILLS, 1, 40),
		new Quest("pvp5", "Kill 5 players", Period.WEEKLY, Goal.PLAYER_KILLS, 5, 250),
		new Quest("mine250", "Mine 250 blocks", Period.DAILY, Goal.BLOCKS, 250, 25),
		new Quest("mine2000", "Mine 2,000 blocks", Period.WEEKLY, Goal.BLOCKS, 2000, 180),
		new Quest("sell500", "Sell 500 items", Period.DAILY, Goal.ITEMS_SOLD, 500, 35),
		new Quest("sell5000", "Sell 5,000 items", Period.WEEKLY, Goal.ITEMS_SOLD, 5000, 300),
		new Quest("play60", "Play for 60 minutes", Period.DAILY, Goal.PLAYTIME_MINUTES, 60, 30),
		new Quest("play600", "Play for 10 hours", Period.WEEKLY, Goal.PLAYTIME_MINUTES, 600, 220)
	);

	/** UUID -> quest id -> progress, for the current period of each quest. */
	private static final Map<UUID, Map<String, Long>> PROGRESS = new HashMap<>();
	/** UUID -> the period key each quest's progress belongs to. */
	private static final Map<UUID, Map<String, String>> PERIODS = new HashMap<>();
	/** UUID -> quest ids already claimed this period. */
	private static final Map<UUID, List<String>> CLAIMED = new HashMap<>();
	private static boolean loaded;
	private static boolean readable = true;

	private Quests() {
	}

	/** The day number, so a daily quest knows which day it is counting. */
	static String dailyKey() {
		return "d" + LocalDate.now().toEpochDay();
	}

	/** The ISO week, so a weekly quest resets once a week. */
	static String weeklyKey() {
		LocalDate today = LocalDate.now();
		return "w" + today.getYear() + "-" + today.getDayOfWeek() + "-" + today.getDayOfYear() / 7;
	}

	/** The key for a quest's period type. */
	static String keyFor(Period period) {
		return period == Period.DAILY ? dailyKey() : weeklyKey();
	}

	/** Every quest of one period type, for the /quests view. */
	static List<Quest> questsOf(Period period) {
		return QUESTS.stream().filter(quest -> quest.period() == period).toList();
	}

	/** How far a player is on one quest, in this quest's current period. */
	static long progressOf(UUID playerId, Quest quest) {
		load();
		Map<String, Long> byQuest = PROGRESS.get(playerId);
		Map<String, String> byPeriod = PERIODS.get(playerId);
		if (byQuest == null || byPeriod == null
			|| !keyFor(quest.period()).equals(byPeriod.get(quest.id()))) {
			return 0; // a fresh period, or never seen
		}
		return byQuest.getOrDefault(quest.id(), 0L);
	}

	/** True once a quest has been claimed in its current period. */
	static boolean claimed(UUID playerId, Quest quest) {
		load();
		List<String> claimed = CLAIMED.get(playerId);
		if (claimed == null) {
			return false;
		}
		String key = keyFor(quest.period());
		// Claim entries carry their period so last week's claim cannot survive
		// into this week under the same quest id.
		return claimed.contains(quest.id() + "|" + key);
	}

	/** True when a quest is done but not yet claimed. */
	static boolean claimable(UUID playerId, Quest quest) {
		return progressOf(playerId, quest) >= quest.target() && !claimed(playerId, quest);
	}

	/**
	 * Claims a finished quest, paying its shards once.
	 *
	 * @return null on success, or the reason it did not happen
	 */
	static synchronized String claim(UUID playerId, Quest quest) {
		load();
		if (claimed(playerId, quest)) {
			return "You already claimed that quest this " + (quest.period() == Period.DAILY ? "day" : "week") + ".";
		}
		if (progressOf(playerId, quest) < quest.target()) {
			return "That quest is not finished yet.";
		}
		String error = Shards.adminGive(playerId, quest.shards());
		if (error != null) {
			return error;
		}
		CLAIMED.computeIfAbsent(playerId, ignored -> new ArrayList<>())
			.add(quest.id() + "|" + keyFor(quest.period()));
		save();
		return null;
	}

	// ---- Progress hooks -----------------------------------------------------

	/** Pushes one unit of progress onto every matching unfinished quest. */
	private static synchronized void bump(UUID playerId, Goal goal, long amount) {
		if (amount <= 0) {
			return;
		}
		load();
		for (Quest quest : QUESTS) {
			if (quest.goal() != goal || claimed(playerId, quest)) {
				continue;
			}
			String key = keyFor(quest.period());
			Map<String, String> byPeriod = PERIODS.computeIfAbsent(playerId, ignored -> new HashMap<>());
			if (!key.equals(byPeriod.get(quest.id()))) {
				// A new period for this quest: start its progress from zero.
				byPeriod.put(quest.id(), key);
				PROGRESS.computeIfAbsent(playerId, ignored -> new HashMap<>()).put(quest.id(), 0L);
			}
			Map<String, Long> byQuest = PROGRESS.computeIfAbsent(playerId, ignored -> new HashMap<>());
			long now = byQuest.getOrDefault(quest.id(), 0L);
			// Cap at the target: the number shown never overflows the goal, and
			// a later buff cannot push progress past what the quest asks.
			byQuest.put(quest.id(), Math.min(quest.target(), now + amount));
		}
		save();
	}

	static void recordMobKill(UUID playerId) {
		bump(playerId, Goal.MOB_KILLS, 1);
	}

	static void recordKill(UUID playerId) {
		bump(playerId, Goal.PLAYER_KILLS, 1);
	}

	static void recordBlock(UUID playerId) {
		bump(playerId, Goal.BLOCKS, 1);
	}

	static void recordSold(UUID playerId, long count) {
		bump(playerId, Goal.ITEMS_SOLD, count);
	}

	static void recordPlaytime(UUID playerId, long seconds) {
		bump(playerId, Goal.PLAYTIME_MINUTES, Math.max(0, seconds) / 60);
	}

	// ---- Persistence --------------------------------------------------------

	private static void load() {
		if (loaded) {
			return;
		}
		loaded = true;
		if (!Files.exists(DATA_FILE)) {
			return;
		}
		Properties properties = new Properties();
		try (InputStream input = Files.newInputStream(DATA_FILE)) {
			properties.load(input);
		} catch (IOException exception) {
			readable = false;
			LOGGER.warn("Could not read {}; quests stay in memory only.", DATA_FILE);
			return;
		}
		for (String key : properties.stringPropertyNames()) {
			try {
				String value = properties.getProperty(key);
				if (key.startsWith("progress.")) {
					// progress.<uuid>.<questId> = periodKey|amount
					String[] parts = key.split("\\.", 3);
					if (parts.length != 3) {
						continue;
					}
					UUID playerId = UUID.fromString(parts[1]);
					String[] fields = value.split("\\|", -1);
					if (fields.length != 2) {
						continue;
					}
					PERIODS.computeIfAbsent(playerId, ignored -> new HashMap<>())
						.put(parts[2], fields[0]);
					PROGRESS.computeIfAbsent(playerId, ignored -> new HashMap<>())
						.put(parts[2], Long.parseLong(fields[1]));
				} else if (key.startsWith("claimed.")) {
					// claimed.<uuid> = id|key,id|key,...
					UUID playerId = UUID.fromString(key.substring("claimed.".length()));
					List<String> list = new ArrayList<>();
					for (String entry : value.split(",")) {
						if (!entry.isBlank()) {
							list.add(entry);
						}
					}
					CLAIMED.put(playerId, list);
				}
			} catch (RuntimeException ignored) {
				// Skip a damaged line.
			}
		}
	}

	private static boolean save() {
		if (!readable) {
			return false;
		}
		Properties properties = new Properties();
		for (Map.Entry<UUID, Map<String, Long>> player : PROGRESS.entrySet()) {
			Map<String, String> periods = PERIODS.getOrDefault(player.getKey(), Map.of());
			for (Map.Entry<String, Long> quest : player.getValue().entrySet()) {
				String period = periods.get(quest.getKey());
				if (period != null) {
					properties.setProperty("progress." + player.getKey() + "." + quest.getKey(),
						period + "|" + quest.getValue());
				}
			}
		}
		CLAIMED.forEach((playerId, list) ->
			properties.setProperty("claimed." + playerId, String.join(",", list)));
		Path temporaryFile = DATA_FILE.resolveSibling("trimskits-quests.tmp");
		try {
			Files.createDirectories(DATA_FILE.getParent());
			try (OutputStream output = Files.newOutputStream(temporaryFile)) {
				properties.store(output, "Trim Kits quests");
			}
			try {
				Files.move(temporaryFile, DATA_FILE, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
			} catch (AtomicMoveNotSupportedException exception) {
				Files.move(temporaryFile, DATA_FILE, StandardCopyOption.REPLACE_EXISTING);
			}
			return true;
		} catch (IOException exception) {
			LOGGER.warn("Could not save quests: {}", exception.getMessage());
			return false;
		}
	}
}
