package com.kodari.trimskits;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.numbers.BlankFormat;
import net.minecraft.network.protocol.game.ClientboundSetDisplayObjectivePacket;
import net.minecraft.network.protocol.game.ClientboundSetObjectivePacket;
import net.minecraft.network.protocol.game.ClientboundSetScorePacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.scores.DisplaySlot;
import net.minecraft.world.scores.Objective;
import net.minecraft.world.scores.Scoreboard;
import net.minecraft.world.scores.criteria.ObjectiveCriteria;

/**
 * Donut-SMP style sidebar for every player.
 *
 * The vanilla scoreboard is shared by the whole server, so per-player data
 * (like each player's own balance) is sent with direct packets instead:
 * one objective, a display slot and a score per line, all in the client's
 * per-connection scoreboard. Numbers are hidden with a blank number format.
 */
final class StatsSidebar {
	private static final String OBJECTIVE = "trimskits";
	/**
	 * Exactly the client's 15-line ceiling. The sidebar used to sit at 14 to
	 * leave headroom, but Shards earned its own line, so any future stat has
	 * to displace one of these rather than be added.
	 */
	private static final int LINE_COUNT = 15;
	/** Shared scoreboard, only used as the Objective parent (never ticked). */
	private static final Scoreboard DUMMY = new Scoreboard();

	record Line(String holder, Component text) {}
	record Entry(Objective objective, Line[] lines) {}

	/**
	 * Title, a spacer, then one line per stat. The holder names are fixed
	 * because the client scoreboard is per-connection.
	 */
	private static final Line[] LAYOUT = {
		new Line("tk0", Component.literal(" ").withStyle(ChatFormatting.WHITE)),
		new Line("tk1", Component.literal("Balance").withStyle(ChatFormatting.GOLD)),
		new Line("tk2", Component.literal("Shards").withStyle(ChatFormatting.LIGHT_PURPLE)),
		new Line("tk3", Component.literal("Rank").withStyle(ChatFormatting.LIGHT_PURPLE)),
		new Line("tk4", Component.literal("Mob Crystal").withStyle(ChatFormatting.DARK_AQUA)),
		new Line("tk5", Component.literal("PvP Crystal").withStyle(ChatFormatting.AQUA)),
		new Line("tk6", Component.literal("Kills").withStyle(ChatFormatting.RED)),
		new Line("tk7", Component.literal("Mob kills").withStyle(ChatFormatting.RED)),
		new Line("tk8", Component.literal("Deaths").withStyle(ChatFormatting.DARK_GRAY)),
		new Line("tk9", Component.literal("K/D").withStyle(ChatFormatting.AQUA)),
		new Line("tk10", Component.literal("Blocks").withStyle(ChatFormatting.GREEN)),
		new Line("tk11", Component.literal("Sold").withStyle(ChatFormatting.GREEN)),
		new Line("tk12", Component.literal("Playtime").withStyle(ChatFormatting.BLUE)),
		new Line("tk13", Component.literal("Online").withStyle(ChatFormatting.WHITE)),
		new Line("tk14", Component.literal(" ").withStyle(ChatFormatting.WHITE)),
	};

	private final Map<UUID, Entry> entries = new HashMap<>();

	void refresh(MinecraftServer server) {
		MarketData.initialize(server.registryAccess());
		for (ServerPlayer player : server.getPlayerList().getPlayers()) {
			UUID id = player.getUUID();
			Entry entry = entries.get(id);
			if (entry == null) {
				entry = create();
				entries.put(id, entry);
				player.connection.send(new ClientboundSetObjectivePacket(entry.objective(), 0));
			}
			player.connection.send(new ClientboundSetDisplayObjectivePacket(DisplaySlot.SIDEBAR, entry.objective()));

			long playtime = PlayerStats.playtimeSeconds(id);
			ChatFormatting rankColour = RankShop.colourOf(id, playtime);
			long kills = PlayerStats.kills(id);
			long deaths = PlayerStats.deaths(id);

			Component[] values = {
				Component.empty(),
				Component.literal("$" + TrimKits.formatAmount(MarketData.balance(id)))
					.withStyle(ChatFormatting.GOLD),
				Component.literal(TrimKits.formatAmount(Shards.balance(id)))
					.withStyle(ChatFormatting.LIGHT_PURPLE),
				Component.literal(RankShop.nameOf(id, playtime)).withStyle(rankColour),
				Component.literal(CombatRanks.nameOf(CombatRanks.Ladder.MOB, id))
					.withStyle(CombatRanks.colourOf(CombatRanks.Ladder.MOB, id)),
				Component.literal(CombatRanks.nameOf(CombatRanks.Ladder.PVP, id))
					.withStyle(CombatRanks.colourOf(CombatRanks.Ladder.PVP, id)),
				Component.literal(TrimKits.formatAmount(kills)).withStyle(ChatFormatting.RED),
				Component.literal(TrimKits.formatAmount(PlayerStats.mobKills(id)))
					.withStyle(ChatFormatting.RED),
				Component.literal(TrimKits.formatAmount(deaths)).withStyle(ChatFormatting.GRAY),
				Component.literal(TrimKits.ratio(kills, deaths)).withStyle(ChatFormatting.AQUA),
				Component.literal(TrimKits.formatAmount(PlayerStats.blocksBroken(id)))
					.withStyle(ChatFormatting.GREEN),
				Component.literal(TrimKits.formatAmount(PlayerStats.itemsSold(id)))
					.withStyle(ChatFormatting.GREEN),
				Component.literal(PlayerStats.playtimeText(id)).withStyle(ChatFormatting.BLUE),
				Component.literal(TrimKits.formatAmount(server.getPlayerCount()))
					.withStyle(ChatFormatting.WHITE),
				Component.empty(),
			};

			Line[] lines = entry.lines();
			for (int i = 0; i < lines.length; i++) {
				player.connection.send(new ClientboundSetScorePacket(
					lines[i].holder(), OBJECTIVE, LINE_COUNT - i,
					Optional.of(lines[i].text().copy().append(": ").append(values[i])),
					Optional.of(BlankFormat.INSTANCE)));
			}
		}
	}

	void forget(UUID id) {
		entries.remove(id);
	}

	/** Drops everything for players that left, so rejoining sends a fresh copy. */
	void clear() {
		entries.clear();
	}

	private static Entry create() {
		Objective objective = new Objective(
			DUMMY, OBJECTIVE,
			ObjectiveCriteria.DUMMY,
			Component.literal("TrimKits").withStyle(ChatFormatting.GOLD),
			ObjectiveCriteria.RenderType.INTEGER,
			false,
			BlankFormat.INSTANCE);
		Line[] lines = new Line[LINE_COUNT];
		System.arraycopy(LAYOUT, 0, lines, 0, LINE_COUNT);
		return new Entry(objective, lines);
	}
}
