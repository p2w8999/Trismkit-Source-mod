package com.kodari.trimskits;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

final class AccountAuth {
	private static final Path ACCOUNT_FILE = Path.of("config", "trimskits-accounts.properties");
	private static final int ITERATIONS = 210_000;
	private static final int HASH_BITS = 256;
	private static final SecureRandom RANDOM = new SecureRandom();
	private static final Map<UUID, Credential> ACCOUNTS = new HashMap<>();
	private static final Set<UUID> AUTHENTICATED = new HashSet<>();
	/**
	 * Password hashing runs here so the 210k-iteration PBKDF2 never blocks the
	 * main server thread — that freeze used to make the whole server hiccup
	 * whenever someone ran /register or /login.
	 */
	private static final ExecutorService HASHES = Executors.newSingleThreadExecutor(runnable -> {
		Thread thread = new Thread(runnable, "trimskits-auth");
		thread.setDaemon(true);
		return thread;
	});

	private AccountAuth() {
	}

	static synchronized void initialize() {
		ACCOUNTS.clear();
		AUTHENTICATED.clear();
		if (!Files.exists(ACCOUNT_FILE)) {
			return;
		}

		Properties properties = new Properties();
		try (InputStream input = Files.newInputStream(ACCOUNT_FILE)) {
			properties.load(input);
		} catch (IOException exception) {
			// Do not refuse to start the whole server over an unreadable file;
			// run without stored accounts instead, like the other data stores.
			TrimKits.LOGGER.warn("Could not load the account file, running without stored accounts: {}",
				exception.getMessage());
			return;
		}

		for (String key : properties.stringPropertyNames()) {
			try {
				String[] values = properties.getProperty(key).split(":", 2);
				if (values.length == 2) {
					ACCOUNTS.put(UUID.fromString(key), new Credential(
						Base64.getDecoder().decode(values[0]),
						Base64.getDecoder().decode(values[1])
					));
				}
			} catch (IllegalArgumentException ignored) {
			}
		}
	}

	static synchronized void beginSession(UUID playerId) {
		AUTHENTICATED.remove(playerId);
	}

	/** Drops the login state when a player leaves, so the set cannot grow forever. */
	static synchronized void endSession(UUID playerId) {
		AUTHENTICATED.remove(playerId);
	}

	/**
	 * Removes an account entirely so the player can register again with a fresh
	 * password.
	 *
	 * <p>This is the reset path for accounts that predate the password vault:
	 * those only have a one-way PBKDF2 hash on file, so there is no password to
	 * read back out and no way to change it in place. Deleting the account is
	 * the only way to let the player choose a new one. The hash file is saved
	 * immediately, so the reset survives a restart rather than being undone the
	 * next time anything else writes.
	 *
	 * @return true when an account existed and was removed
	 */
	static synchronized boolean removeAccount(UUID playerId) {
		if (!ACCOUNTS.containsKey(playerId)) {
			return false;
		}
		ACCOUNTS.remove(playerId);
		AUTHENTICATED.remove(playerId);
		try {
			save();
			return true;
		} catch (IOException exception) {
			TrimKits.LOGGER.warn("Could not persist account removal for {}: {}",
				playerId, exception.getMessage());
			// The in-memory removal already happened, so the account is gone for
			// this session either way; the warning flags that it may return
			// after a restart if the file could not be written.
			return true;
		}
	}

	static synchronized boolean isRegistered(UUID playerId) {
		return ACCOUNTS.containsKey(playerId);
	}

	static synchronized boolean isAuthenticated(UUID playerId) {
		return AUTHENTICATED.contains(playerId);
	}

	/**
	 * Creates an account on a background thread. {@code callback} receives the
	 * outcome; the caller is expected to hop back to the server thread (for
	 * example with {@code server.execute}) before touching players.
	 */
	static void registerAsync(UUID playerId, String password, Consumer<Boolean> callback) {
		synchronized (AccountAuth.class) {
			if (ACCOUNTS.containsKey(playerId)) {
				callback.accept(false);
				return;
			}
		}
		HASHES.execute(() -> {
			byte[] salt = new byte[16];
			RANDOM.nextBytes(salt);
			byte[] hash;
			try {
				hash = hash(password, salt);
			} catch (RuntimeException exception) {
				callback.accept(false);
				return;
			}
			boolean ok;
			synchronized (AccountAuth.class) {
				if (ACCOUNTS.containsKey(playerId)) {
					ok = false;
				} else {
					ACCOUNTS.put(playerId, new Credential(salt, hash));
					try {
						save();
						ok = true;
					} catch (IOException exception) {
						ACCOUNTS.remove(playerId);
						ok = false;
					}
				}
				if (ok) {
					AUTHENTICATED.add(playerId);
				}
			}
			callback.accept(ok);
		});
	}

	/** Verifies a password off the main thread; logs the player in on success. */
	static void loginAsync(UUID playerId, String password, Consumer<Boolean> callback) {
		Credential credential;
		synchronized (AccountAuth.class) {
			credential = ACCOUNTS.get(playerId);
		}
		if (credential == null) {
			callback.accept(false);
			return;
		}
		HASHES.execute(() -> {
			boolean ok;
			try {
				ok = MessageDigest.isEqual(credential.hash(), hash(password, credential.salt()));
			} catch (RuntimeException exception) {
				ok = false;
			}
			if (ok) {
				synchronized (AccountAuth.class) {
					AUTHENTICATED.add(playerId);
				}
			}
			callback.accept(ok);
		});
	}

	private static void save() throws IOException {
		Files.createDirectories(ACCOUNT_FILE.getParent());
		Properties properties = new Properties();
		ACCOUNTS.forEach((playerId, credential) -> properties.setProperty(
			playerId.toString(),
			Base64.getEncoder().encodeToString(credential.salt()) + ":" + Base64.getEncoder().encodeToString(credential.hash())
		));
		try (OutputStream output = Files.newOutputStream(ACCOUNT_FILE)) {
			properties.store(output, "Trim Kits account password hashes");
		}
	}

	private static byte[] hash(String password, byte[] salt) {
		PBEKeySpec keySpec = new PBEKeySpec(password.toCharArray(), salt, ITERATIONS, HASH_BITS);
		try {
			return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(keySpec).getEncoded();
		} catch (GeneralSecurityException exception) {
			throw new IllegalStateException("Password hashing is unavailable", exception);
		} finally {
			keySpec.clearPassword();
		}
	}

	private record Credential(byte[] salt, byte[] hash) {
	}
}