package com.kodari.trimskits;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;

/**
 * Interactive GUI for /tabranks.
 *
 * <p>Displays:
 * <ul>
 *   <li>All purchasable/free tabranks with their distinctive color, custom sign and pricing</li>
 *   <li>Active rank indicator</li>
 *   <li>One-click position toggle (Prefix before name vs Suffix after name)</li>
 *   <li>Web Sync refresh button to fetch free grants from GitHub / online web URL</li>
 *   <li>Player balance tracker</li>
 * </ul>
 */
final class TabRanksMenu extends ChestMenu {
	private static final int ROWS = 6;
	private static final int SIZE = ROWS * 9;

	private static final int POSITION_TOGGLE_SLOT = 47;
	private static final int WEB_SYNC_SLOT = 48;
	private static final int BALANCE_SLOT = 49;
	private static final int CLOSE_SLOT = 53;

	private final ServerPlayer owner;

	TabRanksMenu(int containerId, Inventory inventory, ServerPlayer owner) {
		super(MenuType.GENERIC_9x6, containerId, inventory, new SimpleContainer(SIZE), ROWS);
		this.owner = owner;
		build();
	}

	private void build() {
		SimpleContainer container = (SimpleContainer) getContainer();

		// Border panes
		ItemStack borderPane = new ItemStack(Compat.pickItem("STAINED_GLASS_PANE", net.minecraft.world.item.DyeColor.BLUE));
		borderPane.set(DataComponents.CUSTOM_NAME, Component.literal(" "));
		for (int i = 0; i < SIZE; i++) {
			if (i < 9 || i >= 45 || i % 9 == 0 || i % 9 == 8) {
				container.setItem(i, borderPane);
			}
		}

		// Title item in top center
		ItemStack titleItem = new ItemStack(Items.NETHER_STAR);
		TabRanks.RankDef activeRank = TabRanks.getActiveRank(owner.getUUID());
		TabRanks.Position pos = TabRanks.getPosition(owner.getUUID());
		titleItem.set(DataComponents.CUSTOM_NAME,
			Component.literal("§b§lTAB & NAMETAG RANKS").withStyle(ChatFormatting.BOLD));
		titleItem.set(DataComponents.LORE, new ItemLore(List.of(
			Component.literal("§7Your Active Rank: " + activeRank.format() + "[" + activeRank.sign() + " " + activeRank.displayName() + "]"),
			Component.literal("§7Display Placement: §e" + pos.label()),
			Component.literal(""),
			Component.literal("§7Click any rank below to equip or purchase it!")
		)));
		container.setItem(4, titleItem);

		// Grid slots for ranks: row 1 to 3, columns 1 to 7
		List<TabRanks.RankDef> ranks = TabRanks.ranks();
		int slotIndex = 0;
		List<Integer> gridSlots = new ArrayList<>();
		for (int r = 1; r <= 3; r++) {
			for (int c = 1; c <= 7; c++) {
				gridSlots.add(r * 9 + c);
			}
		}

		for (int i = 0; i < gridSlots.size(); i++) {
			int slot = gridSlots.get(i);
			if (i < ranks.size()) {
				TabRanks.RankDef rank = ranks.get(i);
				container.setItem(slot, buildRankIcon(rank));
			} else {
				ItemStack emptyPane = new ItemStack(Compat.pickItem("STAINED_GLASS_PANE", net.minecraft.world.item.DyeColor.GRAY));
				emptyPane.set(DataComponents.CUSTOM_NAME, Component.literal(" "));
				container.setItem(slot, emptyPane);
			}
		}

		// Bottom row controls:
		// 1. Position toggle button (slot 47)
		ItemStack posItem = new ItemStack(pos == TabRanks.Position.PREFIX ? Items.ARROW : Items.SPECTRAL_ARROW);
		posItem.set(DataComponents.CUSTOM_NAME,
			Component.literal("§e§lRank Position: §f" + (pos == TabRanks.Position.PREFIX ? "Before Name" : "After Name")));
		posItem.set(DataComponents.LORE, new ItemLore(List.of(
			Component.literal("§7Current: " + (pos == TabRanks.Position.PREFIX
				? activeRank.format() + "[" + activeRank.sign() + " " + activeRank.displayName() + "] §f" + owner.getScoreboardName()
				: "§f" + owner.getScoreboardName() + " " + activeRank.format() + "[" + activeRank.sign() + " " + activeRank.displayName() + "]")),
			Component.literal(""),
			Component.literal("§eClick to toggle (Prefix ⇄ Suffix)")
		)));
		container.setItem(POSITION_TOGGLE_SLOT, posItem);

		// 2. Web Sync button (slot 48)
		ItemStack webItem = new ItemStack(Items.COMPASS);
		webItem.set(DataComponents.CUSTOM_NAME, Component.literal("§a§lOnline Free Grants (GitHub/Web)"));
		webItem.set(DataComponents.LORE, new ItemLore(List.of(
			Component.literal("§7Get free ranks from GitHub or server web!"),
			Component.literal("§7Status: §f" + TabRanks.getLastWebStatus()),
			Component.literal(""),
			Component.literal("§aClick to re-sync now")
		)));
		container.setItem(WEB_SYNC_SLOT, webItem);

		// 3. Balance indicator (slot 49)
		ItemStack balanceItem = new ItemStack(Items.EMERALD);
		balanceItem.set(DataComponents.CUSTOM_NAME,
			Component.literal("§aYour Balance: §e$" + TrimKits.formatAmount(MarketData.balance(owner.getUUID()))));
		balanceItem.set(DataComponents.LORE, new ItemLore(List.of(
			Component.literal("§7Used to purchase exclusive ranks.")
		)));
		container.setItem(BALANCE_SLOT, balanceItem);

		// 4. Close button (slot 53)
		ItemStack closeItem = new ItemStack(Items.BARRIER);
		closeItem.set(DataComponents.CUSTOM_NAME, Component.literal("§cClose"));
		container.setItem(CLOSE_SLOT, closeItem);
	}

	private ItemStack buildRankIcon(TabRanks.RankDef rank) {
		ItemStack stack = new ItemStack(rank.icon());
		boolean owned = TabRanks.hasRank(owner, rank.id());
		boolean isActive = rank.id().equalsIgnoreCase(TabRanks.getActiveRank(owner.getUUID()).id());

		String statusColor = isActive ? "§a§l[EQUIPPED]" : (owned ? "§b[OWNED]" : "§e[FOR SALE]");
		stack.set(DataComponents.CUSTOM_NAME,
			Component.literal(rank.format() + rank.sign() + " " + rank.displayName() + " " + statusColor));

		List<Component> lore = new ArrayList<>();
		lore.add(Component.literal("§7Sign: " + rank.format() + rank.sign()));
		lore.add(Component.literal("§7Color: " + rank.format() + rank.format().name()));
		lore.add(Component.literal("§7" + rank.description()));
		lore.add(Component.literal(""));

		if (rank.price() <= 0) {
			lore.add(Component.literal("§aPrice: §lFREE"));
		} else {
			lore.add(Component.literal("§7Price: §e$" + TrimKits.formatAmount(rank.price())));
		}

		if (rank.webGrantsEnabled()) {
			lore.add(Component.literal("§dFree grant available online on GitHub / web"));
		}

		lore.add(Component.literal(""));
		if (isActive) {
			lore.add(Component.literal("§a✔ Currently displayed on your nametag & tablist."));
		} else if (owned) {
			lore.add(Component.literal("§bClick to EQUIP this rank!"));
		} else {
			long bal = MarketData.balance(owner.getUUID());
			if (bal >= rank.price()) {
				lore.add(Component.literal("§a§lClick to BUY this rank!"));
			} else {
				lore.add(Component.literal("§cNot enough money (need $" + TrimKits.formatAmount(rank.price()) + ")"));
			}
		}

		stack.set(DataComponents.LORE, new ItemLore(lore));
		return stack;
	}

	@Override
	public boolean stillValid(Player player) {
		return player == owner;
	}

	@Override
	public ItemStack quickMoveStack(Player player, int index) {
		return ItemStack.EMPTY;
	}

	@Override
	public void clicked(int slotId, int buttonNum, ContainerInput containerInput, Player player) {
		if (slotId < 0 || slotId >= SIZE) return;
		if (!(player instanceof ServerPlayer serverPlayer) || serverPlayer != owner) return;

		// Close
		if (slotId == CLOSE_SLOT) {
			serverPlayer.closeContainer();
			return;
		}

		// Toggle position (prefix vs suffix)
		if (slotId == POSITION_TOGGLE_SLOT) {
			TabRanks.togglePosition(serverPlayer.getUUID());
			TabRanks.applyPlayerTab(serverPlayer);
			serverPlayer.sendSystemMessage(Component.literal("§aRank position set to: §e"
				+ TabRanks.getPosition(serverPlayer.getUUID()).label()));
			reopen();
			return;
		}

		// Web sync
		if (slotId == WEB_SYNC_SLOT) {
			MinecraftServer server = serverPlayer.level().getServer();
			serverPlayer.sendSystemMessage(Component.literal("§eChecking online web/GitHub for free rank grants..."));
			TabRanks.syncWebGrants(server).thenAccept(result -> {
				if (server != null) {
					server.execute(() -> {
						serverPlayer.sendSystemMessage(Component.literal("§a[WebSync] " + result));
						if (serverPlayer.containerMenu == this) {
							reopen();
						}
					});
				}
			});
			return;
		}

		// Rank click
		List<Integer> gridSlots = new ArrayList<>();
		for (int r = 1; r <= 3; r++) {
			for (int c = 1; c <= 7; c++) {
				gridSlots.add(r * 9 + c);
			}
		}

		int rankIdx = gridSlots.indexOf(slotId);
		if (rankIdx >= 0 && rankIdx < TabRanks.ranks().size()) {
			TabRanks.RankDef rank = TabRanks.ranks().get(rankIdx);
			boolean owned = TabRanks.hasRank(serverPlayer, rank.id());
			if (owned) {
				TabRanks.setActiveRank(serverPlayer.getUUID(), rank.id());
				TabRanks.applyPlayerTab(serverPlayer);
				serverPlayer.sendSystemMessage(Component.literal("§aEquipped rank: " + rank.format() + rank.sign() + " " + rank.displayName() + "§r!"));
				reopen();
			} else {
				String problem = TabRanks.purchase(serverPlayer, rank.id(), serverPlayer.level().registryAccess());
				if (problem != null) {
					serverPlayer.sendSystemMessage(Component.literal("§c" + problem));
				} else {
					serverPlayer.sendSystemMessage(Component.literal("§aSuccessfully purchased and equipped: "
						+ rank.format() + rank.sign() + " " + rank.displayName() + "§r!"));
					reopen();
				}
			}
		}
	}

	private void reopen() {
		owner.openMenu(new SimpleMenuProvider(
			(containerId, inventory, viewer) -> new TabRanksMenu(containerId, inventory, owner),
			Component.literal("Tab & Nametag Ranks")
		));
	}
}
