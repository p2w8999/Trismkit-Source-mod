package com.kodari.trimskits;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * A short memory of what the shop's market has been doing.
 *
 * <p>The market drifts every minute and a quarter of the catalogue re-rolls
 * each time, so no single reading means anything. What a trader actually
 * wants is the trend: has the shop been paying more or less over the last few
 * hours, and is this a good moment to sell. This samples the average market
 * factor on a slow timer and keeps the last {@link #MAX_SAMPLES} readings,
 * each stamped with the wall-clock moment it was taken.
 *
 * <p>A sample is one number - the mean multiplier across the whole catalogue -
 * so the file stays tiny however long the server runs, and a restart simply
 * resumes the line where it left off. It is only ever read for display; nothing
 * in the economy depends on it, so a lost or damaged history costs nothing but
 * the chart.
 */
final class PriceHistory {
	private static final Logger LOGGER = LoggerFactory.getLogger("trimskits");
	private static final Path DATA_FILE = Path.of("config", "trimskits-pricehistory.properties");

	/** How many samples to keep - a day of hourly readings, roughly. */
	private static final int MAX_SAMPLES = 24;

	/** One reading: the moment it was taken, and the mean market factor. */
	record Sample(long epochSeconds, double averageFactor) {
	}

	private static final List<Sample> SAMPLES = new ArrayList<>();
	private static boolean loaded;
	private static boolean readable = true;

	private PriceHistory() {
	}

	/** The readings, oldest first. */
	static synchronized List<Sample> samples() {
		load();
		return List.copyOf(SAMPLES);
	}

	/**
	 * Records the current average market factor. Called from the market's tick
	 * on an hourly boundary, so the chart shows the shape of the day rather
	 * than the noise of every minute.
	 */
	static synchronized void record(double averageFactor) {
		load();
		SAMPLES.add(new Sample(Instant.now().getEpochSecond(), averageFactor));
		while (SAMPLES.size() > MAX_SAMPLES) {
			SAMPLES.remove(0);
		}
		save();
	}

	/**
	 * A one-line verdict on the last stretch of readings, written for a player
	 * deciding whether to sell now: rising, falling, or steady. With fewer
	 * than two samples there is nothing to compare, so it says so.
	 */
	static synchronized String trend() {
		load();
		if (SAMPLES.size() < 2) {
			return "Not enough readings yet - check back once the market has had a chance to move.";
		}
		Sample oldest = SAMPLES.get(0);
		Sample newest = SAMPLES.get(SAMPLES.size() - 1);
		double change = newest.averageFactor() - oldest.averageFactor();
		double percent = oldest.averageFactor() == 0 ? 0 : change / oldest.averageFactor() * 100.0;
		String direction;
		if (percent > 3.0) {
			direction = "Rising - the shop is paying more than it was; a good time to sell.";
		} else if (percent < -3.0) {
			direction = "Falling - the shop is paying less than it was; hold off if you can.";
		} else {
			direction = "Steady - prices are about where they were.";
		}
		return direction + " (" + (percent >= 0 ? "+" : "") + String.format("%.1f", percent)
			+ "% over " + SAMPLES.size() + " readings).";
	}

	// ---- Persistence --------------------------------------------------------

	private static void load() {
		if (loaded) {
			return;
		}
		loaded = true;
		if (!Files.exists(DATA_FILE)) {
			return;
		}
		Properties properties = new Properties();
		try (InputStream input = Files.newInputStream(DATA_FILE)) {
			properties.load(input);
		} catch (IOException exception) {
			readable = false;
			LOGGER.warn("Could not read {}; price history stays in memory only.", DATA_FILE);
			return;
		}
		for (String key : properties.stringPropertyNames()) {
			if (!key.startsWith("sample.")) {
				continue;
			}
			try {
				// index = epochSeconds|factor, so the file keeps its order and
				// a restart resumes the same line.
				String[] fields = properties.getProperty(key).split("\\|", -1);
				if (fields.length == 2) {
					SAMPLES.add(new Sample(Long.parseLong(fields[0]), Double.parseDouble(fields[1])));
				}
			} catch (RuntimeException ignored) {
				// Skip a damaged line.
			}
		}
		SAMPLES.sort((left, right) -> Long.compare(left.epochSeconds(), right.epochSeconds()));
	}

	private static boolean save() {
		if (!readable) {
			return false;
		}
		Properties properties = new Properties();
		for (int index = 0; index < SAMPLES.size(); index++) {
			Sample sample = SAMPLES.get(index);
			properties.setProperty("sample." + index,
				sample.epochSeconds() + "|" + sample.averageFactor());
		}
		Path temporaryFile = DATA_FILE.resolveSibling("trimskits-pricehistory.tmp");
		try {
			Files.createDirectories(DATA_FILE.getParent());
			try (OutputStream output = Files.newOutputStream(temporaryFile)) {
				properties.store(output, "Trim Kits price history");
			}
			try {
				Files.move(temporaryFile, DATA_FILE, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
			} catch (AtomicMoveNotSupportedException exception) {
				Files.move(temporaryFile, DATA_FILE, StandardCopyOption.REPLACE_EXISTING);
			}
			return true;
		} catch (IOException exception) {
			LOGGER.warn("Could not save price history: {}", exception.getMessage());
			return false;
		}
	}
}
