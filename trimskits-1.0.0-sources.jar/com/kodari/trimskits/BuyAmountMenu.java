package com.kodari.trimskits;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;

/**
 * "How many do you want?" screen behind {@code /buy}.
 *
 * <p>Nothing here ever costs a click you cannot undo: the quantity is clamped
 * to what your balance covers, the total is shown next to your balance at all
 * times, and nothing is charged until the buy button is pressed. A full stack
 * is one click away, and "max affordable" is one more.
 *
 * <p>The screen stays open after a purchase so several orders can be placed in
 * a row without walking back through the shop.
 */
final class BuyAmountMenu extends ChestMenu {
	private static final int ROWS = 6;
	private static final int SIZE = ROWS * 9;
	/** First slot of the bottom control row. */
	private static final int BAR = (ROWS - 1) * 9;

	/** Hard ceiling on a single order, so the price multiplication stays sane. */
	private static final int MAX_QUANTITY = 1_000_000;

	private static final int SLOT_ITEM = 4;
	private static final int SLOT_TOTAL = 13;

	/** Quick-set buttons; -1 means "as many as I can afford". */
	private static final int[] QUICK_SLOTS = {19, 20, 21, 22, 23, 24, 25};
	private static final int[] QUICK_AMOUNTS = {1, 8, 16, 64, 256, 1000, -1};

	private static final int SLOT_MINUS_64 = 29;
	private static final int SLOT_MINUS_16 = 30;
	private static final int SLOT_MINUS_1 = 31;
	private static final int SLOT_PLUS_1 = 32;
	private static final int SLOT_PLUS_16 = 33;
	private static final int SLOT_PLUS_64 = 34;

	private static final int SLOT_BALANCE = 40;

	private static final int SLOT_BACK = BAR + 0;
	private static final int SLOT_SEARCH = BAR + 1;
	/** Opens the enchantment picker: "buy it, but enchanted". */
	private static final int SLOT_ENCHANT = BAR + 2;
	private static final int SLOT_BUY = BAR + 4;
	private static final int SLOT_CLOSE = BAR + 8;

	private static final Item PANE = Compat.pickItem("STAINED_GLASS_PANE", DyeColor.CYAN);

	private final ServerPlayer owner;
	private final ShopValues.Entry entry;
	private final SimpleContainer container;
	/** Chosen enchantments, applied to every item; shared with the picker. */
	private final List<EnchantOffer> enchants;
	/** What this item could take; the registry scan runs once per menu. */
	private List<EnchantOffer> availableEnchants;

	private int quantity = 1;

	BuyAmountMenu(int containerId, Inventory inventory, ServerPlayer owner, ShopValues.Entry entry) {
		this(containerId, inventory, owner, entry, new ArrayList<>());
	}

	BuyAmountMenu(int containerId, Inventory inventory, ServerPlayer owner, ShopValues.Entry entry,
			List<EnchantOffer> enchants) {
		super(MenuType.GENERIC_9x6, containerId, inventory, new SimpleContainer(SIZE), ROWS);
		this.owner = owner;
		this.entry = entry;
		this.enchants = enchants;
		this.container = (SimpleContainer) getContainer();
		render();
	}

	private String itemName() {
		return entry.name();
	}

	/** Extra cost the chosen enchantments add to every item in the order. */
	private long enchantSurcharge() {
		long sum = 0;
		for (EnchantOffer offer : enchants) {
			sum += offer.price();
		}
		return sum;
	}

	/** The shop's current (market) price for one plain unit. */
	private long listPrice() {
		return ShopValues.shopPrice(entry);
	}

	/** What one item costs now: base price plus any enchantments. */
	private long unitPrice() {
		return listPrice() + enchantSurcharge();
	}

	private boolean enchanted() {
		return !enchants.isEmpty();
	}

	/** Everything this item could be enchanted with (empty for books). */
	private List<EnchantOffer> availableEnchants() {
		if (availableEnchants == null) {
			availableEnchants = EnchantOffer.offersFor(owner.level().registryAccess(), entry.displayStack());
		}
		return availableEnchants;
	}

	/** The most units the current balance covers, never more than the ceiling. */
	private int maxAffordable() {
		long unit = unitPrice();
		if (unit <= 0) {
			return MAX_QUANTITY;
		}
		long affordable = MarketData.balance(owner.getUUID()) / unit;
		return (int) Math.max(1, Math.min(MAX_QUANTITY, affordable));
	}

	private int clamp(int value) {
		return Math.max(1, Math.min(MAX_QUANTITY, Math.min(value, maxAffordable())));
	}

	private long totalCost() {
		return unitPrice() * (long) quantity;
	}

	/**
	 * True when the outer frame sits here. Row 0 is glass with the item on top;
	 * the middle rows are glass only at the sides, which reads as a frame
	 * without burying the buttons.
	 */
	private static boolean isFrame(int slot) {
		int row = slot / 9;
		int column = slot % 9;
		if (row == 0) {
			return true;
		}
		if (row == ROWS - 1) {
			return false;
		}
		return column == 0 || column == 8;
	}

	private void render() {
		quantity = clamp(quantity);

		for (int slot = 0; slot < SIZE; slot++) {
			container.setItem(slot, ItemStack.EMPTY);
		}
		for (int slot = 0; slot < SIZE; slot++) {
			if (isFrame(slot)) {
				container.setItem(slot, new ItemStack(PANE));
			}
		}

		renderItem();
		renderTotal();
		renderQuick();
		renderSteppers();
		renderBalance();
		renderBar();

		broadcastChanges();
	}

	private void renderItem() {
		ItemStack stack = entry.displayStack().copy();
		// Stamp the chosen enchants on the preview so "buy plus its enchanted"
		// is literally what the player is looking at before paying.
		if (enchanted()) {
			for (EnchantOffer offer : enchants) {
				offer.apply(stack);
			}
		}
		stack.set(DataComponents.CUSTOM_NAME,
			Component.literal(itemName()).withStyle(ChatFormatting.WHITE));

		List<Component> lore = new ArrayList<>();
		if (enchanted()) {
			lore.add(Component.literal("Price: $" + TrimKits.formatAmount(unitPrice()) + " each (enchanted)")
				.withStyle(ChatFormatting.GOLD));
			lore.add(Component.literal("$" + TrimKits.formatAmount(listPrice()) + " + $"
					+ TrimKits.formatAmount(enchantSurcharge()) + " of enchantments")
				.withStyle(ChatFormatting.DARK_GRAY));
			lore.add(Component.literal("64 would cost $" + TrimKits.formatAmount(unitPrice() * 64L))
				.withStyle(ChatFormatting.GOLD));
		} else {
			lore.add(Component.literal("Price: $" + TrimKits.formatAmount(listPrice()) + " each")
				.withStyle(ChatFormatting.GOLD));
			lore.add(Component.literal("64 would cost $" + TrimKits.formatAmount(listPrice() * 64L))
				.withStyle(ChatFormatting.GOLD));
		}
		lore.add(Component.literal("Category: " + entry.category())
			.withStyle(ChatFormatting.DARK_GRAY));
		lore.add(Component.empty());
		long owned = ownedCount();
		lore.add(Component.literal(owned > 0
				? "You already own " + TrimKits.formatAmount(owned)
				: "You do not own any yet")
			.withStyle(owned > 0 ? ChatFormatting.GREEN : ChatFormatting.DARK_GRAY));
		lore.add(Component.empty());
		if (enchanted()) {
			lore.add(Component.literal("Enchantments on every item:").withStyle(ChatFormatting.AQUA));
			int shown = 0;
			for (EnchantOffer offer : enchants) {
				if (shown >= 6) {
					lore.add(Component.literal("... and " + TrimKits.formatAmount(enchants.size() - shown)
							+ " more")
						.withStyle(ChatFormatting.GRAY));
					break;
				}
				lore.add(Component.literal(" * ").withStyle(ChatFormatting.DARK_AQUA)
					.append(offer.label().copy())
					.append(Component.literal(" +$" + TrimKits.formatAmount(offer.price()))
						.withStyle(ChatFormatting.GOLD)));
				shown++;
			}
			lore.add(Component.empty());
			lore.add(Component.literal("Click Enchant below to change them")
				.withStyle(ChatFormatting.AQUA));
		} else {
			lore.add(Component.literal("Click an amount below to set the order")
				.withStyle(ChatFormatting.AQUA));
			if (!availableEnchants().isEmpty()) {
				lore.add(Component.literal("Or click Enchant to buy it enchanted")
					.withStyle(ChatFormatting.LIGHT_PURPLE));
			}
		}
		stack.set(DataComponents.LORE, new ItemLore(lore));
		container.setItem(SLOT_ITEM, stack);
	}

	/** Units of this item already in the player's inventory. */
	private long ownedCount() {
		long owned = 0;
		for (ItemStack stack : owner.getInventory().getNonEquipmentItems()) {
			if (ShopValues.matches(entry, stack)) {
				owned += stack.getCount();
			}
		}
		ItemStack offhand = owner.getOffhandItem();
		if (ShopValues.matches(entry, offhand)) {
			owned += offhand.getCount();
		}
		return owned;
	}

	private void renderTotal() {
		boolean affordable = MarketData.canAfford(owner.getUUID(), totalCost());
		ItemStack stack = new ItemStack(affordable ? Items.EMERALD_BLOCK : Items.REDSTONE_BLOCK);
		stack.set(DataComponents.CUSTOM_NAME,
			Component.literal("Buy " + TrimKits.formatAmount(quantity) + " " + itemName())
				.withStyle(ChatFormatting.WHITE)
				.append(Component.literal("  $" + TrimKits.formatAmount(totalCost()))
					.withStyle(affordable ? ChatFormatting.GOLD : ChatFormatting.RED)));

		List<Component> lore = new ArrayList<>();
		if (enchanted()) {
			lore.add(Component.literal(TrimKits.formatAmount(quantity) + " x $"
					+ TrimKits.formatAmount(listPrice()) + " = $"
					+ TrimKits.formatAmount(listPrice() * (long) quantity) + " item(s)")
				.withStyle(affordable ? ChatFormatting.GOLD : ChatFormatting.RED));
			lore.add(Component.literal(TrimKits.formatAmount(quantity) + " x $"
					+ TrimKits.formatAmount(enchantSurcharge()) + " = $"
					+ TrimKits.formatAmount(enchantSurcharge() * (long) quantity) + " enchantments")
				.withStyle(affordable ? ChatFormatting.GOLD : ChatFormatting.RED));
		} else {
			lore.add(Component.literal(TrimKits.formatAmount(quantity) + " x $"
					+ TrimKits.formatAmount(listPrice()) + " = $"
					+ TrimKits.formatAmount(totalCost()))
				.withStyle(affordable ? ChatFormatting.GOLD : ChatFormatting.RED));
		}
		lore.add(Component.empty());
		lore.add(Component.literal(affordable
				? "You can afford this order"
				: "You are short $"
					+ TrimKits.formatAmount(Math.max(0, totalCost() - MarketData.balance(owner.getUUID()))))
			.withStyle(affordable ? ChatFormatting.GREEN : ChatFormatting.RED));
		lore.add(Component.literal("Nothing is charged until you press buy")
			.withStyle(ChatFormatting.DARK_GRAY));
		stack.set(DataComponents.LORE, new ItemLore(lore));
		container.setItem(SLOT_TOTAL, stack);
	}

	private void renderQuick() {
		int affordable = maxAffordable();
		for (int index = 0; index < QUICK_SLOTS.length; index++) {
			int amount = QUICK_AMOUNTS[index];
			boolean isMax = amount < 0;
			int value = isMax ? affordable : amount;
			boolean selected = value == quantity;
			Item icon = isMax ? Items.COMPARATOR : Compat.pickItem("DYE", DyeColor.GRAY);
			if (selected) {
				icon = Compat.pickItem("DYE", DyeColor.LIME);
			}
			if (!isMax && amount > affordable) {
				icon = Compat.pickItem("DYE", DyeColor.GRAY);
			}
			container.setItem(QUICK_SLOTS[index], button(icon,
				isMax ? "Max affordable" : "Buy " + TrimKits.formatAmount(value),
				selected ? ChatFormatting.GREEN : ChatFormatting.AQUA,
				isMax
					? "Sets the order to the most you can pay for"
					: "Sets the order to " + TrimKits.formatAmount(value),
				isMax ? "Max: " + TrimKits.formatAmount(affordable) : "",
				"",
				amount > affordable && !isMax
					? "You cannot afford this many"
					: "Total: $" + TrimKits.formatAmount(unitPrice() * (long) value)));
		}
	}

	private void renderSteppers() {
		container.setItem(SLOT_MINUS_64, step(Items.ARROW, "-64", ChatFormatting.RED, quantity > 1));
		container.setItem(SLOT_MINUS_16, step(Items.ARROW, "-16", ChatFormatting.RED, quantity > 1));
		container.setItem(SLOT_MINUS_1, step(Items.ARROW, "-1", ChatFormatting.RED, quantity > 1));
		container.setItem(SLOT_PLUS_1, step(Items.ARROW, "+1", ChatFormatting.GREEN, quantity < maxAffordable()));
		container.setItem(SLOT_PLUS_16, step(Items.ARROW, "+16", ChatFormatting.GREEN, quantity < maxAffordable()));
		container.setItem(SLOT_PLUS_64, step(Items.ARROW, "+64", ChatFormatting.GREEN, quantity < maxAffordable()));
	}

	private static ItemStack step(Item item, String label, ChatFormatting color, boolean usable) {
		ItemStack stack = new ItemStack(usable ? item : Items.STONE_BUTTON);
		stack.set(DataComponents.CUSTOM_NAME,
			Component.literal(usable ? label : label + " (at limit)").withStyle(
				usable ? color : ChatFormatting.DARK_GRAY));
		return stack;
	}

	private void renderBalance() {
		container.setItem(SLOT_BALANCE, button(Items.GOLD_BLOCK,
			"Balance: $" + TrimKits.formatAmount(MarketData.balance(owner.getUUID())),
			ChatFormatting.GOLD,
			"",
			"You can afford " + TrimKits.formatAmount(maxAffordable()) + " " + itemName()));
	}

	private void renderBar() {
		container.setItem(SLOT_BACK, button(Items.ARROW, "Back to the shop", ChatFormatting.YELLOW,
			"Returns to the item list",
			"",
			"Your order is not kept"));
		container.setItem(SLOT_SEARCH, button(Items.COMPASS,
			"Search", ChatFormatting.AQUA,
			"Type what you want to find",
			"",
			"Click, then type in chat"));
		container.setItem(SLOT_BUY, button(Items.EMERALD_BLOCK,
			"Buy " + TrimKits.formatAmount(quantity), ChatFormatting.GREEN,
			"Costs $" + TrimKits.formatAmount(totalCost()),
			"Gives you " + TrimKits.formatAmount(quantity) + " " + itemName()
				+ (enchanted() ? " (enchanted)" : ""),
			"",
			"Click to confirm"));
		// Enchantment picker, or a plain filler when nothing could be applied
		// (an enchanted book, for instance — it already *is* an enchantment).
		if (availableEnchants().isEmpty()) {
			container.setItem(SLOT_ENCHANT, new ItemStack(PANE));
		} else if (enchanted()) {
			container.setItem(SLOT_ENCHANT, button(Items.ENCHANTED_BOOK,
				"Enchant: " + TrimKits.formatAmount(enchants.size()) + " on", ChatFormatting.GREEN,
				"+$" + TrimKits.formatAmount(enchantSurcharge()) + " per item",
				"Order extra: $" + TrimKits.formatAmount(enchantSurcharge() * (long) quantity),
				"",
				"Click to change what is applied"));
		} else {
			container.setItem(SLOT_ENCHANT, button(Items.BOOK,
				"Enchant this order", ChatFormatting.LIGHT_PURPLE,
				"Buy your items already enchanted",
				TrimKits.formatAmount(availableEnchants().size()) + " enchantment(s) available",
				"",
				"You pay each enchant's price per item"));
		}
		container.setItem(BAR + 3, new ItemStack(PANE));
		for (int slot = BAR + 5; slot <= BAR + 7; slot++) {
			container.setItem(slot, new ItemStack(PANE));
		}
		container.setItem(SLOT_CLOSE, button(Items.BARRIER, "Close", ChatFormatting.RED));
	}

	private static ItemStack button(Item item, String title, ChatFormatting color, String... lore) {
		ItemStack stack = new ItemStack(item);
		stack.set(DataComponents.CUSTOM_NAME, Component.literal(title).withStyle(color));
		List<Component> lines = new ArrayList<>();
		for (String line : lore) {
			lines.add(line.isEmpty() ? Component.empty() : Component.literal(line).withStyle(ChatFormatting.GRAY));
		}
		if (!lines.isEmpty()) {
			stack.set(DataComponents.LORE, new ItemLore(lines));
		}
		return stack;
	}

	@Override
	public void clicked(int slotIndex, int buttonNum, ContainerInput containerInput, Player player) {
		// Display-only menu: the vanilla handler must never touch these stacks,
		// otherwise players could pull the buy button out of the GUI.
		if (slotIndex < 0 || slotIndex >= SIZE || !(player instanceof ServerPlayer serverPlayer)) {
			return;
		}

		switch (slotIndex) {
			case SLOT_CLOSE -> serverPlayer.closeContainer();
			case SLOT_BACK -> goBack();
			case SLOT_SEARCH -> {
				// Anvil-style search box, reopening the buy shop on confirm.
				TrimKits.openSearchPopup(owner, false, null);
			}
			case SLOT_ENCHANT -> openEnchantPicker();
			case SLOT_BUY -> buy();
			case SLOT_MINUS_64 -> setQuantity(quantity - 64);
			case SLOT_MINUS_16 -> setQuantity(quantity - 16);
			case SLOT_MINUS_1 -> setQuantity(quantity - 1);
			case SLOT_PLUS_1 -> setQuantity(quantity + 1);
			case SLOT_PLUS_16 -> setQuantity(quantity + 16);
			case SLOT_PLUS_64 -> setQuantity(quantity + 64);
			default -> {
				for (int index = 0; index < QUICK_SLOTS.length; index++) {
					if (QUICK_SLOTS[index] == slotIndex) {
						int amount = QUICK_AMOUNTS[index];
						setQuantity(amount < 0 ? maxAffordable() : amount);
						return;
					}
				}
			}
		}
	}

	private void setQuantity(int value) {
		quantity = clamp(value);
		render();
	}

	private void buy() {
		TrimKits.BuyResult result = TrimKits.buy(owner, entry, quantity, enchants);
		if (result.ok()) {
			owner.sendSystemMessage(Component.literal(
				"Bought " + TrimKits.formatAmount(result.quantity()) + " " + itemName()
					+ (enchanted() ? " (enchanted)" : "")
					+ " for $" + TrimKits.formatAmount(result.total()) + "."));
		} else {
			owner.sendSystemMessage(Component.literal(result.problem()));
		}
		render();
	}

	/** Hands the shared selection to the enchantment picker and back. */
	private void openEnchantPicker() {
		if (availableEnchants().isEmpty()) {
			return;
		}
		MinecraftServer server = owner.level().getServer();
		Runnable action = () -> {
			if (owner.containerMenu == this) {
				TrimKits.openBuyEnchant(owner, entry, enchants);
			}
		};
		if (server == null) {
			action.run();
		} else {
			server.execute(action);
		}
	}

	/**
	 * Swapping menus inside a click handler would race the packet that is being
	 * processed, so the swap is deferred to the end of the server task queue.
	 */
	private void goBack() {
		MinecraftServer server = owner.level().getServer();
		Runnable action = () -> {
			if (owner.containerMenu == this) {
				TrimKits.openBuyGui(owner);
			}
		};
		if (server == null) {
			action.run();
		} else {
			server.execute(action);
		}
	}

	@Override
	public ItemStack quickMoveStack(Player player, int slotIndex) {
		// No shift-clicking in or out of the buy menu.
		return ItemStack.EMPTY;
	}
}
