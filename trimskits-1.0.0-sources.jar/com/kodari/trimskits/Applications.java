package com.kodari.trimskits;

import java.io.IOException;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.players.NameAndId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Staff application system ({@code /applications}).
 *
 * <p>Each staff rank - Mod, Admin, Sr Admin, Head Admin, Sr Head Admin and
 * Co-Owner - has its own set of questions, asked one at a time in chat after
 * the player clicks its paper in the picker GUI. Answers are captured by the
 * chat hook (never broadcast), and a finished application is stored as a
 * <i>pending submission</i> that the owner or a co-owner reviews in
 * {@code /modlogs}.
 *
 * <p>Accepting a submission:
 * <ul>
 *   <li>records the staff rank (shown in the tab-list roster),</li>
 *   <li>grants the {@code sfmode} permission in config/OPS.json
 *       ({@link #Config} {@code applications.grant_sfmode}),</li>
 *   <li>makes the player a vanilla operator so {@code /gamemode} and every
 *       other server command works ({@code applications.grant_vanilla_op}).
 *       Vanilla op also satisfies this mod's own {@code COMMANDS_ADMIN}
 *       gates, so accepted staff can use the admin commands too.</li>
 * </ul>
 *
 * <p>Everything lives in config/trimskits-applications.json: the submission
 * history plus the staff-rank roster. Writes are atomic (temp file, then
 * move), the same discipline as the password vault. A file that cannot be
 * parsed is quarantined to {@code trimskits-applications.corrupt.json} - the
 * bytes are preserved, never silently destroyed - and a fresh store starts.
 */
final class Applications {
	private static final Logger LOGGER = LoggerFactory.getLogger("trimskits");
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final Path CONFIG_DIR = Path.of("config");
	private static final Path DATA_FILE = CONFIG_DIR.resolve("trimskits-applications.json");

	/** One staff rank and the questions that are asked for it. */
	record Role(String id, String display, String color, List<String> questions) {
	}

	/** A question and the applicant's answer, kept together for the review GUI. */
	record QA(String question, String answer) {
	}

	/** A submitted application. Immutable; reviews create a replacement copy. */
	record Submission(
		long id,
		UUID uuid,
		String username,
		String roleId,
		String status, // pending | accepted | rejected
		long submittedAt,
		List<QA> answers,
		String reviewedBy,
		long reviewedAt
	) {
	}

	/** Who currently holds a staff rank (drives the tab-list roster). */
	record StaffRank(String username, String roleId, long grantedAt) {
	}

	/** A questionnaire in progress: which role, which question, answers so far. */
	private record Session(String roleId, int index, List<QA> answers, long startedAt) {
	}

	// ---- Roles & questions ------------------------------------------------

	// Every rank asks different questions about different things, per the spec.
	private static final List<Role> ROLES = List.of(
		new Role("mod", "Mod", "\u00a7b", List.of(
			"Why do you want to be a Mod on this server?",
			"How many hours per day can you be online, and in which timezone?",
			"A player is spamming insults in chat. What do you do, step by step?",
			"Your friend is cheating on the server. How do you handle it?",
			"What do you think is the most important rule on a survival server, and why?")),
		new Role("admin", "Admin", "\u00a7c", List.of(
			"Have you moderated before? Where, and for how long?",
			"How do you handle a report where both players blame each other?",
			"What is the difference between a bug and an exploit, and how do you treat each?",
			"How would you deal with a staff member abusing their powers?",
			"A group of players threatens to DDoS the server. What do you do?",
			"Which commands would you use to inspect a player and their recent history?")),
		new Role("sr_admin", "Sr Admin", "\u00a76", List.of(
			"How would you train a new Mod during their first week?",
			"Describe a hard decision you made under pressure and what you learned from it.",
			"How do you keep punishments consistent across different players?",
			"An appeals thread is getting toxic with hundreds of messages. How do you manage it?",
			"How do you handle disagreeing with another Admin in public?",
			"What numbers would you look at to know the server is healthy?")),
		new Role("head_admin", "Head Admin", "\u00a7d", List.of(
			"What is your vision for the staff team over the next six months?",
			"It is 3 AM and a serious incident happens while the Owner is offline. What do you do?",
			"How would you design a rule that is fair but hard to abuse?",
			"How do you handle a leaked server file or another security threat?",
			"Tell us about a time you changed your mind about something important, and why.")),
		new Role("sr_head_admin", "Sr Head Admin", "\u00a75", List.of(
			"How do you structure a staff team so it survives real life - people quitting, jobs, exams?",
			"How do you resolve a conflict between two Head Admins?",
			"What is your approach to long-term server growth and events?",
			"How do you audit staff activity so that trust is verifiable, not assumed?",
			"What would you do if the Owner made a decision you strongly disagreed with?")),
		new Role("co_owner", "Co-Owner", "\u00a74", List.of(
			"What does a Co-Owner owe the Owner when they disagree in public?",
			"How would you approach monetization without ruining fairness for normal players?",
			"Who do you promote, who do you let go, and how do you decide?",
			"What is the biggest risk facing this server right now?",
			"Describe this server one year from now if everything goes right."))
	);

	// ---- In-memory state --------------------------------------------------

	private static final Map<UUID, Session> SESSIONS = new ConcurrentHashMap<>();
	private static final List<Submission> SUBMISSIONS = new ArrayList<>();
	private static final Map<UUID, StaffRank> STAFF = new ConcurrentHashMap<>();
	private static long nextId = 1;
	private static boolean loaded = false;

	private Applications() {}

	// ---- Lookups ----------------------------------------------------------

	/** All six roles, in display order. */
	static List<Role> roles() {
		return ROLES;
	}

	/** The role with this id, or null when there is no such rank. */
	static Role role(String id) {
		if (id == null) return null;
		for (Role role : ROLES) {
			if (role.id().equals(id)) return role;
		}
		return null;
	}

	/** The staff rank a player holds, as a display string with colours, or null. */
	static String staffRoleDisplay(UUID playerId) {
		StaffRank rank = STAFF.get(playerId);
		if (rank == null) return null;
		Role role = role(rank.roleId());
		if (role == null) return null;
		return role.color() + "[" + role.display() + "]";
	}

	/** The raw role id a player holds, or null. */
	static String staffRoleId(UUID playerId) {
		StaffRank rank = STAFF.get(playerId);
		return rank == null ? null : rank.roleId();
	}

	/** Every submitted application, newest first, pending ones first. */
	static List<Submission> submissions() {
		load();
		List<Submission> copy = new ArrayList<>(SUBMISSIONS);
		copy.sort((a, b) -> {
			boolean ap = "pending".equals(a.status());
			boolean bp = "pending".equals(b.status());
			if (ap != bp) return ap ? -1 : 1;
			return Long.compare(b.id(), a.id());
		});
		return copy;
	}

	/** One submission by id, or null. */
	static Submission submission(long id) {
		load();
		for (Submission submission : SUBMISSIONS) {
			if (submission.id() == id) return submission;
		}
		return null;
	}

	/** How many submissions are waiting for review. */
	static int pendingCount() {
		load();
		int count = 0;
		for (Submission submission : SUBMISSIONS) {
			if ("pending".equals(submission.status())) count++;
		}
		return count;
	}

	/** True when this player already has an application waiting for review. */
	static boolean hasPending(UUID playerId) {
		load();
		for (Submission submission : SUBMISSIONS) {
			if (submission.uuid().equals(playerId) && "pending".equals(submission.status())) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Who may review applications: the configured owner name, anyone listed in
	 * OPS.json with the admin permission, and vanilla operators.
	 */
	static boolean isReviewer(ServerPlayer player) {
		if (player == null) return false;
		String name = player.getScoreboardName();
		if (OpsConfig.hasPermission(name, OpsConfig.PERM_ADMIN)) return true;
		if (name.equalsIgnoreCase(Config.getString("admin.username", "vadim154655"))) return true;
		MinecraftServer server = player.level().getServer();
		return server != null
			&& server.getPlayerList().isOp(new NameAndId(player.getUUID(), name));
	}

	// ---- Questionnaire ----------------------------------------------------

	/**
	 * Starts the questionnaire for a role. Returns an error message, or null on
	 * success (the first question has been sent in chat).
	 */
	static String start(ServerPlayer player, String roleId) {
		load();
		if (!Config.getBoolean("applications.enabled")) {
			return "Applications are disabled on this server.";
		}
		Role role = role(roleId);
		if (role == null) {
			return "Unknown application type.";
		}
		UUID id = player.getUUID();
		if (SESSIONS.containsKey(id)) {
			return "You already have an application in progress. Use /applications cancel first.";
		}
		if (hasPending(id)) {
			return "You already have an application waiting for review.";
		}
		if (role.id().equals(staffRoleId(id))) {
			return "You are already " + role.display() + ".";
		}
		SESSIONS.put(id, new Session(role.id(), 0, new ArrayList<>(), System.currentTimeMillis()));
		sendQuestion(player, role, 0);
		return null;
	}

	/** True while a questionnaire is running, so the GUI can show it. */
	static boolean inProgress(UUID playerId) {
		return SESSIONS.containsKey(playerId);
	}

	/** Drops a half-finished questionnaire. Returns true when one existed. */
	static boolean clearSession(UUID playerId) {
		return SESSIONS.remove(playerId) != null;
	}

	private static void sendQuestion(ServerPlayer player, Role role, int index) {
		List<String> questions = role.questions();
		player.sendSystemMessage(Component.literal(
			"\u00a76\u00a7l[Application] \u00a7e" + role.display() + " \u00a77- question \u00a7a"
				+ (index + 1) + "\u00a77/\u00a7a" + questions.size()));
		player.sendSystemMessage(Component.literal("\u00a7f" + questions.get(index)));
		player.sendSystemMessage(Component.literal(
			"\u00a78Type your answer in chat, or \u00a77/applications cancel\u00a78."));
	}

	/**
	 * Captures an answer from chat. Returns true when the message was consumed
	 * (the caller must not broadcast it); false lets normal chat through.
	 */
	static boolean handleChat(ServerPlayer sender, String raw) {
		if (sender == null || raw == null) return false;
		UUID id = sender.getUUID();
		Session session = SESSIONS.get(id);
		if (session == null) return false;
		String text = raw.trim();
		// Commands must keep working mid-application: /spawn, /home, ...
		if (text.startsWith("/")) return false;
		Role role = role(session.roleId());
		if (role == null) {
			SESSIONS.remove(id);
			return false;
		}
		if (text.isEmpty()) {
			// An empty line just re-asks the current question.
			sendQuestion(sender, role, session.index());
			return true;
		}
		if (text.equalsIgnoreCase("cancel") || text.equalsIgnoreCase("quit")) {
			SESSIONS.remove(id);
			sender.sendSystemMessage(Component.literal(
				"\u00a7cApplication cancelled. \u00a77Open /applications to start again."));
			return true;
		}
		List<QA> answers = new ArrayList<>(session.answers());
		answers.add(new QA(role.questions().get(session.index()), text));
		int next = session.index() + 1;
		if (next >= role.questions().size()) {
			SESSIONS.remove(id);
			submit(sender, role, answers);
		} else {
			SESSIONS.put(id, new Session(role.id(), next, answers, session.startedAt()));
			sendQuestion(sender, role, next);
		}
		return true;
	}

	/** Files a finished questionnaire as a pending submission. */
	private static void submit(ServerPlayer player, Role role, List<QA> answers) {
		load();
		long id = nextId++;
		Submission submission = new Submission(
			id, player.getUUID(), player.getScoreboardName(), role.id(), "pending",
			System.currentTimeMillis(), List.copyOf(answers), null, 0L);
		SUBMISSIONS.add(submission);
		save();
		player.sendSystemMessage(Component.literal(
			"\u00a7aYour " + role.display() + " application was sent for review (\u00a7e/modlogs\u00a7a)."));
		player.sendSystemMessage(Component.literal(
			"\u00a77You will be told here as soon as it is decided."));
		MinecraftServer server = player.level().getServer();
		if (server != null) {
			String message = "\u00a76[ModLogs] \u00a7e" + player.getScoreboardName()
				+ " \u00a77applied for \u00a7b" + role.display()
				+ "\u00a77. \u00a7e/modlogs \u00a77to review.";
			for (ServerPlayer online : server.getPlayerList().getPlayers()) {
				if (!online.getUUID().equals(player.getUUID()) && isReviewer(online)) {
					online.sendSystemMessage(Component.literal(message));
				}
			}
		}
	}

	// ---- Review actions ---------------------------------------------------

	/**
	 * Accepts a submission: records the rank, grants sfmode + vanilla op.
	 *
	 * @return an error message, or null on success
	 */
	static String accept(long submissionId, String reviewer, MinecraftServer server) {
		Submission submission = submission(submissionId);
		if (submission == null) {
			return "No application with id " + submissionId + ".";
		}
		if (!"pending".equals(submission.status())) {
			return "Application #" + submissionId + " was already " + submission.status() + ".";
		}
		Role role = role(submission.roleId());
		if (role == null) {
			return "Application #" + submissionId + " has an unknown rank; fix the JSON by hand.";
		}
		replace(submission, new Submission(
			submission.id(), submission.uuid(), submission.username(), submission.roleId(),
			"accepted", submission.submittedAt(), submission.answers(),
			reviewer == null ? "console" : reviewer, System.currentTimeMillis()));
		STAFF.put(submission.uuid(), new StaffRank(
			submission.username(), submission.roleId(), System.currentTimeMillis()));
		save();
		// sfmode: lets the new staff member toggle admin mode with /sfmode.
		if (Config.getBoolean("applications.grant_sfmode")) {
			OpsConfig.grant(submission.username(), OpsConfig.PERM_SFMODE);
		}
		// Vanilla op: /gamemode and every other server command, which also
		// satisfies this mod's own COMMANDS_ADMIN command gates.
		if (Config.getBoolean("applications.grant_vanilla_op")) {
			NameAndId nameAndId = new NameAndId(submission.uuid(), submission.username());
			if (!server.getPlayerList().isOp(nameAndId)) {
				server.getPlayerList().op(nameAndId);
			}
		}
		ServerPlayer online = server.getPlayerList().getPlayer(submission.uuid());
		if (online != null) {
			online.sendSystemMessage(Component.literal(
				"\u00a7a\u00a7lYour " + role.display() + " application was \u00a7lACCEPTED\u00a7a\u00a7l!"));
			online.sendSystemMessage(Component.literal(
				"\u00a77You now hold the staff rank" + (Config.getBoolean("applications.grant_vanilla_op")
					? ", /sfmode and full server commands." : ".")));
		}
		LOGGER.info("Application #{} ({}) accepted by {} - granted {}.",
			submission.id(), submission.username(), reviewer, role.id());
		return null;
	}

	/** Rejects a submission. Returns an error message, or null on success. */
	static String reject(long submissionId, String reviewer, MinecraftServer server) {
		Submission submission = submission(submissionId);
		if (submission == null) {
			return "No application with id " + submissionId + ".";
		}
		if (!"pending".equals(submission.status())) {
			return "Application #" + submissionId + " was already " + submission.status() + ".";
		}
		replace(submission, new Submission(
			submission.id(), submission.uuid(), submission.username(), submission.roleId(),
			"rejected", submission.submittedAt(), submission.answers(),
			reviewer == null ? "console" : reviewer, System.currentTimeMillis()));
		save();
		ServerPlayer online = server.getPlayerList().getPlayer(submission.uuid());
		if (online != null) {
			Role role = role(submission.roleId());
			online.sendSystemMessage(Component.literal(
				"\u00a7cYour " + (role == null ? "staff" : role.display())
					+ " application was not accepted. \u00a77You can apply again later."));
		}
		LOGGER.info("Application #{} ({}) rejected by {}.",
			submission.id(), submission.username(), reviewer);
		return null;
	}

	private static void replace(Submission old, Submission updated) {
		int index = SUBMISSIONS.indexOf(old);
		if (index >= 0) {
			SUBMISSIONS.set(index, updated);
		}
	}

	/** Tells reviewers that a new application is waiting. */
	static void notifyReviewer(ServerPlayer reviewer, MinecraftServer server) {
		int pending = pendingCount();
		if (pending > 0 && isReviewer(reviewer)) {
			reviewer.sendSystemMessage(Component.literal(
				"\u00a76[ModLogs] \u00a7e" + pending + " application(s) waiting. \u00a77Use /modlogs."));
		}
	}

	/** A human-readable timestamp for the review GUI. */
	static String formatTime(long millis) {
		if (millis <= 0) return "-";
		return DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")
			.withZone(ZoneId.systemDefault())
			.format(Instant.ofEpochMilli(millis));
	}

	// ---- Persistence ------------------------------------------------------

	private static void load() {
		if (loaded) return;
		loaded = true;
		if (!Files.exists(DATA_FILE)) {
			SUBMISSIONS.clear();
			STAFF.clear();
			save();
			return;
		}
		try {
			parse(Files.readString(DATA_FILE));
			LOGGER.info("Loaded {} application(s) and {} staff rank(s) from {}.",
				SUBMISSIONS.size(), STAFF.size(), DATA_FILE);
		} catch (IOException | RuntimeException e) {
			// Preserve the broken file instead of overwriting it, then start
			// fresh - the operator can still read what happened.
			quarantine(e.getMessage());
			SUBMISSIONS.clear();
			STAFF.clear();
			nextId = 1;
		}
	}

	private static void quarantine(String reason) {
		Path target = CONFIG_DIR.resolve("trimskits-applications.corrupt.json");
		try {
			Files.move(DATA_FILE, target, StandardCopyOption.REPLACE_EXISTING);
			LOGGER.warn("Could not read {} ({}); the file was moved to {} and a fresh store started.",
				DATA_FILE, reason, target);
		} catch (IOException moveFailure) {
			LOGGER.warn("Could not read {} ({}) and could not move it aside ({}); a fresh store started.",
				DATA_FILE, reason, moveFailure.getMessage());
		}
	}

	private static void parse(String content) {
		SUBMISSIONS.clear();
		STAFF.clear();
		nextId = 1;
		if (content == null || content.isBlank()) return;
		JsonElement rootElement = JsonParser.parseString(content);
		if (!rootElement.isJsonObject()) return;
		JsonObject root = rootElement.getAsJsonObject();

		if (root.has("submissions") && root.get("submissions").isJsonArray()) {
			for (JsonElement element : root.getAsJsonArray("submissions")) {
				if (!element.isJsonObject()) continue;
				Submission submission = readSubmission(element.getAsJsonObject());
				if (submission != null) {
					SUBMISSIONS.add(submission);
					if (submission.id() >= nextId) nextId = submission.id() + 1;
				}
			}
		}
		if (root.has("staff") && root.get("staff").isJsonObject()) {
			for (Map.Entry<String, JsonElement> entry : root.getAsJsonObject("staff").entrySet()) {
				if (!entry.getValue().isJsonObject()) continue;
				JsonObject obj = entry.getValue().getAsJsonObject();
				try {
					UUID uuid = UUID.fromString(entry.getKey());
					String username = readString(obj, "username", "name");
					String roleId = readString(obj, "role", "role_id", "rank");
					if (username == null || role(roleId) == null) continue;
					STAFF.put(uuid, new StaffRank(username, roleId, readLong(obj, "grantedAt", "granted_at", "time")));
				} catch (IllegalArgumentException ignored) {
					// A key that is not a uuid carries nothing we can use.
				}
			}
		}
	}

	private static Submission readSubmission(JsonObject obj) {
		try {
			UUID uuid = UUID.fromString(readString(obj, "uuid", "id"));
			String username = readString(obj, "username", "name");
			String roleId = readString(obj, "role", "role_id", "rank");
			if (username == null || roleId == null) return null;
			String status = readString(obj, "status");
			if (status == null) status = "pending";
			List<QA> answers = new ArrayList<>();
			if (obj.has("answers") && obj.get("answers").isJsonArray()) {
				for (JsonElement element : obj.getAsJsonArray("answers")) {
					if (!element.isJsonObject()) continue;
					JsonObject qa = element.getAsJsonObject();
					String question = readString(qa, "question", "q");
					String answer = readString(qa, "answer", "a");
					if (question != null && answer != null) {
						answers.add(new QA(question, answer));
					}
				}
			}
			return new Submission(
				readLong(obj, "id"), uuid, username, roleId, status,
				readLong(obj, "submittedAt", "submitted_at", "time"),
				List.copyOf(answers),
				readString(obj, "reviewedBy", "reviewed_by"),
				readLong(obj, "reviewedAt", "reviewed_at"));
		} catch (IllegalArgumentException ignored) {
			return null;
		}
	}

	/** Writes the store atomically: temp file first, then move over the real one. */
	private static void save() {
		JsonObject root = new JsonObject();
		JsonArray submissions = new JsonArray();
		for (Submission submission : SUBMISSIONS) {
			JsonObject obj = new JsonObject();
			obj.addProperty("id", submission.id());
			obj.addProperty("uuid", submission.uuid().toString());
			obj.addProperty("username", submission.username());
			obj.addProperty("role", submission.roleId());
			obj.addProperty("status", submission.status());
			obj.addProperty("submittedAt", submission.submittedAt());
			JsonArray answers = new JsonArray();
			for (QA qa : submission.answers()) {
				JsonObject pair = new JsonObject();
				pair.addProperty("question", qa.question());
				pair.addProperty("answer", qa.answer());
				answers.add(pair);
			}
			obj.add("answers", answers);
			if (submission.reviewedBy() != null) {
				obj.addProperty("reviewedBy", submission.reviewedBy());
			}
			obj.addProperty("reviewedAt", submission.reviewedAt());
			submissions.add(obj);
		}
		root.add("submissions", submissions);
		JsonObject staff = new JsonObject();
		for (Map.Entry<UUID, StaffRank> entry : STAFF.entrySet()) {
			JsonObject obj = new JsonObject();
			obj.addProperty("username", entry.getValue().username());
			obj.addProperty("role", entry.getValue().roleId());
			obj.addProperty("grantedAt", entry.getValue().grantedAt());
			staff.add(entry.getKey().toString(), obj);
		}
		root.add("staff", staff);

		Path temporaryFile = DATA_FILE.resolveSibling("trimskits-applications.tmp");
		try {
			Files.createDirectories(CONFIG_DIR);
			Files.writeString(temporaryFile, GSON.toJson(root));
			try {
				Files.move(temporaryFile, DATA_FILE,
					StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
			} catch (AtomicMoveNotSupportedException fallback) {
				Files.move(temporaryFile, DATA_FILE, StandardCopyOption.REPLACE_EXISTING);
			}
		} catch (IOException e) {
			LOGGER.warn("Failed to save trimskits-applications.json: {}", e.getMessage());
		}
	}

	private static String readString(JsonObject obj, String... keys) {
		for (String key : keys) {
			if (obj.has(key) && obj.get(key).isJsonPrimitive()) {
				String value = obj.get(key).getAsString();
				if (value != null && !value.isEmpty()) return value;
			}
		}
		return null;
	}

	private static long readLong(JsonObject obj, String... keys) {
		for (String key : keys) {
			if (obj.has(key) && obj.get(key).isJsonPrimitive()) {
				try {
					return obj.get(key).getAsLong();
				} catch (RuntimeException ignored) {
					// Not a number under this key; try the next alias.
				}
			}
		}
		return 0L;
	}
}
