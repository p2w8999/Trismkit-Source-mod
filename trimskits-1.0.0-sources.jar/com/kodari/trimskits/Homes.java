package com.kodari.trimskits;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.TreeMap;
import java.util.UUID;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Relative;
import net.minecraft.world.level.Level;

/**
 * Per-player named warp points ("homes") that survive restarts and can be
 * reached from anywhere, across dimensions and any distance.
 *
 * <p>Homes are stored per player in a flat properties file, one line each, so a
 * damaged line can be skipped without losing everything else. Names are unique
 * per player (case-insensitive) and are the handle every action keys off, which
 * keeps renames and deletes simple and stable.
 */
final class Homes {
	private static final Path DATA_FILE = Path.of("config", "trimskits-homes.properties");
	/** Longest allowed home name; keeps lore lines tidy and the file sane. */
	static final int MAX_NAME_LENGTH = 24;
	/** Characters a name may never contain (field separator + control codes). */
	private static final String ILLEGAL_NAME_CHARS = "|;\n\r\t§";

	private static final Map<UUID, List<Home>> HOMES = new HashMap<>();
	private static boolean loaded;
	private static boolean readable = true;

	private Homes() {
	}

	/** A single named warp point. */
	record Home(String name, ResourceKey<Level> dimension, double x, double y, double z, float yaw, float pitch) {
		/** Short dimension label for lore, e.g. "Overworld", "The Nether". */
		String dimensionLabel() {
			String path = dimension.identifier().getPath();
			return switch (path) {
				case "overworld" -> "Overworld";
				case "the_nether" -> "The Nether";
				case "the_end" -> "The End";
				default -> path;
			};
		}
	}

	static synchronized void initialize() {
		if (loaded) {
			return;
		}
		loaded = true;
		if (!Files.exists(DATA_FILE)) {
			return;
		}

		Properties properties = new Properties();
		try (InputStream input = Files.newInputStream(DATA_FILE)) {
			properties.load(input);
		} catch (IOException | RuntimeException exception) {
			readable = false;
			TrimKits.LOGGER.warn("Could not read {}, homes stay in memory only: {}",
				DATA_FILE, exception.getMessage());
			return;
		}

		// Gather each home with its stored index so the original order is kept
		// even though Properties iterates keys in an unspecified order.
		Map<UUID, TreeMap<Integer, Home>> staged = new HashMap<>();
		for (String key : properties.stringPropertyNames()) {
			if (!key.startsWith("home.")) {
				continue;
			}
			try {
				String rest = key.substring("home.".length());
				int lastDot = rest.lastIndexOf('.');
				if (lastDot <= 0) {
					continue;
				}
				UUID playerId = UUID.fromString(rest.substring(0, lastDot));
				int index = Integer.parseInt(rest.substring(lastDot + 1));
				String[] fields = properties.getProperty(key).split("\\|", -1);
				if (fields.length != 7) {
					continue;
				}
				String name = fields[0].trim();
				if (name.isEmpty()) {
					continue;
				}
				Identifier dimensionId = Identifier.tryParse(fields[1]);
				if (dimensionId == null) {
					continue;
				}
				ResourceKey<Level> dimension = ResourceKey.create(Registries.DIMENSION, dimensionId);
				double x = Double.parseDouble(fields[2]);
				double y = Double.parseDouble(fields[3]);
				double z = Double.parseDouble(fields[4]);
				float yaw = Float.parseFloat(fields[5]);
				float pitch = Float.parseFloat(fields[6]);
				staged.computeIfAbsent(playerId, id -> new TreeMap<>())
					.put(index, new Home(name, dimension, x, y, z, yaw, pitch));
			} catch (RuntimeException ignored) {
				// Skip a damaged line instead of failing the whole file.
			}
		}
		staged.forEach((playerId, ordered) -> HOMES.put(playerId, new ArrayList<>(ordered.values())));
	}

	/** Read-only view of a player's homes, in the order they were created. */
	static synchronized List<Home> homes(UUID playerId) {
		return List.copyOf(HOMES.getOrDefault(playerId, List.of()));
	}

	static synchronized int count(UUID playerId) {
		return HOMES.getOrDefault(playerId, List.of()).size();
	}

	/** Configured per-player home cap (always at least 1). */
	static int limit() {
		return Math.max(1, Config.getInt("homes.max_per_player"));
	}

	/** Case-insensitive lookup; returns null when the player has no such home. */
	static synchronized Home get(UUID playerId, String name) {
		if (name == null) {
			return null;
		}
		for (Home home : HOMES.getOrDefault(playerId, List.of())) {
			if (home.name().equalsIgnoreCase(name.trim())) {
				return home;
			}
		}
		return null;
	}

	/**
	 * Checks a proposed name. Returns null when it is acceptable, otherwise a
	 * player-facing reason. {@code exclude} is a name allowed to collide with
	 * itself (used when renaming a home to its own name).
	 */
	static synchronized String validateName(UUID playerId, String name, String exclude) {
		String trimmed = name == null ? "" : name.trim();
		if (trimmed.isEmpty()) {
			return "Give the home a name.";
		}
		if (trimmed.length() > MAX_NAME_LENGTH) {
			return "Home names are at most " + MAX_NAME_LENGTH + " characters.";
		}
		for (int i = 0; i < trimmed.length(); i++) {
			if (ILLEGAL_NAME_CHARS.indexOf(trimmed.charAt(i)) >= 0) {
				return "Home names cannot contain: | ; § or line breaks.";
			}
		}
		if (exclude != null && trimmed.equalsIgnoreCase(exclude.trim())) {
			return null;
		}
		if (get(playerId, trimmed) != null) {
			return "You already have a home called \"" + trimmed + "\".";
		}
		return null;
	}

	/** Creates a home at the given spot. Returns null on success, else a reason. */
	static synchronized String add(UUID playerId, String name, ResourceKey<Level> dimension,
			double x, double y, double z, float yaw, float pitch, int limit) {
		String problem = validateName(playerId, name, null);
		if (problem != null) {
			return problem;
		}
		if (count(playerId) >= limit) {
			return "You already have the maximum of " + limit + " homes.";
		}
		String trimmed = name.trim();
		HOMES.computeIfAbsent(playerId, id -> new ArrayList<>())
			.add(new Home(trimmed, dimension, x, y, z, yaw, pitch));
		if (!save()) {
			// Roll back so a failed write never silently drops the home.
			List<Home> list = HOMES.get(playerId);
			if (list != null) {
				list.removeIf(home -> home.name().equals(trimmed));
				if (list.isEmpty()) {
					HOMES.remove(playerId);
				}
			}
			return "Could not save that home; try again.";
		}
		return null;
	}

	/** Renames a home. Returns null on success, else a reason. */
	static synchronized String rename(UUID playerId, String oldName, String newName) {
		List<Home> list = HOMES.get(playerId);
		if (list == null) {
			return "That home no longer exists.";
		}
		int index = indexOf(list, oldName);
		if (index < 0) {
			return "That home no longer exists.";
		}
		String problem = validateName(playerId, newName, oldName);
		if (problem != null) {
			return problem;
		}
		Home old = list.get(index);
		Home updated = new Home(newName.trim(), old.dimension(), old.x(), old.y(), old.z(), old.yaw(), old.pitch());
		list.set(index, updated);
		if (!save()) {
			list.set(index, old);
			return "Could not save the new name; try again.";
		}
		return null;
	}

	/** Moves a home to a new spot (keeps the name). Returns true on success. */
	static synchronized boolean move(UUID playerId, String name, ResourceKey<Level> dimension,
			double x, double y, double z, float yaw, float pitch) {
		List<Home> list = HOMES.get(playerId);
		if (list == null) {
			return false;
		}
		int index = indexOf(list, name);
		if (index < 0) {
			return false;
		}
		Home old = list.get(index);
		Home moved = new Home(old.name(), dimension, x, y, z, yaw, pitch);
		list.set(index, moved);
		if (!save()) {
			list.set(index, old);
			return false;
		}
		return true;
	}

	/** Deletes a home by name. Returns true when one was removed. */
	static synchronized boolean remove(UUID playerId, String name) {
		List<Home> list = HOMES.get(playerId);
		if (list == null) {
			return false;
		}
		int index = indexOf(list, name);
		if (index < 0) {
			return false;
		}
		Home removed = list.remove(index);
		if (list.isEmpty()) {
			HOMES.remove(playerId);
		}
		if (!save()) {
			// Put it back so the player does not lose the home to a write error.
			HOMES.computeIfAbsent(playerId, id -> new ArrayList<>()).add(index, removed);
			return false;
		}
		return true;
	}

	/**
	 * Sends a player to a home, switching dimension and covering any distance in
	 * one hop. Returns false only when the target dimension no longer exists.
	 */
	static boolean teleport(ServerPlayer player, Home home) {
		MinecraftServer server = player.level().getServer();
		if (server == null) {
			return false;
		}
		ServerLevel target = server.getLevel(home.dimension());
		if (target == null) {
			return false;
		}
		// Empty relative set = absolute coordinates; works same- or cross-dimension.
		player.teleportTo(target, home.x(), home.y(), home.z(), Set.<Relative>of(), home.yaw(), home.pitch(), false);
		return true;
	}

	private static int indexOf(List<Home> list, String name) {
		if (name == null) {
			return -1;
		}
		for (int i = 0; i < list.size(); i++) {
			if (list.get(i).name().equalsIgnoreCase(name.trim())) {
				return i;
			}
		}
		return -1;
	}

	private static synchronized boolean save() {
		if (!readable) {
			return false;
		}
		Properties properties = new Properties();
		HOMES.forEach((playerId, list) -> {
			for (int i = 0; i < list.size(); i++) {
				Home home = list.get(i);
				properties.setProperty("home." + playerId + "." + i,
					home.name() + "|" + home.dimension().identifier() + "|"
						+ home.x() + "|" + home.y() + "|" + home.z() + "|"
						+ home.yaw() + "|" + home.pitch());
			}
		});

		Path temporaryFile = DATA_FILE.resolveSibling("trimskits-homes.tmp");
		try {
			Files.createDirectories(DATA_FILE.getParent());
			try (OutputStream output = Files.newOutputStream(temporaryFile)) {
				properties.store(output, "Trim Kits player homes");
			}
			try {
				Files.move(temporaryFile, DATA_FILE, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
			} catch (AtomicMoveNotSupportedException exception) {
				// Some filesystems cannot rename atomically; fall back so homes
				// still persist rather than reporting failure every time.
				Files.move(temporaryFile, DATA_FILE, StandardCopyOption.REPLACE_EXISTING);
			}
			return true;
		} catch (IOException exception) {
			TrimKits.LOGGER.warn("Could not save homes: {}", exception.getMessage());
			return false;
		}
	}
}
