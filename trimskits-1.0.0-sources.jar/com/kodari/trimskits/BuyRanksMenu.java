package com.kodari.trimskits;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;

/**
 * The /buyranks store GUI.
 *
 * <p>Two ways to get stuff:
 * <ul>
 *   <li>In game: the tab-rank grid, bought with the /money balance (the same
 *       {@link TabRanks#purchase} path /tabranks uses - nothing new touches
 *       the economy).</li>
 *   <li>On the website: the link button closes the GUI and prints a clickable
 *       chat link (webstore.website_url). The site sells ranks, money, shards
 *       and crate keys for $0.00; every purchase becomes an order in the
 *       repo's orders.json that {@link WebStore} delivers in game, asking for
 *       the Minecraft username to send it to at checkout.</li>
 * </ul>
 */
final class BuyRanksMenu extends ChestMenu {
	private static final int ROWS = 6;
	private static final int SIZE = ROWS * 9;

	private static final int WEBSITE_SLOT = 45;
	private static final int WEB_STATUS_SLOT = 48;
	private static final int BALANCE_SLOT = 49;
	private static final int CLOSE_SLOT = 53;

	private final ServerPlayer owner;

	BuyRanksMenu(int containerId, Inventory inventory, ServerPlayer owner) {
		super(MenuType.GENERIC_9x6, containerId, inventory, new SimpleContainer(SIZE), ROWS);
		this.owner = owner;
		build();
	}

	private void build() {
		SimpleContainer container = (SimpleContainer) getContainer();

		// Border panes
		ItemStack borderPane = new ItemStack(Compat.pickItem("STAINED_GLASS_PANE", net.minecraft.world.item.DyeColor.PURPLE));
		borderPane.set(DataComponents.CUSTOM_NAME, Component.literal(" "));
		for (int i = 0; i < SIZE; i++) {
			if (i < 9 || i >= 45 || i % 9 == 0 || i % 9 == 8) {
				container.setItem(i, borderPane);
			}
		}

		// Title item in top center
		ItemStack titleItem = new ItemStack(Items.NETHER_STAR);
		TabRanks.RankDef activeRank = TabRanks.getActiveRank(owner.getUUID());
		titleItem.set(DataComponents.CUSTOM_NAME,
			Component.literal("§d§lBUY RANKS & P2W STORE").withStyle(ChatFormatting.BOLD));
		titleItem.set(DataComponents.LORE, new ItemLore(List.of(
			Component.literal("§7Your Active Rank: " + activeRank.format() + "[" + rankLabel(activeRank) + "]"),
			Component.literal(""),
			Component.literal("§eIn game: §7buy tab ranks with money below."),
			Component.literal("§dWebsite: §7ranks, money, shards & keys"),
			Component.literal("§7- all for §c§o$0.00§7, delivered in game!")
		)));
		container.setItem(4, titleItem);

		// Grid slots for ranks: row 1 to 3, columns 1 to 7
		List<TabRanks.RankDef> ranks = TabRanks.ranks();
		List<Integer> gridSlots = gridSlots();
		for (int i = 0; i < gridSlots.size(); i++) {
			int slot = gridSlots.get(i);
			if (i < ranks.size()) {
				container.setItem(slot, buildRankIcon(ranks.get(i)));
			} else {
				ItemStack emptyPane = new ItemStack(Compat.pickItem("STAINED_GLASS_PANE", net.minecraft.world.item.DyeColor.GRAY));
				emptyPane.set(DataComponents.CUSTOM_NAME, Component.literal(" "));
				container.setItem(slot, emptyPane);
			}
		}

		// Website link button (slot 45): prints a clickable chat link.
		ItemStack websiteItem = new ItemStack(Items.WRITABLE_BOOK);
		websiteItem.set(DataComponents.CUSTOM_NAME, Component.literal("§d§lOpen the Web Store §7(website)"));
		websiteItem.set(DataComponents.LORE, new ItemLore(List.of(
			Component.literal("§7Ranks, money, shards & crate keys"),
			Component.literal("§7for §c$0.00 §7- pick the Minecraft"),
			Component.literal("§7user to send it to at checkout."),
			Component.literal(""),
			Component.literal("§dClick to get the link in chat!")
		)));
		container.setItem(WEBSITE_SLOT, websiteItem);

		// Web store status + refresh (slot 48)
		ItemStack webItem = new ItemStack(Items.COMPASS);
		webItem.set(DataComponents.CUSTOM_NAME, Component.literal("§dWeb Store Deliveries"));
		webItem.set(DataComponents.LORE, new ItemLore(List.of(
			Component.literal("§7The mod checks the site's orders"),
			Component.literal("§7and hands over what you bought."),
			Component.literal("§7Status: §f" + WebStore.getLastStatus()),
			Component.literal(""),
			Component.literal("§aClick to check for new orders now")
		)));
		container.setItem(WEB_STATUS_SLOT, webItem);

		// Balance indicator (slot 49)
		ItemStack balanceItem = new ItemStack(Items.EMERALD);
		balanceItem.set(DataComponents.CUSTOM_NAME,
			Component.literal("§aYour Balance: §e$" + TrimKits.formatAmount(MarketData.balance(owner.getUUID()))));
		balanceItem.set(DataComponents.LORE, new ItemLore(List.of(
			Component.literal("§7Used to purchase ranks in game.")
		)));
		container.setItem(BALANCE_SLOT, balanceItem);

		// Close button (slot 53)
		ItemStack closeItem = new ItemStack(Items.BARRIER);
		closeItem.set(DataComponents.CUSTOM_NAME, Component.literal("§cClose"));
		container.setItem(CLOSE_SLOT, closeItem);
	}

	private ItemStack buildRankIcon(TabRanks.RankDef rank) {
		ItemStack stack = new ItemStack(rank.icon());
		boolean owned = TabRanks.hasRank(owner, rank.id());
		boolean isActive = rank.id().equalsIgnoreCase(TabRanks.getActiveRank(owner.getUUID()).id());

		String statusColor = isActive ? "§a§l[EQUIPPED]" : (owned ? "§b[OWNED]" : "§e[FOR SALE]");
		stack.set(DataComponents.CUSTOM_NAME,
			Component.literal(rank.format() + rank.sign() + " " + rank.displayName() + " " + statusColor));

		List<Component> lore = new ArrayList<>();
		lore.add(Component.literal("§7" + rank.description()));
		lore.add(Component.literal(""));
		if (rank.price() <= 0) {
			lore.add(Component.literal("§aPrice: §lFREE"));
		} else {
			lore.add(Component.literal("§7Price: §e$" + TrimKits.formatAmount(rank.price())));
		}
		lore.add(Component.literal(""));
		if (isActive) {
			lore.add(Component.literal("§a✔ Currently on your nametag & tablist."));
		} else if (owned) {
			lore.add(Component.literal("§bClick to EQUIP this rank!"));
		} else {
			long balance = MarketData.balance(owner.getUUID());
			if (balance >= rank.price()) {
				lore.add(Component.literal("§a§lClick to BUY this rank!"));
			} else {
				lore.add(Component.literal("§cNot enough money (need $"
					+ TrimKits.formatAmount(rank.price()) + ")"));
			}
		}

		stack.set(DataComponents.LORE, new ItemLore(lore));
		return stack;
	}

	@Override
	public boolean stillValid(Player player) {
		return player == owner;
	}

	@Override
	public ItemStack quickMoveStack(Player player, int index) {
		return ItemStack.EMPTY;
	}

	@Override
	public void clicked(int slotId, int buttonNum, ContainerInput containerInput, Player player) {
		if (slotId < 0 || slotId >= SIZE) return;
		if (!(player instanceof ServerPlayer serverPlayer) || serverPlayer != owner) return;

		if (slotId == CLOSE_SLOT) {
			serverPlayer.closeContainer();
			return;
		}

		// Website link: the GUI closes so the chat message (and its clickable
		// link) is visible, then the URL arrives as an OpenUrl click event.
		if (slotId == WEBSITE_SLOT) {
			String url = Config.getString("webstore.website_url");
			serverPlayer.closeContainer();
			if (url == null || url.isBlank() || url.equalsIgnoreCase("disabled")) {
				serverPlayer.sendSystemMessage(Component.literal(
					"§cThe web store link is not configured on this server."));
				return;
			}
			serverPlayer.sendSystemMessage(Component.literal("§d§l[Store] §7Open the web store:"));
			MutableComponent link = Component.literal("§d§n" + url)
				.withStyle(Style.EMPTY
					.withClickEvent(new ClickEvent.OpenUrl(URI.create(url)))
					.withUnderlined(true));
			serverPlayer.sendSystemMessage(link);
			serverPlayer.sendSystemMessage(Component.literal(
				"§7Everything costs $0.00. At checkout, tell it which Minecraft"));
			serverPlayer.sendSystemMessage(Component.literal(
				"§7user to send the stuff to - it arrives in game automatically."));
			serverPlayer.sendSystemMessage(Component.literal(
				"§8No GitHub account? Copy the order code the site prints into"));
			serverPlayer.sendSystemMessage(Component.literal(
				"§8config/orders.json on the server (or your .minecraft/config in"));
			serverPlayer.sendSystemMessage(Component.literal(
				"§8singleplayer) - it is delivered the same way."));
			return;
		}

		// Check for new web-store orders now.
		if (slotId == WEB_STATUS_SLOT) {
			MinecraftServer server = serverPlayer.level().getServer();
			serverPlayer.sendSystemMessage(Component.literal("§d[Store] §7Checking the web store for orders..."));
			WebStore.poll(server);
			reopen();
			return;
		}

		// Rank click: same purchase/equip path as /tabranks.
		int rankIdx = gridSlots().indexOf(slotId);
		if (rankIdx >= 0 && rankIdx < TabRanks.ranks().size()) {
			TabRanks.RankDef rank = TabRanks.ranks().get(rankIdx);
			if (TabRanks.hasRank(serverPlayer, rank.id())) {
				TabRanks.setActiveRank(serverPlayer.getUUID(), rank.id());
				TabRanks.applyPlayerTab(serverPlayer);
				serverPlayer.sendSystemMessage(Component.literal("§aEquipped rank: "
					+ rank.format() + rank.sign() + " " + rank.displayName() + "§r!"));
				reopen();
			} else {
				String problem = TabRanks.purchase(serverPlayer, rank.id(), serverPlayer.level().registryAccess());
				if (problem != null) {
					serverPlayer.sendSystemMessage(Component.literal("§c" + problem));
				} else {
					serverPlayer.sendSystemMessage(Component.literal("§aPurchased and equipped: "
						+ rank.format() + rank.sign() + " " + rank.displayName() + "§r!"));
					reopen();
				}
			}
		}
	}

	/** The 21 grid positions (rows 1-3, columns 1-7), in display order. */
	private static List<Integer> gridSlots() {
		List<Integer> slots = new ArrayList<>();
		for (int row = 1; row <= 3; row++) {
			for (int column = 1; column <= 7; column++) {
				slots.add(row * 9 + column);
			}
		}
		return slots;
	}

	private static String rankLabel(TabRanks.RankDef rank) {
		return rank.sign() + " " + rank.displayName();
	}

	private void reopen() {
		owner.openMenu(new SimpleMenuProvider(
			(containerId, inventory, viewer) -> new BuyRanksMenu(containerId, inventory, owner),
			Component.literal("Buy Ranks & P2W Store")
		));
	}
}
