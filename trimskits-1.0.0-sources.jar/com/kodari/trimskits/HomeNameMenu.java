package com.kodari.trimskits;

import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AnvilMenu;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;
import net.minecraft.world.level.block.state.BlockState;

/**
 * An anvil-style text box for naming a home - the same familiar rename field the
 * shop search uses. It either creates a new home (captured at the spot you were
 * standing when you confirmed) or renames an existing one, then reopens the
 * right menu.
 *
 * <p>Like {@link SearchInputMenu}, a name tag seeds the input so the text field
 * is live; it can never be taken because every click on the input/result slots
 * is intercepted.
 */
final class HomeNameMenu extends AnvilMenu {
	private final ServerPlayer owner;
	/** True = create a new home; false = rename the one in {@code renameTarget}. */
	private final boolean create;
	/** The existing home being renamed; null when creating. */
	private final String renameTarget;
	private String name;
	private boolean confirmed;

	HomeNameMenu(int containerId, Inventory inventory, ServerPlayer owner, boolean create, String renameTarget, String initial) {
		super(containerId, inventory, ContainerLevelAccess.NULL);
		this.owner = owner;
		this.create = create;
		this.renameTarget = renameTarget;
		this.name = initial == null ? "" : initial;

		ItemStack placeholder = new ItemStack(Items.NAME_TAG);
		placeholder.set(DataComponents.CUSTOM_NAME, Component.literal(this.name));
		placeholder.set(DataComponents.LORE, new ItemLore(List.of(
			Component.literal(create ? "Type a name for this home" : "Type a new name").withStyle(ChatFormatting.GRAY),
			Component.empty(),
			Component.literal("Then click the result to confirm").withStyle(ChatFormatting.GREEN))));
		inputSlots.setItem(INPUT_SLOT, placeholder);
		createResult();
	}

	@Override
	public boolean setItemName(String name) {
		this.name = name == null ? "" : name;
		createResult();
		return true;
	}

	@Override
	public void createResult() {
		String trimmed = name == null ? "" : name.trim();
		String problem = trimmed.isEmpty() ? "Type a name." : Homes.validateName(owner.getUUID(), trimmed, renameTarget);

		ItemStack preview = new ItemStack(Compat.pickItem("BED", DyeColor.BLUE));
		String title = create ? "Create home" : "Rename to";
		preview.set(DataComponents.CUSTOM_NAME, Component.literal("§b" + title + (trimmed.isEmpty() ? "" : " \"" + trimmed + "\"")));

		List<Component> lore = new java.util.ArrayList<>();
		if (trimmed.isEmpty()) {
			preview.set(DataComponents.CUSTOM_NAME, Component.literal("§8Type a name above"));
			lore.add(Component.literal("§7Use the text box to name your home."));
			preview.set(DataComponents.LORE, new ItemLore(lore));
		} else if (problem != null) {
			preview.set(DataComponents.CUSTOM_NAME, Component.literal("§c" + problem));
			lore.add(Component.literal("§c" + problem));
			preview.set(DataComponents.LORE, new ItemLore(lore));
		} else {
			lore.add(Component.literal("§7Name is available."));
			lore.add(Component.empty());
			lore.add(Component.literal("§eClick to confirm"));
			preview.set(DataComponents.LORE, new ItemLore(lore));
		}
		resultSlots.setItem(RESULT_SLOT, preview);
	}

	@Override
	public boolean stillValid(Player player) {
		return player == owner;
	}

	@Override
	protected boolean isValidBlock(BlockState state) {
		return true;
	}

	@Override
	protected boolean mayPickup(Player player, boolean has) {
		return true;
	}

	@Override
	public void removed(Player player) {
		inputSlots.setItem(INPUT_SLOT, ItemStack.EMPTY);
		inputSlots.setItem(ADDITIONAL_SLOT, ItemStack.EMPTY);
		resultSlots.setItem(RESULT_SLOT, ItemStack.EMPTY);
		super.removed(player);
	}

	@Override
	public ItemStack quickMoveStack(Player player, int slotIndex) {
		return ItemStack.EMPTY;
	}

	@Override
	public void clicked(int slotIndex, int buttonNum, ContainerInput containerInput, Player player) {
		if (slotIndex == RESULT_SLOT) {
			confirm();
			return;
		}
		if (slotIndex == INPUT_SLOT || slotIndex == ADDITIONAL_SLOT) {
			return;
		}
		super.clicked(slotIndex, buttonNum, containerInput, player);
	}

	private void confirm() {
		if (confirmed) {
			return;
		}
		String trimmed = name == null ? "" : name.trim();
		if (create) {
			// add() enforces the name rules and the home cap; captures where you
			// stand at confirm time (frozen while the menu is open).
			String problem = Homes.add(owner.getUUID(), trimmed, owner.level().dimension(),
				owner.getX(), owner.getY(), owner.getZ(), owner.getYRot(), owner.getXRot(), Homes.limit());
			if (problem != null) {
				owner.sendSystemMessage(Component.literal(problem));
				return;
			}
			confirmed = true;
			owner.sendSystemMessage(Component.literal("Set home §b" + trimmed + "§r!"));
			owner.closeContainer();
			TrimKits.openHomes(owner, 0);
		} else {
			String problem = Homes.rename(owner.getUUID(), renameTarget, trimmed);
			if (problem != null) {
				owner.sendSystemMessage(Component.literal(problem));
				return;
			}
			confirmed = true;
			owner.sendSystemMessage(Component.literal("Renamed home to §b" + trimmed + "§r."));
			owner.closeContainer();
			TrimKits.openHomeActions(owner, trimmed);
		}
	}
}
