package com.kodari.trimskits;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.component.ItemLore;

/**
 * {@code /sellgui} — a deposit-style selling GUI.
 *
 * <p>Unlike {@link SellMenu}, which shows the whole shop catalogue, this menu is
 * a tray: the player physically places items into the four middle rows and
 * confirms a single bulk transaction. That makes the item-safety rules much
 * sharper than a display-only menu, because real player items live in the
 * container while the menu is open.
 *
 * <p>Design rules, all enforced server-side:
 * <ul>
 *   <li><b>Deposit area</b> = rows 1–4 (slots 9–44). Only these slots are ever
 *       read for value, and only these slots are ever emptied on confirm. The
 *       green confirmation pane sits in the control bar and is therefore never
 *       in the sell set — it cannot be sold, by construction.</li>
 *   <li><b>Control slots</b> (0–8, 45–53) hold panes. A click on them is
 *       intercepted and never reaches the vanilla handler, so they cannot be
 *       picked up. They carry a {@code trimskits_gui} marker in
 *       {@code CUSTOM_DATA} so even a shift-click or number-key swap that
 *       somehow targets them is recognised as a menu object, not an item.</li>
 *   <li><b>Recovery</b>: {@link #removed} returns every deposited stack to the
 *       player (or to mail if their inventory is full) on Escape, death,
 *       dimension change, menu switch and disconnect. Confirm clears the
 *       deposit slots first, so a normal close after a sale returns nothing.</li>
 * </ul>
 *
 * <p>The green pane's display name is pinned by spec to {@code ~$TOTAL} — e.g.
 * {@code ~$0}, {@code ~$125}, {@code ~$12,450}, {@code ~$1.25M} — so it uses
 * {@link TrimKits#formatMoney}. It is recomputed on every change to the deposit
 * from the authoritative server prices, never cached from a client report.
 */
final class SellDepositMenu extends ChestMenu {
	private static final int ROWS = 6;
	private static final int SIZE = ROWS * 9;

	/** Control bar (panes + buttons) lives in the top and bottom rows. */
	private static final int GRID_START = 9;   // first deposit slot (row 1)
	private static final int GRID_END = 44;    // last deposit slot (row 4)

	private static final int SLOT_INSTRUCTIONS = 4;
	private static final int SLOT_BALANCE = 2;
	private static final int SLOT_HEADER = 0;
	private static final int SLOT_FILLER_TOP = 8;

	private static final int SLOT_CANCEL = 47;   // red pane
	private static final int SLOT_CONFIRM = 49;  // green pane, name = ~$TOTAL
	private static final int SLOT_POLICY = 51;   // shulker policy explainer
	private static final int SLOT_CLOSE = 53;    // barrier

	/** Marker stamped into every menu-owned pane so it is never mistaken for loot. */
	private static final String GUI_MARKER = "trimskits_gui";

	private final ServerPlayer owner;
	private final SimpleContainer container;

	/** Authoritative cached total, recomputed from deposit on every change. */
	private long total;
	private int eligibleUnits;
	private ContainerValuer.Policy policy;

	/** Open menus by player, so a disconnect can still salvage deposits. */
	private static final java.util.Map<java.util.UUID, SellDepositMenu> OPEN = new java.util.HashMap<>();

	SellDepositMenu(int containerId, Inventory inventory, ServerPlayer owner) {
		super(MenuType.GENERIC_9x6, containerId, inventory, new SimpleContainer(SIZE), ROWS);
		this.owner = owner;
		this.container = (SimpleContainer) getContainer();
		this.policy = ContainerValuer.Policy.fromConfig();
		OPEN.put(owner.getUUID(), this);
		render();
	}

	// ---- Rendering ---------------------------------------------------------

	private void render() {
		// Control bar only — the deposit rows are the player's and are left
		// exactly as they were, or their items would be wiped every repaint.
		for (int slot = 0; slot < SIZE; slot++) {
			if (inDeposit(slot)) {
				continue;
			}
			container.setItem(slot, paneFor(slot));
		}
		recompute();
		broadcastChanges();
	}

	/** Repaint only the control bar (after a deposit change), keeping loot intact. */
	private void renderBar() {
		for (int slot = 0; slot < SIZE; slot++) {
			if (!inDeposit(slot)) {
				container.setItem(slot, paneFor(slot));
			}
		}
		broadcastChanges();
	}

	private static boolean inDeposit(int slot) {
		return slot >= GRID_START && slot <= GRID_END;
	}

	private ItemStack paneFor(int slot) {
		return switch (slot) {
			case SLOT_HEADER -> infoPane("§6§lSell GUI",
				"§7Place items into the middle rows,",
				"§7then click the green pane to sell.",
				"",
				"§7Current total: §a~" + TrimKits.formatMoney(total),
				"§7Deposit slots: §f" + TrimKits.formatAmount(GRID_END - GRID_START + 1));
			case SLOT_BALANCE -> infoPane("§6Balance: $" + TrimKits.formatMoney(MarketData.balance(owner.getUUID())));
			case SLOT_INSTRUCTIONS -> infoPane("§e§lHow to sell",
				"§71. Drop items in the four middle rows",
				"§72. Watch the green pane total update",
				"§73. Click the green pane to confirm",
				"",
				"§7Shulker boxes: §f" + policyLabel());
			case SLOT_FILLER_TOP -> button(Compat.pickItem("STAINED_GLASS_PANE", DyeColor.GRAY), " ");
			case SLOT_CANCEL -> button(Compat.pickItem("STAINED_GLASS_PANE", DyeColor.RED), "§c§lCancel",
				"§7Returns every deposited item", "§7and sells nothing.");
			case SLOT_CONFIRM -> {
				ItemStack green = button(Compat.pickItem("STAINED_GLASS_PANE", DyeColor.LIME),
					"~" + TrimKits.formatMoney(total),
					"§7Click to sell " + TrimKits.formatAmount(eligibleUnits) + " item(s)",
					"§7for §a$" + TrimKits.formatMoney(total) + "§7.",
					"",
					eligibleUnits == 0 ? "§8Nothing eligible deposited yet."
						: "§aReady to sell.");
				yield green;
			}
			case SLOT_POLICY -> infoPane("§bShulker policy: " + policyLabel(),
				switch (policy) {
					case CONTENTS_AND_BOX -> "§7Sells the contents and the box.";
					case CONTENTS_ONLY -> "§7Sells contents; box returned empty.";
					case BOX_ONLY -> "§7Sells the box itself; never opens it.";
				});
			case SLOT_CLOSE -> button(Items.BARRIER, "§cClose",
				"§7Your deposited items are returned.");
			default -> button(Compat.pickItem("STAINED_GLASS_PANE", DyeColor.GRAY), " ");
		};
	}

	private String policyLabel() {
		return switch (policy) {
			case CONTENTS_AND_BOX -> "Contents + box";
			case CONTENTS_ONLY -> "Contents only";
			case BOX_ONLY -> "Box only";
		};
	}

	// ---- Valuation ---------------------------------------------------------

	/**
	 * Recomputes the authoritative total from whatever is actually in the
	 * deposit rows right now. Deliberately ignores the control bar, so a
	 * confirmation pane or filler can never contribute value.
	 */
	private void recompute() {
		long sum = 0;
		int units = 0;
		long ceiling = Config.getLong("selling.max_container_value");
		int perTransaction = Config.getInt("selling.max_items_per_transaction");
		for (int slot = GRID_START; slot <= GRID_END; slot++) {
			ItemStack stack = container.getItem(slot);
			if (stack.isEmpty()) {
				continue;
			}
			ContainerValuer.Valuation value = ContainerValuer.value(stack, policy);
			if (value.ineligible()) {
				continue;
			}
			sum = Math.min(ceiling, sum + value.value());
			units += value.units();
			if (perTransaction > 0 && units > perTransaction) {
				units = perTransaction;
				break;
			}
		}
		this.total = sum;
		this.eligibleUnits = units;
	}

	// ---- Interaction -------------------------------------------------------

	@Override
	public void clicked(int slotIndex, int buttonNum, ContainerInput containerInput, Player player) {
		if (slotIndex < 0 || slotIndex >= SIZE || !(player instanceof ServerPlayer serverPlayer)) {
			return;
		}

		// Control slots: handled here, vanilla never runs, so panes stay put
		// and cannot be picked up even by a number-key or drag gesture.
		if (!inDeposit(slotIndex)) {
			handleControl(slotIndex, serverPlayer);
			return;
		}

		// Deposit slot: let vanilla move the real item (pickup, place, shift
		// merge, hotbar swap). Then repaint the bar so the total tracks it.
		super.clicked(slotIndex, buttonNum, containerInput, serverPlayer);
		recompute();
		renderBar();
	}

	private void handleControl(int slot, ServerPlayer player) {
		switch (slot) {
			case SLOT_CONFIRM -> confirm(player);
			case SLOT_CANCEL -> {
				cancel(player);
			}
			case SLOT_CLOSE -> player.closeContainer();
			default -> {
				// Header/instructions/policy/fillers: informational only.
			}
		}
	}

	/**
	 * Shift-click: from the player inventory into the deposit area, or from the
	 * deposit area back to the inventory. The control bar is never a target, so
	 * a fast shift-click can never displace a pane.
	 */
	@Override
	public ItemStack quickMoveStack(Player player, int slotIndex) {
		if (slotIndex < 0 || slotIndex >= SIZE) {
			return ItemStack.EMPTY;
		}
		Slot slot = getSlot(slotIndex);
		ItemStack stack = slot.getItem();
		if (stack.isEmpty()) {
			return ItemStack.EMPTY;
		}

		if (inDeposit(slotIndex)) {
			// Deposit -> inventory.
			if (!player.getInventory().add(stack.copy())) {
				player.sendSystemMessage(Component.literal(
					"Your inventory is full - take items out first."));
				return ItemStack.EMPTY;
			}
			slot.remove(stack.getCount());
			slot.setChanged();
		} else if (slotIndex >= SIZE) {
			// Player inventory -> deposit, first slot that will take it.
			int target = firstDepositSlotFor(stack);
			if (target < 0) {
				player.sendSystemMessage(Component.literal(
					"The deposit area is full."));
				return ItemStack.EMPTY;
			}
			ItemStack depositStack = container.getItem(target);
			if (depositStack.isEmpty()) {
				container.setItem(target, stack.copy());
			} else {
				int space = Math.min(stack.getCount(),
					depositStack.getMaxStackSize() - depositStack.getCount());
				if (space <= 0) {
					return ItemStack.EMPTY;
				}
				depositStack.grow(space);
				stack.shrink(space);
				container.setItem(target, depositStack);
			}
			slot.remove(slotIndex >= SIZE ? slot.getItem().getCount() : 0);
			// Clear the source player slot fully for the simple move case.
			slot.set(ItemStack.EMPTY);
			slot.setChanged();
		} else {
			// A control slot: never quick-moved.
			return ItemStack.EMPTY;
		}

		recompute();
		renderBar();
		return ItemStack.EMPTY;
	}

	/** First empty-or-stackable deposit slot, or -1 when the tray is full. */
	private int firstDepositSlotFor(ItemStack stack) {
		for (int slot = GRID_START; slot <= GRID_END; slot++) {
			ItemStack existing = container.getItem(slot);
			if (existing.isEmpty()) {
				return slot;
			}
			if (ItemStack.isSameItemSameComponents(existing, stack)
				&& existing.getCount() < existing.getMaxStackSize()) {
				return slot;
			}
		}
		return -1;
	}

	// ---- Transaction -------------------------------------------------------

	/**
	 * Commits the sale. Re-reads every deposit slot and re-prices it at this
	 * instant — a price change while the menu was open is picked up here, so a
	 * stale preview can never be cashed in. Money is credited only after the
	 * full set of stacks validates, and slots are cleared only after the credit
	 * lands, so a storage failure leaves the player's items untouched.
	 */
	private void confirm(ServerPlayer player) {
		if (!Config.getBoolean("selling.enabled")) {
			player.sendSystemMessage(Component.literal("Selling is disabled on this server."));
			return;
		}
		recompute();
		if (eligibleUnits <= 0 || total <= 0) {
			player.sendSystemMessage(Component.literal(
				"Nothing sellable is deposited. Place items in the middle rows first."));
			renderBar();
			return;
		}

		int perTransaction = Config.getInt("selling.max_items_per_transaction");
		if (perTransaction > 0 && eligibleUnits > perTransaction) {
			player.sendSystemMessage(Component.literal(
				"That is more than the " + TrimKits.formatAmount(perTransaction)
					+ " item(s) allowed per transaction."));
			return;
		}

		// Pass 1: price everything with no side effects. Nothing is credited or
		// removed yet, so a malformed stack or overflow aborts cleanly.
		List<Integer> sellSlots = new ArrayList<>();
		List<Integer> emptiedBoxSlots = new ArrayList<>();
		long grandTotal = 0;
		int units = 0;
		int boxes = 0;
		long ceiling = Config.getLong("selling.max_container_value");

		for (int slot = GRID_START; slot <= GRID_END; slot++) {
			ItemStack stack = container.getItem(slot);
			if (stack.isEmpty()) {
				continue;
			}
			ContainerValuer.Valuation value = ContainerValuer.value(stack, policy);
			if (value.ineligible() || value.value() <= 0) {
				continue;
			}
			if (stack.get(DataComponents.CONTAINER) != null) {
				boxes++;
			}
			try {
				grandTotal = Math.addExact(grandTotal, value.value());
			} catch (ArithmeticException overflow) {
				player.sendSystemMessage(Component.literal("That sale value is too large."));
				return;
			}
			if (grandTotal > ceiling) {
				grandTotal = ceiling;
			}
			units += value.units();
			sellSlots.add(slot);
			if (value.keepBox()) {
				emptiedBoxSlots.add(slot);
			}
		}

		if (grandTotal <= 0 || sellSlots.isEmpty()) {
			player.sendSystemMessage(Component.literal("Nothing eligible could be sold."));
			renderBar();
			return;
		}

		// Pass 2: credit the money first. If this fails we stop with items
		// still in place — never take items for a sale that did not pay.
		if (!MarketData.credit(player.getUUID(), grandTotal, player.level().registryAccess())) {
			player.sendSystemMessage(Component.literal(
				"Could not save the sale - your items were not taken."));
			return;
		}

		// Pass 3: remove the sold stacks. Boxes under CONTENTS_ONLY are emptied
		// and handed back, so nothing a player built is destroyed.
		int returnedBoxes = 0;
		for (int slot : sellSlots) {
			ItemStack stack = container.getItem(slot);
			if (stack.isEmpty()) {
				continue;
			}
			if (emptiedBoxSlots.contains(slot)) {
				ItemStack emptyBox = stack.copy();
				emptyBox.remove(DataComponents.CONTAINER);
				emptyBox.setCount(1);
				giveBack(emptyBox);
				returnedBoxes++;
			}
			getSlot(slot).remove(stack.getCount());
			getSlot(slot).setChanged();
		}

		// Receipt: only now that the credit has committed do we say the number.
		player.sendSystemMessage(Component.literal(
			"§a§lSold §r§a" + TrimKits.formatAmount(units) + " item(s)"
				+ (boxes > 0 ? " in " + TrimKits.formatAmount(boxes) + " container(s)" : "")
				+ " for §a$" + TrimKits.formatMoney(grandTotal) + "§a."));
		if (returnedBoxes > 0) {
			player.sendSystemMessage(Component.literal(
				"Returned " + TrimKits.formatAmount(returnedBoxes) + " emptied shulker box(es)."));
		}
		long kept = countIneligible();
		if (kept > 0) {
			player.sendSystemMessage(Component.literal(
				"§7" + TrimKits.formatAmount(kept) + " item(s) could not be sold and were left in the tray."));
		}
		Ledger.record(player.getUUID(), grandTotal, "sellgui", units + " item(s), " + boxes + " box(es)");
		PlayerStats.recordItemsSold(player.getUUID(), units);

		recompute();
		renderBar();
	}

	/** Deposits left that could not be sold — shown honestly in the receipt. */
	private long countIneligible() {
		long count = 0;
		for (int slot = GRID_START; slot <= GRID_END; slot++) {
			ItemStack stack = container.getItem(slot);
			if (!stack.isEmpty() && ContainerValuer.value(stack, policy).ineligible()) {
				count += stack.getCount();
			}
		}
		return count;
	}

	/** Cancel: hand every deposited stack back and close. */
	private void cancel(ServerPlayer player) {
		salvage(player);
		player.closeContainer();
	}

	/** Returns a stack to the player, falling back to mail when they are full. */
	private void giveBack(ItemStack stack) {
		if (stack.isEmpty()) {
			return;
		}
		if (!owner.getInventory().add(stack.copy())) {
			MarketData.deliver(owner.getUUID(), stack.copy(), "Sell GUI", owner.level().registryAccess());
			owner.sendSystemMessage(Component.literal(
				"Your inventory was full - " + stack.getHoverName().getString()
					+ " was sent to /mail."));
		}
	}

	/**
	 * Returns every deposit slot to the player. Idempotent: slots are emptied
	 * as they are moved, so calling it twice (cancel then close, or close then
	 * disconnect) never returns the same item twice.
	 */
	private void salvage(ServerPlayer player) {
		for (int slot = GRID_START; slot <= GRID_END; slot++) {
			ItemStack stack = container.getItem(slot);
			if (stack.isEmpty()) {
				continue;
			}
			giveBack(stack);
			getSlot(slot).remove(stack.getCount());
			getSlot(slot).setChanged();
		}
		recompute();
	}

	/**
	 * Called whenever the menu closes for any reason — Escape, death, dimension
	 * change, opening another menu, or disconnect. Deposited items are never
	 * silently destroyed: they go back to the inventory, or to mail if it is
	 * full. After a successful confirm the deposit rows are already empty, so a
	 * routine close returns nothing.
	 */
	@Override
	public void removed(Player player) {
		try {
			salvage(owner);
		} finally {
			OPEN.remove(owner.getUUID());
			super.removed(player);
		}
	}

	/** Salvages a specific player's open deposit menu on disconnect. */
	static void salvageOnDisconnect(java.util.UUID playerId, ServerPlayer player) {
		SellDepositMenu menu = OPEN.get(playerId);
		if (menu != null) {
			menu.salvage(player);
			OPEN.remove(playerId);
		}
	}

	static boolean hasOpen(java.util.UUID playerId) {
		return OPEN.containsKey(playerId);
	}

	@Override
	public boolean stillValid(Player player) {
		return true;
	}

	// ---- Pane helpers ------------------------------------------------------

	private static ItemStack button(Item item, String title, String... lore) {
		ItemStack stack = new ItemStack(item);
		stack.set(DataComponents.CUSTOM_NAME, Component.literal(title));
		markGui(stack);
		if (lore.length > 0) {
			List<Component> lines = new ArrayList<>();
			for (String line : lore) {
				lines.add(line.isEmpty() ? Component.empty() : Component.literal(strip(line)));
			}
			stack.set(DataComponents.LORE, new ItemLore(lines));
		}
		return stack;
	}

	private static ItemStack infoPane(String title, String... lore) {
		return button(Items.PAPER, title, lore);
	}

	/**
	 * Stamps a menu-object marker into {@code CUSTOM_DATA}. This is the robust
	 * server-side identification the spec asks for: pane behaviour is keyed off
	 * the slot index (never the visible name), and this marker lets any code
	 * that encounters a stray stack tell a menu object from real loot.
	 */
	private static void markGui(ItemStack stack) {
		net.minecraft.world.item.component.CustomData.update(
			DataComponents.CUSTOM_DATA, stack, tag -> tag.putBoolean(GUI_MARKER, true));
	}

	/** Is this stack a menu object rather than real loot? */
	static boolean isGuiObject(ItemStack stack) {
		if (stack == null || stack.isEmpty()) {
			return false;
		}
		net.minecraft.world.item.component.CustomData data = stack.get(DataComponents.CUSTOM_DATA);
		return data != null && data.copyTag().getBooleanOr(GUI_MARKER, false);
	}

	/** Strips the legacy section-sign prefix from a colour code for plain lore. */
	private static String strip(String line) {
		return line;
	}
}
