package com.kodari.trimskits;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/**
 * The /ranks GUI. Three tabs along the bottom switch the grid between the
 * playtime ladder, the mob crystal ladder and the PvP crystal ladder; each
 * shows which rungs you hold, which is next, and lets you buy it. The daily
 * payout for the playtime rank stays on every tab.
 */
final class RanksMenu extends ChestMenu {
	// 6 rows = 54 slots
	private static final int ROWS = 6;
	private static final int SIZE = ROWS * 9;
	/** First slot of the bottom control row. */
	private static final int BAR = (ROWS - 1) * 9;

	// Layout constants
	/**
	 * Where rank icons go: rows 1-3, columns 1-7 (columns 0 and 8 are the
	 * border panes). 21 slots, comfortably more than the ladder needs, so the
	 * ranks menu can grow without another redesign.
	 */
	private static final List<Integer> RANK_SLOTS = buildRankSlots();
	/** Icon per tier, in order; later tiers fall back to a nether star. */
	private static final List<Item> RANK_ICONS = List.of(
		Items.OAK_LOG, Items.IRON_INGOT, Items.GOLD_INGOT, Items.EMERALD,
		Items.DIAMOND, Items.AMETHYST_SHARD, Items.NETHERITE_INGOT, Items.NETHER_STAR,
		Items.ECHO_SHARD, Items.ELYTRA, Items.BEACON, Items.TOTEM_OF_UNDYING,
		Items.NETHERITE_UPGRADE_SMITHING_TEMPLATE, Items.ENCHANTED_GOLDEN_APPLE, Items.DRAGON_HEAD
	);
	private static final int CLAIM_SLOT = 49;
	private static final int INFO_SLOT = 50;
	private static final int BALANCE_SLOT = 40;
	private static final int CLOSE_SLOT = 53;
	/** Ladder tabs, left to right: playtime ranks, mob crystals, pvp crystals, tab ranks. */
	private static final int TAB_RANKS = 45;
	private static final int TAB_MOB = 46;
	private static final int TAB_PVP = 47;
	private static final int TAB_TABRANKS = 48;

	private static List<Integer> buildRankSlots() {
		List<Integer> slots = new ArrayList<>();
		for (int row = 1; row <= 3; row++) {
			for (int col = 1; col <= 7; col++) {
				slots.add(row * 9 + col);
			}
		}
		return slots;
	}

	private final ServerPlayer owner;
	private final long playtime;
	private final int earnedTier;
	private final int purchasedTier;
	private final int effectiveTier;
	/** Which ladder the grid is showing: 0 playtime, 1 mob crystal, 2 pvp crystal. */
	private int page;

	RanksMenu(int containerId, Inventory inventory, ServerPlayer owner) {
		this(containerId, inventory, owner, 0);
	}

	/** Reopening after a purchase keeps the ladder the player was looking at. */
	RanksMenu(int containerId, Inventory inventory, ServerPlayer owner, int page) {
		super(MenuType.GENERIC_9x6, containerId, inventory, new SimpleContainer(SIZE), ROWS);
		this.owner = owner;
		this.playtime = PlayerStats.playtimeSeconds(owner.getUUID());
		this.earnedTier = RankShop.earnedTier(this.playtime);
		this.purchasedTier = RankShop.purchasedTier(owner.getUUID());
		this.effectiveTier = RankShop.effectiveTier(owner.getUUID(), this.playtime);
		this.page = Math.max(0, Math.min(2, page));

		build();
	}

	private void build() {
		SimpleContainer container = (SimpleContainer) getContainer();

		// Border panes
		ItemStack pane = new ItemStack(Compat.pickItem("STAINED_GLASS_PANE", net.minecraft.world.item.DyeColor.BLACK));
		pane.set(DataComponents.CUSTOM_NAME, Component.literal(" "));
		for (int i = 0; i < SIZE; i++) {
			if (i < 9 || i >= 45 || i % 9 == 0 || i % 9 == 8) {
				container.setItem(i, pane);
			}
		}

		// Clear the ladder area first, or switching tabs leaves the previous
		// ladder's icons behind in the slots the new one does not use.
		for (int slot : RANK_SLOTS) {
			container.setItem(slot, pane);
		}

		// Title row - gold, naming whichever ladder is on screen
		ItemStack title = new ItemStack(Items.PLAYER_HEAD);
		title.set(DataComponents.CUSTOM_NAME, switch (page) {
			case 1 -> Component.literal("MOB CRYSTALS").withStyle(ChatFormatting.GREEN, ChatFormatting.BOLD);
			case 2 -> Component.literal("PVP CRYSTALS").withStyle(ChatFormatting.AQUA, ChatFormatting.BOLD);
			default -> Component.literal("RANKS").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD);
		});
		container.setItem(4, title);

		// Ladder tabs
		container.setItem(TAB_RANKS, tab(Items.CLOCK, "Playtime Ranks", page == 0,
			"§7Climb it by playing the server",
			"§7or by buying the next rank."));
		container.setItem(TAB_MOB, tab(Items.ROTTEN_FLESH, "Mob Crystal Ladder", page == 1,
			"§7Climb it with " + CombatRanks.Ladder.MOB.how() + ".",
			"§7Or buy the next crystal outright."));
		container.setItem(TAB_PVP, tab(Items.IRON_SWORD, "PvP Crystal Ladder", page == 2,
			"§7Climb it with " + CombatRanks.Ladder.PVP.how() + ".",
			"§7Or buy the next crystal outright."));
		container.setItem(TAB_TABRANKS, tab(Items.NAME_TAG, "Tab & Nametag Ranks", false,
			"§7Special badges, unique colors",
			"§7and prefix/suffix display positions.",
			"§eClick to open /tabranks"));

		if (page == 0) {
			buildPlaytimeLadder(container);
		} else {
			buildCrystalLadder(container, page == 1 ? CombatRanks.Ladder.MOB : CombatRanks.Ladder.PVP);
		}

		// Claim daily payout button
		RankShop.Rank current = RankShop.get(effectiveTier);
		if (current.dailyPayout() > 0) {
			ItemStack claim = new ItemStack(Items.SUNFLOWER);
			claim.set(DataComponents.CUSTOM_NAME,
				Component.literal("§a§lClaim Daily Payout").withStyle(ChatFormatting.GREEN));
			claim.set(DataComponents.LORE, new net.minecraft.world.item.component.ItemLore(List.of(
				Component.literal("§7Your rank: " + current.colour() + current.name()),
				Component.literal("§7Daily payout: §a$" + TrimKits.formatAmount(current.dailyPayout())),
				Component.literal(""),
				Component.literal("§eClick to claim")
			)));
			container.setItem(CLAIM_SLOT, claim);
		} else {
			ItemStack noPayout = new ItemStack(Items.WITHER_ROSE);
			noPayout.set(DataComponents.CUSTOM_NAME,
				Component.literal("§cNo Daily Payout").withStyle(ChatFormatting.RED));
			noPayout.set(DataComponents.LORE, new net.minecraft.world.item.component.ItemLore(List.of(
				Component.literal("§7Your rank (" + current.colour() + current.name() + "§7)"),
				Component.literal("§7does not include a daily payout."),
				Component.literal(""),
				Component.literal("§eBuy a higher rank to unlock it.")
			)));
			container.setItem(CLAIM_SLOT, noPayout);
		}

		// Info panel - explains whichever ladder is on screen
		ItemStack info = new ItemStack(Items.BOOK);
		info.set(DataComponents.CUSTOM_NAME,
			Component.literal("§e§lInfo").withStyle(ChatFormatting.YELLOW));
		info.set(DataComponents.LORE, new net.minecraft.world.item.component.ItemLore(infoLore(current)));
		container.setItem(INFO_SLOT, info);

		// Close button
		ItemStack close = new ItemStack(Items.BARRIER);
		close.set(DataComponents.CUSTOM_NAME,
			Component.literal("§cClose").withStyle(ChatFormatting.RED));
		container.setItem(CLOSE_SLOT, close);

		// Balance display (slot 40 - bottom middle)
		ItemStack balance = new ItemStack(Items.EMERALD);
		balance.set(DataComponents.CUSTOM_NAME,
			Component.literal("§aBalance: §r$" + TrimKits.formatAmount(MarketData.balance(owner.getUUID()))));
		balance.set(DataComponents.LORE, new net.minecraft.world.item.component.ItemLore(List.of(
			Component.literal("§7Use this to buy the next rank.")
		)));
		container.setItem(BALANCE_SLOT, balance);
	}

	/** The playtime / money ladder, exactly as it has always looked. */
	private void buildPlaytimeLadder(SimpleContainer container) {
		List<RankShop.Rank> ranks = RankShop.RANKS;
		for (int i = 0; i < ranks.size(); i++) {
			if (i >= RANK_SLOTS.size()) break;
			container.setItem(RANK_SLOTS.get(i), rankIcon(ranks.get(i), i));
		}
	}

	/** One of the two kill ladders: Unranked plus nine crystals, LTW 1 to HTW 3. */
	private void buildCrystalLadder(SimpleContainer container, CombatRanks.Ladder ladder) {
		List<CombatRanks.Crystal> crystals = CombatRanks.tiers(ladder);
		int effective = CombatRanks.effectiveTier(ladder, owner.getUUID());
		for (int i = 0; i < crystals.size() && i < RANK_SLOTS.size(); i++) {
			container.setItem(RANK_SLOTS.get(i), crystalIcon(ladder, crystals.get(i), effective));
		}
	}

	private ItemStack crystalIcon(CombatRanks.Ladder ladder, CombatRanks.Crystal crystal, int effective) {
		ItemStack stack = new ItemStack(crystalIconItem(crystal.tier()));
		boolean owned = crystal.owned(effective);
		String reason = crystal.blocked(effective, ladder);

		Component name = Component.literal(crystal.name())
			.withStyle(owned ? crystal.colour() : ChatFormatting.GRAY);

		List<Component> lore = new ArrayList<>();
		lore.add(Component.literal("§7" + ladder.label() + " ladder, tier " + crystal.tier()
			+ " of " + CombatRanks.tiers(ladder).size()));
		lore.add(Component.literal("§7Climb it with §e" + ladder.how() + "."));
		if (crystal.tier() == 0) {
			lore.add(Component.literal(""));
			lore.add(Component.literal("§7Everyone starts here."));
		} else {
			lore.add(Component.literal(""));
			lore.add(Component.literal("§7Kills needed: §e" + TrimKits.formatAmount(crystal.kills())));
			lore.add(Component.literal("§7Progress: §e"
				+ CombatRanks.progressText(ladder, owner.getUUID())));
			lore.add(Component.literal(""));
			lore.add(Component.literal(owned
				? "§7Price: §cN/A (already owned)"
				: "§7Price: §c$" + TrimKits.formatAmount(crystal.price())));
			lore.add(Component.literal(""));
			if (owned) {
				lore.add(Component.literal("§7Owned ✓"));
			} else if (reason == null) {
				lore.add(Component.literal("§a§lClick to buy!"));
			} else {
				lore.add(Component.literal("§c" + reason));
			}
		}

		stack.set(DataComponents.CUSTOM_NAME, name);
		stack.set(DataComponents.LORE, new net.minecraft.world.item.component.ItemLore(lore));
		return stack;
	}

	/** Low, mid and high tiers get their own icon, so the bands read at a glance. */
	private static Item crystalIconItem(int tier) {
		if (tier >= 7) {
			return Items.DIAMOND;
		}
		if (tier >= 4) {
			return Items.AMETHYST_BLOCK;
		}
		return Items.AMETHYST_SHARD;
	}

	/** A ladder tab in the bottom row; the selected one glows. */
	private static ItemStack tab(Item icon, String label, boolean active, String... detail) {
		ItemStack stack = new ItemStack(icon);
		stack.set(DataComponents.CUSTOM_NAME, Component.literal(label)
			.withStyle(active ? ChatFormatting.GOLD : ChatFormatting.GRAY));
		if (active) {
			stack.set(DataComponents.ENCHANTMENT_GLINT_OVERRIDE, true);
		}
		List<Component> lore = new ArrayList<>();
		for (String line : detail) {
			lore.add(Component.literal(line));
		}
		lore.add(Component.literal(""));
		lore.add(Component.literal(active ? "§6Selected" : "§eClick to view this ladder"));
		stack.set(DataComponents.LORE, new net.minecraft.world.item.component.ItemLore(lore));
		return stack;
	}

	/** The info book, describing whichever ladder is on screen. */
	private List<Component> infoLore(RankShop.Rank current) {
		if (page != 0) {
			CombatRanks.Ladder ladder = page == 1 ? CombatRanks.Ladder.MOB : CombatRanks.Ladder.PVP;
			int earned = CombatRanks.earnedTier(ladder, owner.getUUID());
			int bought = CombatRanks.purchasedTier(ladder, owner.getUUID());
			int held = CombatRanks.effectiveTier(ladder, owner.getUUID());
			return List.of(
				Component.literal("§7Ladder: §e" + ladder.label() + " crystals"),
				Component.literal("§7Climbed with §e" + ladder.how() + "."),
				Component.literal(""),
				Component.literal("§7Earned: " + CombatRanks.get(ladder, earned).colour()
					+ CombatRanks.get(ladder, earned).name()),
				Component.literal("§7Bought: " + (bought > 0
					? CombatRanks.get(ladder, bought).colour() + CombatRanks.get(ladder, bought).name()
					: "§cNone")),
				Component.literal("§7Held: " + CombatRanks.get(ladder, held).colour()
					+ CombatRanks.get(ladder, held).name()),
				Component.literal("§7Progress: §e" + CombatRanks.progressText(ladder, owner.getUUID())),
				Component.literal(""),
				Component.literal("§7Crystals are permanent. You earn them"),
				Component.literal("§7with kills, or buy the next one with money."),
				Component.literal("§7Buying always needs the one below it.")
			);
		}
		return List.of(
			Component.literal("§7Playtime rank: " + RankShop.get(earnedTier).colour() + RankShop.get(earnedTier).name()),
			Component.literal("§7Purchased rank: " + (purchasedTier > 0 ? RankShop.get(purchasedTier).colour() + RankShop.get(purchasedTier).name() : "§cNone")),
			Component.literal("§7Effective rank: " + current.colour() + current.name()),
			Component.literal(""),
			Component.literal("§7Ranks are permanent. You can earn them"),
			Component.literal("§7by playing or buy the next one with money."),
			Component.literal("§7Buying skips straight to that rank."),
			Component.literal(""),
			Component.literal("§7Higher ranks give a daily money payout."),
			Component.literal(""),
			Component.literal("§7Kill ladders live on the two tabs beside this one.")
		);
	}

	private ItemStack rankIcon(RankShop.Rank rank, int index) {
		Item icon = index < RANK_ICONS.size() ? RANK_ICONS.get(index) : Items.NETHER_STAR;
		ItemStack stack = new ItemStack(icon);

		boolean owned = rank.owned(effectiveTier);
		boolean canBuy = rank.blocked(effectiveTier) == null && !owned;

		ChatFormatting nameColour = owned ? rank.colour() : ChatFormatting.GRAY;
		Component name = Component.literal(rank.name()).withStyle(nameColour);

		java.util.List<Component> lore = new java.util.ArrayList<>();
		if (owned) {
			lore.add(Component.literal("§7Owned ✓"));
			lore.add(Component.literal("§7Playtime needed: §e" + RankShop.formatTime(rank.playtimeSeconds())));
			lore.add(Component.literal("§7Price to buy: §cN/A (already owned)"));
			lore.add(Component.literal(""));
			lore.add(Component.literal("§7Daily payout: §a$" + TrimKits.formatAmount(rank.dailyPayout())));
		} else if (canBuy) {
			lore.add(Component.literal("§7Not owned"));
			lore.add(Component.literal("§7Playtime needed: §e" + RankShop.formatTime(rank.playtimeSeconds())));
			lore.add(Component.literal("§7Price: §c$" + TrimKits.formatAmount(rank.price())));
			lore.add(Component.literal(""));
			lore.add(Component.literal("§7Daily payout: §a$" + TrimKits.formatAmount(rank.dailyPayout())));
			lore.add(Component.literal(""));
			lore.add(Component.literal("§a§lClick to buy!"));
		} else {
			String reason = rank.blocked(effectiveTier);
			lore.add(Component.literal("§7Locked"));
			lore.add(Component.literal("§7Playtime needed: §e" + RankShop.formatTime(rank.playtimeSeconds())));
			lore.add(Component.literal("§7Price: §c$" + TrimKits.formatAmount(rank.price())));
			lore.add(Component.literal(""));
			lore.add(Component.literal("§7Daily payout: §a$" + TrimKits.formatAmount(rank.dailyPayout())));
			lore.add(Component.literal(""));
			lore.add(Component.literal("§c" + reason));
		}

		stack.set(DataComponents.CUSTOM_NAME, name);
		stack.set(DataComponents.LORE, new net.minecraft.world.item.component.ItemLore(lore));
		return stack;
	}

	// These three must match AbstractContainerMenu exactly (Player/ContainerInput,
	// not ServerPlayer/ClickAction). Declaring them as overloads instead of
	// overrides silently disables every button and lets the vanilla handler hand
	// the display icons to the player, which is a straight item dupe.

	@Override
	public boolean stillValid(Player player) {
		return player == owner;
	}

	@Override
	public ItemStack quickMoveStack(Player player, int index) {
		// No shift-clicking in or out of the ranks menu.
		return ItemStack.EMPTY;
	}

	@Override
	public void clicked(int slotId, int buttonNum, ContainerInput containerInput, Player player) {
		// Never let the vanilla handler run: the icons are real items and could
		// otherwise be pulled out of the menu.
		if (slotId < 0 || slotId >= SIZE) return;
		if (!(player instanceof ServerPlayer serverPlayer) || serverPlayer != owner) return;

		// Ladder tabs
		if (slotId == TAB_RANKS || slotId == TAB_MOB || slotId == TAB_PVP) {
			showPage(slotId == TAB_RANKS ? 0 : slotId == TAB_MOB ? 1 : 2);
			return;
		}

		if (slotId == TAB_TABRANKS) {
			serverPlayer.openMenu(new SimpleMenuProvider(
				(containerId, inventory, viewer) -> new TabRanksMenu(containerId, inventory, serverPlayer),
				Component.literal("Tab & Nametag Ranks")
			));
			return;
		}

		// Ladder slots
		for (int i = 0; i < RANK_SLOTS.size(); i++) {
			if (slotId != RANK_SLOTS.get(i)) continue;
			if (page == 0) {
				if (i >= RankShop.RANKS.size()) break;
				RankShop.Rank rank = RankShop.RANKS.get(i);
				if (!rank.owned(effectiveTier) && rank.blocked(effectiveTier) == null) {
					buyRank(serverPlayer, i);
				}
			} else {
				CombatRanks.Ladder ladder = page == 1 ? CombatRanks.Ladder.MOB : CombatRanks.Ladder.PVP;
				List<CombatRanks.Crystal> crystals = CombatRanks.tiers(ladder);
				if (i >= crystals.size()) break;
				CombatRanks.Crystal crystal = crystals.get(i);
				int held = CombatRanks.effectiveTier(ladder, serverPlayer.getUUID());
				if (!crystal.owned(held) && crystal.blocked(held, ladder) == null) {
					buyCrystal(serverPlayer, ladder, crystal.tier());
				}
			}
			return;
		}

		// Claim daily payout
		if (slotId == CLAIM_SLOT) {
			claimPayout(serverPlayer);
			return;
		}

		// Close
		if (slotId == CLOSE_SLOT || slotId == INFO_SLOT) {
			serverPlayer.closeContainer();
			return;
		}
	}

	/** Swaps the grid over to another ladder, keeping the menu open. */
	private void showPage(int nextPage) {
		if (page == nextPage) {
			return;
		}
		page = nextPage;
		build();
		broadcastChanges();
	}

	private void reopen() {
		owner.openMenu(new SimpleMenuProvider(
			(containerId, inventory, viewer) -> new RanksMenu(containerId, inventory, owner, page),
			Component.literal("Ranks")
		));
	}

	private void buyRank(ServerPlayer player, int tier) {
		MinecraftServer server = player.level().getServer();
		if (server == null) return;
		server.execute(() -> {
			if (player.containerMenu != this) return;
			String problem = RankShop.purchase(player, tier, player.level().registryAccess());
			if (problem != null) {
				player.sendSystemMessage(Component.literal(problem));
			} else {
				player.sendSystemMessage(Component.literal("You are now a " +
					RankShop.get(tier).colour() + RankShop.get(tier).name() + "§r!"));
				reopen();
			}
		});
	}

	/** Buys the next rung of the ladder the player is currently looking at. */
	private void buyCrystal(ServerPlayer player, CombatRanks.Ladder ladder, int tier) {
		MinecraftServer server = player.level().getServer();
		if (server == null) return;
		server.execute(() -> {
			if (player.containerMenu != this) return;
			String problem = CombatRanks.purchase(player, ladder, tier, player.level().registryAccess());
			if (problem != null) {
				player.sendSystemMessage(Component.literal(problem));
			} else {
				player.sendSystemMessage(Component.literal("You now hold " +
					CombatRanks.get(ladder, tier).colour() + CombatRanks.get(ladder, tier).name() + "§r!"));
				reopen();
			}
		});
	}

	private void claimPayout(ServerPlayer player) {
		MinecraftServer server = player.level().getServer();
		if (server == null) return;
		server.execute(() -> {
			if (player.containerMenu != this) return;
			long paid = RankShop.claimPayout(player, player.level().registryAccess());
			if (paid < 0) {
				player.sendSystemMessage(Component.literal("Could not process the payout; try again later."));
			} else if (paid == 0) {
				long wait = RankShop.millisUntilPayout(player.getUUID());
				if (wait > 0) {
					long hours = (wait + 3_599_999) / 3_600_000;
					player.sendSystemMessage(Component.literal("Daily payout already claimed. Next in ~" + hours + " hour(s)."));
				} else {
					player.sendSystemMessage(Component.literal("Your rank does not have a daily payout."));
				}
			} else {
				player.sendSystemMessage(Component.literal("Claimed daily payout: $" + TrimKits.formatAmount(paid) + "."));
				reopen();
			}
		});
	}
}