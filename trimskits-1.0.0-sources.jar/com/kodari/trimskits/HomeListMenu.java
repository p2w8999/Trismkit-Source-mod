package com.kodari.trimskits;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;

/**
 * The /home GUI - a wall of beds (double-chest sized, bigger than a single
 * chest). White beds are empty slots you click to set a home right where you
 * stand; blue beds are homes you already have, which open a management menu.
 * Multiple pages hold as many homes as the configured cap allows.
 */
final class HomeListMenu extends ChestMenu {
	// 6 rows = 54 slots (the largest vanilla container - a double chest)
	private static final int ROWS = 6;
	private static final int SIZE = ROWS * 9;

	/** Home beds go in rows 1-4, columns 1-7 (columns 0/8 are the border). */
	private static final List<Integer> HOME_SLOTS = buildHomeSlots();
	private static final int PER_PAGE = HOME_SLOTS.size();

	// Control row (bottom row) layout
	private static final int PREV_SLOT = 45;
	private static final int NEXT_SLOT = 46;
	private static final int SET_SLOT = 48;
	private static final int PAGE_SLOT = 49;
	private static final int COUNT_SLOT = 50;
	private static final int CLOSE_SLOT = 53;
	private static final int TITLE_SLOT = 4;

	private final ServerPlayer owner;
	private int page;

	HomeListMenu(int containerId, Inventory inventory, ServerPlayer owner, int page) {
		super(MenuType.GENERIC_9x6, containerId, inventory, new SimpleContainer(SIZE), ROWS);
		this.owner = owner;
		this.page = page;
		build();
	}

	private static List<Integer> buildHomeSlots() {
		List<Integer> slots = new ArrayList<>();
		for (int row = 1; row <= 4; row++) {
			for (int col = 1; col <= 7; col++) {
				slots.add(row * 9 + col);
			}
		}
		return slots;
	}

	private void build() {
		SimpleContainer container = (SimpleContainer) getContainer();
		List<Homes.Home> homes = Homes.homes(owner.getUUID());
		int totalPages = pageCount(homes.size());
		// Keep the page in range if homes were deleted while a menu was open.
		if (page >= totalPages) page = totalPages - 1;
		if (page < 0) page = 0;

		// Border panes around the top and sides.
		ItemStack pane = new ItemStack(Compat.pickItem("STAINED_GLASS_PANE", DyeColor.BLACK));
		pane.set(DataComponents.CUSTOM_NAME, Component.literal(" "));
		for (int i = 0; i < SIZE; i++) {
			if (i < 9 || i % 9 == 0 || i % 9 == 8) {
				container.setItem(i, pane);
			}
		}

		// Title
		ItemStack title = new ItemStack(Items.PLAYER_HEAD);
		title.set(DataComponents.CUSTOM_NAME, Component.literal("§b§lHOMES").withStyle(ChatFormatting.AQUA));
		title.set(DataComponents.LORE, new ItemLore(List.of(
			Component.literal("§7Click an empty bed to set a home here."),
			Component.literal("§7Click a blue bed to manage a home.")
		)));
		container.setItem(TITLE_SLOT, title);

		// Home beds for the current page.
		int start = page * PER_PAGE;
		for (int i = 0; i < PER_PAGE; i++) {
			int slot = HOME_SLOTS.get(i);
			int homeIndex = start + i;
			if (homeIndex < homes.size()) {
				container.setItem(slot, homeBed(homes.get(homeIndex)));
			} else {
				container.setItem(slot, emptyBed());
			}
		}

		// Control bar.
		int totalPagesFinal = totalPages;
		container.setItem(PREV_SLOT, pageControl(
			Items.ARROW, "§ePrevious Page",
			page > 0 ? List.of(Component.literal("§7Go to page " + page + " of " + totalPagesFinal)) : List.of(Component.literal("§8No previous page"))));
		container.setItem(NEXT_SLOT, pageControl(
			Items.ARROW, "§eNext Page",
			page < totalPagesFinal - 1 ? List.of(Component.literal("§7Go to page " + (page + 2) + " of " + totalPagesFinal)) : List.of(Component.literal("§8No next page"))));

		ItemStack decor = new ItemStack(Compat.pickItem("STAINED_GLASS_PANE", DyeColor.BLACK));
		decor.set(DataComponents.CUSTOM_NAME, Component.literal(" "));
		container.setItem(47, decor);
		container.setItem(51, decor);
		container.setItem(52, decor);

		ItemStack set = new ItemStack(Items.SUNFLOWER);
		set.set(DataComponents.CUSTOM_NAME, Component.literal("§a§lSet Home Here").withStyle(ChatFormatting.GREEN));
		set.set(DataComponents.LORE, new ItemLore(List.of(
			Component.literal("§7Create a new home at the spot"),
			Component.literal("§7you are standing on right now."),
			Component.empty(),
			Component.literal("§eClick to set a home")
		)));
		container.setItem(SET_SLOT, set);

		ItemStack pageBook = new ItemStack(Items.WRITABLE_BOOK);
		pageBook.set(DataComponents.CUSTOM_NAME, Component.literal("§ePage " + (page + 1) + "§7/§e" + totalPages).withStyle(ChatFormatting.YELLOW));
		pageBook.set(DataComponents.LORE, new ItemLore(List.of(Component.literal("§7Use the arrows to turn pages."))));
		container.setItem(PAGE_SLOT, pageBook);

		int used = homes.size();
		int limit = Homes.limit();
		ItemStack count = new ItemStack(Items.NAME_TAG);
		count.set(DataComponents.CUSTOM_NAME, Component.literal("§f" + used + "§7/§f" + limit + " §7homes").withStyle(ChatFormatting.WHITE));
		count.set(DataComponents.LORE, new ItemLore(List.of(
			Component.literal("§7You have " + (limit - used) + " home(s) left."),
			Component.empty(),
			Component.literal("§7Cap is set in config/trimskits.json")
		)));
		container.setItem(COUNT_SLOT, count);

		ItemStack close = new ItemStack(Items.BARRIER);
		close.set(DataComponents.CUSTOM_NAME, Component.literal("§cClose").withStyle(ChatFormatting.RED));
		container.setItem(CLOSE_SLOT, close);
	}

	private int pageCount(int homes) {
		int pages = (homes + PER_PAGE - 1) / PER_PAGE;
		return Math.max(1, pages);
	}

	private ItemStack homeBed(Homes.Home home) {
		ItemStack stack = new ItemStack(bed(DyeColor.BLUE));
		stack.set(DataComponents.CUSTOM_NAME, Component.literal("§b" + home.name()).withStyle(ChatFormatting.AQUA));
		stack.set(DataComponents.LORE, new ItemLore(List.of(
			Component.literal("§7" + home.dimensionLabel()),
			Component.literal(String.format("§7%.0f, %.0f, %.0f", home.x(), home.y(), home.z())),
			Component.empty(),
			Component.literal("§eClick to manage")
		)));
		return stack;
	}

	private ItemStack emptyBed() {
		ItemStack stack = new ItemStack(bed(DyeColor.WHITE));
		stack.set(DataComponents.CUSTOM_NAME, Component.literal("§fSet a Home").withStyle(ChatFormatting.WHITE));
		stack.set(DataComponents.LORE, new ItemLore(List.of(
			Component.literal("§7Empty slot - click to create"),
			Component.literal("§7a home at your current location."),
			Component.empty(),
			Component.literal("§aClick to set a home")
		)));
		return stack;
	}

	private ItemStack pageControl(Item icon, String name, List<Component> lore) {
		ItemStack stack = new ItemStack(icon);
		stack.set(DataComponents.CUSTOM_NAME, Component.literal(name).withStyle(ChatFormatting.YELLOW));
		// Copy into a mutable list - the caller passes an immutable List.of(...).
		List<Component> lines = new ArrayList<>(lore);
		lines.add(Component.empty());
		lines.add(Component.literal("§eClick to turn"));
		stack.set(DataComponents.LORE, new ItemLore(lines));
		return stack;
	}

	private static Item bed(DyeColor colour) {
		return Compat.pickItem("BED", colour);
	}

	@Override
	public boolean stillValid(Player player) {
		return player == owner;
	}

	@Override
	public ItemStack quickMoveStack(Player player, int index) {
		// No shift-clicking; the beds are display icons, not real items.
		return ItemStack.EMPTY;
	}

	@Override
	public void clicked(int slotId, int buttonNum, ContainerInput containerInput, Player player) {
		// Never let the vanilla handler hand out the icons.
		if (slotId < 0 || slotId >= SIZE) return;
		if (!(player instanceof ServerPlayer serverPlayer) || serverPlayer != owner) return;

		// Home beds
		for (int i = 0; i < HOME_SLOTS.size(); i++) {
			if (slotId == HOME_SLOTS.get(i)) {
				int homeIndex = page * PER_PAGE + i;
				List<Homes.Home> homes = Homes.homes(owner.getUUID());
				if (homeIndex < homes.size()) {
					TrimKits.openHomeActions(serverPlayer, homes.get(homeIndex).name());
				} else {
					startCreate(serverPlayer);
				}
				return;
			}
		}

		if (slotId == PREV_SLOT) {
			if (page > 0) TrimKits.openHomes(serverPlayer, page - 1);
			return;
		}
		if (slotId == NEXT_SLOT) {
			if (page < pageCount(Homes.count(owner.getUUID())) - 1) TrimKits.openHomes(serverPlayer, page + 1);
			return;
		}
		if (slotId == SET_SLOT) {
			startCreate(serverPlayer);
			return;
		}
		if (slotId == CLOSE_SLOT || slotId == PAGE_SLOT || slotId == COUNT_SLOT || slotId == TITLE_SLOT) {
			serverPlayer.closeContainer();
			return;
		}
		// Border panes and everything else: ignore.
	}

	/** Guards the home cap up front so the name box only opens when a home fits. */
	private void startCreate(ServerPlayer player) {
		if (Homes.count(player.getUUID()) >= Homes.limit()) {
			player.sendSystemMessage(Component.literal("You already have the maximum of " + Homes.limit() + " homes."));
			return;
		}
		TrimKits.openHomeCreateName(player);
	}
}
