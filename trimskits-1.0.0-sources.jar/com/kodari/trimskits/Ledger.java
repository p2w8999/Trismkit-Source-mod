package com.kodari.trimskits;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.Instant;

/**
 * The audit trail behind every large movement of money: one append-only line
 * per event in config/trimskits-ledger.log.
 *
 * <p>Nothing here feeds the economy - balances stay where they were - this is
 * for the admin who logs in to find that somebody has $40 billion and needs to
 * know whether the shop paid it or a bug did. A line is
 * {@code instant|player|delta|where|detail}: delta is signed, "where" is a short
 * tag like "sell" or "ah-buy", and detail is free text (a shop item, a target
 * name). Timestamps come from {@link Instant} so the log sorts correctly across
 * restarts and time zones.
 *
 * <p>Writing is best effort and never throws into gameplay: if the disk is
 * full the economy keeps running and the line is dropped. The file is trimmed
 * on first write of a session when it passes twice {@link #MAX_LINES}, so it
 * cannot grow without bound on a server that has been open for a year.
 */
final class Ledger {
	private static final Path LOG_FILE = Path.of("config", "trimskits-ledger.log");
	/** Twice the kept size, checked once per session. */
	private static final int MAX_LINES = 20_000;
	private static boolean trimmed;

	private Ledger() {
	}

	/**
	 * Records one money movement.
	 *
	 * @param playerId who it happened to (null for the server, e.g. a tax burn)
	 * @param delta    signed change in dollars; negative means they paid out
	 * @param where    a short tag naming the feature, "sell", "ah-buy", "tax"
	 * @param detail   free text: what was sold, who was paid, which item
	 */
	static synchronized void record(java.util.UUID playerId, long delta, String where, String detail) {
		if (!Config.getBoolean("economy.ledger_enabled")) {
			return;
		}
		try {
			if (!trimmed) {
				trimmed = true;
				trimIfNeeded();
			}
			Files.createDirectories(LOG_FILE.getParent());
			String name = playerId == null ? "-" : playerName(playerId);
			String line = Instant.now() + "|" + name + "|" + delta + "|" + where + "|" + detail + "\n";
			try (BufferedWriter writer = Files.newBufferedWriter(LOG_FILE, StandardCharsets.UTF_8,
				StandardOpenOption.CREATE, StandardOpenOption.APPEND)) {
				writer.write(line);
			}
		} catch (IOException ignored) {
			// An audit trail is never worth failing a sale over.
		}
	}

	/** The player's last known name, or their UUID when nobody has seen them. */
	private static String playerName(java.util.UUID playerId) {
		String name = PlayerStats.nameOf(playerId);
		return name == null || name.isBlank() ? playerId.toString() : name;
	}

	/** Cuts the log down to its newest half when it has grown too far. */
	private static void trimIfNeeded() throws IOException {
		if (!Files.exists(LOG_FILE) || Files.size(LOG_FILE) < 4_000_000L) {
			return;
		}
		java.util.List<String> lines = Files.readAllLines(LOG_FILE, StandardCharsets.UTF_8);
		if (lines.size() <= MAX_LINES) {
			return;
		}
		Files.write(LOG_FILE, lines.subList(lines.size() - MAX_LINES, lines.size()),
			StandardCharsets.UTF_8, StandardOpenOption.TRUNCATE_EXISTING);
	}
}
