package com.kodari.trimskits;

import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundTabListPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

/**
 * A tab-list roster sent as the vanilla tab header/footer, so it works in
 * singleplayer too (the integrated server sends the same packets). Every
 * online player is listed with their rank badge and their ping in ms.
 *
 * <p>The roster is rebuilt and re-sent for each viewer on a slow tick (see
 * {@code tab.list_interval_ticks}); the header carries the roster lines and
 * the footer carries the viewer's own ping plus an {@code /applications}
 * hint. Config keys: {@code tab.list_enabled}, {@code tab.list_interval_ticks},
 * {@code tab.list_max_players}.
 */
final class TabListInfo {
	/** Largest roster we will print before truncating with a "+N more" line. */
	private static final int MAX_LINES = 12;

	private TabListInfo() {
	}

	/**
	 * Called from the server tick; cheap when disabled (single boolean read).
	 */
	static void tick(MinecraftServer server) {
		if (!Config.getBoolean("tab.list_enabled")) {
			return;
		}
		long interval = Math.max(1L, Config.getLong("tab.list_interval_ticks"));
		if (server.getTickCount() % interval != 0) {
			return;
		}
		int maxPlayers = Config.getInt("tab.list_max_players");
		List<ServerPlayer> players = server.getPlayerList().getPlayers();
		if (players.isEmpty()) {
			return;
		}
		Component header = buildHeader(players, maxPlayers);
		for (ServerPlayer viewer : players) {
			Component footer = buildFooter(viewer);
			viewer.connection.send(new ClientboundTabListPacket(header, footer));
		}
	}

	/** The roster: one line per online player, capped at {@link #MAX_LINES}. */
	private static Component buildHeader(List<ServerPlayer> players, int maxPlayers) {
		StringBuilder text = new StringBuilder("§6§l» §eOnline §7- §f" + players.size());
		int shown = Math.min(players.size(), Math.min(MAX_LINES, Math.max(1, maxPlayers)));
		for (int i = 0; i < shown; i++) {
			ServerPlayer player = players.get(i);
			text.append('\n').append('§').append('7')
				.append(player.getScoreboardName())
				.append(" §8- ").append(rankBadge(player))
				.append(" §8- ").append('§').append('f')
				.append(player.connection.latency()).append("ms");
		}
		if (players.size() > shown) {
			text.append("\n§8+").append(players.size() - shown).append(" more...");
		}
		return Component.literal(text.toString());
	}

	/** The viewer's own ping plus an applications hint. */
	private static Component buildFooter(ServerPlayer viewer) {
		return Component.literal(
			"§7Your ping: §f" + viewer.connection.latency() + "ms"
			+ "\n§8Type §r/applications §8to apply for staff.");
	}

	/** The viewer-visible rank badge: staff rank first, then the tab-rank. */
	private static String rankBadge(ServerPlayer player) {
		String staff = Applications.staffRoleDisplay(player.getUUID());
		if (staff != null) {
			return staff;
		}
		TabRanks.RankDef rank = TabRanks.getActiveRank(player.getUUID());
		if (rank != null && !"player".equals(rank.id())) {
			return rank.format() + rank.displayName() + "§r";
		}
		return "§7-";
	}
}
