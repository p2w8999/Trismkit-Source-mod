package com.kodari.trimskits;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;
import net.minecraft.core.RegistryAccess;
import net.minecraft.server.level.ServerPlayer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * A weekly-ish lottery: buy tickets with money, and on the draw one ticket
 * wins most of the pot.
 *
 * <p>The pot is a genuine sink - every ticket is destroyed money, and the
 * winner takes the pot minus a house cut that is also destroyed. That keeps
 * the money supply honest: the lottery cannot mint value, it only moves it
 * (and removes a slice on the way).
 *
 * <p>State is a single pot total plus the tickets bought since the last draw,
 * persisted beside the other economy files. The draw itself is driven from the
 * server tick, so it needs no operator and no player to be online at the
 * moment it fires - though the winner, if offline, is simply a name in the log
 * and a line in /lottery history, since money can be credited offline safely.
 */
final class Lottery {
	private static final Logger LOGGER = LoggerFactory.getLogger("trimskits");
	private static final Path DATA_FILE = Path.of("config", "trimskits-lottery.properties");

	/** Share of the pot the house burns on a draw, as a percentage. */
	static final long HOUSE_CUT_PERCENT = 10L;

	private static long pot;
	/** Ticket -> how many tickets that player holds in this round. */
	private static final Map<UUID, Integer> TICKETS = new HashMap<>();
	/** Recent winning lines, newest first, for the /lottery history view. */
	private static final List<String> HISTORY = new ArrayList<>();
	private static boolean loaded;
	private static boolean readable = true;

	/** How many history lines to keep. */
	private static final int HISTORY_LINES = 10;

	private Lottery() {
	}

	static synchronized long pot() {
		load();
		return pot;
	}

	/** How many tickets one player is holding this round. */
	static synchronized int ticketsOf(UUID playerId) {
		load();
		return TICKETS.getOrDefault(playerId, 0);
	}

	/** The total number of tickets in the drum. */
	static synchronized int totalTickets() {
		load();
		int total = 0;
		for (int count : TICKETS.values()) {
			total += count;
		}
		return total;
	}

	/**
	 * Buys tickets, burning the money as it goes.
	 *
	 * @return null on success, or the reason it did not happen
	 */
	static synchronized String buy(ServerPlayer player, int tickets, long priceEach, RegistryAccess registries) {
		load();
		if (tickets <= 0) {
			return "Buy at least one ticket.";
		}
		long cost;
		try {
			cost = Math.multiplyExact(priceEach, tickets);
		} catch (ArithmeticException exception) {
			return "That is more tickets than the economy can count.";
		}
		if (!MarketData.debit(player.getUUID(), cost, registries)) {
			return "That costs $" + TrimKits.formatAmount(cost)
				+ " and you have $" + TrimKits.formatAmount(MarketData.balance(player.getUUID())) + ".";
		}
		TICKETS.merge(player.getUUID(), tickets, Integer::sum);
		pot += cost;
		if (!save()) {
			TICKETS.merge(player.getUUID(), -tickets, Integer::sum);
			pot -= cost;
			MarketData.credit(player.getUUID(), cost, registries);
			return "The lottery could not be saved; you were not charged.";
		}
		Ledger.record(player.getUUID(), -cost, "lottery", tickets + " ticket(s)");
		return null;
	}

	/**
	 * Draws the drum. Every ticket in play is an equal chance; ties are broken
	 * by the natural order of the map iteration, which is fine for a raffle.
	 *
	 * @return the winning name, or null when there was nothing to draw
	 */
	static synchronized String draw(RegistryAccess registries) {
		load();
		if (TICKETS.isEmpty() || totalTickets() <= 0) {
			return null;
		}
		int drum = totalTickets();
		int winningTicket = (int) (Math.random() * drum);
		UUID winner = null;
		int seen = 0;
		for (Map.Entry<UUID, Integer> entry : TICKETS.entrySet()) {
			seen += entry.getValue();
			if (winningTicket < seen) {
				winner = entry.getKey();
				break;
			}
		}
		if (winner == null) {
			return null;
		}
		long gross = pot;
		long burn = gross * HOUSE_CUT_PERCENT / 100;
		long payout = gross - burn;
		String winnerName = playerName(winner);
		MarketData.credit(winner, payout, registries);
		Ledger.record(winner, payout, "lottery-win", "of $" + gross);
		Ledger.record(null, -burn, "lottery-burn", "house cut");
		pot = 0;
		TICKETS.clear();
		HISTORY.add(0, winnerName + " won $" + TrimKits.formatAmount(payout)
			+ " from " + drum + " ticket(s).");
		while (HISTORY.size() > HISTORY_LINES) {
			HISTORY.remove(HISTORY.size() - 1);
		}
		save();
		return winnerName + " won $" + TrimKits.formatAmount(payout)
			+ " from a pot of $" + TrimKits.formatAmount(gross) + "!";
	}

	/** The recent draws, newest first. */
	static synchronized List<String> history() {
		load();
		return List.copyOf(HISTORY);
	}

	/** The price of a single ticket, from the config, never free. */
	static long ticketPrice() {
		return Math.max(1L, Config.getLong("economy.lottery_ticket_price"));
	}

	/** How long between draws, in minutes, from the config. */
	static long drawMinutes() {
		return Math.max(1L, Config.getLong("economy.lottery_draw_minutes"));
	}

	private static String playerName(UUID playerId) {
		String name = PlayerStats.nameOf(playerId);
		return name == null || name.isBlank() ? playerId.toString() : name;
	}

	private static void load() {
		if (loaded) {
			return;
		}
		loaded = true;
		if (!Files.exists(DATA_FILE)) {
			return;
		}
		Properties properties = new Properties();
		try (InputStream input = Files.newInputStream(DATA_FILE)) {
			properties.load(input);
		} catch (IOException exception) {
			readable = false;
			LOGGER.warn("Could not read {}; lottery stays in memory only.", DATA_FILE);
			return;
		}
		pot = Math.max(0L, Long.parseLong(properties.getProperty("pot", "0")));
		for (String key : properties.stringPropertyNames()) {
			if (key.startsWith("tickets.")) {
				try {
					TICKETS.put(UUID.fromString(key.substring("tickets.".length())),
						Math.max(0, Integer.parseInt(properties.getProperty(key))));
				} catch (RuntimeException ignored) {
					// Skip a damaged line.
				}
			} else if (key.startsWith("history.")) {
				HISTORY.add(properties.getProperty(key));
			}
		}
		HISTORY.sort((left, right) -> 0); // keep file order
	}

	private static boolean save() {
		if (!readable) {
			return false;
		}
		Properties properties = new Properties();
		properties.setProperty("pot", Long.toString(pot));
		TICKETS.forEach((playerId, count) ->
			properties.setProperty("tickets." + playerId, Integer.toString(count)));
		for (int index = 0; index < HISTORY.size(); index++) {
			properties.setProperty("history." + index, HISTORY.get(index));
		}
		Path temporaryFile = DATA_FILE.resolveSibling("trimskits-lottery.tmp");
		try {
			Files.createDirectories(DATA_FILE.getParent());
			try (OutputStream output = Files.newOutputStream(temporaryFile)) {
				properties.store(output, "Trim Kits lottery");
			}
			try {
				Files.move(temporaryFile, DATA_FILE, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
			} catch (AtomicMoveNotSupportedException exception) {
				Files.move(temporaryFile, DATA_FILE, StandardCopyOption.REPLACE_EXISTING);
			}
			return true;
		} catch (IOException exception) {
			LOGGER.warn("Could not save the lottery: {}", exception.getMessage());
			return false;
		}
	}
}
