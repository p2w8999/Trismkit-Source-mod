package com.kodari.trimskits;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.RegistryAccess;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.ItemEnchantments;

/**
 * One enchantment the buy screen can stamp onto an order, and the price of
 * doing so.
 *
 * <p>Pricing follows the live market: a vanilla enchant costs exactly what its
 * book currently costs ({@link ShopValues#enchantWorth}) and that is also what
 * it adds back on resale - break-even at worst, whatever either price has done
 * since. Custom enchants cost their book's current price
 * ({@link ShopValues#customBookPrice}), which sits above the 72.5% they return
 * when sold, so a resale is a small loss rather than a loop.
 *
 * <p>The book item itself is never offered: an enchanted book <em>is</em> an
 * enchantment, and adding lore to one would stop it matching its shop entry.
 */
final class EnchantOffer {
	private final String id;
	private final Component label;
	private final long price;
	private final int level;
	/** Set for this server's custom enchants; null for vanilla ones. */
	private final CustomEnchants.Type custom;
	/** Set for vanilla enchants; null for custom ones. */
	private final Holder<Enchantment> vanilla;

	private EnchantOffer(String id, Component label, long price, int level,
			CustomEnchants.Type custom, Holder<Enchantment> vanilla) {
		this.id = id;
		this.label = label;
		this.price = price;
		this.level = level;
		this.custom = custom;
		this.vanilla = vanilla;
	}

	String id() {
		return id;
	}

	/** Display name: "Smelter III" in its colour, or the vanilla fullname. */
	Component label() {
		return label;
	}

	/** Per-item cost added to the order when this enchant is selected. */
	long price() {
		return price;
	}

	int level() {
		return level;
	}

	boolean isCustom() {
		return custom != null;
	}

	CustomEnchants.Type customType() {
		return custom;
	}

	Holder<Enchantment> vanillaEnchant() {
		return vanilla;
	}

	/**
	 * Everything that can still be added to this stack right now, custom
	 * enchants first. Skips anything the stack already carries at the offered
	 * level, so nobody is charged for nothing.
	 */
	static List<EnchantOffer> offersFor(RegistryAccess registries, ItemStack target) {
		List<EnchantOffer> offers = new ArrayList<>();
		if (target == null || target.isEmpty() || target.getItem() == Items.ENCHANTED_BOOK) {
			return offers;
		}

		for (CustomEnchants.Type type : CustomEnchants.Type.values()) {
			if (!CustomEnchants.compatible(type, target)
					|| CustomEnchants.levelOf(target, type) >= type.maxLevel()) {
				continue;
			}
			offers.add(customOffer(type));
		}

		// Vanilla enchants only make sense on gear with durability: blocks would
		// carry components they can never use, and books are excluded above.
		if (target.getMaxDamage() > 0) {
			Registry<Enchantment> registry;
			try {
				registry = registries.lookupOrThrow(Registries.ENCHANTMENT);
			} catch (RuntimeException exception) {
				return offers;
			}
			ItemEnchantments applied = target.get(DataComponents.ENCHANTMENTS);
			List<EnchantOffer> vanillaOffers = new ArrayList<>();
			for (var candidate : registry.entrySet()) {
				Holder<Enchantment> holder = registry.get(candidate.getKey()).orElse(null);
				if (holder == null) {
					continue;
				}
				Enchantment enchantment = holder.value();
				int level = enchantment.getMaxLevel();
				if (level < 1 || !enchantment.isSupportedItem(target)) {
					continue;
				}
				if (applied != null && applied.getLevel(holder) >= level) {
					continue;
				}
				vanillaOffers.add(new EnchantOffer("vanilla:" + candidate.getKey().identifier().getPath(),
					Enchantment.getFullname(holder, level),
					ShopValues.enchantWorth(holder, level),
					level, null, holder));
			}
			vanillaOffers.sort(Comparator.comparing(EnchantOffer::id));
			offers.addAll(vanillaOffers);
		}
		return offers;
	}

	private static EnchantOffer customOffer(CustomEnchants.Type type) {
		int level = type.maxLevel();
		return new EnchantOffer("custom:" + type.name(),
			Component.literal(type.displayName() + " " + CustomEnchants.roman(level))
				.withStyle(type.colour()),
			ShopValues.customBookPrice(type),
			level, type, null);
	}

	/** True when this enchant can sit alongside everything already picked. */
	static boolean compatibleWith(List<EnchantOffer> selected, EnchantOffer candidate) {
		if (candidate.vanilla == null) {
			return true;
		}
		for (EnchantOffer other : selected) {
			if (other.vanilla != null && !Enchantment.areCompatible(candidate.vanilla, other.vanilla)) {
				return false;
			}
		}
		return true;
	}

	/**
	 * The selection reduced to what can actually be applied together. The menu
	 * already hides conflicting choices; this is the belt-and-braces guard so
	 * the charged amount always matches what is stamped on the items.
	 */
	static List<EnchantOffer> filterCompatible(List<EnchantOffer> enchants) {
		List<EnchantOffer> kept = new ArrayList<>();
		for (EnchantOffer offer : enchants) {
			if (compatibleWith(kept, offer)) {
				kept.add(offer);
			}
		}
		return kept;
	}

	/** Stamps this enchant onto one purchased stack. */
	void apply(ItemStack stack) {
		if (stack == null || stack.isEmpty()) {
			return;
		}
		if (custom != null) {
			// apply() never downgrades: a better level already on the item stays.
			CustomEnchants.apply(stack, custom, level);
			return;
		}
		ItemEnchantments current = stack.getOrDefault(DataComponents.ENCHANTMENTS, ItemEnchantments.EMPTY);
		ItemEnchantments.Mutable mutable = new ItemEnchantments.Mutable(current);
		mutable.set(vanilla, level);
		stack.set(DataComponents.ENCHANTMENTS, mutable.toImmutable());
	}
}
