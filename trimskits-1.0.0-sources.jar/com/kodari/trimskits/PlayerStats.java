package com.kodari.trimskits;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Persistent per-player statistics (kills, deaths, mob kills, blocks mined,
 * items sold and playtime) backing the /stats command and the sidebar
 * scoreboard.
 *
 * <p>Each line is name|kills|deaths|blocks|sold|playtime|firstSeen, with mob
 * kills appended as an eighth field. Lines written before mob kills existed
 * still have seven fields and load fine, so an upgraded server keeps its
 * history.
 */
final class PlayerStats {
	private static final Logger LOGGER = LoggerFactory.getLogger("trimskits");
	private static final Path DATA_FILE = Path.of("config", "trimskits-stats.properties");
	private static final Map<UUID, Entry> STATS = new HashMap<>();
	private static final Map<UUID, Long> SESSIONS = new HashMap<>();
	private static final Map<String, UUID> NAMES = new HashMap<>();
	private static boolean loaded;
	private static boolean readable = true;

	private PlayerStats() {
	}

	static final class Entry {
		private String name = "";
		private long kills;
		private long mobKills;
		private long deaths;
		private long blocksBroken;
		private long itemsSold;
		private long playtimeSeconds;
		private long firstSeenMillis = System.currentTimeMillis();
	}

	static synchronized void load() {
		if (loaded) {
			return;
		}
		loaded = true;
		if (!Files.exists(DATA_FILE)) {
			return;
		}

		Properties properties = new Properties();
		try (InputStream input = Files.newInputStream(DATA_FILE)) {
			properties.load(input);
		} catch (IOException exception) {
			// Never overwrite a file we could not read.
			readable = false;
			LOGGER.warn("Could not read {}; stats stay in memory only.", DATA_FILE);
			return;
		}

		for (String key : properties.stringPropertyNames()) {
			try {
				String[] fields = properties.getProperty(key).split("\\|", -1);
				// Seven fields is the pre-mob-kill format; eight is current.
				if (fields.length != 7 && fields.length != 8) {
					continue;
				}
				UUID playerId = UUID.fromString(key);
				Entry entry = new Entry();
				entry.name = fields[0];
				entry.kills = Long.parseLong(fields[1]);
				entry.deaths = Long.parseLong(fields[2]);
				entry.blocksBroken = Long.parseLong(fields[3]);
				entry.itemsSold = Long.parseLong(fields[4]);
				entry.playtimeSeconds = Long.parseLong(fields[5]);
				entry.firstSeenMillis = Long.parseLong(fields[6]);
				entry.mobKills = fields.length == 8 ? Long.parseLong(fields[7]) : 0L;
				STATS.put(playerId, entry);
				index(playerId, entry.name);
			} catch (RuntimeException ignored) {
				// Skip a damaged line instead of failing the whole file.
			}
		}
	}

	static synchronized void beginSession(UUID playerId, String name) {
		load();
		Entry entry = entry(playerId);
		if (name != null && !name.isBlank()) {
			entry.name = name;
			index(playerId, name);
		}
		SESSIONS.put(playerId, System.currentTimeMillis());
	}

	static synchronized void endSession(UUID playerId) {
		load();
		Long started = SESSIONS.remove(playerId);
		if (started != null) {
			entry(playerId).playtimeSeconds += elapsedSeconds(started);
		}
		save();
	}

	static synchronized void recordKill(UUID playerId) {
		load();
		entry(playerId).kills++;
	}

	/** A mob fell to this player; counts towards the mob crystal ladder. */
	static synchronized void recordMobKill(UUID playerId) {
		load();
		entry(playerId).mobKills++;
	}

	static synchronized void recordDeath(UUID playerId) {
		load();
		entry(playerId).deaths++;
	}

	static synchronized void recordBlockBroken(UUID playerId) {
		load();
		entry(playerId).blocksBroken++;
	}

	static synchronized void recordItemsSold(UUID playerId, long count) {
		load();
		entry(playerId).itemsSold += Math.max(0, count);
		// Quests read this one funnel so every sale path counts: the GUI, /sell,
		// the liquidation tools and the auto-sell totem all land here.
		Quests.recordSold(playerId, Math.max(0, count));
	}

	static synchronized long kills(UUID playerId) {
		load();
		return entry(playerId).kills;
	}

	/** Mobs killed by this player (players do not count). */
	static synchronized long mobKills(UUID playerId) {
		load();
		return entry(playerId).mobKills;
	}

	static synchronized long deaths(UUID playerId) {
		load();
		return entry(playerId).deaths;
	}

	static synchronized long blocksBroken(UUID playerId) {
		load();
		return entry(playerId).blocksBroken;
	}

	static synchronized long itemsSold(UUID playerId) {
		load();
		return entry(playerId).itemsSold;
	}

	static synchronized long firstSeen(UUID playerId) {
		load();
		return entry(playerId).firstSeenMillis;
	}

	static synchronized long playtimeSeconds(UUID playerId) {
		load();
		long total = entry(playerId).playtimeSeconds;
		Long started = SESSIONS.get(playerId);
		if (started != null) {
			total += elapsedSeconds(started);
		}
		return total;
	}

	static synchronized String nameOf(UUID playerId) {
		load();
		return entry(playerId).name;
	}

	/** Human readable playtime, e.g. "3h 12m" or "45s". */
	static synchronized String playtimeText(UUID playerId) {
		long seconds = playtimeSeconds(playerId);
		if (seconds < 60) {
			return seconds + "s";
		}
		long minutes = seconds / 60;
		if (minutes < 60) {
			return minutes + "m";
		}
		long hours = minutes / 60;
		return hours + "h " + (minutes % 60) + "m";
	}

	static synchronized UUID byName(String name) {
		load();
		if (name == null) {
			return null;
		}
		UUID playerId = NAMES.get(name.toLowerCase(Locale.ROOT));
		if (playerId == null) {
			playerId = STATS.entrySet().stream()
				.filter(candidate -> name.equalsIgnoreCase(candidate.getValue().name))
				.map(Map.Entry::getKey)
				.findFirst()
				.orElse(null);
		}
		return playerId;
	}

	static synchronized Collection<UUID> knownPlayers() {
		load();
		return new ArrayList<>(STATS.keySet());
	}

	static synchronized void save() {
		if (!readable) {
			return;
		}

		long now = System.currentTimeMillis();
		Properties properties = new Properties();
		for (Map.Entry<UUID, Entry> record : STATS.entrySet()) {
			Entry entry = record.getValue();
			long playtime = entry.playtimeSeconds;
			Long started = SESSIONS.get(record.getKey());
			if (started != null) {
				playtime += elapsedSeconds(started);
			}
			properties.setProperty(record.getKey().toString(), String.join("|",
				entry.name,
				Long.toString(entry.kills),
				Long.toString(entry.deaths),
				Long.toString(entry.blocksBroken),
				Long.toString(entry.itemsSold),
				Long.toString(playtime),
				Long.toString(entry.firstSeenMillis),
				Long.toString(entry.mobKills)
			));
		}

		Path temporaryFile = DATA_FILE.resolveSibling("trimskits-stats.tmp");
		try {
			Files.createDirectories(DATA_FILE.getParent());
			try (OutputStream output = Files.newOutputStream(temporaryFile)) {
				properties.store(output, "Trim Kits player statistics");
			}
			try {
				Files.move(temporaryFile, DATA_FILE, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
			} catch (AtomicMoveNotSupportedException exception) {
				Files.move(temporaryFile, DATA_FILE, StandardCopyOption.REPLACE_EXISTING);
			}
		} catch (IOException exception) {
			LOGGER.warn("Could not save player statistics: {}", exception.getMessage());
		}
	}

	/** Names of every known player, best match first. */
	static synchronized List<UUID> topByPlaytime(int limit) {
		load();
		List<UUID> ordered = new ArrayList<>(STATS.keySet());
		ordered.sort((left, right) -> Long.compare(playtimeSeconds(right), playtimeSeconds(left)));
		return ordered.stream().limit(Math.max(0, limit)).toList();
	}

	private static Entry entry(UUID playerId) {
		return STATS.computeIfAbsent(playerId, key -> new Entry());
	}

	private static void index(UUID playerId, String name) {
		if (name != null && !name.isBlank()) {
			NAMES.put(name.toLowerCase(Locale.ROOT), playerId);
		}
	}

	private static long elapsedSeconds(long startedMillis) {
		return Math.max(0, (System.currentTimeMillis() - startedMillis) / 1000L);
	}
}
