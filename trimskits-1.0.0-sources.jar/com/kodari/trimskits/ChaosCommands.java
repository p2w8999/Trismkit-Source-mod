package com.kodari.trimskits;

import java.util.concurrent.ThreadLocalRandom;
import java.util.function.BiFunction;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.entity.item.PrimedTnt;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Blocks;

/**
 * The fun admin-chaos subcommands of /sfmode (alpha):
 *
 * <ul>
 *   <li>{@code /sfmode weapons} - hand yourself the four alpha event weapons</li>
 *   <li>{@code /sfmode event <type> <player>} - summon chaos around a player:
 *       lightning, tnt, wither, arrows, anvil, silverfish</li>
 *   <li>{@code /sfmode abuse <type> <player>} - debuff a player directly:
 *       burn, freeze, launch, zap, web, lava, poison</li>
 * </ul>
 *
 * <p>Registered as a second {@code /sfmode} tree: Brigadier merges children
 * by name and keeps the original node's command when the incoming node has
 * none, so the existing /sfmode toggle and every other subcommand stay
 * exactly as they were. All new commands require admin mode, the same rule
 * as the other admin commands.</p>
 */
final class ChaosCommands {
	/** Event types - each summons something on the target. */
	private static final String[] EVENTS = {"lightning", "tnt", "wither", "arrows", "anvil", "silverfish"};

	/** Abuse types - each debuffs the target directly. */
	private static final String[] ABUSE = {"burn", "freeze", "launch", "zap", "web", "lava", "poison"};

	private ChaosCommands() {
	}

	/** Adds the event/abuse/weapons subcommands to the /sfmode tree. */
	static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
		LiteralArgumentBuilder<CommandSourceStack> event = Commands.literal("event");
		for (String type : EVENTS) {
			event.then(targeted(type, (admin, target) -> runEvent(admin, target, type)));
		}
		LiteralArgumentBuilder<CommandSourceStack> abuse = Commands.literal("abuse");
		for (String type : ABUSE) {
			abuse.then(targeted(type, (admin, target) -> runAbuse(admin, target, type)));
		}
		// No .executes on the sfmode node itself - the merge must leave the
		// existing /sfmode toggle command untouched.
		dispatcher.register(Commands.literal("sfmode")
			.then(event)
			.then(abuse)
			.then(Commands.literal("weapons").executes(ChaosCommands::giveWeapons)));
	}

	/** One {@code /sfmode <group> <type> <player>} leaf with online-target resolution. */
	private static LiteralArgumentBuilder<CommandSourceStack> targeted(String type,
			BiFunction<ServerPlayer, ServerPlayer, Integer> action) {
		return Commands.literal(type)
			.then(Commands.argument("player", StringArgumentType.word())
				.executes(context -> {
					CommandSourceStack source = context.getSource();
					ServerPlayer admin = source.getPlayerOrException();
					if (!isAdminMode(source, admin)) {
						return 0;
					}
					ServerPlayer target = source.getServer().getPlayerList()
						.getPlayerByName(StringArgumentType.getString(context, "player"));
					if (target == null) {
						admin.sendSystemMessage(Component.literal("That player is not online."));
						return 0;
					}
					return action.apply(admin, target);
				}));
	}

	/** The same authorization rule as every other admin command. Package-private for InfEnchants. */
	static boolean isAdminMode(CommandSourceStack source, ServerPlayer admin) {
		if (TrimKits.isAdminMode(source, admin)) {
			return true;
		}
		admin.sendSystemMessage(Component.literal("§cAdmin mode required. Use /sfmode first."));
		return false;
	}

	/** /sfmode event <type> <player> - summon chaos on the target. */
	private static int runEvent(ServerPlayer admin, ServerPlayer target, String type) {
		ServerLevel level = target.level();
		ThreadLocalRandom random = ThreadLocalRandom.current();
		switch (type) {
			case "lightning" -> Compat.spawnEntity(level,
				target.getX(), target.getY() + 0.5, target.getZ(), "LIGHTNING_BOLT");
			case "tnt" -> level.addFreshEntity(new PrimedTnt(level,
				target.getX(), target.getY() + 2.0, target.getZ(), admin));
			case "wither" -> Compat.spawnEntity(level,
				target.getX(), target.getY() + 1.0, target.getZ(), "WITHER");
			case "arrows" -> {
				for (int i = 0; i < 12; i++) {
					Entity arrow = Compat.spawnEntity(level,
						target.getX() + random.nextDouble(-3.0, 3.0),
						target.getY() + 9.0 + random.nextDouble(0.0, 4.0),
						target.getZ() + random.nextDouble(-3.0, 3.0), "ARROW");
					if (arrow != null) {
						arrow.setDeltaMovement(0.0, -1.7, 0.0);
					}
				}
			}
			case "anvil" -> FallingBlockEntity.fall(level,
				BlockPos.containing(target.getX(), target.getY() + 10.0, target.getZ()),
				Blocks.ANVIL.defaultBlockState());
			case "silverfish" -> {
				for (int i = 0; i < 8; i++) {
					Compat.spawnEntity(level,
						target.getX() + random.nextDouble(-2.0, 2.0),
						target.getY(),
						target.getZ() + random.nextDouble(-2.0, 2.0), "SILVERFISH");
				}
			}
			default -> {
				return 0;
			}
		}
		admin.sendSystemMessage(Component.literal(
			"§aChaos event '" + type + "' summoned on " + target.getScoreboardName() + "."));
		return 1;
	}

	/** /sfmode abuse <type> <player> - debuff the target directly. */
	private static int runAbuse(ServerPlayer admin, ServerPlayer target, String type) {
		ServerLevel level = target.level();
		switch (type) {
			case "burn" -> target.igniteForTicks(100);
			case "freeze" -> {
				target.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 200, 3));
				target.addEffect(new MobEffectInstance(MobEffects.MINING_FATIGUE, 200, 2));
				target.addEffect(new MobEffectInstance(MobEffects.GLOWING, 200, 0));
			}
			case "launch" -> {
				target.push(0.0, 3.4, 0.0);
				target.needsSync = true; // resend velocity to clients
			}
			case "zap" -> target.hurtServer(level, target.damageSources().lightningBolt(), 6.0f);
			case "web" -> level.setBlockAndUpdate(feet(target), Blocks.COBWEB.defaultBlockState());
			case "lava" -> level.setBlockAndUpdate(feet(target), Blocks.LAVA.defaultBlockState());
			case "poison" -> target.addEffect(new MobEffectInstance(MobEffects.POISON, 300, 1));
			default -> {
				return 0;
			}
		}
		admin.sendSystemMessage(Component.literal(
			"§aChaos abuse '" + type + "' hit " + target.getScoreboardName() + "."));
		return 1;
	}

	/** /sfmode weapons - hand the admin the four alpha event weapons. */
	private static int giveWeapons(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
		CommandSourceStack source = context.getSource();
		ServerPlayer admin = source.getPlayerOrException();
		if (!isAdminMode(source, admin)) {
			return 0;
		}
		for (Item weapon : new Item[] {Weapons.VOID_BLADE, Weapons.THUNDER_AXE,
				Weapons.FROST_DAGGER, Weapons.WAR_HAMMER}) {
			Compat.placeBack(admin.getInventory(), new ItemStack(weapon));
		}
		admin.sendSystemMessage(Component.literal(
			"§aAlpha event kit handed over: Void Blade, Thunder Axe, Frost Dagger, War Hammer."));
		return 1;
	}

	/** The block the target's body occupies. */
	private static BlockPos feet(ServerPlayer target) {
		return BlockPos.containing(target.getX(), target.getY(), target.getZ());
	}
}
