package com.kodari.trimskits;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;

/**
 * The spawner management GUI: a two-view menu for {@code /spawners}.
 *
 * <p><b>List view</b> (no type selected) shows every spawner type the player is
 * currently holding, with how many they have and how much loot is waiting.
 * Picking one switches to <b>detail view</b>, which is the loot-management
 * surface described in the spec: entity info and stack size up top, the stored
 * loot across the middle, and collect / sell / upgrade controls along the
 * bottom.
 *
 * <p>Every slot is a button. Nothing in this container is ever a real item —
 * the loot shown in the centre lives authoritatively in {@link SpawnerState},
 * not in these slots — so {@link #clicked} never delegates to the vanilla
 * handler. That makes it impossible for a player to pull a display stack out of
 * the menu (which would dupe, since the real item is still in storage), and
 * impossible for a shift-click or number-key swap to displace a control.
 *
 * <p>Collect and sell both re-read storage at the moment of the click and move
 * items exactly once: collect fills the inventory first and spills overflow to
 * mail so nothing is lost to a full inventory, and sell credits money only
 * after pricing, never before.
 */
final class SpawnerMenu extends ChestMenu {

	private static final int ROWS = 6;
	private static final int SIZE = ROWS * 9;

	// List view: one slot per held type across the middle four rows.
	private static final int LIST_START = 9;
	private static final int LIST_END = 44;

	// Detail view: stored loot across the middle four rows.
	private static final int LOOT_START = 9;
	private static final int LOOT_END = 44;

	// Detail view: top info/upgrades row.
	private static final int SLOT_BACK = 0;
	private static final int SLOT_ICON = 1;
	private static final int SLOT_RATE = 2;
	private static final int SLOT_STORAGE = 3;
	private static final int SLOT_TIER = 4;
	private static final int SLOT_UPG_EFF = 5;
	private static final int SLOT_UPG_CAP = 6;
	private static final int SLOT_PRICE = 7;
	private static final int SLOT_CLOSE = 8;

	// Detail view: bottom control row.
	private static final int SLOT_INSTRUCTIONS = 45;
	private static final int SLOT_COLLECT = 47;
	private static final int SLOT_SELL = 49;
	private static final int SLOT_REFRESH = 51;
	private static final int SLOT_LIST = 53;

	// List view: header/close.
	private static final int SLOT_LIST_TITLE = 0;
	private static final int SLOT_LIST_HINT = 8;

	/** Non-null when the detail view is showing this type. */
	private SpawnerType.Spec selected;

	private final ServerPlayer owner;
	private final SimpleContainer container;

	SpawnerMenu(int containerId, Inventory inventory, ServerPlayer owner) {
		super(MenuType.GENERIC_9x6, containerId, inventory, new SimpleContainer(SIZE), ROWS);
		this.owner = owner;
		this.container = (SimpleContainer) getContainer();
		render();
	}

	/** True when a specific type is being shown. */
	private boolean detail() {
		return selected != null;
	}

	// ---- Rendering ---------------------------------------------------------

	private void render() {
		for (int slot = 0; slot < SIZE; slot++) {
			container.setItem(slot, detail() ? detailPane(slot) : listPane(slot));
		}
		broadcastChanges();
	}

	// ---- List view ---------------------------------------------------------

	private ItemStack listPane(int slot) {
		if (slot == SLOT_LIST_TITLE) {
			return info(Items.SPAWNER, "§6§lYour Spawners",
				"§7Click a spawner to manage it.",
				"§7Held: §f" + TrimKits.formatAmount(heldTypes().size()) + " type(s)");
		}
		if (slot == SLOT_LIST_HINT) {
			return info(Items.BARRIER, "§cClose", "§7Nothing here is taken from you.");
		}
		if (slot < LIST_START || slot > LIST_END) {
			return filler();
		}
		int index = slot - LIST_START;
		List<String> types = heldTypes();
		if (index >= types.size()) {
			return filler();
		}
		SpawnerType.Spec type = SpawnerType.byId(types.get(index));
		if (type == null) {
			return filler();
		}
		int held = SpawnerItem.countOf(owner.getInventory(), type.entityId());
		long stored = SpawnerState.storedTotal(owner.getUUID(), type.entityId());
		int cap = SpawnerState.capacity(owner.getUUID(), type.entityId());

		ItemStack icon = SpawnerItem.create(type, Math.min(held, SpawnerItem.stackCap()));
		if (icon.isEmpty()) {
			icon = new ItemStack(Items.SPAWNER);
		}
		List<Component> lore = new ArrayList<>();
		lore.add(line("§7Held: §f" + TrimKits.formatAmount(held) + " spawner(s)"));
		lore.add(line("§7Stored loot: §f" + TrimKits.formatAmount(stored)
			+ " §8/ " + TrimKits.formatAmount(cap)));
		lore.add(line(""));
		lore.add(line("§eClick to open this spawner."));
		icon.set(net.minecraft.core.component.DataComponents.LORE,
			new net.minecraft.world.item.component.ItemLore(lore));
		return icon;
	}

	// ---- Detail view -------------------------------------------------------

	private ItemStack detailPane(int slot) {
		SpawnerType.Spec type = selected;
		if (type == null) {
			return filler();
		}
		UUID playerId = owner.getUUID();
		int held = SpawnerItem.countOf(owner.getInventory(), type.entityId());
		long stored = SpawnerState.storedTotal(playerId, type.entityId());
		int cap = SpawnerState.capacity(playerId, type.entityId());
		SpawnerState.Upgrade upgrade = SpawnerState.upgradeOf(playerId, type.entityId());

		return switch (slot) {
			case SLOT_BACK -> button(Items.ARROW, "§eBack to list",
				"§7Return to all your spawners.");
			case SLOT_ICON -> {
				ItemStack icon = SpawnerItem.create(type, Math.min(Math.max(held, 1),
					SpawnerItem.stackCap()));
				List<Component> lore = new ArrayList<>();
				lore.add(line("§7You hold §f" + TrimKits.formatAmount(held) + " §7of these."));
				lore.add(line("§7Tier: §f" + type.tier().label()));
				lore.add(line(""));
				lore.add(line(held == 0
					? "§cYou hold none - buy or find more."
					: "§aProducing while you are online."));
				icon.set(net.minecraft.core.component.DataComponents.LORE,
					new net.minecraft.world.item.component.ItemLore(lore));
				yield icon;
			}
			case SLOT_RATE -> info(Items.CLOCK, "§6Production rate",
				"§7Held: §f" + TrimKits.formatAmount(held),
				"§7Efficiency lvl §f" + upgrade.efficiency() + " §7(+" +
					(int) Math.round((SpawnerState.rateMultiplier(playerId, type.entityId()) - 1.0) * 100) + "%)",
				"§7Mode: §f" + Config.getString("spawners.mode", "virtual"),
				"",
				"§8Produces only while you are online and");
			case SLOT_STORAGE -> info(Items.CHEST, "§6Storage",
				"§7Stored: §f" + TrimKits.formatAmount(stored),
				"§7Capacity: §f" + TrimKits.formatAmount(cap),
				"§7Free: §f" + TrimKits.formatAmount(Math.max(0, cap - stored)),
				"",
				stored >= cap ? "§cFull - collect or sell it." : "§aAccepting production.");
			case SLOT_TIER -> info(Items.NETHER_STAR, "§6" + type.tier().label() + " spawner",
				"§7Entity: §f" + type.entityId(),
				"§7Value each: §e$" + TrimKits.formatMoney(SpawnerType.priceOf(type)));
			case SLOT_UPG_EFF -> {
				int level = upgrade.efficiency();
				long cost = SpawnerState.upgradeCost(0, level);
				boolean maxed = level >= SpawnerState.MAX_LEVEL;
				yield button(Items.BLAZE_POWDER,
					maxed ? "§aEfficiency MAX" : "§bEfficiency " + level + " → " + (level + 1),
					"§7Speed up production.",
					"§7Current: §f+" + (int) Math.round(
						(SpawnerState.rateMultiplier(playerId, type.entityId()) - 1.0) * 100) + "%",
					maxed ? "§aAlready at max level." : "§6Cost: §e$" + TrimKits.formatMoney(cost));
			}
			case SLOT_UPG_CAP -> {
				int level = upgrade.capacity();
				long cost = SpawnerState.upgradeCost(1, level);
				boolean maxed = level >= SpawnerState.MAX_LEVEL;
				yield button(Items.BARREL,
					maxed ? "§aCapacity MAX" : "§bCapacity " + level + " → " + (level + 1),
					"§7Hold more stored loot.",
					"§7Current cap: §f" + TrimKits.formatAmount(cap),
					maxed ? "§aAlready at max level." : "§6Cost: §e$" + TrimKits.formatMoney(cost));
			}
			case SLOT_PRICE -> info(Items.EMERALD, "§6Sell value",
				"§7Stored loot sells for what the",
				"§7shop currently pays - recalculated",
				"§7at the moment you click sell.");
			case SLOT_INSTRUCTIONS -> info(Items.BOOK, "§6§lHow to use",
				"§7Middle rows: loot waiting to collect.",
				"§7Collect → into your inventory.",
				"§7Sell → straight into your balance.",
				"§7Upgrades cost money and persist.");
			case SLOT_COLLECT -> button(Items.HOPPER, "§aCollect all",
				"§7Moves stored loot into your inventory.",
				"§7Overflow goes to /mail, never lost.",
				"",
				stored == 0 ? "§8Nothing stored right now." : "§aReady.");
			case SLOT_SELL -> button(Items.GOLD_INGOT, "§6Sell all",
				"§7Sells every stored item at current prices.",
				"§7Stored: §f" + TrimKits.formatAmount(stored),
				"",
				stored == 0 ? "§8Nothing stored right now." : "§aReady.");
			case SLOT_REFRESH -> button(Items.SUNFLOWER, "§eRefresh", "§7Reload this view.");
			case SLOT_LIST -> button(Items.CHEST, "§eAll spawners", "§7Back to the list.");
			case SLOT_CLOSE -> button(Items.BARRIER, "§cClose", "§7Your loot stays stored.");
			default -> {
				if (slot >= LOOT_START && slot <= LOOT_END) {
					yield lootPane(slot);
				}
				yield filler();
			}
		};
	}

	/**
	 * One stored item type per slot, in a stable order.
	 *
	 * <p>Only the first 36 distinct stored items are shown; the collect and sell
	 * buttons always operate on <em>everything</em> in storage, so a player with
	 * more than 36 distinct items never loses any by not seeing it — the summary
	 * line and the buttons both reflect the true total.
	 */
	private ItemStack lootPane(int slot) {
		Map<String, Long> stored = SpawnerState.stored(owner.getUUID(), selected.entityId());
		if (stored.isEmpty()) {
			if (slot == LOOT_START) {
				return info(Compat.pickItem("STAINED_GLASS_PANE", net.minecraft.world.item.DyeColor.GRAY),
					"§8Storage empty",
					"§7Hold this spawner and stay online",
					"§7to start producing loot.");
			}
			return filler();
		}
		int index = slot - LOOT_START;
		List<Map.Entry<String, Long>> entries = new ArrayList<>(stored.entrySet());
		if (index >= entries.size() || index >= 36) {
			return filler();
		}
		Map.Entry<String, Long> entry = entries.get(index);
		Item item = BuiltInRegistries.ITEM.getOptional(Identifier.tryParse(entry.getKey())).orElse(null);
		if (item == null) {
			return filler();
		}
		long total = entry.getValue();
		int shown = (int) Math.min(total, 64);
		ItemStack stack = new ItemStack(item, Math.max(1, shown));
		stack.set(net.minecraft.core.component.DataComponents.CUSTOM_NAME,
			Component.literal("§f" + TrimKits.formatAmount(total) + " total"));
		List<Component> lore = new ArrayList<>();
		lore.add(line("§7Stored: §f" + TrimKits.formatAmount(total)));
		lore.add(line("§8" + entry.getKey()));
		lore.add(line(""));
		lore.add(line("§7Use Collect all or Sell all below."));
		stack.set(net.minecraft.core.component.DataComponents.LORE,
			new net.minecraft.world.item.component.ItemLore(lore));
		return stack;
	}

	// ---- Helpers -----------------------------------------------------------

	private List<String> heldTypes() {
		LinkedHashMap<String, Boolean> seen = new LinkedHashMap<>();
		for (String id : SpawnerItem.countByType(owner.getInventory()).keySet()) {
			if (SpawnerType.usable(SpawnerType.byId(id))) {
				seen.put(id, Boolean.TRUE);
			}
		}
		// Include types that still have stored loot even if the spawner was sold.
		for (String id : SpawnerState.activeTypes(owner.getUUID())) {
			if (!seen.containsKey(id) && SpawnerType.byId(id) != null) {
				seen.put(id, Boolean.TRUE);
			}
		}
		return new ArrayList<>(seen.keySet());
	}

	private static Component line(String text) {
		return text.isEmpty() ? Component.empty() : Component.literal(text);
	}

	private static ItemStack filler() {
		return button(Compat.pickItem("STAINED_GLASS_PANE", net.minecraft.world.item.DyeColor.GRAY), " ");
	}

	private static ItemStack button(Item item, String title, String... lore) {
		ItemStack stack = new ItemStack(item);
		stack.set(net.minecraft.core.component.DataComponents.CUSTOM_NAME, Component.literal(title));
		if (lore.length > 0) {
			List<Component> lines = new ArrayList<>();
			for (String text : lore) {
				lines.add(text.isEmpty() ? Component.empty() : Component.literal(text));
			}
			stack.set(net.minecraft.core.component.DataComponents.LORE,
				new net.minecraft.world.item.component.ItemLore(lines));
		}
		return stack;
	}

	private static ItemStack info(Item item, String title, String... lore) {
		return button(item, title, lore);
	}

	// ---- Interaction -------------------------------------------------------

	@Override
	public void clicked(int slotIndex, int buttonNum, ContainerInput containerInput, Player player) {
		if (slotIndex < 0 || slotIndex >= SIZE || !(player instanceof ServerPlayer serverPlayer)) {
			return;
		}
		// Every slot is a button; never let vanilla move real items around, since
		// nothing in this container is a real item.
		if (detail()) {
			handleDetail(slotIndex, serverPlayer);
		} else {
			handleList(slotIndex, serverPlayer);
		}
	}

	private void handleList(int slot, ServerPlayer player) {
		if (slot == SLOT_LIST_CLOSE()) {
			player.closeContainer();
			return;
		}
		if (slot < LIST_START || slot > LIST_END) {
			return;
		}
		List<String> types = heldTypes();
		int index = slot - LIST_START;
		if (index < 0 || index >= types.size()) {
			return;
		}
		SpawnerType.Spec type = SpawnerType.byId(types.get(index));
		if (type == null) {
			return;
		}
		selected = type;
		render();
	}

	private static int SLOT_LIST_CLOSE() {
		return SLOT_LIST_HINT;
	}

	private void handleDetail(int slot, ServerPlayer player) {
		SpawnerType.Spec type = selected;
		if (type == null) {
			return;
		}
		switch (slot) {
			case SLOT_BACK, SLOT_LIST -> {
				selected = null;
				render();
			}
			case SLOT_CLOSE -> player.closeContainer();
			case SLOT_REFRESH -> render();
			case SLOT_UPG_EFF -> buy(player, type, 0);
			case SLOT_UPG_CAP -> buy(player, type, 1);
			case SLOT_COLLECT -> collectAll(player, type);
			case SLOT_SELL -> sellAll(player, type);
			default -> {
				// Loot slots and info panes are display-only.
			}
		}
	}

	private void buy(ServerPlayer player, SpawnerType.Spec type, int track) {
		String error = SpawnerState.buyUpgrade(player.getUUID(), type, track,
			player.level().registryAccess());
		if (error != null) {
			player.sendSystemMessage(Component.literal("§c" + error));
		} else {
			String name = track == 0 ? "Efficiency" : "Capacity";
			int level = track == 0
				? SpawnerState.upgradeOf(player.getUUID(), type.entityId()).efficiency()
				: SpawnerState.upgradeOf(player.getUUID(), type.entityId()).capacity();
			player.sendSystemMessage(Component.literal(
				"§aUpgraded " + type.spawnerName() + " " + name + " to level " + level + "."));
		}
		render();
	}

	/**
	 * Moves all stored loot into the player's inventory, spilling to mail.
	 *
	 * <p>Storage is debited first and only what actually left storage is handed
	 * out, so a partial move cannot duplicate items: the record is the single
	 * source of truth and it is written down before the items appear anywhere.
	 */
	private void collectAll(ServerPlayer player, SpawnerType.Spec type) {
		Map<String, Long> stored = SpawnerState.stored(player.getUUID(), type.entityId());
		if (stored.isEmpty()) {
			player.sendSystemMessage(Component.literal("§7Nothing stored to collect yet."));
			render();
			return;
		}
		// Remove everything from storage, tracking what we took.
		Map<String, Long> taken = SpawnerState.takeAll(player.getUUID(), type.entityId());
		if (taken.isEmpty()) {
			player.sendSystemMessage(Component.literal("§7Nothing stored to collect yet."));
			render();
			return;
		}
		int collected = 0;
		int mailed = 0;
		for (Map.Entry<String, Long> entry : taken.entrySet()) {
			Item item = BuiltInRegistries.ITEM.getOptional(Identifier.tryParse(entry.getKey())).orElse(null);
			if (item == null) {
				continue;
			}
			long remaining = entry.getValue();
			// Hand out in stack-sized chunks so a big total fits normal slots.
			while (remaining > 0) {
				int chunk = (int) Math.min(remaining, 64);
				ItemStack stack = new ItemStack(item, chunk);
				if (player.getInventory().add(stack.copy())) {
					collected += chunk;
				} else {
					// Inventory full: mail the rest so it is never destroyed.
					MarketData.deliver(player.getUUID(), stack, "Spawner collect",
						player.level().registryAccess());
					mailed += chunk;
				}
				remaining -= chunk;
			}
		}
		player.sendSystemMessage(Component.literal(
			"§aCollected " + TrimKits.formatAmount(collected) + " item(s) into your inventory."));
		if (mailed > 0) {
			player.sendSystemMessage(Component.literal(
				"§eYour inventory was full - " + TrimKits.formatAmount(mailed)
					+ " item(s) went to /mail."));
		}
		render();
	}

	/**
	 * Sells every stored item at current prices, crediting once.
	 *
	 * <p>Prices are read now (not cached from when the menu opened), the total
	 * is credited first, and only after the credit succeeds is storage cleared.
	 * A failed credit therefore leaves the loot untouched rather than deleting
	 * it for free.
	 */
	private void sellAll(ServerPlayer player, SpawnerType.Spec type) {
		Map<String, Long> stored = SpawnerState.stored(player.getUUID(), type.entityId());
		if (stored.isEmpty()) {
			player.sendSystemMessage(Component.literal("§7Nothing stored to sell yet."));
			render();
			return;
		}
		long total = 0;
		int units = 0;
		for (Map.Entry<String, Long> entry : stored.entrySet()) {
			Item item = BuiltInRegistries.ITEM.getOptional(Identifier.tryParse(entry.getKey())).orElse(null);
			if (item == null) {
				continue;
			}
			Long unit = ShopValues.sellPrice(new ItemStack(item, 1));
			if (unit == null || unit <= 0) {
				continue;
			}
			try {
				total = Math.addExact(total, Math.multiplyExact(unit, entry.getValue()));
			} catch (ArithmeticException overflow) {
				total = Long.MAX_VALUE / 4;
			}
			units += (int) Math.min(entry.getValue(), Integer.MAX_VALUE);
		}
		if (total <= 0) {
			player.sendSystemMessage(Component.literal("§cThe stored loot has no sell value right now."));
			render();
			return;
		}
		if (!MarketData.credit(player.getUUID(), total, player.level().registryAccess())) {
			player.sendSystemMessage(Component.literal(
				"§cCould not save the sale - your stored loot was not taken."));
			return;
		}
		// Credit landed: clear storage now.
		SpawnerState.takeAll(player.getUUID(), type.entityId());
		PlayerStats.recordItemsSold(player.getUUID(), units);
		Ledger.record(player.getUUID(), total, "spawner-sell",
			type.entityId() + " " + units + " item(s)");
		player.sendSystemMessage(Component.literal(
			"§aSold " + TrimKits.formatAmount(units) + " item(s) for $" + TrimKits.formatMoney(total) + "."));
		render();
	}

	@Override
	public boolean stillValid(Player player) {
		return true;
	}
}
