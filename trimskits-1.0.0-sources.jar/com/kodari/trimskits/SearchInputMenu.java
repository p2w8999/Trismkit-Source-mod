package com.kodari.trimskits;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AnvilMenu;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;
import net.minecraft.world.level.block.state.BlockState;

/**
 * An anvil-style search box, replacing the old "type it in chat" capture.
 *
 * <p>The vanilla anvil screen ships with a real text field. By opening an
 * {@link AnvilMenu} that reports {@link MenuType#ANVIL} while overriding the
 * server-side hooks, players get that familiar rename box with none of the
 * anvil's rules: type "mace", watch the result slot show how many matches you
 * have, click it, and the shop reopens filtered to your query.
 *
 * <p>A name tag sits in the input slot purely so the text field is enabled and
 * pre-filled; it is cleared on close and can never be taken, because every
 * click on the input/result slots is intercepted.
 */
final class SearchInputMenu extends AnvilMenu {
	private final ServerPlayer owner;
	/** True when the search was started from the sell GUI (vs the buy GUI). */
	private final boolean fromSell;
	private String query;
	private boolean ran;

	SearchInputMenu(int containerId, Inventory inventory, ServerPlayer owner, boolean fromSell, String initial) {
		super(containerId, inventory, ContainerLevelAccess.NULL);
		this.owner = owner;
		this.fromSell = fromSell;
		this.query = initial == null ? "" : initial;

		// The rename field only enables when the input slot holds a renameable
		// item, so seed one carrying the current query. It is never handed out.
		ItemStack placeholder = new ItemStack(Items.NAME_TAG);
		placeholder.set(DataComponents.CUSTOM_NAME, Component.literal(this.query));
		placeholder.set(DataComponents.LORE, new ItemLore(List.of(
			Component.literal("Type the item you want to find").withStyle(ChatFormatting.GRAY),
			Component.empty(),
			Component.literal("Then click the result to search").withStyle(ChatFormatting.GREEN))));
		inputSlots.setItem(INPUT_SLOT, placeholder);
		createResult();
	}

	/** The server sees every keystroke here; refresh the live match preview. */
	@Override
	public boolean setItemName(String name) {
		this.query = name == null ? "" : name;
		createResult();
		return true;
	}

	@Override
	public void createResult() {
		String trimmed = query == null ? "" : query.trim();
		int matches = trimmed.isEmpty() ? 0 : ShopSearch.search(trimmed).size();

		ItemStack preview = new ItemStack(Items.COMPASS);
		preview.set(DataComponents.CUSTOM_NAME, Component.literal(
			trimmed.isEmpty() ? "Search the shop" : "Search \"" + trimmed + "\"").withStyle(ChatFormatting.AQUA));
		List<Component> lore = new ArrayList<>();
		if (trimmed.isEmpty()) {
			lore.add(Component.literal("Type an item name in the box above").withStyle(ChatFormatting.GRAY));
		} else {
			lore.add(Component.literal(TrimKits.formatAmount(matches) + " match(es) found").withStyle(ChatFormatting.GRAY));
		}
		lore.add(Component.empty());
		lore.add(Component.literal("Click to search").withStyle(ChatFormatting.GREEN));
		preview.set(DataComponents.LORE, new ItemLore(lore));
		resultSlots.setItem(RESULT_SLOT, preview);
	}

	@Override
	public boolean stillValid(Player player) {
		// Usable anywhere, not only next to a physical anvil.
		return player == owner;
	}

	@Override
	protected boolean isValidBlock(BlockState state) {
		return true;
	}

	@Override
	protected boolean mayPickup(Player player, boolean has) {
		return true;
	}

	@Override
	public void removed(Player player) {
		// Never hand back the placeholder name tag or the preview compass.
		inputSlots.setItem(INPUT_SLOT, ItemStack.EMPTY);
		inputSlots.setItem(ADDITIONAL_SLOT, ItemStack.EMPTY);
		resultSlots.setItem(RESULT_SLOT, ItemStack.EMPTY);
		super.removed(player);
	}

	@Override
	public ItemStack quickMoveStack(Player player, int slotIndex) {
		// No shift-clicking; this is a search box, not a container.
		return ItemStack.EMPTY;
	}

	@Override
	public void clicked(int slotIndex, int buttonNum, ContainerInput containerInput, Player player) {
		// The result slot is the Search button - never give the item away.
		if (slotIndex == RESULT_SLOT) {
			runSearch();
			return;
		}
		// Block taking or replacing the placeholder in the input slots.
		if (slotIndex == INPUT_SLOT || slotIndex == ADDITIONAL_SLOT) {
			return;
		}
		// Anything else is the player's own inventory; let it behave normally.
		super.clicked(slotIndex, buttonNum, containerInput, player);
	}

	private void runSearch() {
		if (ran) {
			return;
		}
		ran = true;
		String trimmed = query == null ? "" : query.trim();
		owner.closeContainer();
		if (trimmed.isEmpty()) {
			if (fromSell) {
				TrimKits.openSellGui(owner);
			} else {
				TrimKits.openBuyGui(owner);
			}
			return;
		}
		if (fromSell) {
			TrimKits.openSellGuiWithSearch(owner, trimmed);
		} else {
			TrimKits.openBuyGuiWithSearch(owner, trimmed);
		}
	}
}
