package com.kodari.trimskits;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;
import net.minecraft.core.RegistryAccess;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Shard boosts: pay shards to double what you earn for a while.
 *
 * <p>A boost is a window of wall-clock time during which every shard the
 * player would earn is earned twice. It is deliberately bought with shards and
 * pays out in shards, so it is a bet on your own play rather than a way to
 * convert one currency into the other - the balance can only go up by actually
 * doing things, and faster only after spending to unlock it.
 *
 * <p>The multiplier is stored as an expiry timestamp per player, persisted
 * beside the other economy files. {@link Shards#earned} reads it, so the boost
 * applies to the same derived figure the rest of the system uses, and a
 * restart does not hand back extra time.
 */
final class ShardBoosts {
	private static final Logger LOGGER = LoggerFactory.getLogger("trimskits");
	private static final Path DATA_FILE = Path.of("config", "trimskits-boosts.properties");

	/** How long one boost lasts, in minutes. */
	static final long BOOST_MINUTES = 60L;
	/** The multiplier applied while a boost is running. */
	static final long BOOST_MULTIPLIER = 2L;
	/** What a boost costs, in shards. */
	static final long BOOST_PRICE = 400L;

	/** UUID -> the millis timestamp at which the running boost expires. */
	private static final Map<UUID, Long> EXPIRY = new HashMap<>();
	private static boolean loaded;
	private static boolean readable = true;

	private ShardBoosts() {
	}

	/** True while this player's boost is still running. */
	static boolean isActive(UUID playerId) {
		load();
		return EXPIRY.getOrDefault(playerId, 0L) > System.currentTimeMillis();
	}

	/** How many seconds of boost are left, zero when none. */
	static long secondsLeft(UUID playerId) {
		load();
		long left = EXPIRY.getOrDefault(playerId, 0L) - System.currentTimeMillis();
		return Math.max(0L, left / 1000L);
	}

	/** The multiplier the shard math should apply right now. */
	static long multiplier(UUID playerId) {
		return isActive(playerId) ? BOOST_MULTIPLIER : 1L;
	}

	/**
	 * Pushes a boost's expiry out by some minutes, stacking onto whatever is
	 * left of any running one so buying early is never wasted. Used both by
	 * /boost buy and by the shop's boost offer.
	 *
	 * @return the new expiry timestamp
	 */
	static boolean extend(UUID playerId, long minutes) {
		load();
		long now = System.currentTimeMillis();
		long base = Math.max(now, EXPIRY.getOrDefault(playerId, 0L));
		long next = base + Math.max(1L, minutes) * 60_000L;
		EXPIRY.put(playerId, next);
		if (!save()) {
			EXPIRY.put(playerId, base);
			return false;
		}
		return true;
	}

	/**
	 * Buys a boost, stacking its window onto whatever is left of the current
	 * one so a bought-too-early boost is never wasted.
	 *
	 * @return null on success, or the reason it did not happen
	 */
	static synchronized String buy(UUID playerId, RegistryAccess registries) {
		load();
		String error = Shards.buy(playerId, BOOST_PRICE);
		if (error != null) {
			return error;
		}
		if (!extend(playerId, BOOST_MINUTES)) {
			// The boost window could not be written down, so hand the shards
			// back rather than charge for a boost that would vanish on restart.
			Shards.adminGive(playerId, BOOST_PRICE);
			return "The boost could not be saved; you were not charged.";
		}
		return null;
	}

	// ---- Persistence --------------------------------------------------------

	private static void load() {
		if (loaded) {
			return;
		}
		loaded = true;
		if (!Files.exists(DATA_FILE)) {
			return;
		}
		Properties properties = new Properties();
		try (InputStream input = Files.newInputStream(DATA_FILE)) {
			properties.load(input);
		} catch (IOException exception) {
			readable = false;
			LOGGER.warn("Could not read {}; boosts stay in memory only.", DATA_FILE);
			return;
		}
		for (String key : properties.stringPropertyNames()) {
			try {
				if (key.startsWith("expiry.")) {
					EXPIRY.put(UUID.fromString(key.substring("expiry.".length())),
						Long.parseLong(properties.getProperty(key)));
				}
			} catch (RuntimeException ignored) {
				// Skip a damaged line.
			}
		}
	}

	private static boolean save() {
		if (!readable) {
			return false;
		}
		Properties properties = new Properties();
		long now = System.currentTimeMillis();
		EXPIRY.forEach((playerId, expiry) -> {
			// Only future boosts are worth writing; a lapsed one has nothing
			// left to remember.
			if (expiry > now) {
				properties.setProperty("expiry." + playerId, Long.toString(expiry));
			}
		});
		Path temporaryFile = DATA_FILE.resolveSibling("trimskits-boosts.tmp");
		try {
			Files.createDirectories(DATA_FILE.getParent());
			try (OutputStream output = Files.newOutputStream(temporaryFile)) {
				properties.store(output, "Trim Kits shard boosts");
			}
			try {
				Files.move(temporaryFile, DATA_FILE, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
			} catch (AtomicMoveNotSupportedException exception) {
				Files.move(temporaryFile, DATA_FILE, StandardCopyOption.REPLACE_EXISTING);
			}
			return true;
		} catch (IOException exception) {
			LOGGER.warn("Could not save boosts: {}", exception.getMessage());
			return false;
		}
	}
}
