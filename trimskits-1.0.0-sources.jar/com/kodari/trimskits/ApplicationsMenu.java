package com.kodari.trimskits;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;

/**
 * The {@code /applications} picker: one paper per staff rank (Mod, Admin,
 * Sr Admin, Head Admin, Sr Head Admin, Co-Owner). Clicking a paper closes the
 * menu and starts that rank's question set, which is asked one question at a
 * time in chat.
 *
 * <p>Every slot is a button - nothing here is a real item, so {@link #clicked}
 * blocks vanilla container behaviour the same way the other menus do.
 */
final class ApplicationsMenu extends ChestMenu {
	// 3 rows = 27 slots
	private static final int ROWS = 3;
	private static final int SIZE = ROWS * 9;

	private static final int INFO_SLOT = 4;
	// Six papers across the middle row (border columns 0 and 8 are panes).
	private static final int[] PAPER_SLOTS = {10, 11, 12, 13, 14, 15};
	private static final int STATUS_SLOT = 16;
	private static final int CLOSE_SLOT = 22;

	private final ServerPlayer owner;

	ApplicationsMenu(int containerId, Inventory inventory, ServerPlayer owner) {
		super(MenuType.GENERIC_9x3, containerId, inventory, new SimpleContainer(SIZE), ROWS);
		this.owner = owner;
		build();
	}

	private void build() {
		SimpleContainer container = (SimpleContainer) getContainer();

		// Border panes (top row, bottom row, and the two side columns).
		ItemStack pane = new ItemStack(Compat.pickItem("STAINED_GLASS_PANE", DyeColor.BLACK));
		pane.set(DataComponents.CUSTOM_NAME, Component.literal(" "));
		for (int i = 0; i < SIZE; i++) {
			int row = i / 9;
			int col = i % 9;
			if (row == 0 || row == ROWS - 1 || col == 0 || col == 8) {
				container.setItem(i, pane);
			}
		}

		// Info panel
		ItemStack info = new ItemStack(Items.BOOK);
		info.set(DataComponents.CUSTOM_NAME, Component.literal("§6§lStaff Applications"));
		info.set(DataComponents.LORE, new ItemLore(List.of(
			Component.literal("§7Pick a rank to apply for."),
			Component.literal("§7Each rank asks its own questions,"),
			Component.literal("§7one at a time in chat."),
			Component.empty(),
			Component.literal("§7Finished applications go to the"),
			Component.literal("§7owner and co-owners for review."),
			Component.empty(),
			Component.literal("§8Say §7cancel §8in chat to abort.")
		)));
		container.setItem(INFO_SLOT, info);

		// Six application papers, one per rank.
		List<Applications.Role> roles = Applications.roles();
		for (int i = 0; i < PAPER_SLOTS.length && i < roles.size(); i++) {
			container.setItem(PAPER_SLOTS[i], paperFor(roles.get(i)));
		}
		if (roles.size() < PAPER_SLOTS.length) {
			for (int i = roles.size(); i < PAPER_SLOTS.length; i++) {
				container.setItem(PAPER_SLOTS[i], filler());
			}
		}
		// Status paper for a rank with no slot left over.
		container.setItem(STATUS_SLOT, statusItem());

		// Close
		ItemStack close = new ItemStack(Items.BARRIER);
		close.set(DataComponents.CUSTOM_NAME, Component.literal("§c§lClose"));
		container.setItem(CLOSE_SLOT, close);
	}

	private ItemStack paperFor(Applications.Role role) {
		ItemStack paper = new ItemStack(Items.PAPER);
		paper.set(DataComponents.CUSTOM_NAME,
			Component.literal(role.color() + "§lApply: §f" + role.display()));

		List<Component> lore = new ArrayList<>();
		lore.add(Component.literal("§7Questions: §f" + role.questions().size()));
		lore.add(Component.empty());

		String heldRole = Applications.staffRoleId(owner.getUUID());
		if (role.id().equals(heldRole)) {
			lore.add(Component.literal("§aYou already hold this rank."));
		} else if (Applications.inProgress(owner.getUUID())) {
			lore.add(Component.literal("§eYou have an application in progress."));
			lore.add(Component.literal("§8Finish or cancel it first."));
		} else if (Applications.hasPending(owner.getUUID())) {
			lore.add(Component.literal("§cYou already have one waiting for review."));
			lore.add(Component.literal("§8Decide: /modlogs is for staff."));
		} else {
			lore.add(Component.literal("§eClick to start -"));
			lore.add(Component.literal("§eanswers are typed in chat."));
		}
		paper.set(DataComponents.LORE, new ItemLore(lore));
		return paper;
	}

	private ItemStack statusItem() {
		ItemStack status = new ItemStack(Items.WRITABLE_BOOK);
		String heldRole = Applications.staffRoleId(owner.getUUID());
		if (heldRole != null) {
			Applications.Role role = Applications.role(heldRole);
			status.set(DataComponents.CUSTOM_NAME, Component.literal("§aYour Rank: "
				+ (role == null ? heldRole : role.color() + role.display())));
			status.set(DataComponents.LORE, new ItemLore(List.of(
				Component.literal("§7Granted staff rank on this server."),
				Component.literal("§7Use /sfmode to toggle admin mode.")
			)));
		} else {
			status.set(DataComponents.CUSTOM_NAME, Component.literal("§eYour Status"));
			List<Component> lore = new ArrayList<>();
			if (Applications.hasPending(owner.getUUID())) {
				lore.add(Component.literal("§7Application: §ePending review"));
			} else if (Applications.inProgress(owner.getUUID())) {
				lore.add(Component.literal("§7Application: §eIn progress (chat)"));
			} else {
				lore.add(Component.literal("§7No staff rank yet."));
				lore.add(Component.literal("§7Pick a paper to apply!"));
			}
			status.set(DataComponents.LORE, new ItemLore(lore));
		}
		return status;
	}

	private static ItemStack filler() {
		ItemStack pane = new ItemStack(Compat.pickItem("STAINED_GLASS_PANE", DyeColor.GRAY));
		pane.set(DataComponents.CUSTOM_NAME, Component.literal(" "));
		return pane;
	}

	// ---- Interaction -------------------------------------------------------

	@Override
	public void clicked(int slotIndex, int buttonNum, ContainerInput containerInput, Player player) {
		if (slotIndex < 0 || slotIndex >= SIZE || !(player instanceof ServerPlayer serverPlayer)) {
			return;
		}
		if (slotIndex == CLOSE_SLOT) {
			serverPlayer.closeContainer();
			return;
		}
		int paperIndex = -1;
		for (int i = 0; i < PAPER_SLOTS.length; i++) {
			if (PAPER_SLOTS[i] == slotIndex) {
				paperIndex = i;
				break;
			}
		}
		if (paperIndex < 0) return;
		List<Applications.Role> roles = Applications.roles();
		if (paperIndex >= roles.size()) return;
		Applications.Role role = roles.get(paperIndex);

		String error = Applications.start(serverPlayer, role.id());
		if (error != null) {
			serverPlayer.sendSystemMessage(Component.literal("§c" + error));
			return;
		}
		// The questionnaire now lives in chat; close the picker.
		serverPlayer.closeContainer();
	}

	@Override
	public boolean stillValid(Player player) {
		return player == owner;
	}
}
