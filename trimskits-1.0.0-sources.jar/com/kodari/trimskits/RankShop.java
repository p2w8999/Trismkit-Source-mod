package com.kodari.trimskits;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;
import net.minecraft.ChatFormatting;
import net.minecraft.core.RegistryAccess;
import net.minecraft.server.level.ServerPlayer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Ranks you can earn with time on the server or buy outright.
 *
 * <p>Every rank is a rung on one ladder, so playtime and money reach the same
 * place - a long-serving player is never locked out because they are poor, and
 * a rich player is never told their money is worthless. Ranks are permanent.
 *
 * <p>The only economic perk is a daily payout, which only ever moves money
 * <em>onto</em> the player. A sell-price bonus would let someone buy low and
 * sell high forever, so that is deliberately not on offer here.
 */
final class RankShop {
	private static final Logger LOGGER = LoggerFactory.getLogger("trimskits");
	private static final Path DATA_FILE = Path.of("config", "trimskits-ranks.properties");
	private static final long PAYOUT_INTERVAL_MILLIS = 24L * 60L * 60L * 1000L;
	/** A version tag so a future format change can be spotted on load. */
	private static final String FORMAT = "v1";

	/** One rung of the ladder. */
	record Rank(int tier, String name, ChatFormatting colour, String how,
			long playtimeSeconds, long price, long dailyPayout) {
		boolean owned(int effectiveTier) {
			return effectiveTier >= tier;
		}

		/** Why this rank is not up for sale right now, or null when it is. */
		String blocked(int effectiveTier) {
			if (tier == 0) {
				return "Everyone starts here.";
			}
			if (owned(effectiveTier)) {
				return "You already have this rank.";
			}
			if (tier != effectiveTier + 1) {
				return "Earn or buy " + RankShop.get(effectiveTier + 1).name() + " first.";
			}
			return null;
		}
	}

	static final List<Rank> RANKS = List.of(
		new Rank(0, "Newcomer", ChatFormatting.GRAY, "Free, everyone starts here",
			0L, 0L, 0L),
		new Rank(1, "Miner", ChatFormatting.WHITE, "1 hour played, or buy it",
			3_600L, 1_000L, 50L),
		new Rank(2, "Trader", ChatFormatting.GREEN, "5 hours played, or buy it",
			18_000L, 5_000L, 200L),
		new Rank(3, "Veteran", ChatFormatting.AQUA, "20 hours played, or buy it",
			72_000L, 25_000L, 750L),
		new Rank(4, "Elite", ChatFormatting.BLUE, "50 hours played, or buy it",
			180_000L, 100_000L, 2_500L),
		new Rank(5, "Champion", ChatFormatting.LIGHT_PURPLE, "100 hours played, or buy it",
			360_000L, 400_000L, 7_500L),
		new Rank(6, "Master", ChatFormatting.GOLD, "250 hours played, or buy it",
			900_000L, 1_500_000L, 20_000L),
		new Rank(7, "Legend", ChatFormatting.RED, "500 hours played, or buy it",
			1_800_000L, 5_000_000L, 60_000L),
		new Rank(8, "Mythic", ChatFormatting.DARK_AQUA, "800 hours played, or buy it",
			2_880_000L, 12_000_000L, 150_000L),
		new Rank(9, "Eternal", ChatFormatting.DARK_GREEN, "1,200 hours played, or buy it",
			4_320_000L, 30_000_000L, 400_000L),
		new Rank(10, "Ascendant", ChatFormatting.DARK_RED, "1,800 hours played, or buy it",
			6_480_000L, 75_000_000L, 1_000_000L),
		new Rank(11, "Transcendent", ChatFormatting.DARK_PURPLE, "2,600 hours played, or buy it",
			9_360_000L, 180_000_000L, 2_500_000L),
		new Rank(12, "Celestial", ChatFormatting.LIGHT_PURPLE, "3,600 hours played, or buy it",
			12_960_000L, 400_000_000L, 6_000_000L),
		new Rank(13, "Divine", ChatFormatting.GOLD, "5,000 hours played, or buy it",
			18_000_000L, 900_000_000L, 15_000_000L),
		new Rank(14, "Immortal", ChatFormatting.WHITE, "7,000 hours played, or buy it",
			25_200_000L, 2_000_000_000L, 35_000_000L)
	);

	/** Highest purchasable tier, for the /ranks buy argument range. */
	static final int MAX_TIER = RANKS.size() - 1;

	/** purchased tier -> last payout epoch millis. */
	private static final Map<UUID, long[]> OWNERSHIP = new HashMap<>();
	private static boolean loaded;
	private static boolean readable = true;

	private RankShop() {
	}

	static Rank get(int tier) {
		int clamped = Math.max(0, Math.min(RANKS.size() - 1, tier));
		return RANKS.get(clamped);
	}

	static synchronized int purchasedTier(UUID playerId) {
		load();
		long[] record = OWNERSHIP.get(playerId);
		return record == null ? 0 : (int) record[0];
	}

	/** The rank they actually hold, whichever way they got it. */
	static synchronized int effectiveTier(UUID playerId, long playtimeSeconds) {
		return Math.max(earnedTier(playtimeSeconds), purchasedTier(playerId));
	}

	static int earnedTier(long playtimeSeconds) {
		int tier = 0;
		for (Rank rank : RANKS) {
			if (playtimeSeconds >= rank.playtimeSeconds()) {
				tier = rank.tier();
			}
		}
		return tier;
	}

	static synchronized String nameOf(UUID playerId, long playtimeSeconds) {
		return get(effectiveTier(playerId, playtimeSeconds)).name();
	}

	static synchronized ChatFormatting colourOf(UUID playerId, long playtimeSeconds) {
		return get(effectiveTier(playerId, playtimeSeconds)).colour();
	}

	/**
	 * Buys the next rung of the ladder.
	 *
	 * @return null on success, or the reason it did not happen
	 */
	static synchronized String purchase(ServerPlayer player, int tier, RegistryAccess registries) {
		load();
		UUID playerId = player.getUUID();
		Rank rank = get(tier);
		int effective = effectiveTier(playerId, PlayerStats.playtimeSeconds(playerId));

		String blocked = rank.blocked(effective);
		if (blocked != null) {
			return blocked;
		}
		if (!MarketData.debit(playerId, rank.price(), registries)) {
			return "That rank costs $" + TrimKits.formatAmount(rank.price())
				+ " and you have $" + TrimKits.formatAmount(MarketData.balance(playerId)) + ".";
		}

		long previous = purchasedTier(playerId);
		long[] record = OWNERSHIP.computeIfAbsent(playerId, key -> new long[] {0, 0});
		record[0] = tier;
		if (!save()) {
			// Roll the money back rather than charging for a rank that did not save.
			record[0] = previous;
			MarketData.credit(playerId, rank.price(), registries);
			return "Your rank could not be saved. You were not charged.";
		}
		return null;
	}

	/**
	 * Admin: sets the purchased half of the ladder outright, without charging.
	 *
	 * <p>The playtime rank is the <em>higher</em> of what play earned and what
	 * was bought, so this can only ever raise a player's standing - it cannot
	 * demote someone whose hours already put them there. That is deliberate:
	 * the earned half is not a purchase and the admin command does not pretend
	 * to be able to take it away.
	 *
	 * @return null on success, or the reason it did not happen
	 */
	static synchronized String adminSetTier(UUID playerId, int tier) {
		load();
		if (tier < 0 || tier > MAX_TIER) {
			return "Rank tiers run from 0 to " + MAX_TIER + ".";
		}
		long previous = purchasedTier(playerId);
		long[] record = OWNERSHIP.computeIfAbsent(playerId, key -> new long[] {0, 0});
		record[0] = tier;
		if (!save()) {
			record[0] = previous;
			return "That change could not be saved. Nothing was changed.";
		}
		return null;
	}

	/**
	 * Pays out the daily allowance for the rank the player currently holds.
	 *
	 * @return the amount paid, or 0 when it is too early
	 */
	static synchronized long claimPayout(ServerPlayer player, RegistryAccess registries) {
		load();
		UUID playerId = player.getUUID();
		long tier = effectiveTier(playerId, PlayerStats.playtimeSeconds(playerId));
		Rank rank = get((int) tier);
		if (rank.dailyPayout() <= 0) {
			return 0;
		}
		long[] record = OWNERSHIP.computeIfAbsent(playerId, key -> new long[] {0, 0});
		long now = System.currentTimeMillis();
		if (now - record[1] < PAYOUT_INTERVAL_MILLIS) {
			return 0;
		}
		long previousClaim = record[1];
		if (!MarketData.credit(playerId, rank.dailyPayout(), registries)) {
			return -1;
		}
		record[1] = now;
		if (!save()) {
			// The money is already paid, so undo the credit rather than leave a
			// cooldown that only exists in memory - otherwise the payout can be
			// claimed again straight after a restart.
			record[1] = previousClaim;
			MarketData.debit(playerId, rank.dailyPayout(), registries);
			return -1;
		}
		return rank.dailyPayout();
	}

	/** Milliseconds until the next payout is due; 0 when it is ready now. */
	static synchronized long millisUntilPayout(UUID playerId) {
		load();
		long[] record = OWNERSHIP.get(playerId);
		if (record == null) {
			return 0;
		}
		long remaining = PAYOUT_INTERVAL_MILLIS - (System.currentTimeMillis() - record[1]);
		return Math.max(0, remaining);
	}

	static synchronized long dailyPayout(UUID playerId, long playtimeSeconds) {
		return get(effectiveTier(playerId, playtimeSeconds)).dailyPayout();
	}

	/** Formats seconds into a human-readable playtime string. */
	static String formatTime(long seconds) {
		if (seconds < 60) return seconds + "s";
		long minutes = seconds / 60;
		if (minutes < 60) return minutes + "m";
		long hours = minutes / 60;
		if (hours < 24) return hours + "h";
		long days = hours / 24;
		return days + "d";
	}

	private static synchronized void load() {
		if (loaded) {
			return;
		}
		loaded = true;
		if (!Files.exists(DATA_FILE)) {
			return;
		}
		Properties properties = new Properties();
		try (InputStream input = Files.newInputStream(DATA_FILE)) {
			properties.load(input);
		} catch (IOException exception) {
			readable = false;
			LOGGER.warn("Could not read {}; ranks stay in memory only.", DATA_FILE);
			return;
		}
		for (String key : properties.stringPropertyNames()) {
			try {
				String[] fields = properties.getProperty(key).split("\\|", -1);
				if (fields.length != 3 || !FORMAT.equals(fields[0])) {
					continue;
				}
				UUID playerId = UUID.fromString(key);
				OWNERSHIP.put(playerId, new long[] {
					Long.parseLong(fields[1]),
					Long.parseLong(fields[2])
				});
			} catch (RuntimeException ignored) {
				// Skip a damaged line instead of failing the whole file.
			}
		}
	}

	private static synchronized boolean save() {
		if (!readable) {
			return false;
		}
		Properties properties = new Properties();
		for (Map.Entry<UUID, long[]> record : OWNERSHIP.entrySet()) {
			properties.setProperty(record.getKey().toString(), String.join("|",
				FORMAT,
				Long.toString((long) record.getValue()[0]),
				Long.toString(record.getValue()[1])));
		}

		Path temporaryFile = DATA_FILE.resolveSibling("trimskits-ranks.tmp");
		try {
			Files.createDirectories(DATA_FILE.getParent());
			try (OutputStream output = Files.newOutputStream(temporaryFile)) {
				properties.store(output, "Trim Kits purchased ranks");
			}
			try {
				Files.move(temporaryFile, DATA_FILE, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
			} catch (AtomicMoveNotSupportedException exception) {
				Files.move(temporaryFile, DATA_FILE, StandardCopyOption.REPLACE_EXISTING);
			}
			return true;
		} catch (IOException exception) {
			LOGGER.warn("Could not save ranks: {}", exception.getMessage());
			return false;
		}
	}
}
