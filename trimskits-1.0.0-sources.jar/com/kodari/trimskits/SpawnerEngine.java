package com.kodari.trimskits;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The controlled spawner production engine.
 *
 * <p>One shared pass runs on {@code spawners.generation_interval_ticks} for
 * every online player — not one scheduled task per spawner, and never a scan of
 * the world's entities. Each pass reads only the owning player's inventory
 * (a bounded 36-ish slots) to find out what they are carrying, then produces
 * into that player's {@link SpawnerState}. This is what stops a stack of 100
 * spawners from becoming 100 ticking loops: the whole stack is a single line of
 * arithmetic, and its size scales the <em>rate</em>, never the number of tasks.
 *
 * <p>Exactly one mode runs, chosen by {@code spawners.mode}, so the two can
 * never be active at once and double the output:
 * <ul>
 *   <li><b>{@code virtual}</b> (default, preferred for high stacks): loot is
 *       generated straight into persistent storage, bounded by the storage
 *       capacity. No entities are created, so it is safe next to a busy base.</li>
 *   <li><b>{@code real}</b>: actual entities are spawned around the owner, hard
 *       capped by {@code spawners.max_active_entities}. The cap counts what is
 *       already alive near the player first, so it degrades safely instead of
 *       flooding the world.</li>
 * </ul>
 *
 * <p>Production is deliberately offline-proof in the safe direction: it only
 * runs while the owner is online and holding the spawners. A player cannot
 * accumulate loot while away, and a spawner moved into a chest stops working —
 * which keeps the "nearby player" rule true by construction rather than by a
 * fragile distance check.
 */
final class SpawnerEngine {

	private static final Logger LOGGER = LoggerFactory.getLogger("trimskits");

	/**
	 * Fractional production carried between passes, keyed {@code player|entity}.
	 *
	 * <p>Without this, an efficiency multiplier of 1.25 on a single spawner
	 * would floor to 1.0 forever and quietly swallow a quarter of the output.
	 * Holding the remainder means an upgrade pays out its full value. Entries
	 * are dropped when their owner leaves or the spawner is gone, so the map
	 * stays bounded by the number of online players actually carrying spawners.
	 */
	private static final Map<String, Double> PROGRESS = new HashMap<>();

	/** Production points that one spawner item contributes per pass. */
	private static final double BASE_POINTS_PER_ITEM = 1.0;

	private SpawnerEngine() {
	}

	/** Drops carried progress when a player disconnects; keeps the map small. */
	static void forget(UUID playerId) {
		if (playerId == null) {
			return;
		}
		String prefix = playerId + "|";
		PROGRESS.keySet().removeIf(key -> key.startsWith(prefix));
	}

	/**
	 * Runs one production pass for every online player.
	 *
	 * <p>Called from the shared economy tick on the configured interval. Every
	 * guard below is cheap and local, so a server that has spawners switched off
	 * pays a single boolean read for the whole feature.
	 */
	static void tick(MinecraftServer server) {
		if (!Config.getBoolean("spawners.enabled")) {
			return;
		}
		String mode = mode();
		boolean virtual = !"real".equals(mode);
		for (ServerPlayer player : server.getPlayerList().getPlayers()) {
			try {
				if (virtual) {
					produceVirtual(player);
				} else {
					produceReal(player, server);
				}
			} catch (RuntimeException exception) {
				// One bad player/type must never stop the engine for everyone.
				LOGGER.warn("Spawner production failed for {}: {}",
					player.getScoreboardName(), exception.getMessage());
			}
		}
		// Persist only when something actually changed since the last flush.
		SpawnerState.saveIfDirty(SpawnerState.revision());
	}

	/** The configured mode, normalised so unknown values fall back to virtual. */
	private static String mode() {
		String raw = Config.getString("spawners.mode", "virtual").trim().toLowerCase();
		return "real".equals(raw) ? "real" : "virtual";
	}

	// ---- Virtual mode ------------------------------------------------------

	/**
	 * Generates loot into storage for every spawner type the player holds.
	 *
	 * <p>Nothing here touches the world, so it stays correct across chunk
	 * unload and restart — the only state it writes is the player's own
	 * persistent record.
	 */
	private static void produceVirtual(ServerPlayer player) {
		Map<String, Integer> held = SpawnerItem.countByType(player.getInventory());
		if (held.isEmpty()) {
			// Carrying nothing: drop any half-finished progress for this player.
			forget(player.getUUID());
			return;
		}
		// Remove progress for types no longer held, so a sold spawner cannot
		// keep banking production it never earned.
		String prefix = player.getUUID() + "|";
		PROGRESS.keySet().removeIf(key ->
			key.startsWith(prefix) && !held.containsKey(key.substring(prefix.length())));

		boolean autoSell = Config.getBoolean("spawners.auto_sell");

		for (Map.Entry<String, Integer> entry : held.entrySet()) {
			SpawnerType.Spec type = SpawnerType.byId(entry.getKey());
			if (!SpawnerType.usable(type)) {
				continue;
			}
			int count = Math.max(0, entry.getValue());
			if (count == 0) {
				continue;
			}
			double multiplier = SpawnerState.rateMultiplier(player.getUUID(), type.entityId());
			double produced = count * multiplier * BASE_POINTS_PER_ITEM;
			if (produced <= 0) {
				continue;
			}

			String key = prefix + type.entityId();
			double carried = PROGRESS.getOrDefault(key, 0.0) + produced;
			long wholePoints = (long) Math.floor(carried);
			if (wholePoints <= 0) {
				PROGRESS.put(key, carried);
				continue;
			}
			PROGRESS.put(key, carried - wholePoints);

			Map<String, Long> gains = lootFor(type, wholePoints);
			if (gains.isEmpty()) {
				continue;
			}
			if (autoSell) {
				sellImmediately(player, type, gains);
			} else {
				long accepted = SpawnerState.store(player.getUUID(), type.entityId(), gains);
				if (accepted == 0 && Config.getBoolean("spawners.announce_production")) {
					player.sendSystemMessage(net.minecraft.network.chat.Component.literal(
						"§e" + type.spawnerName() + " storage is full - collect it at /spawners."));
				}
			}
		}
	}

	/**
	 * Converts whole production points into loot items using the type's table.
	 *
	 * <p>Every value is validated against the real item registry, so a loot
	 * entry naming a missing item yields nothing rather than an unobtainable or
	 * crash-prone stack. Counts are clamped so a large stack cannot overflow a
	 * long when multiplied by a big point total.
	 */
	private static Map<String, Long> lootFor(SpawnerType.Spec type, long points) {
		Map<String, Long> gains = new HashMap<>();
		if (points <= 0) {
			return gains;
		}
		for (Map.Entry<String, Integer> drop : type.loot().entrySet()) {
			Item item = BuiltInRegistries.ITEM.getOptional(Identifier.tryParse(drop.getKey())).orElse(null);
			if (item == null || item == net.minecraft.world.item.Items.AIR) {
				continue;
			}
			long perPoint = Math.max(0, drop.getValue());
			if (perPoint == 0) {
				continue;
			}
			try {
				long total = Math.multiplyExact(perPoint, points);
				gains.put(drop.getKey(), Math.min(total, 1_000_000_000L));
			} catch (ArithmeticException overflow) {
				gains.put(drop.getKey(), 1_000_000_000L);
			}
		}
		return gains;
	}

	/**
	 * Sells generated loot straight to the bank instead of storing it.
	 *
	 * <p>Prices are read at this instant and credited exactly once per batch, so
	 * an auto-selling spawner can never pay twice for the same items.
	 */
	private static void sellImmediately(ServerPlayer player, SpawnerType.Spec type,
			Map<String, Long> gains) {
		long total = 0;
		int units = 0;
		for (Map.Entry<String, Long> gain : gains.entrySet()) {
			Item item = BuiltInRegistries.ITEM.getOptional(Identifier.tryParse(gain.getKey())).orElse(null);
			if (item == null) {
				continue;
			}
			ItemStack sample = new ItemStack(item, 1);
			Long unit = ShopValues.sellPrice(sample);
			if (unit == null || unit <= 0) {
				continue;
			}
			try {
				total = Math.addExact(total, Math.multiplyExact(unit, gain.getValue()));
			} catch (ArithmeticException overflow) {
				total = Long.MAX_VALUE / 4;
			}
			units += (int) Math.min(gain.getValue(), Integer.MAX_VALUE);
		}
		if (total <= 0) {
			return;
		}
		if (MarketData.credit(player.getUUID(), total, player.level().registryAccess())) {
			PlayerStats.recordItemsSold(player.getUUID(), units);
			Ledger.record(player.getUUID(), total, "spawner-autosell",
				type.entityId() + " " + units + " item(s)");
			if (Config.getBoolean("spawners.announce_production")) {
				player.sendSystemMessage(net.minecraft.network.chat.Component.literal(
					"§a" + type.spawnerName() + " auto-sold " + TrimKits.formatAmount(units)
						+ " item(s) for $" + TrimKits.formatMoney(total) + "."));
			}
		}
	}

	// ---- Real mode ---------------------------------------------------------

	/**
	 * Spawns actual entities around the owner, respecting the configured cap.
	 *
	 * <p>The cap is enforced by counting what is already alive near the player
	 * before spawning anything, and only a few entities are added per pass. If
	 * the area is already at the limit this pass simply does nothing — it never
	 * queues more work and never removes entities someone else placed.
	 */
	private static void produceReal(ServerPlayer player, MinecraftServer server) {
		ServerLevel level = player.level();
		Map<String, Integer> held = SpawnerItem.countByType(player.getInventory());
		if (held.isEmpty()) {
			return;
		}
		// A spawner only works when somebody is actually there to feed it.
		if (Config.getBoolean("spawners.require_nearby_player") && player.isRemoved()) {
			return;
		}
		int maxActive = Math.max(0, Config.getInt("spawners.max_active_entities"));
		if (maxActive == 0) {
			return;
		}
		int spawnRadius = Math.max(4, Config.getInt("spawners.nearby_player_blocks") / 4);

		for (Map.Entry<String, Integer> entry : held.entrySet()) {
			SpawnerType.Spec type = SpawnerType.byId(entry.getKey());
			if (!SpawnerType.usable(type)) {
				continue;
			}
			EntityType<?> entityType = resolveEntity(type);
			if (entityType == null) {
				continue;
			}
			int count = entry.getValue();
			// Bigger stacks mean a faster spawn cadence, but never a larger
			// burst: the per-pass batch stays small and the cap is absolute.
			int desired = Math.min(Math.max(1, count / 8 + 1), 4);
			desired = Math.min(desired, 4);

			AABB area = player.getBoundingBox().inflate(spawnRadius);
			int alive = countNearby(level, area, entityType);
			int room = maxActive - alive;
			if (room <= 0) {
				continue;
			}
			int toSpawn = Math.min(desired, room);
			for (int spawned = 0; spawned < toSpawn; spawned++) {
				spawnOne(level, entityType, player, spawnRadius);
			}
		}
	}

	/** Counts already-alive entities of this type near the player. */
	private static int countNearby(ServerLevel level, AABB area, EntityType<?> entityType) {
		int total = 0;
		for (Entity entity : level.getEntitiesOfClass(Mob.class, area, mob -> true)) {
			if (entity.getType() == entityType) {
				total++;
			}
		}
		return total;
	}

	/** Creates and places one entity a short way from the player. */
	private static void spawnOne(ServerLevel level, EntityType<?> entityType,
			ServerPlayer player, int radius) {
		Entity entity = entityType.create(level, EntitySpawnReason.SPAWNER);
		if (entity == null) {
			return;
		}
		net.minecraft.util.RandomSource random = level.getRandom();
		double angle = random.nextDouble() * Math.PI * 2.0;
		double distance = 2.0 + random.nextDouble() * Math.max(1.0, radius - 2.0);
		double x = player.getX() + Math.cos(angle) * distance;
		double z = player.getZ() + Math.sin(angle) * distance;
		double y = player.getY();
		entity.setPos(x, y, z);
		entity.setYRot(random.nextFloat() * 360.0f);
		if (entity instanceof Mob mob) {
			mob.finalizeSpawn(level, level.getCurrentDifficultyAt(entity.blockPosition()),
				EntitySpawnReason.SPAWNER, null);
		}
		level.addFreshEntity(entity);
	}

	/** Resolves a spawner's type to a real entity type, or null if unsupported. */
	private static EntityType<?> resolveEntity(SpawnerType.Spec type) {
		Identifier id = Identifier.tryParse(type.entityId());
		if (id == null) {
			return null;
		}
		return BuiltInRegistries.ENTITY_TYPE.getOptional(id).orElse(null);
	}
}
