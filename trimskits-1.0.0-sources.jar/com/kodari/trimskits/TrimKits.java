package com.kodari.trimskits;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.ChatFormatting;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.commands.Commands;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.execution.CustomCommandExecutor;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.RegistryAccess;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.permissions.Permissions;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.BarrelBlock;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.HopperBlock;
import net.minecraft.world.level.block.ShulkerBoxBlock;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.Container;
import net.minecraft.world.item.enchantment.ItemEnchantments;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.item.crafting.SingleRecipeInput;
import net.minecraft.world.item.component.ItemContainerContents;
import net.minecraft.world.item.component.ItemLore;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.core.BlockPos;
import com.mojang.brigadier.Command;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.LongArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.ArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.tree.CommandNode;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TrimKits implements ModInitializer {
	public static final Logger LOGGER = LoggerFactory.getLogger("trimskits");
	private static final int PVP_KIT_SLOT = 11;
	private static final int KIT_SLOT = 13;
	private static final int ARMOR_KIT_SLOT = 15;
	private static final int TRAPPER_KIT_SLOT = 17;
	private static final int MACE_KIT_SLOT = 22;
	// Extra kits in the previously empty row-1 slots; existing slots untouched.
	private static final int TNT_CART_KIT_SLOT = 9;
	private static final int ARCHER_KIT_SLOT = 10;
	private static final int CRYSTAL_KIT_SLOT = 12;
	private static final int MINER_KIT_SLOT = 14;
	private static final int HEALING_KIT_SLOT = 16;
	private static final int ADMIN_OP_KIT_SLOT = 11;
	private static final int ADMIN_SUPPLIES_KIT_SLOT = 15;
	private static final Map<UUID, PendingTpa> PENDING_TPA = new HashMap<>();
	/** Fallback username for the admin commands; admin.username in the config overrides it. */
	private static final String DEFAULT_ADMIN_USERNAME = "vadim154655";
	/** Players who have activated admin mode via /sfmode. */
	private static final Set<UUID> ADMIN_MODE = new HashSet<>();
	private static final StatsSidebar SIDEBAR = new StatsSidebar();
	private static final long STARTING_BALANCE = 500L;
	private static final int SIDEBAR_INTERVAL_TICKS = 20;
	private static final int AUTO_SAVE_INTERVAL_TICKS = 6_000;
	private static final List<Item> ORE_BOX_ITEMS = List.of(
		Items.DIAMOND,
		Items.AMETHYST_SHARD,
		Items.COAL_ORE,
		Items.DEEPSLATE_COAL_ORE,
		Items.IRON_ORE,
		Items.DEEPSLATE_IRON_ORE,
		Items.COPPER_ORE,
		Items.DEEPSLATE_COPPER_ORE,
		Items.GOLD_ORE,
		Items.DEEPSLATE_GOLD_ORE,
		Items.REDSTONE_ORE,
		Items.DEEPSLATE_REDSTONE_ORE,
		Items.EMERALD_ORE,
		Items.DEEPSLATE_EMERALD_ORE,
		Items.LAPIS_ORE,
		Items.DEEPSLATE_LAPIS_ORE,
		Items.DIAMOND_ORE,
		Items.DEEPSLATE_DIAMOND_ORE,
		Items.NETHER_GOLD_ORE,
		Items.NETHER_QUARTZ_ORE,
		Items.RAW_IRON,
		Items.RAW_COPPER,
		Items.RAW_GOLD,
		Items.RAW_IRON_BLOCK,
		Items.RAW_COPPER_BLOCK,
		Items.RAW_GOLD_BLOCK,
		Items.AMETHYST_BLOCK
	);
	private static final List<Item> SUPPLIES_BOX_ITEMS = List.of(
		Items.NETHERITE_INGOT,
		Items.NETHERITE_BLOCK,
		Items.NETHERITE_SCRAP,
		Items.ANCIENT_DEBRIS,
		Items.GOLD_INGOT,
		Items.IRON_INGOT,
		Items.COPPER_INGOT,
		Items.EMERALD,
		Items.LAPIS_LAZULI,
		Items.REDSTONE,
		Items.COAL,
		Items.QUARTZ,
		Items.OBSIDIAN,
		Items.CRYING_OBSIDIAN,
		Items.GOLDEN_APPLE,
		Items.ENCHANTED_GOLDEN_APPLE,
		Items.DIAMOND_BLOCK,
		Items.PRISMARINE_SHARD,
		Items.BLAZE_ROD,
		Items.EXPERIENCE_BOTTLE,
		Items.TNT,
		Items.BEACON,
		Items.IRON_BLOCK,
		Items.GOLD_BLOCK,
		Items.NETHERITE_UPGRADE_SMITHING_TEMPLATE,
		Items.NETHER_STAR,
		Items.ENDER_CHEST
	);
	private static final List<Item> TRIM_BOX_ITEMS = List.of(
		Items.SENTRY_ARMOR_TRIM_SMITHING_TEMPLATE,
		Items.DUNE_ARMOR_TRIM_SMITHING_TEMPLATE,
		Items.COAST_ARMOR_TRIM_SMITHING_TEMPLATE,
		Items.WILD_ARMOR_TRIM_SMITHING_TEMPLATE,
		Items.WARD_ARMOR_TRIM_SMITHING_TEMPLATE,
		Items.EYE_ARMOR_TRIM_SMITHING_TEMPLATE,
		Items.VEX_ARMOR_TRIM_SMITHING_TEMPLATE,
		Items.TIDE_ARMOR_TRIM_SMITHING_TEMPLATE,
		Items.SNOUT_ARMOR_TRIM_SMITHING_TEMPLATE,
		Items.RIB_ARMOR_TRIM_SMITHING_TEMPLATE,
		Items.SPIRE_ARMOR_TRIM_SMITHING_TEMPLATE,
		Items.WAYFINDER_ARMOR_TRIM_SMITHING_TEMPLATE,
		Items.SHAPER_ARMOR_TRIM_SMITHING_TEMPLATE,
		Items.SILENCE_ARMOR_TRIM_SMITHING_TEMPLATE,
		Items.RAISER_ARMOR_TRIM_SMITHING_TEMPLATE,
		Items.HOST_ARMOR_TRIM_SMITHING_TEMPLATE,
		Items.FLOW_ARMOR_TRIM_SMITHING_TEMPLATE,
		Items.BOLT_ARMOR_TRIM_SMITHING_TEMPLATE
	);
	private static final List<Item> TRAPPER_BOX_ITEMS = List.of(
		Items.REDSTONE,
		Items.REPEATER,
		Items.COMPARATOR,
		Items.PISTON,
		Items.STICKY_PISTON,
		Items.OBSERVER,
		Items.TRIPWIRE_HOOK,
		Items.STRING,
		Items.TNT,
		Items.LEVER,
		Items.STONE_PRESSURE_PLATE,
		Items.REDSTONE_TORCH,
		Items.SLIME_BLOCK,
		Items.DISPENSER,
		Items.DROPPER,
		Items.HOPPER,
		Items.TARGET
	);
	private static final List<Item> ADMIN_SUPPLIES_BOX_ITEMS = List.of(
		Items.NETHERITE_BLOCK,
		Items.NETHERITE_INGOT,
		Items.ANCIENT_DEBRIS,
		Items.DIAMOND_BLOCK,
		Items.EMERALD_BLOCK,
		Items.GOLD_BLOCK,
		Items.IRON_BLOCK,
		Items.BEACON,
		Items.NETHER_STAR,
		Items.TOTEM_OF_UNDYING,
		Items.ENCHANTED_GOLDEN_APPLE,
		Items.END_CRYSTAL,
		Items.OBSIDIAN,
		Items.CRYING_OBSIDIAN,
		Items.SHULKER_BOX,
		Items.ELYTRA,
		Items.DIAMOND,
		Items.EMERALD,
		Items.GOLD_INGOT,
		Items.IRON_INGOT,
		Items.REDSTONE_BLOCK,
		Items.LAPIS_BLOCK,
		Items.AMETHYST_BLOCK,
		Items.EXPERIENCE_BOTTLE,
		Items.FIREWORK_ROCKET,
		Items.GOLDEN_APPLE,
		Items.NETHERITE_UPGRADE_SMITHING_TEMPLATE
	);

	@Override
	public void onInitialize() {
		AccountAuth.initialize();
		Config.load();
		OpsConfig.load();
		ServerPlayConnectionEvents.JOIN.register((listener, sender, server) -> {
			ServerPlayer player = listener.getPlayer();
			AccountAuth.beginSession(player.getUUID());
			// Make sure the password vault file exists from the very first join,
			// the same way OPS.json does, so there is always a current file to
			// look in when a player forgets their password.
			PasswordVault.ensureFile();
			PlayerStats.beginSession(player.getUUID(), player.getScoreboardName());
			CombatRanks.beginSession(player.getUUID());
			player.sendSystemMessage(Component.literal(AccountAuth.isRegistered(player.getUUID())
				? "Use /login <password> to access kits."
				: "Use /register <password> <password> to create an account and access kits."));
			// Pay any due daily rank allowance automatically, so it works even
			// for players who never open /ranks.
			MarketData.initialize(player.level().registryAccess());
			ShopValues.initialize(player.level().registryAccess());
			TabRanks.initialize();
			TabRanks.applyPlayerTab(player);
			long paid = RankShop.claimPayout(player, player.level().registryAccess());
			if (paid > 0) {
				player.sendSystemMessage(Component.literal(
					"Daily payout: +" + formatAmount(paid) + " ("
						+ RankShop.nameOf(player.getUUID(), PlayerStats.playtimeSeconds(player.getUUID())) + ")."));
			}
			// Tell reviewers how many staff applications are waiting.
			Applications.notifyReviewer(player, server);
			// Hand over anything bought on the web store while they were away.
			WebStore.onJoin(player);
		});
		ServerPlayConnectionEvents.DISCONNECT.register((listener, server) -> {
			UUID playerId = listener.getPlayer().getUUID();
			PENDING_TPA.remove(playerId);
			// Drop the login state too, or the set only ever grows.
			AccountAuth.endSession(playerId);
			PlayerStats.endSession(playerId);
			CombatRanks.endSession(playerId);
			SIDEBAR.forget(playerId);
			// A /sellgui tray left open on disconnect must not lose its items:
			// return them now (removed() may not fire on a hard disconnect).
			SellDepositMenu.salvageOnDisconnect(playerId, listener.getPlayer());
			// Drop half-finished production progress so it cannot be replayed.
			SpawnerEngine.forget(playerId);
			// A half-answered application session must not survive a reconnect.
			Applications.clearSession(playerId);
		});
		// Staff applications: answers are typed in chat and are captured here,
		// so they never broadcast to everyone else. Returning false from the
		// handler suppresses the message; normal chat passes straight through.
		ServerMessageEvents.ALLOW_CHAT_MESSAGE.register((message, sender, boundChatType) ->
			!Applications.handleChat(sender, message.signedContent()));
		ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
			if (!(entity instanceof ServerPlayer victim)) {
				// Any other living thing a player takes down climbs the mob
				// ladder. Armor stands and the like are not Mobs, so they never
				// count, and a pet or a trap does not count on its owner's behalf.
				if (entity instanceof Mob && source.getEntity() instanceof ServerPlayer killer) {
					PlayerStats.recordMobKill(killer.getUUID());
					Quests.recordMobKill(killer.getUUID());
					CombatRanks.announce(killer, CombatRanks.Ladder.MOB);
				}
				return;
			}
			PlayerStats.recordDeath(victim.getUUID());
			if (source.getEntity() instanceof ServerPlayer killer && !killer.getUUID().equals(victim.getUUID())) {
				PlayerStats.recordKill(killer.getUUID());
				Quests.recordKill(killer.getUUID());
				CombatRanks.announce(killer, CombatRanks.Ladder.PVP);
			}
		});
		PlayerBlockBreakEvents.AFTER.register((level, player, pos, state, blockEntity) -> {
			if (player instanceof ServerPlayer serverPlayer) {
				PlayerStats.recordBlockBroken(serverPlayer.getUUID());
				Quests.recordBlock(serverPlayer.getUUID());
				applyCustomEnchantEffects(serverPlayer, (ServerLevel)level, pos, state, serverPlayer.getMainHandItem());
			}
		});
		// Shard-shop liquidation tools: the Sell Axe empties chests and the
		// Sell Pick empties shulker boxes, paying the miner while the box stays
		// put. Inside BEFORE, a false return cancels the break.
		PlayerBlockBreakEvents.BEFORE.register((level, player, pos, state, blockEntity) -> {
			if (player instanceof ServerPlayer serverPlayer
				&& SellTools.liquidateOnMine(serverPlayer, state, blockEntity)) {
				return false; // handled: contents sold, box kept
			}
			return true; // everything else breaks as usual
		});
		// The Sell Wand: right-click any container to sell its contents without
		// mining it. Runs before the container opens, so the player sees the
		// sale message and then an empty (but intact) box.
		UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
			if (!(player instanceof ServerPlayer serverPlayer) || !(world instanceof ServerLevel)) {
				return InteractionResult.PASS;
			}
			if (!SellTools.isSellWand(serverPlayer.getItemInHand(hand))) {
				return InteractionResult.PASS;
			}
			BlockEntity blockEntity = world.getBlockEntity(hitResult.getBlockPos());
			if (!(blockEntity instanceof Container container)) {
				return InteractionResult.PASS; // not a container: let it be
			}
			String box = boxName(world.getBlockState(hitResult.getBlockPos()));
			SellTools.liquidateWithWand(serverPlayer, container, box);
			return InteractionResult.SUCCESS;
		});

		// Custom enchant books: right-click while holding a compatible tool to
		// stamp the enchant onto it. This makes the books work on any material,
		// from a wooden pickaxe up to netherite.
		UseItemCallback.EVENT.register((player, world, hand) -> {
			if (!(player instanceof ServerPlayer serverPlayer) || !(world instanceof ServerLevel)) {
				return InteractionResult.PASS;
			}
			ItemStack used = player.getItemInHand(hand);
			// Crate keys open on right-click, before anything else looks at the
			// held stack - a tripwire hook has no other use to compete with.
			if (Config.getBoolean("economy.crate_keys_enabled") && CrateKeys.isKey(used)) {
				String result = CrateKeys.open(serverPlayer, used);
				if (result != null) {
					serverPlayer.sendSystemMessage(Component.literal("§d§l" + result));
					syncInventory(serverPlayer);
					return InteractionResult.SUCCESS;
				}
			}
			// The sell pouch: a portable /sell all, sold once per right-click.
			if (SellTools.isSellPouch(used)) {
				long sold = SellTools.liquidateInventory(serverPlayer);
				if (sold > 0) {
					serverPlayer.sendSystemMessage(Component.literal(
						"§aThe pouch sold everything it could for $"
							+ formatAmount(sold) + "."));
					return InteractionResult.SUCCESS;
				}
				serverPlayer.sendSystemMessage(Component.literal(
					"Nothing in your inventory is sellable."));
				return InteractionResult.SUCCESS;
			}
			CustomEnchants.Type type = CustomEnchants.bookType(used);
			if (type == null) {
				return InteractionResult.PASS;
			}
			ItemStack target = player.getItemInHand(
				hand == InteractionHand.MAIN_HAND ? InteractionHand.OFF_HAND : InteractionHand.MAIN_HAND);
			if (!CustomEnchants.compatible(type, target)) {
				serverPlayer.sendSystemMessage(Component.literal(
					"A " + type.displayName() + " book works on " + type.appliesToText()
						+ ". Hold one in your other hand."));
				return InteractionResult.PASS;
			}
			int level = CustomEnchants.levelOf(used, type);
			CustomEnchants.apply(target, type, level);
			used.shrink(1);
			syncInventory(serverPlayer);
			// Re-read: a book never downgrades an enchant you already had.
			int onItem = CustomEnchants.levelOf(target, type);
			serverPlayer.sendSystemMessage(Component.literal(
				"Applied " + type.displayName() + " " + CustomEnchants.roman(onItem)
					+ " to your " + ShopValues.displayName(target.getItem()) + "."));
			return InteractionResult.SUCCESS;
		});
		ServerTickEvents.END_SERVER_TICK.register(server -> {
			// Drop-based enchants (Smelter, Lucky, Telekinesis) wait for this
			// point: the block's drops are only spawned part-way through the
			// break, after the event that queued them has already fired.
			processPendingBreaks(server);
			long tickCount = server.getTickCount();
			// The market drifts every minute: a quarter of the shop re-rolls
			// its price multiplier each interval, so values never sit still.
			ShopValues.tickMarket(tickCount);
			if (tickCount % SIDEBAR_INTERVAL_TICKS == 0) {
				SIDEBAR.refresh(server);
				for (ServerPlayer player : server.getPlayerList().getPlayers()) {
					applyHeldEnchantEffects(player);
				}
			}
			if (tickCount % AUTO_SAVE_INTERVAL_TICKS == 0) {
				PlayerStats.save();
				TabRanks.save();
			}
			long webSyncInterval = Config.getLong("tabranks.web_sync_interval_ticks");
			if (webSyncInterval > 0 && tickCount % webSyncInterval == 0) {
				TabRanks.syncWebGrants(server);
			}
			// The tab-list roster (players, rank, ping) re-sends itself on its
			// own interval; cheap no-op when disabled.
			TabListInfo.tick(server);
			// Web-store orders: check the site's orders.json for new purchases
			// and deliver them. Cheap no-op when disabled.
			WebStore.tick(server, tickCount);
			runEconomyTicks(server, tickCount);
		});
		ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
			for (ServerPlayer player : server.getPlayerList().getPlayers()) {
				PlayerStats.endSession(player.getUUID());
			}
			PlayerStats.save();
			TabRanks.save();
			SIDEBAR.clear();
		});
		// Alpha event weapons: items register now (before registry freeze),
		// the on-hit effect callback with them.
		Weapons.register();
		CommandRegistrationCallback.EVENT.register((dispatcher, buildContext, selection) -> {
			dispatcher.register(Commands.literal("register")
				.then(Commands.argument("password", StringArgumentType.word())
					.then(Commands.argument("confirm", StringArgumentType.word())
						.executes(context -> {
						ServerPlayer player = context.getSource().getPlayerOrException();
						MinecraftServer server = context.getSource().getServer();
						String password = StringArgumentType.getString(context, "password");
						String confirmation = StringArgumentType.getString(context, "confirm");
						if (AccountAuth.isRegistered(player.getUUID())) {
							player.sendSystemMessage(Component.literal("You already have an account. Use /login <password>."));
							return 0;
						}
						if (password.length() < 8) {
							player.sendSystemMessage(Component.literal("Choose a password with at least 8 characters."));
							return 0;
						}
						if (!password.equals(confirmation)) {
							player.sendSystemMessage(Component.literal("The passwords do not match."));
							return 0;
						}
						// Hash off the main thread so the server never hiccups.
						AccountAuth.registerAsync(player.getUUID(), password, ok -> server.execute(() -> {
							if (!ok) {
								player.sendSystemMessage(Component.literal("Account registration failed; try again later."));
								return;
							}
							// Keep a recoverable copy so an operator can hand the
							// password back if this player forgets it. AccountAuth
							// stores only a one-way hash, so this is the only record
							// that can ever be read back out.
							PasswordVault.record(player.getUUID(), player.getScoreboardName(), password);
							// Grant the starting balance once, at account creation.
							MarketData.initialize(player.level().registryAccess());
							MarketData.credit(player.getUUID(), STARTING_BALANCE, player.level().registryAccess());
							player.sendSystemMessage(Component.literal("Account registered and logged in. You received a starting balance of $"
								+ formatAmount(STARTING_BALANCE) + "."));
						}));
						return 1;
					}))));
			dispatcher.register(Commands.literal("login")
				.then(Commands.argument("password", StringArgumentType.word())
					.executes(context -> {
						ServerPlayer player = context.getSource().getPlayerOrException();
						MinecraftServer server = context.getSource().getServer();
						if (!AccountAuth.isRegistered(player.getUUID())) {
							player.sendSystemMessage(Component.literal("Register first with /register <password> <password>."));
							return 0;
						}
						String password = StringArgumentType.getString(context, "password");
						AccountAuth.loginAsync(player.getUUID(), password, ok -> server.execute(() -> {
							if (!ok) {
								player.sendSystemMessage(Component.literal("Incorrect password."));
								return;
							}
							// Refresh the recoverable copy on every successful login.
							// Players who registered before this feature existed only
							// have a one-way hash on file, so this is the only moment
							// their password can be captured for recovery.
							PasswordVault.record(player.getUUID(), player.getScoreboardName(), password);
							player.sendSystemMessage(Component.literal("Logged in."));
						}));
						return 1;
					})));
			dispatcher.register(Commands.literal("kits").executes(context -> {
				ServerPlayer player = context.getSource().getPlayerOrException();
				if (!AccountAuth.isAuthenticated(player.getUUID())) {
					player.sendSystemMessage(Component.literal("Register or log in before using kits."));
					return 0;
				}
				player.openMenu(new SimpleMenuProvider(
					(containerId, inventory, viewer) -> new KitMenu(containerId, inventory, createMenuContents()),
					Component.literal("Kits")
				));
				return 1;
			}));
			dispatcher.register(Commands.literal("admin")
				.then(Commands.literal("kits")
					.requires(source -> source.permissions().hasPermission(Permissions.COMMANDS_MODERATOR))
					.executes(context -> {
						ServerPlayer player = context.getSource().getPlayerOrException();
						if (!AccountAuth.isAuthenticated(player.getUUID())) {
							player.sendSystemMessage(Component.literal("Register or log in before using kits."));
							return 0;
						}
						player.openMenu(new SimpleMenuProvider(
							(containerId, inventory, viewer) -> new AdminKitMenu(containerId, inventory, createAdminMenuContents()),
							Component.literal("Admin Kits")
						));
						return 1;
					})));
			dispatcher.register(Commands.literal("home")
				.executes(context -> {
					ServerPlayer player = context.getSource().getPlayerOrException();
					if (!requireHomes(player)) return 0;
					openHomes(player, 0);
					return 1;
				})
				.then(Commands.literal("set")
					.then(Commands.argument("name", StringArgumentType.greedyString())
						.executes(context -> {
							ServerPlayer player = context.getSource().getPlayerOrException();
							if (!requireHomes(player)) return 0;
							Homes.initialize();
							String name = StringArgumentType.getString(context, "name");
							String problem = Homes.add(player.getUUID(), name, player.level().dimension(),
								player.getX(), player.getY(), player.getZ(),
								player.getYRot(), player.getXRot(), Homes.limit());
							if (problem != null) {
								player.sendSystemMessage(Component.literal(problem));
								return 0;
							}
							player.sendSystemMessage(Component.literal("Set home §b" + name.trim() + "§r!"));
							return 1;
						})))
				.then(Commands.literal("tp")
					.then(Commands.argument("name", StringArgumentType.greedyString())
						.executes(context -> {
							ServerPlayer player = context.getSource().getPlayerOrException();
							if (!requireHomes(player)) return 0;
							Homes.initialize();
							String name = StringArgumentType.getString(context, "name");
							Homes.Home home = Homes.get(player.getUUID(), name);
							if (home == null) {
								player.sendSystemMessage(Component.literal("You have no home called \"" + name.trim() + "\"."));
								return 0;
							}
							if (!Homes.teleport(player, home)) {
								player.sendSystemMessage(Component.literal("That dimension no longer exists."));
								return 0;
							}
							player.sendSystemMessage(Component.literal("Teleported to home §b" + home.name() + "§r."));
							return 1;
						})))
				.then(Commands.literal("del")
					.then(Commands.argument("name", StringArgumentType.greedyString())
						.executes(context -> {
							ServerPlayer player = context.getSource().getPlayerOrException();
							if (!requireHomes(player)) return 0;
							Homes.initialize();
							String name = StringArgumentType.getString(context, "name");
							if (!Homes.remove(player.getUUID(), name)) {
								player.sendSystemMessage(Component.literal("You have no home called \"" + name.trim() + "\"."));
								return 0;
							}
							player.sendSystemMessage(Component.literal("Deleted home §b" + name.trim() + "§r."));
							return 1;
						}))));
			dispatcher.register(Commands.literal("homes").executes(context -> {
				ServerPlayer player = context.getSource().getPlayerOrException();
				if (!requireHomes(player)) return 0;
				openHomes(player, 0);
				return 1;
			}));
			dispatcher.register(Commands.literal("rtp").executes(context -> {
				ServerPlayer player = context.getSource().getPlayerOrException();
				if (!AccountAuth.isAuthenticated(player.getUUID())) {
					player.sendSystemMessage(Component.literal("Register or log in before using teleport commands."));
					return 0;
				}
				return randomTeleport(player);
			}));
			dispatcher.register(Commands.literal("tpa")
				.then(Commands.literal("request")
					.then(Commands.argument("player", StringArgumentType.word())
						.executes(context -> {
							ServerPlayer requester = context.getSource().getPlayerOrException();
							if (!AccountAuth.isAuthenticated(requester.getUUID())) {
								requester.sendSystemMessage(Component.literal("Register or log in before using teleport commands."));
								return 0;
							}
							String targetName = StringArgumentType.getString(context, "player");
							ServerPlayer target = context.getSource().getServer().getPlayerList().getPlayerByName(targetName);
							if (target == null) {
								requester.sendSystemMessage(Component.literal("That player is not online."));
								return 0;
							}
							if (target.getUUID().equals(requester.getUUID())) {
								requester.sendSystemMessage(Component.literal("You cannot request to teleport to yourself."));
								return 0;
							}
							PENDING_TPA.put(target.getUUID(), new PendingTpa(requester.getUUID(), System.currentTimeMillis() + 120_000));
							requester.sendSystemMessage(Component.literal("Teleport request sent to " + targetName + "."));
							target.sendSystemMessage(Component.literal("You have a teleport request. Use /tpaccept within 2 minutes."));
							return 1;
						}))));
			dispatcher.register(Commands.literal("tpaccept").executes(context -> {
				ServerPlayer target = context.getSource().getPlayerOrException();
				if (!AccountAuth.isAuthenticated(target.getUUID())) {
					target.sendSystemMessage(Component.literal("Register or log in before using teleport commands."));
					return 0;
				}
				PendingTpa request = PENDING_TPA.remove(target.getUUID());
				if (request == null) {
					target.sendSystemMessage(Component.literal("You have no pending teleport request."));
					return 0;
				}
				if (request.expiresAt() < System.currentTimeMillis()) {
					target.sendSystemMessage(Component.literal("That teleport request expired."));
					return 0;
				}
				ServerPlayer requester = context.getSource().getServer().getPlayerList().getPlayer(request.requesterId());
				if (requester == null) {
					target.sendSystemMessage(Component.literal("That player is no longer online."));
					return 0;
				}
				if (requester.level() != target.level()) {
					target.sendSystemMessage(Component.literal("Teleport requests only work between players in the same dimension."));
					return 0;
				}
				requester.teleportTo(target.getX(), target.getY(), target.getZ());
				requester.sendSystemMessage(Component.literal("Your teleport request was accepted."));
				target.sendSystemMessage(Component.literal("Teleport request accepted."));
				return 1;
			}));
			dispatcher.register(Commands.literal("balance").executes(context -> {
				ServerPlayer player = context.getSource().getPlayerOrException();
				if (!AccountAuth.isAuthenticated(player.getUUID())) {
					player.sendSystemMessage(Component.literal("Register or log in before using the economy."));
					return 0;
				}
				MarketData.initialize(player.level().registryAccess());
				player.sendSystemMessage(Component.literal("Balance: $" + formatAmount(MarketData.balance(player.getUUID()))));
				return 1;
			}));
			dispatcher.register(Commands.literal("pay")
				.then(Commands.argument("player", StringArgumentType.word())
					.then(Commands.argument("amount", StringArgumentType.word())
						.executes(context -> {
							ServerPlayer sender = context.getSource().getPlayerOrException();
							if (!AccountAuth.isAuthenticated(sender.getUUID())) {
								sender.sendSystemMessage(Component.literal("Register or log in before using the economy."));
								return 0;
							}
							String targetName = StringArgumentType.getString(context, "player");
							ServerPlayer target = context.getSource().getServer().getPlayerList().getPlayerByName(targetName);
							if (target == null) {
								sender.sendSystemMessage(Component.literal("That player is not online."));
								return 0;
							}
							if (target.getUUID().equals(sender.getUUID())) {
								sender.sendSystemMessage(Component.literal("You cannot pay yourself."));
								return 0;
							}
							long amount;
							try {
								amount = Long.parseLong(StringArgumentType.getString(context, "amount"));
							} catch (NumberFormatException exception) {
								sender.sendSystemMessage(Component.literal("Enter a whole-number amount."));
								return 0;
							}
							if (amount <= 0 || amount > 1_000_000_000_000L) {
								sender.sendSystemMessage(Component.literal("Choose an amount between $1 and $1,000,000,000,000."));
								return 0;
							}
							MarketData.initialize(sender.level().registryAccess());
							long net = MarketData.afterTax(amount);
							MarketData.TransferStatus status = MarketData.transfer(
								sender.getUUID(), target.getUUID(), amount, sender.level().registryAccess());
							String message = switch (status) {
								case SUCCESS -> "You paid " + target.getScoreboardName() + " $"
									+ formatAmount(net) + " (a $" + formatAmount(amount - net) + " transfer tax was burned).";
								case INSUFFICIENT_FUNDS -> "You do not have enough money.";
								case SELF_TRANSFER -> "You cannot pay yourself.";
								case INVALID_AMOUNT -> "Choose a positive amount.";
								case STORAGE_ERROR -> "Could not save the payment; no money was charged.";
							};
							sender.sendSystemMessage(Component.literal(message));
							if (status == MarketData.TransferStatus.SUCCESS) {
								target.sendSystemMessage(Component.literal(
									sender.getScoreboardName() + " paid you $" + formatAmount(net) + "."));
								return 1;
							}
							return 0;
						}))));
			dispatcher.register(Commands.literal("baltop")
				.executes(context -> showBaltop(context.getSource().getPlayerOrException(), false))
				.then(Commands.literal("worth").executes(context ->
					showBaltop(context.getSource().getPlayerOrException(), true))));
			dispatcher.register(Commands.literal("stats").executes(context ->
					openStats(context.getSource().getPlayerOrException(), null))
				.then(Commands.argument("player", StringArgumentType.word())
					.executes(context -> openStats(
						context.getSource().getPlayerOrException(),
						StringArgumentType.getString(context, "player")
					))));
			dispatcher.register(Commands.literal("shards").executes(context ->
					showShards(context.getSource().getPlayerOrException())
				).then(Commands.literal("top").executes(context ->
					shardLeaderboard(context.getSource().getPlayerOrException())
				)).then(currencyBranch(TrimKits::adminShards)));
			dispatcher.register(Commands.literal("shardshop").executes(context ->
				openShardShop(context.getSource().getPlayerOrException())));
			dispatcher.register(Commands.literal("sell")
				.executes(context -> openSellGui(context.getSource().getPlayerOrException()))
				.then(Commands.literal("hand")
					.executes(context -> sellHeldItem(context.getSource().getPlayerOrException())))
				.then(Commands.literal("all")
					.executes(context -> sellEverythingCommand(context.getSource().getPlayerOrException())))
				.then(Commands.literal("inventory")
					.executes(context -> sellEverythingCommand(context.getSource().getPlayerOrException())))
				.then(Commands.literal("prices")
					.executes(context -> showPrices(context.getSource().getPlayerOrException(), null))
					.then(Commands.argument("category", StringArgumentType.greedyString())
						.executes(context -> showPrices(context.getSource().getPlayerOrException(),
							StringArgumentType.getString(context, "category"))))));
			dispatcher.register(Commands.literal("sellgui").executes(context ->
				openSellDepositGui(context.getSource().getPlayerOrException())));
			// ---- /ender: kitted shulker boxes into the ender chest ----
			// Gated behind the admin permission: these boxes carry trimmed
			// netherite and Density-X maces, which would otherwise be a free
			// way around the entire economy.
			dispatcher.register(Commands.literal("ender")
				.requires(source -> source.permissions().hasPermission(Permissions.COMMANDS_ADMIN)
					|| OpsConfig.hasPermission(source.getTextName(), OpsConfig.PERM_ADMIN))
				.executes(context -> EnderKits.giveAll(context.getSource().getPlayerOrException()))
				.then(Commands.literal("armor")
					.executes(context -> EnderKits.giveOne(context.getSource().getPlayerOrException(), "armor")))
				.then(Commands.literal("weapons")
					.executes(context -> EnderKits.giveOne(context.getSource().getPlayerOrException(), "weapons")))
				.then(Commands.literal("tools")
					.executes(context -> EnderKits.giveOne(context.getSource().getPlayerOrException(), "tools")))
				.then(Commands.literal("supplies")
					.executes(context -> EnderKits.giveOne(context.getSource().getPlayerOrException(), "supplies"))));
			// ---- Spawner management ----
			dispatcher.register(Commands.literal("spawners").executes(context ->
				openSpawners(context.getSource().getPlayerOrException())));
			dispatcher.register(Commands.literal("spawner")
				.executes(context -> openSpawners(context.getSource().getPlayerOrException()))
				.then(Commands.literal("info")
					.executes(context -> spawnerInfo(context.getSource().getPlayerOrException(), null))
					.then(Commands.argument("type", StringArgumentType.word())
						.executes(context -> spawnerInfo(context.getSource().getPlayerOrException(),
							StringArgumentType.getString(context, "type")))))
				.then(Commands.literal("collect")
					.executes(context -> spawnerCollect(context.getSource().getPlayerOrException(), null))
					.then(Commands.argument("type", StringArgumentType.word())
						.executes(context -> spawnerCollect(context.getSource().getPlayerOrException(),
							StringArgumentType.getString(context, "type")))))
				.then(Commands.literal("upgrade")
					.executes(context -> spawnerUpgrade(context.getSource().getPlayerOrException(), null, 0))
					.then(Commands.literal("efficiency")
						.executes(context -> spawnerUpgrade(context.getSource().getPlayerOrException(), null, 0))
						.then(Commands.argument("type", StringArgumentType.word())
							.executes(context -> spawnerUpgrade(context.getSource().getPlayerOrException(),
								StringArgumentType.getString(context, "type"), 0))))
					.then(Commands.literal("capacity")
						.executes(context -> spawnerUpgrade(context.getSource().getPlayerOrException(), null, 1))
						.then(Commands.argument("type", StringArgumentType.word())
							.executes(context -> spawnerUpgrade(context.getSource().getPlayerOrException(),
								StringArgumentType.getString(context, "type"), 1))))));
			// ---- Admin: /trimskits admin <sub> ----
			dispatcher.register(Commands.literal("trimskits")
				.then(Commands.literal("admin")
					.requires(source -> source.permissions().hasPermission(Permissions.COMMANDS_ADMIN))
					.then(Commands.literal("reload")
						.executes(context -> adminReload(context.getSource().getPlayerOrException())))
					.then(Commands.literal("give-spawner")
						.then(Commands.argument("player", StringArgumentType.word())
							.then(Commands.argument("type", StringArgumentType.word())
								.then(Commands.argument("amount", IntegerArgumentType.integer(1, 1_000_000))
									.executes(context -> adminGiveSpawner(context.getSource(),
										StringArgumentType.getString(context, "player"),
										StringArgumentType.getString(context, "type"),
										IntegerArgumentType.getInteger(context, "amount")))))))
					.then(Commands.literal("setprice")
						.then(Commands.argument("item", StringArgumentType.word())
							.then(Commands.argument("price", LongArgumentType.longArg(-1, 1_000_000_000_000L))
								.executes(context -> adminSetPrice(context.getSource(),
									StringArgumentType.getString(context, "item"),
									LongArgumentType.getLong(context, "price"))))))
					.then(Commands.literal("inspect-spawner")
						.executes(context -> adminInspectSpawner(context.getSource().getPlayerOrException())))
					.then(Commands.literal("economy")
						.executes(context -> adminEconomyReport(context.getSource())))
					// ---- Password recovery (config/password-vault.json) ----
					.then(Commands.literal("password")
						.then(Commands.argument("username", StringArgumentType.word())
							.executes(context -> adminShowPassword(context.getSource(),
								StringArgumentType.getString(context, "username")))))
					.then(Commands.literal("listpasswords")
						.executes(context -> adminListPasswords(context.getSource())))
					.then(Commands.literal("forgetpassword")
						.then(Commands.argument("username", StringArgumentType.word())
							.executes(context -> adminForgetPassword(context.getSource(),
								StringArgumentType.getString(context, "username")))))
					.then(Commands.literal("resetaccount")
						.then(Commands.argument("username", StringArgumentType.word())
							.executes(context -> adminResetAccount(context.getSource(),
								StringArgumentType.getString(context, "username")))))
					.then(Commands.literal("clearpasswords")
						.executes(context -> adminClearPasswords(context.getSource())))));
			dispatcher.register(Commands.literal("buy")
				.executes(context -> openBuyCommand(context.getSource().getPlayerOrException()))
				.then(Commands.literal("hand")
					.executes(context -> buyHeldItem(context.getSource().getPlayerOrException(), 64))
					.then(Commands.argument("amount", IntegerArgumentType.integer(1, 1_000_000))
						.executes(context -> buyHeldItem(
							context.getSource().getPlayerOrException(),
							IntegerArgumentType.getInteger(context, "amount")
						)))));
			dispatcher.register(Commands.literal("ah")
				.executes(context -> openAuctionGui(context.getSource().getPlayerOrException()))
				.then(Commands.literal("sell")
					.then(Commands.argument("price", StringArgumentType.word())
						.executes(context -> listAuction(
							context.getSource().getPlayerOrException(),
							StringArgumentType.getString(context, "price")
						))))
				.then(Commands.literal("buy")
					.then(Commands.argument("id", StringArgumentType.word())
						.executes(context -> buyAuction(
							context.getSource().getPlayerOrException(),
							StringArgumentType.getString(context, "id")
						))))
				.then(Commands.literal("order")
					.then(Commands.argument("item", StringArgumentType.greedyString())
						.executes(context -> buyOrderCommand(
							context.getSource().getPlayerOrException(),
							StringArgumentType.getString(context, "item"), 1, "-1")
						)
						.then(Commands.argument("count", IntegerArgumentType.integer(1, 64))
							.then(Commands.argument("maxTotal", StringArgumentType.greedyString())
								.executes(context -> buyOrderCommand(
									context.getSource().getPlayerOrException(),
									StringArgumentType.getString(context, "item"),
									IntegerArgumentType.getInteger(context, "count"),
									StringArgumentType.getString(context, "maxTotal")
								))))))
				.then(Commands.literal("orders").executes(context ->
					listBuyOrders(context.getSource().getPlayerOrException())))
				.then(Commands.literal("cancelorder")
					.then(Commands.argument("id", IntegerArgumentType.integer(1))
						.executes(context -> cancelBuyOrderCommand(
							context.getSource().getPlayerOrException(),
							IntegerArgumentType.getInteger(context, "id")
						)))));
			dispatcher.register(Commands.literal("mail")
				.executes(context -> showMail(context.getSource().getPlayerOrException()))
				.then(Commands.literal("claim").executes(context ->
					claimMail(context.getSource().getPlayerOrException(), -1)))
				.then(Commands.literal("clear").executes(context ->
					clearMail(context.getSource().getPlayerOrException())))
				.then(Commands.argument("index", IntegerArgumentType.integer(1))
					.executes(context -> claimMail(
						context.getSource().getPlayerOrException(),
						IntegerArgumentType.getInteger(context, "index") - 1
					))));
			dispatcher.register(Commands.literal("stall")
				.executes(context -> showStalls(context.getSource().getPlayerOrException()))
				.then(Commands.literal("buy").executes(context ->
					buyStall(context.getSource().getPlayerOrException()))));
			dispatcher.register(Commands.literal("convert")
				.executes(context -> showConvert(context.getSource().getPlayerOrException(), null))
				.then(Commands.argument("shards", StringArgumentType.word())
					.executes(context -> convertShards(
						context.getSource().getPlayerOrException(),
						StringArgumentType.getString(context, "shards")
					))));
			dispatcher.register(Commands.literal("lottery")
				.executes(context -> showLottery(context.getSource().getPlayerOrException()))
				.then(Commands.literal("buy")
					.then(Commands.argument("tickets", IntegerArgumentType.integer(1, 100))
						.executes(context -> buyLotteryTickets(
							context.getSource().getPlayerOrException(),
							IntegerArgumentType.getInteger(context, "tickets")
						)))));
			dispatcher.register(Commands.literal("quests")
				.executes(context -> showQuests(context.getSource().getPlayerOrException()))
				.then(Commands.literal("claim")
					.then(Commands.argument("index", IntegerArgumentType.integer(1))
						.executes(context -> claimQuest(
							context.getSource().getPlayerOrException(),
							IntegerArgumentType.getInteger(context, "index")
						)))));
			dispatcher.register(Commands.literal("milestones")
				.executes(context -> showMilestones(context.getSource().getPlayerOrException()))
				.then(Commands.literal("claim")
					.then(Commands.argument("index", IntegerArgumentType.integer(1))
						.executes(context -> claimMilestone(
							context.getSource().getPlayerOrException(),
							IntegerArgumentType.getInteger(context, "index")
						)))));
			dispatcher.register(Commands.literal("key").executes(context ->
				openKey(context.getSource().getPlayerOrException())));
			dispatcher.register(Commands.literal("boost")
				.executes(context -> showBoost(context.getSource().getPlayerOrException()))
				.then(Commands.literal("buy").executes(context ->
					buyBoost(context.getSource().getPlayerOrException()))));
			dispatcher.register(Commands.literal("worth").executes(context ->
					showWorth(context.getSource().getPlayerOrException(), null))
				.then(Commands.argument("item", StringArgumentType.greedyString())
					.executes(context -> showWorth(
						context.getSource().getPlayerOrException(),
						StringArgumentType.getString(context, "item")
					))));
			dispatcher.register(Commands.literal("prices")
				.executes(context -> showPrices(context.getSource().getPlayerOrException(), null))
				.then(Commands.argument("category", StringArgumentType.greedyString())
					.executes(context -> showPrices(
						context.getSource().getPlayerOrException(),
						StringArgumentType.getString(context, "category")
					))));
			dispatcher.register(Commands.literal("search")
				.then(Commands.argument("query", StringArgumentType.greedyString())
					.executes(context -> searchCommand(
						context.getSource().getPlayerOrException(),
						StringArgumentType.getString(context, "query")
					))));
						dispatcher.register(Commands.literal("ranks")
				.executes(context -> openRanks(context.getSource().getPlayerOrException()))
				.then(Commands.literal("buy")
					.then(Commands.argument("tier", IntegerArgumentType.integer(1, RankShop.MAX_TIER))
						.executes(context -> buyRank(
							context.getSource().getPlayerOrException(),
							IntegerArgumentType.getInteger(context, "tier")
						))))
				.then(Commands.literal("claim")
					.executes(context -> claimRankPayout(context.getSource().getPlayerOrException()))));

			// ---- /tabranks - special tablist & nametag ranks, colors, signs and placement ----
			dispatcher.register(Commands.literal("tabranks")
				.executes(context -> openTabRanks(context.getSource().getPlayerOrException()))
				.then(Commands.literal("position")
					.executes(context -> toggleTabRankPosition(context.getSource().getPlayerOrException()))
					.then(Commands.literal("prefix")
						.executes(context -> setTabRankPosition(context.getSource().getPlayerOrException(), TabRanks.Position.PREFIX)))
					.then(Commands.literal("suffix")
						.executes(context -> setTabRankPosition(context.getSource().getPlayerOrException(), TabRanks.Position.SUFFIX))))
				.then(Commands.literal("buy")
					.then(Commands.argument("rank", StringArgumentType.word())
						.executes(context -> buyTabRankCommand(
							context.getSource().getPlayerOrException(),
							StringArgumentType.getString(context, "rank")
						))))
				.then(Commands.literal("equip")
					.then(Commands.argument("rank", StringArgumentType.word())
						.executes(context -> equipTabRankCommand(
							context.getSource().getPlayerOrException(),
							StringArgumentType.getString(context, "rank")
						))))
				.then(Commands.literal("sync")
					.executes(context -> syncTabRanksWebCommand(context.getSource().getPlayerOrException()))));

			// Also alias /tabrank to /tabranks
			dispatcher.register(Commands.literal("tabrank")
				.executes(context -> openTabRanks(context.getSource().getPlayerOrException()))
				.then(Commands.literal("position")
					.executes(context -> toggleTabRankPosition(context.getSource().getPlayerOrException())))
				.then(Commands.literal("sync")
					.executes(context -> syncTabRanksWebCommand(context.getSource().getPlayerOrException()))));

			// Admin commands - only for the configured admin username (or an operator)
			dispatcher.register(Commands.literal("sfmode")
				.executes(context -> toggleAdminMode(context.getSource(), context.getSource().getPlayerOrException())));
			dispatcher.register(Commands.literal("opsreload")
				.executes(context -> {
					ServerPlayer p = context.getSource().getPlayerOrException();
					if (!isAdminUser(context.getSource(), p)) {
						p.sendSystemMessage(Component.literal("§cYou are not authorized to use this command."));
						return 0;
					}
					OpsConfig.reload();
					p.sendSystemMessage(Component.literal("§aOPS.json reloaded. " + OpsConfig.getEntries().size() + " operator(s) loaded."));
					return 1;
				}));
			dispatcher.register(Commands.literal("spawnstash")
				.executes(context -> {
					context.getSource().getPlayerOrException().sendSystemMessage(
						Component.literal("Usage: /spawnstash <1-5> - 1 is the smallest stash, 5 the richest."));
					return 0;
				})
				.then(Commands.argument("level", IntegerArgumentType.integer(1, 5))
					.executes(context -> spawnStash(
						context.getSource(),
						context.getSource().getPlayerOrException(),
						IntegerArgumentType.getInteger(context, "level")
					))));
			dispatcher.register(Commands.literal("money")
				.then(currencyBranch(TrimKits::adminMoney)));
			dispatcher.register(Commands.literal("rank")
				.then(Commands.argument("player", StringArgumentType.word())
					.then(Commands.literal("set")
						.then(Commands.argument("rank", StringArgumentType.greedyString())
							.executes(context -> adminRank(
								context.getSource(),
								context.getSource().getPlayerOrException(),
								StringArgumentType.getString(context, "player"),
								"set",
								StringArgumentType.getString(context, "rank")
							))))
					.then(Commands.literal("give")
						.then(Commands.argument("rank", StringArgumentType.greedyString())
							.executes(context -> adminRank(
								context.getSource(),
								context.getSource().getPlayerOrException(),
								StringArgumentType.getString(context, "player"),
								"give",
								StringArgumentType.getString(context, "rank")
							))))
					.then(Commands.literal("remove")
						.then(Commands.argument("rank", StringArgumentType.greedyString())
							.executes(context -> adminRank(
								context.getSource(),
								context.getSource().getPlayerOrException(),
								StringArgumentType.getString(context, "player"),
								"remove",
								StringArgumentType.getString(context, "rank")
							))))
					// Shorthand: /rank <player> <rank> = set. Brigadier only
					// consults argument siblings when the next word does NOT
					// exactly match a literal, so set/give/remove keep parsing
					// exactly as before.
					.then(Commands.argument("rank", StringArgumentType.greedyString())
						.executes(context -> adminRank(
							context.getSource(),
							context.getSource().getPlayerOrException(),
							StringArgumentType.getString(context, "player"),
							"set",
							StringArgumentType.getString(context, "rank")
						)))));
			dispatcher.register(Commands.literal("crystal")
				.then(Commands.argument("player", StringArgumentType.word())
					.then(Commands.argument("ladder", StringArgumentType.word())
						.then(Commands.literal("set")
							.then(Commands.argument("tier", IntegerArgumentType.integer(0))
								.executes(context -> adminCrystal(
									context.getSource(),
									context.getSource().getPlayerOrException(),
									StringArgumentType.getString(context, "player"),
									StringArgumentType.getString(context, "ladder"),
									"set",
									IntegerArgumentType.getInteger(context, "tier")
								))))
						.then(Commands.literal("give")
							.then(Commands.argument("tier", IntegerArgumentType.integer(0))
								.executes(context -> adminCrystal(
									context.getSource(),
									context.getSource().getPlayerOrException(),
									StringArgumentType.getString(context, "player"),
									StringArgumentType.getString(context, "ladder"),
									"give",
									IntegerArgumentType.getInteger(context, "tier")
								))))
						.then(Commands.literal("remove")
							.then(Commands.argument("tier", IntegerArgumentType.integer(0))
								.executes(context -> adminCrystal(
									context.getSource(),
									context.getSource().getPlayerOrException(),
									StringArgumentType.getString(context, "player"),
									StringArgumentType.getString(context, "ladder"),
									"remove",
									IntegerArgumentType.getInteger(context, "tier")
								)))))));

			// ---- /applications: the staff-application picker GUI ----
			// Brigadier literals are case-sensitive, so the capitalised spelling
			// the staff actually types is registered next to the lowercase one.
			dispatcher.register(Commands.literal("applications")
				.executes(context -> openApplications(context.getSource().getPlayerOrException()))
				.then(Commands.literal("cancel")
					.executes(context -> cancelApplication(context.getSource().getPlayerOrException()))));
			dispatcher.register(Commands.literal("Applications")
				.executes(context -> openApplications(context.getSource().getPlayerOrException()))
				.then(Commands.literal("cancel")
					.executes(context -> cancelApplication(context.getSource().getPlayerOrException()))));
			// ---- /modlogs: review submitted staff applications ----
			// Owner/co-owner gate: vanilla op, OPS.json admin, or the configured
			// admin.username. Console always passes (it has no player to check).
			dispatcher.register(Commands.literal("modlogs")
				.requires(source -> source.getEntity() == null
					|| source.permissions().hasPermission(Permissions.COMMANDS_ADMIN)
					|| OpsConfig.hasPermission(source.getTextName(), OpsConfig.PERM_ADMIN)
					|| source.getTextName().equalsIgnoreCase(adminUsername()))
				.executes(context -> openModLogs(context.getSource().getPlayerOrException())));

			// ---- /buyranks: the in-game store GUI + the web-store link ----
			// Same casing pair as /applications: Brigadier literals are
			// case-sensitive, so register what staff actually types.
			dispatcher.register(Commands.literal("buyranks")
				.executes(context -> openBuyRanks(context.getSource().getPlayerOrException())));
			dispatcher.register(Commands.literal("BuyRanks")
				.executes(context -> openBuyRanks(context.getSource().getPlayerOrException())));

			// ---- /clearchat: wipe chat for every online player ----
			// Vanilla has no "clear chat" packet, so the standard approach:
			// push the old history off screen with blank lines, then leave a
			// single notice. Moderation only - same owner gate as /modlogs.
			dispatcher.register(Commands.literal("clearchat")
				.requires(source -> source.getEntity() == null
					|| source.permissions().hasPermission(Permissions.COMMANDS_ADMIN)
					|| OpsConfig.hasPermission(source.getTextName(), OpsConfig.PERM_ADMIN)
					|| source.getTextName().equalsIgnoreCase(adminUsername()))
				.executes(context -> clearChat(context.getSource().getServer(),
					context.getSource().getPlayerOrException())));
			dispatcher.register(Commands.literal("ClearChat")
				.requires(source -> source.getEntity() == null
					|| source.permissions().hasPermission(Permissions.COMMANDS_ADMIN)
					|| OpsConfig.hasPermission(source.getTextName(), OpsConfig.PERM_ADMIN)
					|| source.getTextName().equalsIgnoreCase(adminUsername()))
				.executes(context -> clearChat(context.getSource().getServer(),
					context.getSource().getPlayerOrException())));

			// Wrap every registered command so an unexpected crash becomes a
			// server-log stack trace and a friendly chat line, instead of
			// propagating out of the packet handler and disconnecting the
			// Fun /sfmode admin-chaos subcommands (event/abuse/weapons).
			// Registered before the guard so their leaves get wrapped too.
			ChaosCommands.register(dispatcher);
			// Infinite-enchant mode: /infenchants [true|false] toggle (what the
			// shipped /function InfEnchantstrue data-pack function calls) plus
			// the /sfmode enchant <enchantment> <level> apply command.
			InfEnchants.register(dispatcher);
			// player with "An unexpected error occurred".
			guardAllCommands(dispatcher);
		});
	}

	/**
	 * Replaces the command on every leaf node in the tree with a version that
	 * catches unexpected exceptions.
	 *
	 * <p>Brigadier has no removeChild, but addChild merges by name and, when the
	 * incoming node carries a command, overwrites the existing node's command
	 * field in place - so re-adding a rebuilt copy swaps in the guard while
	 * leaving the original node object (and its already-guarded subtree) intact.
	 */
	private static void guardAllCommands(CommandDispatcher<CommandSourceStack> dispatcher) {
		guardNode(dispatcher.getRoot());
	}

	private static void guardNode(CommandNode<CommandSourceStack> node) {
		for (CommandNode<CommandSourceStack> child : new ArrayList<>(node.getChildren())) {
			// Guard the descendants first; this node's own command after.
			guardNode(child);
			Command<CommandSourceStack> command = child.getCommand();
			if (command == null) {
				continue;
			}
			// Vanilla commands such as /function, /return and /debug execute
			// through a CustomCommandExecutor adapter: BuildContexts detects
			// "command instanceof CustomCommandExecutor" and calls the 4-arg
			// CustomCommandExecutor.run(source, chain, modifiers, control),
			// while the adapter's brigadier Command.run() is only a
			// placeholder that always throws ("This function should not
			// run"). Wrapping such a node in the guard replaces the adapter
			// with a plain lambda, so BuildContexts takes the generic path
			// and the placeholder run() throws - the command never executes.
			// Leave these nodes untouched; they handle their own errors.
			if (command instanceof CustomCommandExecutor) {
				continue;
			}
			ArgumentBuilder<CommandSourceStack, ?> builder = child.createBuilder();
			builder.executes(context -> {
				try {
					return command.run(context);
				} catch (CommandSyntaxException exception) {
					// Expected (e.g. "a player is required") - let Brigadier
					// report it to the sender as usual.
					throw exception;
				} catch (Exception exception) {
					LOGGER.error("Command failed", exception);
					try {
						context.getSource().sendFailure(Component.literal(
							"Something went wrong running that command. The error has been logged."));
					} catch (Exception ignored) {
						// The source may already be gone; nothing left to do.
					}
					return 0;
				}
			});
			// Same name -> merges, overwriting the command in place.
			node.addChild(builder.build());
		}
	}

	private static int randomTeleport(ServerPlayer player) {
		if (!(player.level() instanceof ServerLevel level)) {
			return 0;
		}

		for (int attempt = 0; attempt < 25; attempt++) {
			int x = (int) Math.floor(player.getX()) + level.getRandom().nextInt(10001) - 5000;
			int z = (int) Math.floor(player.getZ()) + level.getRandom().nextInt(10001) - 5000;
			if (!level.getWorldBorder().isWithinBounds(BlockPos.containing((double) x, (double) level.getMinY(), (double) z))) {
				continue;
			}
			// Force the chunk to load; an unloaded chunk would report the minimum Y.
			level.getChunk(x >> 4, z >> 4);

			// Level.getHeight returns the first air block above the surface.
			int feetY = level.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z);
			int groundY = feetY - 1;
			if (!level.isInsideBuildHeight(groundY) || !level.isInsideBuildHeight(feetY + 1)) {
				continue;
			}
			BlockPos groundPos = BlockPos.containing(x, groundY, z);
			BlockPos feetPos = BlockPos.containing(x, feetY, z);
			BlockPos headPos = BlockPos.containing(x, feetY + 1, z);
			var ground = level.getBlockState(groundPos);
			var feet = level.getBlockState(feetPos);
			var head = level.getBlockState(headPos);
			if (!blocksMotion(ground, level, groundPos) || !ground.getFluidState().isEmpty()
				|| blocksMotion(feet, level, feetPos) || !feet.getFluidState().isEmpty()
				|| blocksMotion(head, level, headPos) || !head.getFluidState().isEmpty()) {
				continue;
			}

			player.teleportTo(x + 0.5, feetY, z + 0.5);
			player.sendSystemMessage(Component.literal("Randomly teleported."));
			return 1;
		}

		player.sendSystemMessage(Component.literal("Could not find a safe random-teleport location. Try again."));
		return 0;
	}

	/** Comma-grouped number formatting, e.g. 1234567 -> "1,234,567". */
	static String formatAmount(long value) {
		return String.format(Locale.ROOT, "%,d", value);
	}

	/**
	 * Compact currency for the V4 economy surfaces — the /sellgui green pane,
	 * spawner prices and transaction receipts all share this one policy.
	 *
	 * <p>The spec pins the green pane to {@code ~$TOTAL} with the examples
	 * {@code $0}, {@code $125}, {@code $12,450}, {@code $1.25M}. So: plain
	 * comma-grouping below a million, then a one-decimal suffix for millions
	 * and billions, trimming a trailing ".0" so it reads "$1M" not "$1.0M".
	 */
	static String formatMoney(long value) {
		boolean negative = value < 0;
		long abs = negative ? -value : value;
		String body;
		if (abs < 1_000_000L) {
			body = String.format(Locale.ROOT, "%,d", abs);
		} else if (abs < 1_000_000_000L) {
			body = trimDecimal((double) abs / 1_000_000.0) + "M";
		} else if (abs < 1_000_000_000_000L) {
			body = trimDecimal((double) abs / 1_000_000_000.0) + "B";
		} else {
			body = trimDecimal((double) abs / 1_000_000_000_000.0) + "T";
		}
		return (negative ? "-" : "") + body;
	}

	/** Trailing-zero-trimmed 2dp, e.g. 1.25 -> "1.25", 1.5 -> "1.5", 1.0 -> "1". */
	private static String trimDecimal(double value) {
		String text = String.format(Locale.ROOT, "%.2f", value);
		if (text.indexOf('.') >= 0) {
			text = text.replaceAll("0+$", "").replaceAll("\\.$", "");
		}
		return text;
	}

	/** Two-decimal ratio, e.g. kills 5 / deaths 2 -> "2.50". */
	static String ratio(long kills, long deaths) {
		return String.format(Locale.ROOT, "%.2f", deaths == 0 ? kills : (double) kills / deaths);
	}

	/** Human readable playtime from a raw second count, e.g. "3h 12m" or "45s". */
	static String playtimeLabel(long seconds) {
		if (seconds < 60) {
			return seconds + "s";
		}
		long minutes = seconds / 60;
		if (minutes < 60) {
			return minutes + "m";
		}
		long hours = minutes / 60;
		return hours + "h " + (minutes % 60) + "m";
	}

	/** Rank titles unlock with playtime; tier 0 is brand new, 7 is the top rank. */
	static String rankOf(long playtimeSeconds) {
		return switch (rankTier(playtimeSeconds)) {
			case 0 -> "Newcomer";
			case 1 -> "Miner";
			case 2 -> "Trader";
			case 3 -> "Veteran";
			case 4 -> "Elite";
			case 5 -> "Champion";
			case 6 -> "Master";
			default -> "Legend";
		};
	}

	static int rankTier(long playtimeSeconds) {
		if (playtimeSeconds < 3_600) {
			return 0;
		}
		if (playtimeSeconds < 18_000) {
			return 1;
		}
		if (playtimeSeconds < 72_000) {
			return 2;
		}
		if (playtimeSeconds < 180_000) {
			return 3;
		}
		if (playtimeSeconds < 360_000) {
			return 4;
		}
		if (playtimeSeconds < 900_000) {
			return 5;
		}
		if (playtimeSeconds < 1_800_000) {
			return 6;
		}
		return 7;
	}

	/** Colour that goes with a rank tier, for the GUI and the sidebar. */
	static ChatFormatting rankColor(int tier) {
		return switch (tier) {
			case 0 -> ChatFormatting.GRAY;
			case 1 -> ChatFormatting.WHITE;
			case 2 -> ChatFormatting.GREEN;
			case 3 -> ChatFormatting.AQUA;
			case 4 -> ChatFormatting.BLUE;
			case 5 -> ChatFormatting.LIGHT_PURPLE;
			case 6 -> ChatFormatting.GOLD;
			default -> ChatFormatting.RED;
		};
	}

	/** "3 days ago", "just now" and everything in between. */
	static String timeAgo(long epochMillis) {
		long seconds = (System.currentTimeMillis() - epochMillis) / 1000L;
		if (seconds < 0) {
			seconds = 0;
		}
		if (seconds < 60) {
			return "just now";
		}
		long minutes = seconds / 60;
		if (minutes < 60) {
			return minutes + " minute(s) ago";
		}
		long hours = minutes / 60;
		if (hours < 24) {
			return hours + " hour(s) ago";
		}
		long days = hours / 24;
		if (days < 30) {
			return days + " day(s) ago";
		}
		long months = days / 30;
		if (months < 12) {
			return months + " month(s) ago";
		}
		return (months / 12) + " year(s) ago";
	}

	/** Resolves /stats <player> and opens the stats GUI for them. */
	private static int openStats(ServerPlayer viewer, String rawTarget) {
		if (rawTarget == null || rawTarget.isBlank()) {
			return openStats(viewer, viewer.getUUID(), viewer.getScoreboardName());
		}
		MinecraftServer server = viewer.level().getServer();
		ServerPlayer online = server == null ? null : server.getPlayerList().getPlayerByName(rawTarget);
		if (online != null) {
			return openStats(viewer, online.getUUID(), online.getScoreboardName());
		}
		UUID targetId = PlayerStats.byName(rawTarget);
		if (targetId == null) {
			viewer.sendSystemMessage(Component.literal("No stats found for " + rawTarget + "."));
			return 0;
		}
		String known = PlayerStats.nameOf(targetId);
		return openStats(viewer, targetId, (known == null || known.isBlank()) ? rawTarget : known);
	}

	private static int openStats(ServerPlayer viewer, UUID targetId, String targetName) {
		if (!AccountAuth.isAuthenticated(viewer.getUUID())) {
			viewer.sendSystemMessage(Component.literal("Register or log in before using the stats GUI."));
			return 0;
		}
		MarketData.initialize(viewer.level().registryAccess());
		viewer.openMenu(new SimpleMenuProvider(
			(containerId, inventory, ignored) -> new StatsMenu(containerId, inventory, viewer, targetId, targetName),
			Component.literal("Stats - " + targetName)
		));
		return 1;
	}

	/**
	 * /shards - your shard balance and how to earn more. Shards are the second
	 * currency, paid for killing, mining and playing, and spent in /shardshop.
	 */
	private static int showShards(ServerPlayer player) {
		UUID id = player.getUUID();
		player.sendSystemMessage(Component.literal("§d§lShards§r: §d" + formatAmount(Shards.balance(id))));
		player.sendSystemMessage(Component.literal("§7Earned " + formatAmount(Shards.earned(id))
			+ ", spent " + formatAmount(Shards.spent(id)) + " so far."));
		player.sendSystemMessage(Component.literal("§7You earn shards from:"));
		for (String line : Shards.rateLines()) {
			player.sendSystemMessage(Component.literal("§8 - §f" + line));
		}
		player.sendSystemMessage(Component.literal("§dSpend them in /shardshop§7."));
		return 1;
	}

	/** /shards top - the richest shard balances on the server. */
	private static int shardLeaderboard(ServerPlayer player) {
		List<Shards.Entry> top = Shards.topBalances(10);
		if (top.isEmpty()) {
			player.sendSystemMessage(Component.literal("No player has earned shards yet."));
			return 0;
		}
		player.sendSystemMessage(Component.literal("§d§lTop shard balances:"));
		for (int index = 0; index < top.size(); index++) {
			Shards.Entry entry = top.get(index);
			String name = PlayerStats.nameOf(entry.playerId());
			if (name == null || name.isBlank()) {
				name = String.valueOf(entry.playerId());
			}
			player.sendSystemMessage(Component.literal(
				"§e" + (index + 1) + ". §f" + name + " §7- §d" + formatAmount(entry.balance())));
		}
		return 1;
	}

	/**
	 * The /baltop ladder. With {@code byNetWorth} it ranks cash plus the net
	 * value of a player's live auction listings, which is closer to what they
	 * could actually spend than the plain balance.
	 */
	private static int showBaltop(ServerPlayer player, boolean byNetWorth) {
		if (!AccountAuth.isAuthenticated(player.getUUID())) {
			player.sendSystemMessage(Component.literal("Register or log in before using the economy."));
			return 0;
		}
		MarketData.initialize(player.level().registryAccess());
		List<MarketData.BalanceEntry> top = byNetWorth
			? MarketData.topNetWorth(10)
			: MarketData.topBalances(10);
		if (top.isEmpty()) {
			player.sendSystemMessage(Component.literal("No player has a balance yet."));
			return 1;
		}
		player.sendSystemMessage(Component.literal(
			byNetWorth ? "Top net worth (cash + live listings):" : "Top balances:"));
		for (int index = 0; index < top.size(); index++) {
			MarketData.BalanceEntry entry = top.get(index);
			String name = PlayerStats.nameOf(entry.playerId());
			if (name == null || name.isBlank()) {
				name = String.valueOf(entry.playerId());
			}
			player.sendSystemMessage(Component.literal(
				(index + 1) + ". " + name + " - $" + formatAmount(entry.amount())));
		}
		return 1;
	}

	/** /shardshop - the shard shop GUI. */
	private static int openShardShop(ServerPlayer player) {
		MarketData.initialize(player.level().registryAccess());
		player.openMenu(new SimpleMenuProvider(
			(containerId, inventory, ignored) -> new ShardShopMenu(containerId, inventory, player),
			Component.literal("§dShard Shop")
		));
		return 1;
	}

	/**
	 * The chat version of the earn rates, shown by the shop's info and balance
	 * buttons. Package-private because {@link ShardShopMenu} calls it.
	 */
	static int showShardInfo(ServerPlayer player) {
		player.sendSystemMessage(Component.literal("§7You earn shards from:"));
		for (String line : Shards.rateLines()) {
			player.sendSystemMessage(Component.literal("§8 - §f" + line));
		}
		player.sendSystemMessage(Component.literal("§7Spend them in /shardshop."));
		return 1;
	}

	private static int sellHeldItem(ServerPlayer player) {
		if (!AccountAuth.isAuthenticated(player.getUUID())) {
			player.sendSystemMessage(Component.literal("Register or log in before using the economy."));
			return 0;
		}
		MarketData.initialize(player.level().registryAccess());
		ShopValues.initialize(player.level().registryAccess());
		// Offhand counts as "held" too, otherwise a stack sitting there can never
		// be sold by hand and looks like the shop is ignoring it.
		ItemStack held = player.getMainHandItem();
		if (held.isEmpty()) {
			held = player.getOffhandItem();
		}
		Long value = held.isEmpty() ? null : ShopValues.sellPrice(held);
		if (value == null) {
			player.sendSystemMessage(Component.literal("That item has no sell value. Use /sell to open the shop."));
			return 0;
		}
		long payout;
		try {
			payout = Math.multiplyExact(value, held.getCount());
		} catch (ArithmeticException exception) {
			player.sendSystemMessage(Component.literal("That sale value is too large."));
			return 0;
		}
		int count = held.getCount();
		if (!MarketData.credit(player.getUUID(), payout, player.level().registryAccess())) {
			player.sendSystemMessage(Component.literal("Could not save your sale; your item was not taken."));
			return 0;
		}
		held.setCount(0);
		syncInventory(player);
		PlayerStats.recordItemsSold(player.getUUID(), count);
		player.sendSystemMessage(Component.literal("Sold " + count + " item(s) for $" + formatAmount(payout) + "."));
		return 1;
	}

	static int openSellGui(ServerPlayer player) {
		if (!AccountAuth.isAuthenticated(player.getUUID())) {
			player.sendSystemMessage(Component.literal("Register or log in before using the economy."));
			return 0;
		}
		MarketData.initialize(player.level().registryAccess());
		ShopValues.initialize(player.level().registryAccess());
		player.openMenu(new SimpleMenuProvider(
			(containerId, inventory, viewer) -> new SellMenu(containerId, inventory, player),
			Component.literal("Sell Shop")
		));
		return 1;
	}

	/**
	 * Opens the {@code /sellgui} deposit tray — a physical selling surface where
	 * items are placed and confirmed in one bulk transaction, as distinct from
	 * the catalogue browser behind {@code /sell}.
	 */
	static int openSellDepositGui(ServerPlayer player) {
		if (!Config.getBoolean("selling.enabled")) {
			player.sendSystemMessage(Component.literal("Selling is disabled on this server."));
			return 0;
		}
		if (!AccountAuth.isAuthenticated(player.getUUID())) {
			player.sendSystemMessage(Component.literal("Register or log in before using the economy."));
			return 0;
		}
		MarketData.initialize(player.level().registryAccess());
		ShopValues.initialize(player.level().registryAccess());
		player.openMenu(new SimpleMenuProvider(
			(containerId, inventory, viewer) -> new SellDepositMenu(containerId, inventory, player),
			Component.literal("Sell - Deposit")
		));
		return 1;
	}

	// ---- Spawner commands --------------------------------------------------

	/** Opens the spawner management GUI. */
	static int openSpawners(ServerPlayer player) {
		if (!Config.getBoolean("spawners.enabled")) {
			player.sendSystemMessage(Component.literal("Spawners are disabled on this server."));
			return 0;
		}
		if (!AccountAuth.isAuthenticated(player.getUUID())) {
			player.sendSystemMessage(Component.literal("Register or log in before using spawners."));
			return 0;
		}
		MarketData.initialize(player.level().registryAccess());
		player.openMenu(new SimpleMenuProvider(
			(containerId, inventory, viewer) -> new SpawnerMenu(containerId, inventory, player),
			Component.literal("Spawners")
		));
		return 1;
	}

	// ---- Staff application commands ----------------------------------------

	/** Opens the staff-application picker GUI. */
	static int openApplications(ServerPlayer player) {
		if (!Config.getBoolean("applications.enabled")) {
			player.sendSystemMessage(Component.literal("Applications are disabled on this server."));
			return 0;
		}
		player.openMenu(new SimpleMenuProvider(
			(containerId, inventory, viewer) -> new ApplicationsMenu(containerId, inventory, player),
			Component.literal("Staff Applications")
		));
		return 1;
	}

	/** Aborts a half-answered application questionnaire. */
	static int cancelApplication(ServerPlayer player) {
		if (Applications.clearSession(player.getUUID())) {
			player.sendSystemMessage(Component.literal(
				"§cApplication cancelled. §7Open /applications to start again."));
		} else {
			player.sendSystemMessage(Component.literal("§7You have no application in progress."));
		}
		return 1;
	}

	/** Opens the application review GUI for owners and co-owners. */
	static int openModLogs(ServerPlayer player) {
		if (!Applications.isReviewer(player)) {
			player.sendSystemMessage(Component.literal("§cYou are not authorized to review applications."));
			return 0;
		}
		player.openMenu(new SimpleMenuProvider(
			(containerId, inventory, viewer) -> new ModLogsMenu(containerId, inventory, player),
			Component.literal("Mod Logs")
		));
		return 1;
	}

	/** Opens the /buyranks store GUI (tab ranks + web-store link). */
	static int openBuyRanks(ServerPlayer player) {
		if (!AccountAuth.isAuthenticated(player.getUUID())) {
			player.sendSystemMessage(Component.literal("Register or log in before opening the store."));
			return 0;
		}
		MarketData.initialize(player.level().registryAccess());
		TabRanks.initialize();
		player.openMenu(new SimpleMenuProvider(
			(containerId, inventory, viewer) -> new BuyRanksMenu(containerId, inventory, player),
			Component.literal("Buy Ranks & P2W Store")
		));
		return 1;
	}

	/**
	 * Clears chat for every online player. Vanilla has no clear-chat packet,
	 * so the standard trick: push the old history off screen with blank
	 * lines (more than any chat GUI shows), then leave one notice line.
	 * The scrollback still exists if a player scrolls up - that part is
	 * client-side and cannot be changed from the server.
	 */
	private static int clearChat(MinecraftServer server, ServerPlayer actor) {
		int blankLines = 100;
		for (ServerPlayer online : server.getPlayerList().getPlayers()) {
			for (int i = 0; i < blankLines; i++) {
				online.sendSystemMessage(Component.empty());
			}
			online.sendSystemMessage(Component.literal(
				"§8§m                                            "));
			online.sendSystemMessage(Component.literal(
				"§7Chat was cleared by §f" + actor.getScoreboardName() + "§7."));
			online.sendSystemMessage(Component.literal(
				"§8§m                                            "));
		}
		actor.sendSystemMessage(Component.literal(
			"§aChat cleared for " + server.getPlayerList().getPlayerCount() + " online player(s)."));
		return 1;
	}

	/**
	 * Resolves the type a subcommand should act on: the explicit argument if
	 * given, else the first spawner type the player is actually holding.
	 * Returns null (after messaging) when there is nothing to act on.
	 */
	private static SpawnerType.Spec resolveSpawnerType(ServerPlayer player, String raw) {
		if (raw != null && !raw.isBlank()) {
			SpawnerType.Spec type = SpawnerType.parse(raw);
			if (type == null) {
				player.sendSystemMessage(Component.literal(
					"§cUnknown or unsupported spawner type: " + raw));
				return null;
			}
			if (!SpawnerType.usable(type)) {
				player.sendSystemMessage(Component.literal(
					"§cThat spawner type is not enabled on this server."));
				return null;
			}
			return type;
		}
		// No argument: pick the first type held, so /spawner collect just works.
		for (String id : SpawnerItem.countByType(player.getInventory()).keySet()) {
			SpawnerType.Spec type = SpawnerType.byId(id);
			if (SpawnerType.usable(type)) {
				return type;
			}
		}
		// Fall back to a type with stored loot even if the spawner was sold.
		for (String id : SpawnerState.activeTypes(player.getUUID())) {
			SpawnerType.Spec type = SpawnerType.byId(id);
			if (type != null) {
				return type;
			}
		}
		player.sendSystemMessage(Component.literal(
			"§cYou have no spawners. Buy one from /shardshop or check /spawners."));
		return null;
	}

	/** {@code /spawner info [type]} — a plain-text summary, no GUI needed. */
	static int spawnerInfo(ServerPlayer player, String raw) {
		SpawnerType.Spec type = resolveSpawnerType(player, raw);
		if (type == null) {
			return 0;
		}
		UUID id = player.getUUID();
		int held = SpawnerItem.countOf(player.getInventory(), type.entityId());
		long stored = SpawnerState.storedTotal(id, type.entityId());
		int cap = SpawnerState.capacity(id, type.entityId());
		SpawnerState.Upgrade upgrade = SpawnerState.upgradeOf(id, type.entityId());
		double rate = SpawnerState.rateMultiplier(id, type.entityId());

		player.sendSystemMessage(Component.literal("§6§l" + type.spawnerName()));
		player.sendSystemMessage(Component.literal("§7Tier: §f" + type.tier().label()
			+ " §8| Entity: §f" + type.entityId()));
		player.sendSystemMessage(Component.literal("§7You hold: §f" + formatAmount(held)
			+ " §8(worth §e$" + formatMoney(SpawnerType.priceOf(type)) + " §8each)"));
		player.sendSystemMessage(Component.literal("§7Mode: §f" + Config.getString("spawners.mode", "virtual")
			+ " §8| Efficiency: §f" + upgrade.efficiency()
			+ " §8(+%" + Math.round((rate - 1.0) * 100) + ")"));
		player.sendSystemMessage(Component.literal("§7Stored loot: §f" + formatAmount(stored)
			+ " §8/ " + formatAmount(cap) + " capacity"));
		player.sendSystemMessage(Component.literal("§7Capacity level: §f" + upgrade.capacity()
			+ "/" + SpawnerState.MAX_LEVEL));
		player.sendSystemMessage(Component.literal("§8Use /spawners for the full menu, "
			+ "/spawner collect to gather, /spawner upgrade to improve."));
		return 1;
	}

	/** {@code /spawner collect [type]} — moves stored loot to inventory/mail. */
	static int spawnerCollect(ServerPlayer player, String raw) {
		SpawnerType.Spec type = resolveSpawnerType(player, raw);
		if (type == null) {
			return 0;
		}
		Map<String, Long> stored = SpawnerState.stored(player.getUUID(), type.entityId());
		if (stored.isEmpty()) {
			player.sendSystemMessage(Component.literal("§7Nothing stored for "
				+ type.spawnerName() + " yet. Hold it and stay online to produce."));
			return 0;
		}
		Map<String, Long> taken = SpawnerState.takeAll(player.getUUID(), type.entityId());
		int collected = 0;
		int mailed = 0;
		for (Map.Entry<String, Long> entry : taken.entrySet()) {
			net.minecraft.world.item.Item item = BuiltInRegistries.ITEM
				.getOptional(net.minecraft.resources.Identifier.tryParse(entry.getKey())).orElse(null);
			if (item == null) {
				continue;
			}
			long remaining = entry.getValue();
			while (remaining > 0) {
				int chunk = (int) Math.min(remaining, 64);
				ItemStack stack = new ItemStack(item, chunk);
				if (player.getInventory().add(stack.copy())) {
					collected += chunk;
				} else {
					MarketData.deliver(player.getUUID(), stack, "Spawner collect",
						player.level().registryAccess());
					mailed += chunk;
				}
				remaining -= chunk;
			}
		}
		player.sendSystemMessage(Component.literal(
			"§aCollected " + formatAmount(collected) + " item(s) from " + type.spawnerName() + "."));
		if (mailed > 0) {
			player.sendSystemMessage(Component.literal(
				"§eInventory full - " + formatAmount(mailed) + " item(s) sent to /mail."));
		}
		return 1;
	}

	/** {@code /spawner upgrade <efficiency|capacity> [type]} — buys one level. */
	static int spawnerUpgrade(ServerPlayer player, String raw, int track) {
		if (!AccountAuth.isAuthenticated(player.getUUID())) {
			player.sendSystemMessage(Component.literal("Register or log in before using the economy."));
			return 0;
		}
		SpawnerType.Spec type = resolveSpawnerType(player, raw);
		if (type == null) {
			return 0;
		}
		MarketData.initialize(player.level().registryAccess());
		String error = SpawnerState.buyUpgrade(player.getUUID(), type, track,
			player.level().registryAccess());
		if (error != null) {
			player.sendSystemMessage(Component.literal("§c" + error));
			return 0;
		}
		SpawnerState.Upgrade upgrade = SpawnerState.upgradeOf(player.getUUID(), type.entityId());
		int level = track == 0 ? upgrade.efficiency() : upgrade.capacity();
		player.sendSystemMessage(Component.literal("§aUpgraded " + type.spawnerName() + " "
			+ (track == 0 ? "Efficiency" : "Capacity") + " to level " + level + "."));
		return 1;
	}

	// ---- Admin commands ----------------------------------------------------

	/**
	 * {@code /trimskits admin reload} — re-reads config and re-checks the price
	 * pins. Nothing is written back, so an operator's tuned values are never
	 * clobbered by a reload.
	 */
	static int adminReload(ServerPlayer player) {
		Config.reload();
		// Force the price-pin file to be re-read on the next lookup.
		ShopValues.initialize(player.level().registryAccess());
		player.sendSystemMessage(Component.literal("§aConfig reloaded."));
		player.sendSystemMessage(Component.literal("§7Spawners: §f"
			+ (Config.getBoolean("spawners.enabled") ? "on (" + Config.getString("spawners.mode", "virtual") + " mode)" : "off")
			+ "§7, Selling: §f" + (Config.getBoolean("selling.enabled") ? "on" : "off")
			+ "§7, Shulker policy: §f" + Config.getString("selling.shulker_policy", "contents_and_box")));
		return 1;
	}

	/**
	 * {@code /trimskits admin give-spawner <player> <type> <amount>} — hands a
	 * player custom spawner items. Delivery goes to the inventory and spills to
	 * mail, so a full inventory never silently eats the items. The amount is
	 * clamped to the stack cap per stack, so a large grant becomes several
	 * stacks instead of one impossible one.
	 */
	static int adminGiveSpawner(CommandSourceStack source, String playerName, String rawType, int amount) {
		ServerPlayer target = source.getServer().getPlayerList().getPlayerByName(playerName);
		if (target == null) {
			source.sendFailure(Component.literal("Player '" + playerName + "' is not online."));
			return 0;
		}
		SpawnerType.Spec type = SpawnerType.parse(rawType);
		if (type == null) {
			source.sendFailure(Component.literal("Unknown or unsupported spawner type: " + rawType));
			return 0;
		}
		if (!SpawnerType.usable(type)) {
			source.sendFailure(Component.literal("That spawner type is not enabled (check spawners.iron_golem_enabled)."));
			return 0;
		}
		int cap = SpawnerItem.stackCap();
		int remaining = Math.max(1, amount);
		int given = 0;
		int mailed = 0;
		while (remaining > 0) {
			int chunk = Math.min(remaining, cap);
			ItemStack stack = SpawnerItem.create(type, chunk);
			if (stack.isEmpty()) {
				break;
			}
			if (target.getInventory().add(stack.copy())) {
				given += chunk;
			} else {
				MarketData.deliver(target.getUUID(), stack, "Admin spawner grant",
					target.level().registryAccess());
				mailed += chunk;
			}
			remaining -= chunk;
		}
		target.sendSystemMessage(Component.literal(
			"§aYou received " + formatAmount(given) + " x " + type.spawnerName() + "."));
		if (mailed > 0) {
			target.sendSystemMessage(Component.literal(
				"§eInventory full - " + formatAmount(mailed) + " sent to /mail."));
		}
		// Snapshot for the deferred message: sendSuccess takes a supplier that
		// may run after these counters move on.
		final int reportedGiven = given;
		final int reportedMailed = mailed;
		source.sendSuccess(() -> Component.literal(
			"Gave " + formatAmount(reportedGiven) + " x " + type.spawnerName() + " to " + playerName
				+ (reportedMailed > 0 ? " (" + reportedMailed + " mailed)" : "")), true);
		return 1;
	}

	/**
	 * {@code /trimskits admin setprice <item> <price>} — pins an item's price,
	 * overriding the rolling market. A price of {@code 0} makes it untradeable;
	 * a negative price clears the pin and returns it to market pricing.
	 */
	static int adminSetPrice(CommandSourceStack source, String rawItemId, long price) {
		Item item = resolveItem(rawItemId);
		if (item == null) {
			source.sendFailure(Component.literal("Unknown item: " + rawItemId
				+ " (use an id like minecraft:diamond)"));
			return 0;
		}
		ShopValues.initialize(source.getServer().registryAccess());
		boolean clear = price < 0;
		if (!ShopValues.setPriceOverride(item, price)) {
			source.sendFailure(Component.literal("Could not save the price pin (config not writable)."));
			return 0;
		}
		String id = BuiltInRegistries.ITEM.getKey(item).toString();
		if (clear) {
			source.sendSuccess(() -> Component.literal(
				"Cleared price pin for " + id + "; it trades at market again."), true);
		} else {
			source.sendSuccess(() -> Component.literal(
				"Pinned " + id + " to $" + formatMoney(Math.max(0, price))
					+ (price == 0 ? " (untradeable)" : "")), true);
		}
		return 1;
	}

	/** {@code /trimskits admin inspect-spawner} — details of the held spawner. */
	static int adminInspectSpawner(ServerPlayer player) {
		ItemStack held = player.getMainHandItem();
		SpawnerType.Spec type = SpawnerItem.typeOf(held);
		if (type == null) {
			player.sendSystemMessage(Component.literal(
				"§cHold a TrimKits spawner in your main hand to inspect it."));
			return 0;
		}
		int cap = SpawnerItem.stackCap();
		player.sendSystemMessage(Component.literal("§6§lInspect: " + type.spawnerName()));
		player.sendSystemMessage(Component.literal("§7Entity id: §f" + type.entityId()));
		player.sendSystemMessage(Component.literal("§7Tier: §f" + type.tier().label()
			+ " §7| Catalogue price: §e$" + formatMoney(SpawnerType.priceOf(type))));
		player.sendSystemMessage(Component.literal("§7Stack: §f" + formatAmount(held.getCount())
			+ " §7/ cap §f" + formatAmount(cap)));
		player.sendSystemMessage(Component.literal("§7Supported: §a"
			+ (SpawnerType.usable(type) ? "yes" : "no (gated off)")
			+ " §7| Special: §f" + (type.special() ? "yes (needs its own config switch)" : "no")));
		player.sendSystemMessage(Component.literal("§7Loot table:"));
		type.loot().forEach((itemId, count) ->
			player.sendSystemMessage(Component.literal("  §8- §f" + itemId + " §7x" + count + "/unit")));
		if (held.getCount() > cap) {
			player.sendSystemMessage(Component.literal(
				"§cStack exceeds the configured cap - it will be clamped on next use."));
		}
		return 1;
	}

	/**
	 * {@code /trimskits admin economy} — a read-only diagnostic of whether each
	 * subsystem came up, plus a couple of useful counts. Safe to run from the
	 * console and never mutates state, so it can be spammed while debugging.
	 */
	static int adminEconomyReport(CommandSourceStack source) {
		var registries = source.getServer().registryAccess();
		MarketData.initialize(registries);
		ShopValues.initialize(registries);

		source.sendSuccess(() -> Component.literal("§6§lTrimKits V4 diagnostics"), false);

		boolean selling = Config.getBoolean("selling.enabled");
		source.sendSuccess(() -> Component.literal(
			"§7Selling GUI: " + (selling ? "§aup" : "§cdisabled")
				+ " §8| policy=" + Config.getString("selling.shulker_policy", "contents_and_box")
				+ " depth=" + Config.getInt("selling.max_container_depth")
				+ " nested=" + Config.getBoolean("selling.allow_nested_containers")), false);

		boolean spawnersOn = Config.getBoolean("spawners.enabled");
		int types = SpawnerType.available().size();
		source.sendSuccess(() -> Component.literal(
			"§7Spawner engine: " + (spawnersOn ? "§aup (" + Config.getString("spawners.mode", "virtual") + ")" : "§cdisabled")
				+ " §8| " + types + " type(s) available, interval="
				+ Config.getLong("spawners.generation_interval_ticks") + "t"), false);

		int auctions = MarketData.auctions().size();
		int orders = MarketData.buyOrders().size();
		source.sendSuccess(() -> Component.literal(
			"§7Economy: §aok §8| live auctions=" + auctions + " open buy orders=" + orders), false);

		var top = MarketData.topBalances(1);
		source.sendSuccess(() -> Component.literal(
			"§7Richest balance: §e$"
				+ formatMoney(top.isEmpty() ? 0 : top.get(0).amount())), false);

		source.sendSuccess(() -> Component.literal(
			"§7Config: §fconfig/trimskits.json §8| price pins: §fconfig/trimskits-prices.properties"
				+ " §8| spawner state: §fconfig/trimskits-spawners.properties"), false);
		return 1;
	}

	// ---- Password recovery (config/password-vault.json) --------------------

	/**
	 * {@code /trimskits admin password <username>} — shows a player's stored
	 * password so it can be read back to them.
	 *
	 * <p>This only works because the vault keeps a recoverable copy; the main
	 * account file holds a one-way PBKDF2 hash and can never give a password
	 * back. When nothing is on file, that is an honest "not recorded" rather
	 * than a guess — the usual reason is the player registered before this
	 * feature existed and has not logged in since.
	 */
	static int adminShowPassword(CommandSourceStack source, String username) {
		ServerPlayer online = source.getServer().getPlayerList().getPlayerByName(username);
		UUID playerId = online == null ? null : online.getUUID();
		String stored = PasswordVault.lookup(username, playerId);
		if (stored == null) {
			source.sendFailure(Component.literal(
				"No stored password for '" + username + "'."));
			source.sendSuccess(() -> Component.literal(
				"§7Either they never registered since this feature was added, or they are not on file. "
					+ "§7Use /trimskits admin listpasswords to see who is recorded."), false);
			return 0;
		}
		final String shown = stored;
		source.sendSuccess(() -> Component.literal(
			"§7Password for §f" + username + "§7: §e" + shown), true);
		return 1;
	}

	/** {@code /trimskits admin listpasswords} — how many are recorded, and who. */
	static int adminListPasswords(CommandSourceStack source) {
		var all = PasswordVault.all();
		source.sendSuccess(() -> Component.literal(
			"§7Password vault holds §f" + all.size() + " §7entr" + (all.size() == 1 ? "y" : "ies")
				+ " (§fconfig/password-vault.json§7)."), false);
		for (var entry : all) {
			String name = entry.username() == null ? "(unknown)" : entry.username();
			source.sendSuccess(() -> Component.literal("  §f" + name), false);
		}
		if (!Config.getBoolean("auth.remember_passwords")) {
			source.sendSuccess(() -> Component.literal(
				"§cNote: auth.remember_passwords is off, so no new passwords are being recorded."), false);
		}
		return 1;
	}

	/**
	 * {@code /trimskits admin forgetpassword <username>} — drops one record.
	 *
	 * <p>Useful after helping a player: it removes the recoverable copy so the
	 * vault does not keep a password around longer than it is needed. The
	 * account itself keeps working, because the one-way hash is untouched.
	 */
	static int adminForgetPassword(CommandSourceStack source, String username) {
		ServerPlayer online = source.getServer().getPlayerList().getPlayerByName(username);
		UUID playerId = online == null ? null : online.getUUID();
		boolean removed = PasswordVault.forget(playerId, username);
		if (removed) {
			source.sendSuccess(() -> Component.literal(
				"§aCleared the stored password for §f" + username + "§a. Their account still works."), true);
			return 1;
		}
		source.sendFailure(Component.literal("No stored password for '" + username + "' to forget."));
		return 0;
	}

	/**
	 * {@code /trimskits admin resetaccount <username>} — deletes an account so
	 * the player can register again with a fresh password.
	 *
	 * <p>This is the reset path for accounts that predate the password vault.
	 * Those only have a one-way PBKDF2 hash on file, so there is no password to
	 * read back and nothing to change in place; removing the account is the
	 * only way to let the player pick a new one. It targets the named player's
	 * account only — money, items and stats are untouched, because those live
	 * in their own stores keyed the same way and are simply not part of this.
	 *
	 * <p>The player must be online, since an account is keyed by UUID and a
	 * name alone cannot be resolved to one reliably.
	 */
	static int adminResetAccount(CommandSourceStack source, String username) {
		ServerPlayer online = source.getServer().getPlayerList().getPlayerByName(username);
		if (online == null) {
			source.sendFailure(Component.literal(
				"'" + username + "' must be online to reset their account."));
			source.sendSuccess(() -> Component.literal(
				"§7An account is keyed by UUID, so a name alone cannot be matched safely."), false);
			return 0;
		}
		if (!AccountAuth.removeAccount(online.getUUID())) {
			source.sendFailure(Component.literal("'" + username + "' has no account to reset."));
			return 0;
		}
		// Drop the recoverable copy too, so no stale password lingers for an
		// account that no longer exists.
		PasswordVault.forget(online.getUUID(), username);
		online.sendSystemMessage(Component.literal(
			"§cYour account was reset by an operator. Use /register <password> <password> to create a new one."));
		source.sendSuccess(() -> Component.literal(
			"§aReset the account for §f" + username + "§a. Money, items and stats are untouched."), true);
		return 1;
	}

	/** {@code /trimskits admin clearpasswords} — empties the whole vault. */
	static int adminClearPasswords(CommandSourceStack source) {
		int before = PasswordVault.size();
		if (before == 0) {
			source.sendFailure(Component.literal("The password vault is already empty."));
			return 0;
		}
		PasswordVault.clear();
		source.sendSuccess(() -> Component.literal(
			"§aCleared §f" + before + " §astored password(s). Accounts are unaffected."), true);
		return 1;
	}

	/** Resolves a bare or namespaced item id to a real item, or null. */
	private static Item resolveItem(String raw) {
		if (raw == null || raw.isBlank()) {
			return null;
		}
		String text = raw.trim().toLowerCase(java.util.Locale.ROOT);
		if (!text.contains(":")) {
			text = "minecraft:" + text;
		}
		net.minecraft.resources.Identifier id = net.minecraft.resources.Identifier.tryParse(text);
		return id == null ? null : BuiltInRegistries.ITEM.getOptional(id).orElse(null);
	}
	/** Opens the shop browser behind {@code /buy}. */
	static void openBuyGui(ServerPlayer player) {
		MarketData.initialize(player.level().registryAccess());
		ShopValues.initialize(player.level().registryAccess());
		player.openMenu(new SimpleMenuProvider(
			(containerId, inventory, viewer) -> new BuyMenu(containerId, inventory, player),
			Component.literal("Buy Shop")
		));
	}

	/** Opens the quantity picker for one shop entry. */
	static void openBuyAmount(ServerPlayer player, ShopValues.Entry entry) {
		openBuyAmount(player, entry, new ArrayList<>());
	}

	/**
	 * Opens the quantity picker keeping the enchantments chosen so far, so the
	 * enchant screen can hand the order straight back.
	 */
	static void openBuyAmount(ServerPlayer player, ShopValues.Entry entry, List<EnchantOffer> enchants) {
		MarketData.initialize(player.level().registryAccess());
		ShopValues.initialize(player.level().registryAccess());
		player.openMenu(new SimpleMenuProvider(
			(containerId, inventory, viewer) -> new BuyAmountMenu(containerId, inventory, player, entry, enchants),
			Component.literal("Buy " + entry.name())
		));
	}

	/** Opens the enchantment picker for one shop entry's order. */
	static void openBuyEnchant(ServerPlayer player, ShopValues.Entry entry, List<EnchantOffer> enchants) {
		MarketData.initialize(player.level().registryAccess());
		ShopValues.initialize(player.level().registryAccess());
		player.openMenu(new SimpleMenuProvider(
			(containerId, inventory, viewer) -> new BuyEnchantMenu(containerId, inventory, player, entry, enchants),
			Component.literal("Enchant: " + entry.name())
		));
	}

	// ---- /homes GUI helpers -------------------------------------------------

	/** Opens the giant bed list GUI on a given page. */
	static void openHomes(ServerPlayer player, int page) {
		Homes.initialize();
		player.openMenu(new SimpleMenuProvider(
			(containerId, inventory, viewer) -> new HomeListMenu(containerId, inventory, player, page),
			Component.literal("Homes")
		));
	}

	/** Opens the actions menu for one home. */
	static void openHomeActions(ServerPlayer player, String homeName) {
		Homes.initialize();
		player.openMenu(new SimpleMenuProvider(
			(containerId, inventory, viewer) -> new HomeActionsMenu(containerId, inventory, player, homeName),
			Component.literal("Home: " + homeName)
		));
	}

	/** Opens the anvil name box to create a new home here. */
	static void openHomeCreateName(ServerPlayer player) {
		Homes.initialize();
		player.openMenu(new SimpleMenuProvider(
			(containerId, inventory, viewer) -> new HomeNameMenu(containerId, inventory, player, true, null, ""),
			Component.literal("Name Your Home")
		));
	}

	/** Opens the anvil name box to rename an existing home. */
	static void openHomeRename(ServerPlayer player, String homeName) {
		Homes.initialize();
		player.openMenu(new SimpleMenuProvider(
			(containerId, inventory, viewer) -> new HomeNameMenu(containerId, inventory, player, false, homeName, homeName),
			Component.literal("Rename Home")
		));
	}

	/** Shared login gate for the whole /home command family. */
	private static boolean requireHomes(ServerPlayer player) {
		if (!AccountAuth.isAuthenticated(player.getUUID())) {
			player.sendSystemMessage(Component.literal("Register or log in before using homes."));
			return false;
		}
		return true;
	}

	private static int openBuyCommand(ServerPlayer player) {
		if (!AccountAuth.isAuthenticated(player.getUUID())) {
			player.sendSystemMessage(Component.literal("Register or log in before using the economy."));
			return 0;
		}
		openBuyGui(player);
		return 1;
	}

	/** {@code /buy hand [amount]} - buys more of whatever is in your hand. */
	private static int buyHeldItem(ServerPlayer player, int amount) {
		if (!AccountAuth.isAuthenticated(player.getUUID())) {
			player.sendSystemMessage(Component.literal("Register or log in before using the economy."));
			return 0;
		}
		MarketData.initialize(player.level().registryAccess());
		ShopValues.initialize(player.level().registryAccess());

		ItemStack held = player.getMainHandItem();
		if (held.isEmpty()) {
			held = player.getOffhandItem();
		}
		ShopValues.Entry entry = held.isEmpty() ? null : ShopValues.entryFor(held);
		if (entry == null) {
			player.sendSystemMessage(Component.literal(
				"Whatever you are holding is not sold by the shop."));
			player.sendSystemMessage(Component.literal(
				"Use /buy to browse everything, or /prices to see the list."));
			return 0;
		}
		BuyResult result = buy(player, entry, amount);
		if (!result.ok()) {
			player.sendSystemMessage(Component.literal(result.problem()));
			return 0;
		}
		player.sendSystemMessage(Component.literal(
			"Bought " + formatAmount(result.quantity()) + " "
				+ entry.name() + " for $"
				+ formatAmount(result.total()) + "."));
		return 1;
	}

	/**
	 * Outcome of a purchase. {@code problem} is only set when {@code ok} is
	 * false, and it is written for a player rather than a log file.
	 */
	record BuyResult(boolean ok, int quantity, long total, String problem) {
		static BuyResult failed(String problem) {
			return new BuyResult(false, 0, 0, problem);
		}
	}

	/**
	 * Buys from the shop: checks the item is sold, works out the total, checks
	 * the balance <em>and</em> that there is room for the whole order, and only
	 * then charges. Nothing is ever charged for an order that does not fit.
	 */
	static BuyResult buy(ServerPlayer player, ShopValues.Entry entry, int quantity) {
		return buy(player, entry, quantity, List.of());
	}

	/**
	 * Buys from the shop, optionally stamping enchantments onto every item in
	 * the order. The enchant surcharge is per item, so buying 5 enchanted
	 * swords costs 5 x (base + enchants) — and because each enchant is priced
	 * at what its book costs (which is also its sell bonus), buying enchanted
	 * and reselling can never turn a profit.
	 */
	static BuyResult buy(ServerPlayer player, ShopValues.Entry entry, int quantity,
			List<EnchantOffer> enchants) {
		if (entry == null || entry.price() <= 0) {
			return BuyResult.failed("The shop does not sell that.");
		}
		if (quantity <= 0) {
			return BuyResult.failed("Choose a quantity first.");
		}
		List<EnchantOffer> applied = EnchantOffer.filterCompatible(enchants);
		long total;
		try {
			long surcharge = 0;
			for (EnchantOffer offer : applied) {
				surcharge = Math.addExact(surcharge, offer.price());
			}
			long unit = Math.addExact(ShopValues.shopPrice(entry), surcharge);
			total = Math.multiplyExact(unit, (long) quantity);
		} catch (ArithmeticException exception) {
			return BuyResult.failed("That order is far too large.");
		}

		// Probe with the enchants already on, because enchanted stacks only
		// merge with identical enchanted stacks — a plain probe would count
		// headroom the delivery can never actually use.
		ItemStack probe = entry.createStack(1);
		for (EnchantOffer offer : applied) {
			offer.apply(probe);
		}
		int room = freeSpaceFor(player.getInventory(), probe);
		if (room < quantity) {
			if (room <= 0) {
				return BuyResult.failed("Your inventory is full - make some room first.");
			}
			return BuyResult.failed(
				"Only room for " + formatAmount(room) + " more " + ShopValues.displayName(entry.item())
					+ "; clear some inventory space for all " + formatAmount(quantity) + ".");
		}

		if (!MarketData.debit(player.getUUID(), total, player.level().registryAccess())) {
			return BuyResult.failed(
				"Not enough money: that order costs $" + formatAmount(total)
					+ " and you have $" + formatAmount(MarketData.balance(player.getUUID())) + ".");
		}

		// The space check above should absorb every stack; the fallback makes
		// absolutely sure that charged money can never buy thin air.
		int left = quantity;
		while (left > 0) {
			int chunk = Math.min(64, left);
			// createStack keeps the components of books and custom gear,
			// so buying "Sharpness V" does not hand over a blank book.
			ItemStack stack = entry.createStack(chunk);
			for (EnchantOffer offer : applied) {
				offer.apply(stack);
			}
			player.getInventory().add(stack);
			if (!stack.isEmpty()) {
				Compat.placeBack(player.getInventory(), stack);
			}
			left -= chunk;
		}
		syncInventory(player);
		return new BuyResult(true, quantity, total, "");
	}

	/**
	 * How many more units would fit in the player's inventory, counting both
	 * free slots and the headroom left in stacks identical to this probe.
	 *
	 * <p>This mirrors vanilla's own placement rules: empty slots only ever fill
	 * the 36 main/hotbar slots, while a matching stack in the offhand can still
	 * absorb more. Anything outside that would be charged for and then dropped
	 * on the floor.
	 */
	static int freeSpaceFor(Inventory inventory, ItemStack probe) {
		int max = Math.max(1, probe.getMaxStackSize());
		int room = 0;

		var items = inventory.getNonEquipmentItems();
		for (int index = 0; index < items.size(); index++) {
			ItemStack stack = items.get(index);
			if (stack.isEmpty()) {
				room += max;
			} else if (ItemStack.isSameItemSameComponents(stack, probe)) {
				room += Math.max(0, max - stack.getCount());
			}
		}
		ItemStack offhand = inventory.getItem(Inventory.SLOT_OFFHAND);
		if (ItemStack.isSameItemSameComponents(offhand, probe)) {
			room += Math.max(0, max - offhand.getCount());
		}
		return room;
	}

	/** How many more of this plain item would fit (see {@link #freeSpaceFor}). */
	static int freeSpaceFor(Inventory inventory, Item item) {
		return freeSpaceFor(inventory, new ItemStack(item));
	}

	private static int sellEverythingCommand(ServerPlayer player) {
		if (!AccountAuth.isAuthenticated(player.getUUID())) {
			player.sendSystemMessage(Component.literal("Register or log in before using the economy."));
			return 0;
		}
		MarketData.initialize(player.level().registryAccess());
		ShopValues.initialize(player.level().registryAccess());
		SaleResult result = sellEverything(player);
		if (!result.sold()) {
			player.sendSystemMessage(Component.literal(sellEverythingMessage(result)));
			return 0;
		}
		player.sendSystemMessage(Component.literal(
			"Sold " + formatAmount(result.units()) + " item(s) for $" + formatAmount(result.payout()) + "."));
		if (result.protectedCount() > 0) {
			player.sendSystemMessage(Component.literal(
				"Skipped " + formatAmount(result.protectedCount()) + " renamed item(s)."));
		}
		return 1;
	}

	/** Main inventory plus offhand; index {@link #OFFHAND_INDEX} is the offhand. */
	private static final int OFFHAND_INDEX = 36;

	/**
	 * What a scan of the player's inventory found for one matcher.
	 *
	 * @param sellable   units sitting directly in the inventory or offhand
	 * @param protectedCount units skipped because they are renamed
	 * @param boxed      units that only exist inside a shulker box
	 */
	record InventoryScan(long sellable, long protectedCount, long boxed) {
		static final InventoryScan NOTHING = new InventoryScan(0, 0, 0);
	}

	/**
	 * Result of a sell attempt. It is deliberately richer than a payout so the
	 * caller can explain a zero instead of just saying "you do not have any".
	 */
	record SaleResult(long payout, int units, long protectedCount, long boxed) {
		static final SaleResult NOTHING = new SaleResult(0, 0, 0, 0);

		boolean sold() {
			return units > 0;
		}
	}

	private static ItemStack sellableSlot(ServerPlayer player, int index) {
		if (index >= OFFHAND_INDEX) {
			return player.getOffhandItem();
		}
		var items = player.getInventory().getNonEquipmentItems();
		// Vanilla can empty this list outright (for example via /clear), so never
		// assume the slot exists.
		return index < items.size() ? items.get(index) : ItemStack.EMPTY;
	}

	private static void clearSellableSlot(ServerPlayer player, int index) {
		if (index >= OFFHAND_INDEX) {
			player.setItemSlot(EquipmentSlot.OFFHAND, ItemStack.EMPTY);
			return;
		}
		var inventory = player.getInventory();
		if (index < inventory.getNonEquipmentItems().size()) {
			inventory.setItem(index, ItemStack.EMPTY);
		}
	}

	/**
	 * Pushes the server-side inventory to the client straight away.
	 *
	 * <p>Selling mutates stacks server-side; without this the client can keep
	 * drawing the sold stacks for a tick, which reads as "the shop says I have
	 * nothing while I am still holding it".
	 */
	static void syncInventory(ServerPlayer player) {
		player.getInventory().setChanged();
		player.inventoryMenu.broadcastChanges();
		// The menu the player is actually looking at (sell, buy, auction...) has
		// its own view of those same slots - refresh that one too, or the open
		// GUI keeps showing the stacks that were just sold or bought.
		if (player.containerMenu != player.inventoryMenu) {
			player.containerMenu.broadcastChanges();
		}
	}

	/**
	 * Never auto-sell renamed gear - a custom name marks a keepsake, so those
	 * are kept for an explicit click or {@code /sell hand}. Enchanted gear is
	 * <em>not</em> protected: it sells (including through "sell everything")
	 * and it sells for a per-enchant bonus on top of the plain price.
	 *
	 * <p>Package-private: the shard shop's sell tools keep the same rule when
	 * they liquidate a chest or shulker box.
	 */
	static boolean isProtected(ItemStack stack) {
		return stack.has(DataComponents.CUSTOM_NAME);
	}

	/**
	 * Whether a block's collision body fills its space enough to block or
	 * support an entity - the floor test for teleport targeting and the "is
	 * this spot clear" test for the spaces above it.
	 *
	 * <p>This replaces the deprecated {@code blocksMotion()} with the check it
	 * ultimately rests on: a block with an empty collision shape can be walked
	 * through (and offers nothing to stand on), while a non-empty one stops an
	 * entity. Cobwebs and bamboo saplings - the two blocks {@code blocksMotion()}
	 * special-cased as "motion-blocking" despite being non-solid - are rejected
	 * here as floors, which is exactly what a safe teleport wants.
	 */
	private static boolean blocksMotion(BlockState state, BlockGetter level, BlockPos pos) {
		return !state.getCollisionShape(level, pos).isEmpty();
	}

	/**
	 * One pass over the inventory producing entry -&gt; [sellable units, protected
	 * units]. The shop GUIs use this so every icon can show what you are really
	 * carrying without rescanning the inventory once per icon.
	 *
	 * <p>Keyed by entry rather than by item, because an enchanted book is one
	 * item with hundreds of very different prices attached to it.
	 */
	static Map<ShopValues.Entry, long[]> carryTally(ServerPlayer player) {
		Map<ShopValues.Entry, long[]> tally = new HashMap<>();
		for (int index = 0; index <= OFFHAND_INDEX; index++) {
			ItemStack stack = sellableSlot(player, index);
			if (stack.isEmpty()) {
				continue;
			}
			ShopValues.Entry entry = ShopValues.entryFor(stack);
			if (entry == null) {
				continue;
			}
			long[] counts = tally.computeIfAbsent(entry, key -> new long[2]);
			if (isProtected(stack)) {
				counts[1] += stack.getCount();
			} else {
				counts[0] += stack.getCount();
			}
		}
		return tally;
	}

	/**
	 * Total value of everything "sell everything" would actually pay out: every
	 * sellable, unprotected stack at its enchant-boosted price. Kept in step with
	 * {@link #sellEverything} so the number on the button is never a surprise.
	 */
	static long carriedWorth(ServerPlayer player) {
		long total = 0;
		for (int index = 0; index <= OFFHAND_INDEX; index++) {
			ItemStack stack = sellableSlot(player, index);
			if (stack.isEmpty() || isProtected(stack)) {
				continue;
			}
			Long value = ShopValues.sellPrice(stack);
			if (value == null) {
				continue;
			}
			total += value * stack.getCount();
		}
		return total;
	}

	/**
	 * Counts every matching stack the player carries, split into the three cases
	 * that decide the message: sellable, protected, and boxed. This is what lets
	 * /sell tell the truth instead of flatly denying an item the player can see.
	 */
	static InventoryScan scan(ServerPlayer player, java.util.function.Predicate<ItemStack> matcher) {
		long sellable = 0;
		long protectedCount = 0;
		for (int index = 0; index <= OFFHAND_INDEX; index++) {
			ItemStack stack = sellableSlot(player, index);
			if (stack.isEmpty() || !matcher.test(stack)) {
				continue;
			}
			if (isProtected(stack)) {
				protectedCount += stack.getCount();
			} else {
				sellable += stack.getCount();
			}
		}
		return new InventoryScan(sellable, protectedCount, countInBoxes(player, matcher));
	}

	/** Counts matching items sitting inside shulker boxes; boxes never auto-sell. */
	private static long countInBoxes(ServerPlayer player, java.util.function.Predicate<ItemStack> matcher) {
		var inventory = player.getInventory().getNonEquipmentItems();
		long boxed = 0;
		for (int slot = 0; slot < inventory.size(); slot++) {
			ItemStack stack = inventory.get(slot);
			if (stack.isEmpty()) {
				continue;
			}
			ItemContainerContents contents = stack.get(DataComponents.CONTAINER);
			if (contents == null) {
				continue;
			}
			for (ItemStack inner : Compat.containerItemStream(contents).toList()) {
				if (!inner.isEmpty() && matcher.test(inner)) {
					boxed += inner.getCount();
				}
			}
		}
		return boxed;
	}

	/** Sells every sellable stack in the player's inventory. */
	static SaleResult sellEverything(ServerPlayer player) {
		return sellMatching(player,
			stack -> !stack.isEmpty() && ShopValues.entryFor(stack) != null,
			false);
	}

	/**
	 * Sells every stack matching the predicate.
	 *
	 * @param explicitClick true when the player picked this exact item in the GUI,
	 *                     which also sells renamed copies
	 */
	static SaleResult sellMatching(ServerPlayer player, java.util.function.Predicate<ItemStack> matcher,
			boolean explicitClick) {
		MarketData.initialize(player.level().registryAccess());

		// Tally first, so a storage failure leaves the inventory untouched.
		List<Integer> targets = new ArrayList<>();
		long protectedCount = 0;
		long total = 0;
		int units = 0;
		for (int index = 0; index <= OFFHAND_INDEX; index++) {
			ItemStack stack = sellableSlot(player, index);
			if (stack.isEmpty() || !matcher.test(stack)) {
				continue;
			}
			if (!explicitClick && isProtected(stack)) {
				protectedCount += stack.getCount();
				continue;
			}
			// Stack-based lookup: an enchanted book is priced by its enchant,
			// and enchanted gear gains a bonus for what is on it.
			Long value = ShopValues.sellPrice(stack);
			if (value == null) {
				continue;
			}
			try {
				total = Math.addExact(total, Math.multiplyExact(value, stack.getCount()));
			} catch (ArithmeticException exception) {
				player.sendSystemMessage(Component.literal("That sale value is too large."));
				return new SaleResult(0, 0, protectedCount, 0);
			}
			units += stack.getCount();
			targets.add(index);
		}
		if (units == 0) {
			return new SaleResult(0, 0, protectedCount, scan(player, matcher).boxed());
		}
		if (!MarketData.credit(player.getUUID(), total, player.level().registryAccess())) {
			player.sendSystemMessage(Component.literal("Could not save the sale; your items were not taken."));
			return new SaleResult(0, 0, protectedCount, 0);
		}

		for (int index : targets) {
			clearSellableSlot(player, index);
		}
		syncInventory(player);
		PlayerStats.recordItemsSold(player.getUUID(), units);
		return new SaleResult(total, units, protectedCount, 0);
	}

	/**
	 * Explains a zero payout from "sell everything" — the message both the
	 * {@code /sell all} command and the GUI button show. Protected items are
	 * named keepsakes worth real money, so the text says where they went and
	 * how to sell one instead of flatly claiming there is nothing to sell.
	 */
	static String sellEverythingMessage(SaleResult result) {
		if (result.protectedCount() > 0) {
			return "Kept " + formatAmount(result.protectedCount())
				+ " renamed item(s) - renamed things are protected so keepsakes cannot be lost."
				+ " Hold one and use /sell hand to sell it at its full price.";
		}
		if (result.boxed() > 0) {
			return "Everything matching is inside a shulker box ("
				+ formatAmount(result.boxed()) + " item(s)) - take them out first; boxes are never sold.";
		}
		return "You have nothing sellable in your inventory."
			+ " Enchanted gear does sell (for a bonus), so check /worth -"
			+ " or use /sell to browse everything the shop buys.";
	}

	/**
	 * Explains a zero payout. Instead of always claiming the player has nothing —
	 * which is wrong whenever the items are protected or boxed — it says where
	 * their items actually are and how to sell them.
	 */
	static String nothingSoldMessage(String displayName, SaleResult result) {
		if (result.protectedCount() > 0) {
			return "You have " + formatAmount(result.protectedCount()) + " " + displayName
				+ ", but they are renamed, so they are protected."
				+ " Hold one and use /sell hand to sell it.";
		}
		if (result.boxed() > 0) {
			return "You have " + formatAmount(result.boxed()) + " " + displayName
				+ " inside a shulker box. Take them out first - boxes are never sold.";
		}
		return "You have no " + displayName + " in your inventory.";
	}

	/** A readable name for the container a sell tool or wand just touched. */
	private static String boxName(BlockState state) {
		Block block = state.getBlock();
		if (block instanceof ChestBlock) {
			return "chest";
		}
		if (block instanceof ShulkerBoxBlock) {
			return "shulker box";
		}
		if (block instanceof BarrelBlock) {
			return "barrel";
		}
		if (block instanceof HopperBlock) {
			return "hopper";
		}
		return "container";
	}

	/**
	 * The economy's own heartbeat, driven off the server tick. Kept apart from
	 * the tick handler above so each timer can be reasoned about on its own:
	 * the auto-sell totem sweeps on its own cadence, interest pays out on a
	 * minutes-long timer, and stale auction listings are swept once a minute.
	 * Every one of these is a no-op when its feature is switched off in the
	 * config, so a server that wants none of it pays nothing for having it.
	 */
	private static void runEconomyTicks(MinecraftServer server, long tickCount) {
		// Spawner production: one shared pass per configured interval, never a
		// task per spawner. Virtual and real modes are mutually exclusive
		// inside SpawnerEngine.tick, so a stack can never be double-produced.
		if (Config.getBoolean("spawners.enabled")) {
			long interval = Math.max(20L, Config.getLong("spawners.generation_interval_ticks"));
			if (tickCount % interval == 0) {
				SpawnerEngine.tick(server);
			}
		}
		// Auto-sell totem: only when somebody is online carrying one.
		if (Config.getBoolean("economy.auto_sell_totem_enabled")
			&& tickCount % SellTools.totemIntervalTicks() == 0) {
			for (ServerPlayer player : server.getPlayerList().getPlayers()) {
				SellTools.sweepInventory(player);
			}
		}
		// Interest and auction expiry share one slow timer (once a minute).
		if (tickCount % 1_200 == 0) {
			MarketData.initialize(server.registryAccess());
			MarketData.expireStaleListings(server.registryAccess());
			// Playtime quests tick once a minute per online player: one real
			// minute played is one quest minute, so a relog cannot fake it and
			// neither can a lag spike, since this counts fires, not wall time.
			for (ServerPlayer player : server.getPlayerList().getPlayers()) {
				Quests.recordPlaytime(player.getUUID(), 60);
			}
			long minutes = Math.max(1, Config.getLong("economy.interest_payout_minutes"));
			// Fire on the boundary of the configured interval, not on every
			// minute, so a 10-minute setting pays every tenth minute exactly.
			if (tickCount % (1_200 * minutes) == 0) {
				MarketData.payInterest(server.registryAccess());
			}
		}
		// Lottery draw: fires on its own interval so it needs no operator and
		// no player present at the moment it happens.
		if (Config.getBoolean("economy.lottery_enabled")) {
			long drawTicks = 1_200L * Lottery.drawMinutes();
			if (drawTicks > 0 && tickCount % drawTicks == 0 && Lottery.totalTickets() > 0) {
				String result = Lottery.draw(server.registryAccess());
				if (result != null) {
					server.getPlayerList().getPlayers().forEach(player ->
						player.sendSystemMessage(Component.literal("§6§lLottery §7- " + result)));
				}
			}
		}
	}

	private static int showWorth(ServerPlayer player, String rawItem) {
		if (!AccountAuth.isAuthenticated(player.getUUID())) {
			player.sendSystemMessage(Component.literal("Register or log in before using the economy."));
			return 0;
		}
		MarketData.initialize(player.level().registryAccess());
		ShopValues.initialize(player.level().registryAccess());

		if (rawItem == null || rawItem.isBlank()) {
			// Worth of everything sellable currently held, including the offhand.
			long total = 0;
			int units = 0;
			long protectedCount = 0;
			for (int index = 0; index <= OFFHAND_INDEX; index++) {
				ItemStack stack = sellableSlot(player, index);
				if (stack.isEmpty()) {
					continue;
				}
				Long value = ShopValues.sellPrice(stack);
				if (value == null) {
					continue;
				}
				if (isProtected(stack)) {
					protectedCount += stack.getCount();
					continue;
				}
				total += value * stack.getCount();
				units += stack.getCount();
			}
			long boxed = scan(player, stack -> ShopValues.entryFor(stack) != null).boxed();
			if (units == 0) {
				player.sendSystemMessage(Component.literal(
					"You are carrying nothing sellable. Use /prices to see the price list."));
			} else {
				player.sendSystemMessage(Component.literal(
					"Your inventory is worth $" + formatAmount(total) + " across " + formatAmount(units) + " item(s)."));
			}
			if (protectedCount > 0) {
				player.sendSystemMessage(Component.literal(
					"Skipped " + formatAmount(protectedCount) + " renamed item(s)."));
			}
			if (boxed > 0) {
				player.sendSystemMessage(Component.literal(
					"Plus " + formatAmount(boxed) + " item(s) inside shulker boxes, which are not sold."));
			}
			return units == 0 ? 0 : 1;
		}

		String needle = rawItem.trim().toLowerCase(Locale.ROOT).replace(' ', '_');
		ShopValues.Entry match = null;
		for (ShopValues.Entry entry : ShopValues.all()) {
			String id = BuiltInRegistries.ITEM.getKey(entry.item()).getPath();
			if (id.equals(needle) || id.contains(needle)) {
				match = entry;
				break;
			}
		}
		if (match == null) {
			player.sendSystemMessage(Component.literal("No price found for \"" + rawItem + "\". Use /prices for the list."));
			return 0;
		}
		Long worth = ShopValues.sellPrice(match.displayStack());
		long each = worth != null ? worth : ShopValues.marketPrice(match);
		player.sendSystemMessage(Component.literal(
			ShopValues.displayName(match.item()) + ": $" + formatAmount(each)
				+ " each (" + match.category() + ")"));
		return 1;
	}

	/**
	 * /prices with no argument summarises every category; /prices &lt;category&gt;
	 * lists it. Dumping thousands of block prices into chat helped nobody.
	 */
	private static int showPrices(ServerPlayer player, String rawCategory) {
		if (!AccountAuth.isAuthenticated(player.getUUID())) {
			player.sendSystemMessage(Component.literal("Register or log in before using the economy."));
			return 0;
		}
		MarketData.initialize(player.level().registryAccess());
		ShopValues.initialize(player.level().registryAccess());

		// "trend" is a word, not a category, so it is caught before the shop
		// goes looking for a category by that name.
		if (rawCategory != null && rawCategory.trim().equalsIgnoreCase("trend")) {
			player.sendSystemMessage(Component.literal("§6§lMarket trend"));
			for (PriceHistory.Sample sample : PriceHistory.samples()) {
				String when = java.time.Instant.ofEpochSecond(sample.epochSeconds())
					.atZone(java.time.ZoneId.systemDefault())
					.toLocalTime().toString();
				player.sendSystemMessage(Component.literal(
					"§8 - §7" + when + " §f" + String.format("%.2fx", sample.averageFactor())));
			}
			player.sendSystemMessage(Component.literal("§7" + PriceHistory.trend()));
			return 1;
		}

		if (rawCategory == null || rawCategory.isBlank()) {
			player.sendSystemMessage(Component.literal("The shop buys "
				+ formatAmount(ShopValues.all().size()) + " item(s) across "
				+ ShopValues.categories().size() + " categories."));
			player.sendSystemMessage(Component.literal(
				"Use /prices <category> for a list, /worth <item> for one price."));
			player.sendSystemMessage(Component.literal(
				"/sell opens the sell GUI, /buy opens the shop."));
			for (String category : ShopValues.categories()) {
				List<ShopValues.Entry> entries = ShopValues.inCategory(category);
				if (entries.isEmpty()) {
					continue;
				}
				long lowest = Long.MAX_VALUE;
				long highest = 0;
				for (ShopValues.Entry entry : entries) {
					lowest = Math.min(lowest, ShopValues.marketPrice(entry));
					highest = Math.max(highest, ShopValues.marketPrice(entry));
				}
				player.sendSystemMessage(Component.literal("  " + category + ": "
					+ formatAmount(entries.size()) + " item(s), $"
					+ formatAmount(lowest) + " - $" + formatAmount(highest)));
			}
			return 1;
		}

		String needle = rawCategory.trim().toLowerCase(Locale.ROOT);
		for (String category : ShopValues.categories()) {
			if (!category.toLowerCase(Locale.ROOT).contains(needle)) {
				continue;
			}
			List<ShopValues.Entry> entries = new ArrayList<>(ShopValues.inCategory(category));
			entries.sort(java.util.Comparator.comparingLong((ShopValues.Entry entry) -> ShopValues.marketPrice(entry)).reversed());
			player.sendSystemMessage(Component.literal(
				category + " (" + formatAmount(entries.size()) + " item(s), dearest first):"));
			int shown = 0;
			for (ShopValues.Entry entry : entries) {
				if (shown++ >= 60) {
					player.sendSystemMessage(Component.literal(
						"  ... and " + formatAmount(entries.size() - 60)
							+ " more. Use /sell or /buy to browse them."));
					break;
				}
				player.sendSystemMessage(Component.literal("  " + ShopValues.displayName(entry.item())
					+ " - $" + formatAmount(ShopValues.marketPrice(entry))));
			}
			return 1;
		}
		player.sendSystemMessage(Component.literal("No category matches \"" + rawCategory + "\". Use /prices to see them all."));
		return 0;
	}

	/** /search <query> - finds items in the shop. */
	private static int searchCommand(ServerPlayer player, String query) {
		if (!AccountAuth.isAuthenticated(player.getUUID())) {
			player.sendSystemMessage(Component.literal("Register or log in before using the shop."));
			return 0;
		}
		MarketData.initialize(player.level().registryAccess());
		ShopValues.initialize(player.level().registryAccess());

		List<ShopValues.Entry> results = ShopSearch.search(query, 20);
		if (results.isEmpty()) {
			player.sendSystemMessage(Component.literal("No items match \"" + query + "\"."));
			return 0;
		}
		player.sendSystemMessage(Component.literal("Top matches for \"" + query + "\":"));
		for (int i = 0; i < results.size(); i++) {
			ShopValues.Entry entry = results.get(i);
			player.sendSystemMessage(Component.literal("  " + (i + 1) + ". " + entry.name()
				+ " - $" + formatAmount(ShopValues.marketPrice(entry)) + " (" + entry.category() + ")"));
		}
		player.sendSystemMessage(Component.literal("Use /buy to browse and buy, or click an item in /sell."));
		return 1;
	}

	

	

	

	/** Opens the /ranks GUI. */
	private static int openRanks(ServerPlayer player) {
		if (!AccountAuth.isAuthenticated(player.getUUID())) {
			player.sendSystemMessage(Component.literal("Register or log in before using the economy."));
			return 0;
		}
		MarketData.initialize(player.level().registryAccess());
		player.openMenu(new SimpleMenuProvider(
			(containerId, inventory, viewer) -> new RanksMenu(containerId, inventory, player),
			Component.literal("Ranks")
		));
		return 1;
	}

	/** /ranks buy <tier> - purchases the given rank tier. */
	private static int buyRank(ServerPlayer player, int tier) {
		if (!AccountAuth.isAuthenticated(player.getUUID())) {
			player.sendSystemMessage(Component.literal("Register or log in before using the economy."));
			return 0;
		}
		MarketData.initialize(player.level().registryAccess());
		String problem = RankShop.purchase(player, tier, player.level().registryAccess());
		if (problem != null) {
			player.sendSystemMessage(Component.literal(problem));
			return 0;
		}
		RankShop.Rank rank = RankShop.get(tier);
		player.sendSystemMessage(Component.literal("You are now a " + rank.colour() + rank.name() + "§r!"));
		return 1;
	}

	/** /ranks claim - claims the daily payout for your current rank. */
	private static int claimRankPayout(ServerPlayer player) {
		if (!AccountAuth.isAuthenticated(player.getUUID())) {
			player.sendSystemMessage(Component.literal("Register or log in before using the economy."));
			return 0;
		}
		MarketData.initialize(player.level().registryAccess());
		long paid = RankShop.claimPayout(player, player.level().registryAccess());
		if (paid < 0) {
			player.sendSystemMessage(Component.literal("Could not process the payout; try again later."));
			return 0;
		}
		if (paid == 0) {
			long wait = RankShop.millisUntilPayout(player.getUUID());
			if (wait > 0) {
				long hours = (wait + 3_599_999) / 3_600_000;
				player.sendSystemMessage(Component.literal("Daily payout already claimed. Next in ~" + hours + " hour(s)."));
			} else {
				player.sendSystemMessage(Component.literal("Your rank does not have a daily payout."));
			}
			return 0;
		}
		player.sendSystemMessage(Component.literal("Claimed daily payout: $" + formatAmount(paid) + "."));
		return 1;
	}

	/** Opens the /tabranks GUI. */
	private static int openTabRanks(ServerPlayer player) {
		if (!AccountAuth.isAuthenticated(player.getUUID())) {
			player.sendSystemMessage(Component.literal("Register or log in before accessing tab ranks."));
			return 0;
		}
		MarketData.initialize(player.level().registryAccess());
		TabRanks.initialize();
		player.openMenu(new SimpleMenuProvider(
			(containerId, inventory, viewer) -> new TabRanksMenu(containerId, inventory, player),
			Component.literal("Tab & Nametag Ranks")
		));
		return 1;
	}

	/** Toggles player's tabrank position between prefix and suffix. */
	private static int toggleTabRankPosition(ServerPlayer player) {
		if (!AccountAuth.isAuthenticated(player.getUUID())) {
			player.sendSystemMessage(Component.literal("Register or log in before accessing tab ranks."));
			return 0;
		}
		TabRanks.togglePosition(player.getUUID());
		TabRanks.applyPlayerTab(player);
		player.sendSystemMessage(Component.literal("§aRank position changed to: §e"
			+ TabRanks.getPosition(player.getUUID()).label()));
		return 1;
	}

	/** Sets explicit rank position. */
	private static int setTabRankPosition(ServerPlayer player, TabRanks.Position pos) {
		if (!AccountAuth.isAuthenticated(player.getUUID())) {
			player.sendSystemMessage(Component.literal("Register or log in before accessing tab ranks."));
			return 0;
		}
		TabRanks.setPosition(player.getUUID(), pos);
		TabRanks.applyPlayerTab(player);
		player.sendSystemMessage(Component.literal("§aRank position set to: §e" + pos.label()));
		return 1;
	}

	/** /tabranks buy <rank> */
	private static int buyTabRankCommand(ServerPlayer player, String rankId) {
		if (!AccountAuth.isAuthenticated(player.getUUID())) {
			player.sendSystemMessage(Component.literal("Register or log in before using the economy."));
			return 0;
		}
		MarketData.initialize(player.level().registryAccess());
		String problem = TabRanks.purchase(player, rankId, player.level().registryAccess());
		if (problem != null) {
			player.sendSystemMessage(Component.literal("§c" + problem));
			return 0;
		}
		TabRanks.RankDef rank = TabRanks.getRank(rankId);
		player.sendSystemMessage(Component.literal("§aPurchased and equipped rank: "
			+ rank.format() + rank.sign() + " " + rank.displayName() + "§r!"));
		return 1;
	}

	/** /tabranks equip <rank> */
	private static int equipTabRankCommand(ServerPlayer player, String rankId) {
		if (!AccountAuth.isAuthenticated(player.getUUID())) {
			player.sendSystemMessage(Component.literal("Register or log in before accessing tab ranks."));
			return 0;
		}
		TabRanks.initialize();
		if (!TabRanks.hasRank(player, rankId)) {
			player.sendSystemMessage(Component.literal("§cYou do not own this rank. Use /tabranks to view and purchase it."));
			return 0;
		}
		TabRanks.setActiveRank(player.getUUID(), rankId);
		TabRanks.applyPlayerTab(player);
		TabRanks.RankDef rank = TabRanks.getRank(rankId);
		player.sendSystemMessage(Component.literal("§aEquipped rank: "
			+ rank.format() + rank.sign() + " " + rank.displayName() + "§r!"));
		return 1;
	}

	/** /tabranks sync */
	private static int syncTabRanksWebCommand(ServerPlayer player) {
		if (!AccountAuth.isAuthenticated(player.getUUID())) {
			player.sendSystemMessage(Component.literal("Register or log in before accessing tab ranks."));
			return 0;
		}
		MinecraftServer server = player.level().getServer();
		player.sendSystemMessage(Component.literal("§eChecking online web/GitHub for free rank grants..."));
		TabRanks.syncWebGrants(server).thenAccept(result -> {
			if (server != null) {
				server.execute(() -> {
					player.sendSystemMessage(Component.literal("§a[WebSync] " + result));
				});
			}
		});
		return 1;
	}

	/** Toggles admin mode for an authorized user (see admin.username in the config). */
	private static int toggleAdminMode(CommandSourceStack source, ServerPlayer player) {
		// Check OPS.json for sfmode permission (admin perm also grants sfmode)
		String name = player.getScoreboardName();
		boolean allowed = source.permissions().hasPermission(Permissions.COMMANDS_ADMIN)
			|| OpsConfig.hasPermission(name, OpsConfig.PERM_SFMODE);
		if (!allowed) {
			player.sendSystemMessage(Component.literal("§cYou are not authorized to use this command."));
			return 0;
		}
		UUID id = player.getUUID();
		if (ADMIN_MODE.remove(id)) {
			player.sendSystemMessage(Component.literal("§cAdmin mode disabled."));
		} else {
			ADMIN_MODE.add(id);
			player.sendSystemMessage(Component.literal("§aAdmin mode enabled."));
			player.sendSystemMessage(Component.literal("§7/money <player> <set|give|remove> <amount>"));
			player.sendSystemMessage(Component.literal("§7/shards <player> <set|give|remove> <amount>"));
			player.sendSystemMessage(Component.literal("§7/rank <player> <set|give|remove> <rank>"));
			player.sendSystemMessage(Component.literal("§7/crystal <player> <mob|pvp> <set|give|remove> <tier>"));
			player.sendSystemMessage(Component.literal("§7/spawnstash <1-5>"));
		}
		return 1;
	}

	/** The username allowed to use the admin commands; configurable, defaults to vadim154655. Package-private for InfEnchants. */
	static String adminUsername() {
		String name = Config.getString("admin.username", DEFAULT_ADMIN_USERNAME).trim();
		return name.isEmpty() ? DEFAULT_ADMIN_USERNAME : name;
	}

	/** Admin commands belong to users listed in OPS.json with 'admin' permission, and to server operators. */
	private static boolean isAdminUser(CommandSourceStack source, ServerPlayer player) {
		if (source.permissions().hasPermission(Permissions.COMMANDS_ADMIN)) {
			return true;
		}
		String name = player.getScoreboardName();
		// Check OPS.json for admin permission
		if (OpsConfig.hasPermission(name, OpsConfig.PERM_ADMIN)) {
			return true;
		}
		// Fallback: still check the legacy config admin.username for backwards compat
		return name != null && name.equalsIgnoreCase(adminUsername());
	}

	/** Checks if a player has admin mode active. Package-private for ChaosCommands. */
	static boolean isAdminMode(CommandSourceStack source, ServerPlayer player) {
		return isAdminUser(source, player) && ADMIN_MODE.contains(player.getUUID());
	}

	/** A target of an admin command: their UUID and the name we know them by. */
	private record Target(UUID id, String name) {
	}

	/**
	 * Resolves a name typed by an admin to a player, online or not. Admin
	 * commands have to work while the subject is offline, so an unknown name is
	 * an error rather than "must be online" - the data files are keyed by UUID
	 * and there is nothing sensible to write to otherwise.
	 *
	 * @return the target, or null when the name is not a player we have data for
	 */
	private static Target resolveTarget(ServerPlayer admin, String rawName) {
		MinecraftServer server = admin.level().getServer();
		ServerPlayer online = server == null ? null : server.getPlayerList().getPlayerByName(rawName);
		if (online != null) {
			return new Target(online.getUUID(), online.getScoreboardName());
		}
		UUID id = PlayerStats.byName(rawName);
		if (id == null) {
			return null;
		}
		String known = PlayerStats.nameOf(id);
		return new Target(id, (known == null || known.isBlank()) ? rawName : known);
	}

	/** Reads the shared "set|give|remove" verb the currency commands share. */
	@FunctionalInterface
	private interface CurrencyHandler {
		int handle(CommandSourceStack source, ServerPlayer admin, String player, String action, long amount);
	}

	/**
	 * Builds the shared "&lt;player&gt; &lt;set|give|remove&gt; &lt;amount&gt;"
	 * branch. The verbs are literals so the client suggests them, and the
	 * amount is a long because both money and shards easily exceed int.
	 */
	private static RequiredArgumentBuilder<CommandSourceStack, String> currencyBranch(CurrencyHandler handler) {
		RequiredArgumentBuilder<CommandSourceStack, String> player =
			Commands.argument("player", StringArgumentType.word());
		for (String action : List.of("set", "give", "remove")) {
			player.then(Commands.literal(action)
				.then(Commands.argument("amount", LongArgumentType.longArg(0))
					.executes(context -> handler.handle(
						context.getSource(),
						context.getSource().getPlayerOrException(),
						StringArgumentType.getString(context, "player"),
						action,
						LongArgumentType.getLong(context, "amount")
					))));
		}
		return player;
	}

	/**
	 * Applies one of the three currency verbs to a current balance.
	 *
	 * @return the new balance, or -1 when the verb is not understood
	 */
	private static long applyAction(String action, long current, long amount) {
		return switch (action) {
			case "set" -> amount;
			case "give" -> Math.addExact(current, amount);
			case "remove" -> Math.max(0L, current - amount);
			default -> -1L;
		};
	}

	/** /money <player> <set|give|remove> <amount> - the admin money command. */
	private static int adminMoney(CommandSourceStack source, ServerPlayer admin, String rawName,
			String action, long amount) {
		if (!isAdminMode(source, admin)) {
			admin.sendSystemMessage(Component.literal("§cAdmin mode required. Use /sfmode first."));
			return 0;
		}
		if (amount < 0) {
			admin.sendSystemMessage(Component.literal("§cAmount cannot be negative."));
			return 0;
		}
		Target target = resolveTarget(admin, rawName);
		if (target == null) {
			admin.sendSystemMessage(Component.literal("§cNo player called " + rawName + "."));
			return 0;
		}
		RegistryAccess registries = admin.level().registryAccess();
		MarketData.initialize(registries);
		long before = MarketData.balance(target.id());
		long after;
		try {
			after = applyAction(action, before, amount);
		} catch (ArithmeticException overflow) {
			admin.sendSystemMessage(Component.literal("§cThat total is too large to hold."));
			return 0;
		}
		if (after < 0) {
			admin.sendSystemMessage(Component.literal("§cUnknown action \"" + action + "\". Use set, give or remove."));
			return 0;
		}
		if (!MarketData.setBalance(target.id(), after, registries)) {
			admin.sendSystemMessage(Component.literal("§cThat change could not be saved. Nothing was changed."));
			return 0;
		}
		admin.sendSystemMessage(Component.literal("§a" + target.name() + " now has $"
			+ formatAmount(after) + " §7(was $" + formatAmount(before) + ")."));
		return 1;
	}

	/** /shards <player> <set|give|remove> <amount> - the admin shard command. */
	private static int adminShards(CommandSourceStack source, ServerPlayer admin, String rawName,
			String action, long amount) {
		if (!isAdminMode(source, admin)) {
			admin.sendSystemMessage(Component.literal("§cAdmin mode required. Use /sfmode first."));
			return 0;
		}
		Target target = resolveTarget(admin, rawName);
		if (target == null) {
			admin.sendSystemMessage(Component.literal("§cNo player called " + rawName + "."));
			return 0;
		}
		String problem = switch (action) {
			case "set" -> Shards.adminSet(target.id(), amount);
			case "give" -> Shards.adminGive(target.id(), amount);
			case "remove" -> Shards.adminRemove(target.id(), amount);
			default -> "Unknown action \"" + action + "\". Use set, give or remove.";
		};
		if (problem != null) {
			admin.sendSystemMessage(Component.literal("§c" + problem));
			return 0;
		}
		admin.sendSystemMessage(Component.literal("§a" + target.name() + " now has "
			+ formatAmount(Shards.balance(target.id())) + " shards."));
		return 1;
	}

	/** /rank <player> <set|give|remove> <rank> - the admin playtime-rank command. */
	private static int adminRank(CommandSourceStack source, ServerPlayer admin, String rawName,
			String action, String rawRank) {
		if (!isAdminMode(source, admin)) {
			admin.sendSystemMessage(Component.literal("§cAdmin mode required. Use /sfmode first."));
			return 0;
		}
		Target target = resolveTarget(admin, rawName);
		if (target == null) {
			admin.sendSystemMessage(Component.literal("§cNo player called " + rawName + "."));
			return 0;
		}
		int wanted = resolveRankTier(rawRank);
		if (wanted < 0) {
			// Not a combat tier: try a tab rank (vip, MVP+...). Combat names
			// win conflicts, so every existing /rank command behaves as before.
			TabRanks.RankDef tabRank = TabRanks.findRank(rawRank);
			if (tabRank != null) {
				return adminTabRank(admin, target, action, tabRank);
			}
			admin.sendSystemMessage(Component.literal("§cUnknown rank \"" + rawRank
				+ "\". Use a combat name (e.g. Legend), a tab rank (e.g. vip), or a tier 0-" + RankShop.MAX_TIER + "."));
			return 0;
		}
		int purchased = RankShop.purchasedTier(target.id());
		int next = switch (action) {
			case "set" -> wanted;
			case "give" -> Math.max(purchased, wanted);
			case "remove" -> Math.min(purchased, wanted);
			default -> -1;
		};
		if (next < 0) {
			admin.sendSystemMessage(Component.literal("§cUnknown action \"" + action + "\". Use set, give or remove."));
			return 0;
		}
		String problem = RankShop.adminSetTier(target.id(), next);
		if (problem != null) {
			admin.sendSystemMessage(Component.literal("§c" + problem));
			return 0;
		}
		reportRank(admin, target, RankShop.get(RankShop.effectiveTier(target.id(),
			PlayerStats.playtimeSeconds(target.id()))));
		return 1;
	}

	/**
	 * Applies set/give/remove to a tab rank for an (possibly offline) target.
	 * set equips it, give only unlocks it, remove takes it back - the same
	 * vocabulary the combat half of /rank already uses.
	 */
	private static int adminTabRank(ServerPlayer admin, Target target, String action, TabRanks.RankDef rank) {
		ServerPlayer online = admin.level().getServer() == null
			? null : admin.level().getServer().getPlayerList().getPlayerByName(target.name());
		switch (action) {
			case "set" -> {
				TabRanks.grantRank(target.id(), rank.id());
				TabRanks.setActiveRank(target.id(), rank.id());
				if (online != null) {
					TabRanks.applyPlayerTab(online);
				}
			}
			case "give" -> TabRanks.grantRank(target.id(), rank.id());
			case "remove" -> {
				if (!TabRanks.revokeRank(target.id(), rank.id())) {
					admin.sendSystemMessage(Component.literal(
						"§c" + target.name() + " does not hold the " + rank.displayName() + " tab rank."));
					return 0;
				}
				if (online != null) {
					TabRanks.applyPlayerTab(online);
				}
			}
			default -> {
				admin.sendSystemMessage(Component.literal("§cUnknown action \"" + action + "\". Use set, give or remove."));
				return 0;
			}
		}
		admin.sendSystemMessage(Component.literal("§a" + target.name() + " now holds the "
			+ rank.format() + rank.sign() + " " + rank.displayName() + "§r tab rank ("
			+ action + ")."));
		return 1;
	}

	/** /crystal <player> <mob|pvp> <set|give|remove> <tier> - admin crystal command. */
	private static int adminCrystal(CommandSourceStack source, ServerPlayer admin, String rawName,
			String ladderName, String action, int wanted) {
		if (!isAdminMode(source, admin)) {
			admin.sendSystemMessage(Component.literal("§cAdmin mode required. Use /sfmode first."));
			return 0;
		}
		CombatRanks.Ladder ladder;
		try {
			ladder = CombatRanks.Ladder.valueOf(ladderName.toUpperCase(Locale.ROOT));
		} catch (IllegalArgumentException unknown) {
			admin.sendSystemMessage(Component.literal("§cUnknown ladder \"" + ladderName + "\". Use mob or pvp."));
			return 0;
		}
		Target target = resolveTarget(admin, rawName);
		if (target == null) {
			admin.sendSystemMessage(Component.literal("§cNo player called " + rawName + "."));
			return 0;
		}
		int purchased = CombatRanks.purchasedTier(ladder, target.id());
		int next = switch (action) {
			case "set" -> wanted;
			case "give" -> Math.max(purchased, wanted);
			case "remove" -> Math.min(purchased, wanted);
			default -> -1;
		};
		if (next < 0) {
			admin.sendSystemMessage(Component.literal("§cUnknown action \"" + action + "\". Use set, give or remove."));
			return 0;
		}
		String problem = CombatRanks.adminSetTier(ladder, target.id(), next);
		if (problem != null) {
			admin.sendSystemMessage(Component.literal("§c" + problem));
			return 0;
		}
		CombatRanks.Crystal held = CombatRanks.get(ladder, CombatRanks.effectiveTier(ladder, target.id()));
		admin.sendSystemMessage(Component.literal("§a" + target.name() + " now holds "
			+ held.colour() + held.name() + "§a (" + ladder.label() + " ladder)."));
		return 1;
	}

	/** Names the rank a player ended up holding, so the admin sees the result. */
	private static void reportRank(ServerPlayer admin, Target target, RankShop.Rank rank) {
		admin.sendSystemMessage(Component.literal("§a" + target.name() + " now holds "
			+ rank.colour() + rank.name() + "§a."));
	}

	/**
	 * Reads a rank as either its display name (Legend) or its bare tier (7).
	 *
	 * @return the tier, or -1 when it matches nothing
	 */
	private static int resolveRankTier(String raw) {
		String text = raw == null ? "" : raw.trim();
		if (text.isEmpty()) {
			return -1;
		}
		try {
			int tier = Integer.parseInt(text);
			return (tier >= 0 && tier <= RankShop.MAX_TIER) ? tier : -1;
		} catch (NumberFormatException ignored) {
			// Not a number - fall through to matching by name.
		}
		String wanted = text.toLowerCase(Locale.ROOT);
		for (RankShop.Rank rank : RankShop.RANKS) {
			if (rank.name().toLowerCase(Locale.ROOT).equals(wanted)) {
				return rank.tier();
			}
		}
		return -1;
	}

	/** Spawns a stash of the given level (1-5) at the player's location. */
	private static int spawnStash(CommandSourceStack source, ServerPlayer player, int level) {
		if (!isAdminMode(source, player)) {
			player.sendSystemMessage(Component.literal("§cAdmin mode required. Use /sfmode first."));
			return 0;
		}
		if (level < 1 || level > 5) {
			player.sendSystemMessage(Component.literal("§cStash level must be between 1 and 5."));
			return 0;
		}

		ServerLevel world = player.level();
		BlockPos pos = findStashSpot(world, player.blockPosition());
		if (pos == null) {
			player.sendSystemMessage(Component.literal("§cThere is no clear space near you for a stash chest."));
			return 0;
		}

		// A chest with nothing under it falls off on the next block update, so
		// give it a stone pedestal whenever the ground itself is missing.
		BlockPos support = pos.below();
		BlockState supportState = world.getBlockState(support);
		if (!blocksMotion(supportState, world, support)) {
			world.setBlock(support, Blocks.STONE.defaultBlockState(), 3);
		}

		if (!world.setBlock(pos, Blocks.CHEST.defaultBlockState(), 3)) {
			player.sendSystemMessage(Component.literal("§cThe stash chest could not be placed here; nothing was given."));
			return 0;
		}
		if (!(world.getBlockEntity(pos) instanceof ChestBlockEntity chest)) {
			player.sendSystemMessage(Component.literal("§cThe stash chest failed to spawn; nothing was given."));
			return 0;
		}

		fillStashChest(chest, level, world.registryAccess(), world.getRandom());
		player.sendSystemMessage(Component.literal(
			"§aSpawned a level " + level + " stash at " + pos.getX() + ", " + pos.getY() + ", " + pos.getZ() + "."));
		return 1;
	}

	/**
	 * Finds a free block for the stash chest, starting at the player's feet and
	 * working upwards. The spot also needs solid ground under it - or room to
	 * place some - so the chest cannot immediately pop back off as an item.
	 */
	private static BlockPos findStashSpot(ServerLevel world, BlockPos feet) {
		for (int offset = 0; offset <= 3; offset++) {
			BlockPos candidate = feet.above(offset);
			if (!world.isInsideBuildHeight(candidate.getY())) {
				continue;
			}
			BlockState at = world.getBlockState(candidate);
			if (!at.isAir() && !at.canBeReplaced()) {
				continue;
			}
			BlockState below = world.getBlockState(candidate.below());
			if (!blocksMotion(below, world, candidate.below()) && !below.isAir() && !below.canBeReplaced()) {
				continue;
			}
			return candidate;
		}
		return null;
	}

	/** Fills a chest block entity with loot appropriate for the given stash level. */
	private static void fillStashChest(net.minecraft.world.level.block.entity.ChestBlockEntity chest, int level, RegistryAccess registries, net.minecraft.util.RandomSource random) {
		Registry<Enchantment> enchantRegistry = registries.lookupOrThrow(Registries.ENCHANTMENT);
		
		// Clear the chest first
		for (int i = 0; i < chest.getContainerSize(); i++) {
			chest.setItem(i, ItemStack.EMPTY);
		}
		
		switch (level) {
			case 1 -> { // Worst - few spawners and basic blocks
				addItemToChest(chest, random, new ItemStack(Items.SPAWNER), 1);
				addItemToChest(chest, random, new ItemStack(Items.COBBLESTONE), 32 + random.nextInt(32));
				addItemToChest(chest, random, new ItemStack(Items.OAK_LOG), 16 + random.nextInt(16));
				addItemToChest(chest, random, new ItemStack(Items.COAL), 8 + random.nextInt(8));
				addItemToChest(chest, random, new ItemStack(Items.IRON_INGOT), 2 + random.nextInt(4));
			}
			case 2 -> { // Low - some spawners, basic ores
				addItemToChest(chest, random, new ItemStack(Items.SPAWNER), 1 + random.nextInt(2));
				addItemToChest(chest, random, new ItemStack(Items.IRON_ORE), 16 + random.nextInt(16));
				addItemToChest(chest, random, new ItemStack(Items.COPPER_ORE), 16 + random.nextInt(16));
				addItemToChest(chest, random, new ItemStack(Items.GOLD_ORE), 8 + random.nextInt(8));
				addItemToChest(chest, random, new ItemStack(Items.REDSTONE), 16 + random.nextInt(16));
				addItemToChest(chest, random, new ItemStack(Items.IRON_INGOT), 8 + random.nextInt(8));
				addItemToChest(chest, random, new ItemStack(Items.GOLD_INGOT), 4 + random.nextInt(4));
			}
			case 3 -> { // Medium - multiple spawners, diamonds, enchanted gear
				addItemToChest(chest, random, new ItemStack(Items.SPAWNER), 2 + random.nextInt(2));
				addItemToChest(chest, random, new ItemStack(Items.DIAMOND_ORE), 8 + random.nextInt(8));
				addItemToChest(chest, random, new ItemStack(Items.DEEPSLATE_DIAMOND_ORE), 8 + random.nextInt(8));
				addItemToChest(chest, random, new ItemStack(Items.DIAMOND), 4 + random.nextInt(6));
				addItemToChest(chest, random, new ItemStack(Items.EMERALD), 2 + random.nextInt(4));
				addItemToChest(chest, random, new ItemStack(Items.ENCHANTED_GOLDEN_APPLE), 1);
				// Add some enchanted gear
				if (random.nextBoolean()) addItemToChest(chest, random, enchantedBook(enchantRegistry, Enchantments.SHARPNESS, 3 + random.nextInt(2)), 1);
				if (random.nextBoolean()) addItemToChest(chest, random, enchantedBook(enchantRegistry, Enchantments.PROTECTION, 3 + random.nextInt(2)), 1);
				if (random.nextBoolean()) addItemToChest(chest, random, enchantedBook(enchantRegistry, Enchantments.EFFICIENCY, 3 + random.nextInt(2)), 1);
			}
			case 4 -> { // High - many spawners, netherite, rare items
				addItemToChest(chest, random, new ItemStack(Items.SPAWNER), 3 + random.nextInt(3));
				addItemToChest(chest, random, new ItemStack(Items.ANCIENT_DEBRIS), 8 + random.nextInt(8));
				addItemToChest(chest, random, new ItemStack(Items.NETHERITE_SCRAP), 2 + random.nextInt(4));
				addItemToChest(chest, random, new ItemStack(Items.DIAMOND), 8 + random.nextInt(8));
				addItemToChest(chest, random, new ItemStack(Items.NETHERITE_INGOT), 1 + random.nextInt(2));
				addItemToChest(chest, random, new ItemStack(Items.ELYTRA), 1);
				addItemToChest(chest, random, new ItemStack(Items.TOTEM_OF_UNDYING), 1 + random.nextInt(2));
				addItemToChest(chest, random, new ItemStack(Items.ENCHANTED_GOLDEN_APPLE), 2 + random.nextInt(2));
				// High-level enchanted books
				addItemToChest(chest, random, enchantedBook(enchantRegistry, Enchantments.MENDING, 1), 1);
				addItemToChest(chest, random, enchantedBook(enchantRegistry, Enchantments.UNBREAKING, 3), 1);
				addItemToChest(chest, random, enchantedBook(enchantRegistry, Enchantments.FORTUNE, 3), 1);
				addItemToChest(chest, random, enchantedBook(enchantRegistry, Enchantments.LOOTING, 3), 1);
			}
			case 5 -> { // Best - massive loot, multiple spawners, netherite gear, custom enchants
				addItemToChest(chest, random, new ItemStack(Items.SPAWNER), 5 + random.nextInt(5));
				addItemToChest(chest, random, new ItemStack(Items.ANCIENT_DEBRIS), 16 + random.nextInt(16));
				addItemToChest(chest, random, new ItemStack(Items.NETHERITE_INGOT), 3 + random.nextInt(4));
				addItemToChest(chest, random, new ItemStack(Items.DIAMOND), 16 + random.nextInt(16));
				addItemToChest(chest, random, new ItemStack(Items.NETHERITE_BLOCK), 1);
				addItemToChest(chest, random, new ItemStack(Items.ELYTRA), 1);
				addItemToChest(chest, random, new ItemStack(Items.TOTEM_OF_UNDYING), 3 + random.nextInt(3));
				addItemToChest(chest, random, new ItemStack(Items.ENCHANTED_GOLDEN_APPLE), 4 + random.nextInt(4));
				addItemToChest(chest, random, new ItemStack(Items.BEACON), 1);
				addItemToChest(chest, random, new ItemStack(Items.END_CRYSTAL), 4);
				// Full netherite armor set (pre-enchanted)
				for (ItemStack stack : preEnchantedNetheriteArmor(enchantRegistry)) {
					addItemToChest(chest, random, stack, 1);
				}
				// Netherite tools
				for (ItemStack stack : preEnchantedNetheriteTools(enchantRegistry)) {
					addItemToChest(chest, random, stack, 1);
				}
				// Max enchanted books
				addItemToChest(chest, random, enchantedBook(enchantRegistry, Enchantments.MENDING, 1), 2);
				addItemToChest(chest, random, enchantedBook(enchantRegistry, Enchantments.UNBREAKING, 3), 2);
				addItemToChest(chest, random, enchantedBook(enchantRegistry, Enchantments.FORTUNE, 3), 2);
				addItemToChest(chest, random, enchantedBook(enchantRegistry, Enchantments.LOOTING, 3), 2);
				addItemToChest(chest, random, enchantedBook(enchantRegistry, Enchantments.SHARPNESS, 5), 1);
				addItemToChest(chest, random, enchantedBook(enchantRegistry, Enchantments.PROTECTION, 4), 1);
				// Custom enchanted gear
				if (random.nextBoolean()) addItemToChest(chest, random, customEnchantedGear(CustomEnchants.Type.SMELTER, 3, enchantRegistry), 1);
				if (random.nextBoolean()) addItemToChest(chest, random, customEnchantedGear(CustomEnchants.Type.TELEKINESIS, 1, enchantRegistry), 1);
				if (random.nextBoolean()) addItemToChest(chest, random, customEnchantedGear(CustomEnchants.Type.LUCKY, 3, enchantRegistry), 1);
			}
		}
		chest.setChanged();
	}

	/** Adds an item stack to a random empty slot in the chest. */
	private static void addItemToChest(net.minecraft.world.level.block.entity.ChestBlockEntity chest, net.minecraft.util.RandomSource random, ItemStack stack, int count) {
		if (stack.isEmpty()) return;
		ItemStack copy = stack.copy();
		copy.setCount(count);
		
		// Find a random empty slot
		int attempts = 0;
		while (attempts < 100) {
			int slot = random.nextInt(chest.getContainerSize());
			if (chest.getItem(slot).isEmpty()) {
				chest.setItem(slot, copy);
				return;
			}
			attempts++;
		}
		// If no empty slot found, try to stack with existing items
		for (int i = 0; i < chest.getContainerSize(); i++) {
			ItemStack existing = chest.getItem(i);
			if (!existing.isEmpty() && ItemStack.isSameItemSameComponents(existing, copy)) {
				int space = existing.getMaxStackSize() - existing.getCount();
				if (space > 0) {
					int toAdd = Math.min(space, copy.getCount());
					existing.grow(toAdd);
					copy.shrink(toAdd);
					if (copy.isEmpty()) return;
				}
			}
		}
		// If still items left, place in first empty slot (shouldn't happen normally)
		for (int i = 0; i < chest.getContainerSize(); i++) {
			if (chest.getItem(i).isEmpty()) {
				chest.setItem(i, copy);
				return;
			}
		}
	}

	/** Builds a stash ItemStack for the given level. */
	private static ItemStack buildStash(int level, RegistryAccess registries) {
		ItemStack chest = new ItemStack(Items.CHEST);
		chest.set(DataComponents.CUSTOM_NAME, 
			Component.literal("§6§lStash Level " + level).withStyle(ChatFormatting.GOLD));
		
		List<Component> lore = new ArrayList<>();
		lore.add(Component.literal("§7Right-click to open").withStyle(ChatFormatting.GRAY));
		lore.add(Component.literal("§7Level " + level + " stash").withStyle(ChatFormatting.YELLOW));
		chest.set(DataComponents.LORE, new ItemLore(lore));
		
		// The actual loot will be placed directly in the chest block entity when spawned
		// We store the level in the item's custom data so the spawner knows what to fill
		var customTag = new CompoundTag();
			customTag.putInt("stash_level", level);
			chest.set(DataComponents.CUSTOM_DATA, net.minecraft.world.item.component.CustomData.of(customTag));
		return chest;
	}

	

	private static ItemStack enchantedBook(Registry<Enchantment> registry, ResourceKey<Enchantment> key, int level) {
		ItemStack book = new ItemStack(Items.ENCHANTED_BOOK);
		Holder<Enchantment> holder = registry.get(key).orElseThrow();
		var stored = new ItemEnchantments.Mutable(ItemEnchantments.EMPTY);
		stored.set(holder, level);
		book.set(DataComponents.STORED_ENCHANTMENTS, stored.toImmutable());
		return book;
	}

	static List<ItemStack> preEnchantedNetheriteArmor(Registry<Enchantment> registry) {
		List<ItemStack> result = new ArrayList<>();
		Item[] armor = {Items.NETHERITE_HELMET, Items.NETHERITE_CHESTPLATE, Items.NETHERITE_LEGGINGS, Items.NETHERITE_BOOTS};
		for (Item item : armor) {
			ItemStack stack = new ItemStack(item);
			var ench = new ItemEnchantments.Mutable(ItemEnchantments.EMPTY);
			ench.set(registry.get(Enchantments.PROTECTION).orElseThrow(), 4);
			ench.set(registry.get(Enchantments.UNBREAKING).orElseThrow(), 3);
			ench.set(registry.get(Enchantments.MENDING).orElseThrow(), 1);
			if (item == Items.NETHERITE_BOOTS) {
				ench.set(registry.get(Enchantments.FEATHER_FALLING).orElseThrow(), 4);
				ench.set(registry.get(Enchantments.DEPTH_STRIDER).orElseThrow(), 3);
			}
			stack.set(DataComponents.ENCHANTMENTS, ench.toImmutable());
			result.add(stack);
		}
		return result;
	}

	static List<ItemStack> preEnchantedNetheriteTools(Registry<Enchantment> registry) {
		List<ItemStack> result = new ArrayList<>();
		Item[] tools = {Items.NETHERITE_SWORD, Items.NETHERITE_PICKAXE, Items.NETHERITE_AXE, Items.NETHERITE_SHOVEL};
		for (Item item : tools) {
			ItemStack stack = new ItemStack(item);
			var ench = new ItemEnchantments.Mutable(ItemEnchantments.EMPTY);
			if (item == Items.NETHERITE_SWORD) {
				ench.set(registry.get(Enchantments.SHARPNESS).orElseThrow(), 5);
				ench.set(registry.get(Enchantments.LOOTING).orElseThrow(), 3);
				ench.set(registry.get(Enchantments.FIRE_ASPECT).orElseThrow(), 2);
			} else if (item == Items.NETHERITE_PICKAXE) {
				ench.set(registry.get(Enchantments.EFFICIENCY).orElseThrow(), 5);
				ench.set(registry.get(Enchantments.FORTUNE).orElseThrow(), 3);
				ench.set(registry.get(Enchantments.UNBREAKING).orElseThrow(), 3);
			} else if (item == Items.NETHERITE_AXE) {
				ench.set(registry.get(Enchantments.SHARPNESS).orElseThrow(), 5);
				ench.set(registry.get(Enchantments.EFFICIENCY).orElseThrow(), 5);
			} else {
				ench.set(registry.get(Enchantments.EFFICIENCY).orElseThrow(), 5);
				ench.set(registry.get(Enchantments.FORTUNE).orElseThrow(), 3);
			}
			ench.set(registry.get(Enchantments.MENDING).orElseThrow(), 1);
			ench.set(registry.get(Enchantments.UNBREAKING).orElseThrow(), 3);
			stack.set(DataComponents.ENCHANTMENTS, ench.toImmutable());
			result.add(stack);
		}
		return result;
	}

	private static ItemStack customEnchantedGear(CustomEnchants.Type type, int level, Registry<Enchantment> registry) {
		Item baseItem = switch (type) {
			case SMELTER -> Items.DIAMOND_PICKAXE;
			case TELEKINESIS -> Items.DIAMOND_SHOVEL;
			case LUCKY -> Items.DIAMOND_SWORD;
			case HASTE -> Items.DIAMOND_SWORD;
			case AUTO_REPAIR -> Items.DIAMOND_PICKAXE;
			case NIGHT_VISION -> Items.DIAMOND_SWORD;
		};
		ItemStack stack = new ItemStack(baseItem);
		stack.set(DataComponents.CUSTOM_NAME, Component.literal(type.displayName() + " " + CustomEnchants.roman(level)).withStyle(type.colour()));
		CustomEnchants.apply(stack, type, level);
		// Also add vanilla enchants
		var ench = new ItemEnchantments.Mutable(ItemEnchantments.EMPTY);
		if (baseItem == Items.DIAMOND_PICKAXE || baseItem == Items.DIAMOND_SHOVEL) {
			ench.set(registry.get(Enchantments.EFFICIENCY).orElseThrow(), 5);
			ench.set(registry.get(Enchantments.UNBREAKING).orElseThrow(), 3);
			ench.set(registry.get(Enchantments.FORTUNE).orElseThrow(), 3);
		} else if (baseItem == Items.DIAMOND_SWORD) {
			ench.set(registry.get(Enchantments.SHARPNESS).orElseThrow(), 5);
			ench.set(registry.get(Enchantments.LOOTING).orElseThrow(), 3);
			ench.set(registry.get(Enchantments.UNBREAKING).orElseThrow(), 3);
		}
		ench.set(registry.get(Enchantments.MENDING).orElseThrow(), 1);
		stack.set(DataComponents.ENCHANTMENTS, ench.toImmutable());
		return stack;
	}

	/**
	 * Opens the buy GUI pre-filtered to the given search query.
	 * This is used by the chat-capture flow when the player clicks Search.
	 */
	static void openBuyGuiWithSearch(ServerPlayer player, String query) {
		MarketData.initialize(player.level().registryAccess());
		ShopValues.initialize(player.level().registryAccess());
		List<ShopValues.Entry> results = ShopSearch.search(query);
		player.openMenu(new SimpleMenuProvider(
			(containerId, inventory, viewer) -> new BuyMenu(containerId, inventory, player, query, results),
			Component.literal("Search: " + query)
		));
	}

	/**
	 * Opens the sell GUI pre-filtered to the given search query. Used when the
	 * chat capture was started from the sell GUI, so a search there keeps you in
	 * the sell shop instead of dropping you into the buy shop.
	 */
	static void openSellGuiWithSearch(ServerPlayer player, String query) {
		MarketData.initialize(player.level().registryAccess());
		ShopValues.initialize(player.level().registryAccess());
		List<ShopValues.Entry> results = ShopSearch.search(query);
		player.openMenu(new SimpleMenuProvider(
			(containerId, inventory, viewer) -> new SellMenu(containerId, inventory, player, query, results),
			Component.literal("Search: " + query)
		));
	}

	/**
	 * Opens the anvil-style search box. {@code fromSell} decides which shop the
	 * results reopen once the player confirms a query.
	 */
	static void openSearchPopup(ServerPlayer player, boolean fromSell, String initial) {
		MarketData.initialize(player.level().registryAccess());
		ShopValues.initialize(player.level().registryAccess());
		player.openMenu(new SimpleMenuProvider(
			(containerId, inventory, viewer) -> new SearchInputMenu(containerId, inventory, player, fromSell, initial),
			Component.literal("Search the shop")
		));
	}

	/** A break whose drop-based effects have not run yet. */
	private record PendingBreak(ServerPlayer player, BlockPos pos, int smelter, int lucky,
		int telekinesis, ItemStack fallback) {
	}

	private static final List<PendingBreak> PENDING_BREAKS = new ArrayList<>();

	/**
	 * Drops an enchant has already acted on. The freshness window below is a few
	 * ticks wide, so a second break a block away would otherwise cook the same
	 * stack twice - cobblestone becoming smooth stone instead of stone.
	 */
	private static final Set<ItemEntity> TOUCHED_DROPS = new HashSet<>();

	/**
	 * Applies all active custom enchant effects when a player breaks a block.
	 * Handles: Smelter, Auto-Repair, Telekinesis, Lucky.
	 *
	 * <p>Auto-Repair mends the tool immediately, but the other three act on the
	 * block's drops, and vanilla only spawns those part-way through the break -
	 * after {@link PlayerBlockBreakEvents#AFTER} has fired. They are queued here
	 * and run at the end of the tick instead, which is why they used to look
	 * like they did nothing.
	 */
	private static void applyCustomEnchantEffects(ServerPlayer player, ServerLevel level, BlockPos pos, BlockState state, ItemStack tool) {
		if (tool == null || tool.isEmpty()) return;
		// custom_enchants.enabled: false turns every effect off server-wide.
		if (!CustomEnchants.enabled()) return;

		// Auto-Repair - mends the tool
		int autoRepair = CustomEnchants.levelOf(tool, CustomEnchants.Type.AUTO_REPAIR);
		if (autoRepair > 0) tryRepairTool(tool, autoRepair, player.getRandom());

		// Creative breaks and worlds with block drops turned off leave nothing
		// on the ground, and Lucky must not hand out drops the world refused.
		if (player.preventsBlockDrops()
			|| !level.getGameRules().get(net.minecraft.world.level.gamerules.GameRules.BLOCK_DROPS)) {
			return;
		}

		int smelter = CustomEnchants.levelOf(tool, CustomEnchants.Type.SMELTER);
		int lucky = CustomEnchants.levelOf(tool, CustomEnchants.Type.LUCKY);
		int telekinesis = CustomEnchants.levelOf(tool, CustomEnchants.Type.TELEKINESIS);
		if (smelter > 0 || lucky > 0 || telekinesis > 0) {
			PENDING_BREAKS.add(new PendingBreak(player, pos, smelter, lucky, telekinesis,
				state.getBlock().asItem().getDefaultInstance()));
		}
	}

	/** Runs the queued drop effects now that the drops are in the world. */
	private static void processPendingBreaks(MinecraftServer server) {
		if (PENDING_BREAKS.isEmpty()) return;
		List<PendingBreak> batch = new ArrayList<>(PENDING_BREAKS);
		PENDING_BREAKS.clear();
		// Forget drops that have been picked up, merged away or despawned.
		TOUCHED_DROPS.removeIf(entity -> !entity.isAlive() || entity.getAge() > 100);

		for (PendingBreak pending : batch) {
			if (server.getPlayerList().getPlayer(pending.player().getUUID()) == null) {
				// Signed out between the break and this tick; let the drops lie.
				continue;
			}
			processBreak(pending, server);
		}
	}

	private static void processBreak(PendingBreak pending, MinecraftServer server) {
		ServerLevel level = (ServerLevel) pending.player().level();
		BlockPos pos = pending.pos();

		// Smelter first, so Lucky copies an already-cooked drop and Telekinesis
		// vacuums whatever is left.
		List<ItemEntity> drops = freshDrops(level, pos);
		if (pending.smelter() > 0) {
			smeltDrops(server, level, drops, pending.smelter());
		}
		ItemEntity bonus = null;
		if (pending.lucky() > 0) {
			bonus = maybeExtraDrops(level, pos, drops, pending.fallback(), pending.lucky(), level.getRandom());
		}
		if (pending.telekinesis() > 0) {
			// Re-read the ground: Lucky may just have added one more stack.
			vacuumDrops(pending.player(), freshDrops(level, pos));
		}
		TOUCHED_DROPS.addAll(drops);
		if (bonus != null) {
			TOUCHED_DROPS.add(bonus);
		}
	}

	/**
	 * The item entities a single break produced. Vanilla gives every drop a
	 * ten-tick pickup delay, so freshness is judged by age alone - filtering on
	 * the delay was what stopped these enchants from ever seeing a drop.
	 */
	private static List<ItemEntity> freshDrops(ServerLevel level, BlockPos pos) {
		List<ItemEntity> drops = new ArrayList<>();
		for (ItemEntity entity : level.getEntitiesOfClass(ItemEntity.class,
			new net.minecraft.world.phys.AABB(pos).inflate(2.5),
			fresh -> fresh.getAge() < 5 && !TOUCHED_DROPS.contains(fresh))) {
			drops.add(entity);
		}
		return drops;
	}

	/**
	 * Inputs the Smelter leaves alone. The furnace's recipe list includes
	 * logs -&gt; charcoal and leaves -&gt; leaf litter, and quietly turning a
	 * player's whole tree into charcoal would be a nasty surprise on a tool
	 * that is meant to cook ores and stones.
	 */
	private static final List<net.minecraft.tags.TagKey<Item>> SMELTER_PASSES = List.of(
		net.minecraft.tags.TagKey.create(Registries.ITEM, Identifier.withDefaultNamespace("logs")),
		net.minecraft.tags.TagKey.create(Registries.ITEM, Identifier.withDefaultNamespace("leaves")));

	/**
	 * Cooks every drop on the spot, using the furnace's own recipes so ores,
	 * stones, deepslate and anything else with a smelting recipe - including
	 * ones a data pack adds - is covered rather than a hand-written list.
	 * II has a 20% chance and III a 50% chance to double the result.
	 */
	private static void smeltDrops(MinecraftServer server, ServerLevel level, List<ItemEntity> drops, int smelterLevel) {
		double bonus = switch (smelterLevel) {
			case 2 -> 0.2;
			case 3 -> 0.5;
			default -> 0.0;
		};
		for (ItemEntity entity : drops) {
			ItemStack stack = entity.getItem();
			if (stack.isEmpty()) continue;
			if (passesThrough(stack)) continue;

			SingleRecipeInput input = new SingleRecipeInput(stack);
			ItemStack result = server.getRecipeManager()
				.getRecipeFor(RecipeType.SMELTING, input, level)
				.map(holder -> holder.value().assemble(input))
				.orElse(ItemStack.EMPTY);
			if (result.isEmpty()) continue;

			int count = stack.getCount();
			if (bonus > 0 && level.getRandom().nextDouble() < bonus) {
				count *= 2;
			}
			result.setCount(Math.min(result.getMaxStackSize(), count));
			entity.setItem(result);
		}
	}

	/** Wood and leaves ride through the Smelter untouched. */
	private static boolean passesThrough(ItemStack stack) {
		for (net.minecraft.tags.TagKey<Item> tag : SMELTER_PASSES) {
			if (stack.typeHolder().is(tag)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Gives the tool a chance to repair itself - the "self mending" enchant,
	 * and it does so without any experience, unlike vanilla Mending.
	 *
	 * <p>The amount mended rises with the level, not just the odds, so a III
	 * tool visibly climbs back to full as you mine rather than ticking up one
	 * point at a time. Chance is I 25%, II 50%, III 75%; points are I 1, II 2,
	 * III 3 per proc.
	 */
	private static void tryRepairTool(ItemStack tool, int level, net.minecraft.util.RandomSource random) {
		int damage = tool.getDamageValue();
		if (damage <= 0) return;
		double chance = level * 0.25;
		if (random.nextDouble() < chance) {
			tool.setDamageValue(Math.max(0, damage - Math.max(1, level)));
		}
	}

	/** Vacuums the fresh drops straight into the player's inventory. */
	private static void vacuumDrops(ServerPlayer player, List<ItemEntity> drops) {
		for (ItemEntity entity : drops) {
			ItemStack stack = entity.getItem();
			if (stack.isEmpty()) continue;
			ItemStack remainder = stack.copy();
			Compat.placeBack(player.getInventory(), remainder);
			if (remainder.isEmpty()) {
				entity.discard();
			} else {
				entity.setItem(remainder);
			}
		}
	}

	/**
	 * Rolls for one extra drop, copied from something the block actually
	 * dropped so an ore vein hands back an extra ore rather than an ore block.
	 *
	 * @return the spawned entity, or null when nothing extra dropped
	 */
	private static ItemEntity maybeExtraDrops(ServerLevel level, BlockPos pos, List<ItemEntity> drops,
		ItemStack fallback, int luckyLevel, net.minecraft.util.RandomSource random) {
		// I: 10%, II: 25%, III: 50%
		double chance = switch (luckyLevel) {
			case 1 -> 0.1;
			case 2 -> 0.25;
			default -> 0.5;
		};
		if (random.nextDouble() >= chance) return null;

		ItemStack bonus = ItemStack.EMPTY;
		if (!drops.isEmpty()) {
			bonus = drops.get(random.nextInt(drops.size())).getItem().copy();
			bonus.setCount(1);
		}
		if (bonus.isEmpty()) bonus = fallback.copy();
		if (bonus.isEmpty()) return null;

		ItemEntity extra = new ItemEntity(level, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, bonus);
		level.addFreshEntity(extra);
		return extra;
	}

    private static void applyHeldEnchantEffects(ServerPlayer player) {
		// The same switch as the block-break effects: one key turns all of
		// them off, so a server can be run without the custom enchants.
		if (!CustomEnchants.enabled()) return;

		ItemStack main = player.getMainHandItem();
		ItemStack off = player.getOffhandItem();

		// Haste - whichever hand holds the better copy of it
		int haste = Math.max(CustomEnchants.levelOf(main, CustomEnchants.Type.HASTE),
			CustomEnchants.levelOf(off, CustomEnchants.Type.HASTE));
		if (haste > 0) {
			player.addEffect(new net.minecraft.world.effect.MobEffectInstance(
				net.minecraft.world.effect.MobEffects.HASTE, 40, haste - 1, true, false));
		}

		// Night Vision - applies while holding in either hand
		int nightVision = CustomEnchants.levelOf(main, CustomEnchants.Type.NIGHT_VISION);
		if (nightVision == 0) nightVision = CustomEnchants.levelOf(off, CustomEnchants.Type.NIGHT_VISION);
		if (nightVision > 0) {
			player.addEffect(new net.minecraft.world.effect.MobEffectInstance(
				net.minecraft.world.effect.MobEffects.NIGHT_VISION, 40, 0, true, false));
		}

		// Auto-Repair - a slow top-up between swings, and the only way a piece
		// of armour with this enchant ever mends, since armour never breaks a
		// block.
		for (EquipmentSlot slot : EquipmentSlot.values()) {
			ItemStack worn = player.getItemBySlot(slot);
			int autoRepair = CustomEnchants.levelOf(worn, CustomEnchants.Type.AUTO_REPAIR);
			if (autoRepair > 0) {
				tryRepairTool(worn, autoRepair, player.getRandom());
			}
		}
	}

	private static int openAuctionGui(ServerPlayer player) {
		if (!AccountAuth.isAuthenticated(player.getUUID())) {
			player.sendSystemMessage(Component.literal("Register or log in before using the auction house."));
			return 0;
		}
		MarketData.initialize(player.level().registryAccess());
		player.openMenu(new SimpleMenuProvider(
			(containerId, inventory, viewer) -> new AuctionMenu(containerId, inventory, player),
			Component.literal("Auction House")
		));
		return 1;
	}

	private static int showAuctions(ServerPlayer player) {
		if (!AccountAuth.isAuthenticated(player.getUUID())) {
			player.sendSystemMessage(Component.literal("Register or log in before using the auction house."));
			return 0;
		}
		MarketData.initialize(player.level().registryAccess());
		Map<Integer, MarketData.AuctionListing> auctions = MarketData.auctions();
		if (auctions.isEmpty()) {
			player.sendSystemMessage(Component.literal("The auction house is empty. List an item with /ah sell <price>."));
			return 1;
		}
		player.sendSystemMessage(Component.literal("Auction house — buy with /ah buy <id>:"));
		auctions.keySet().stream().sorted().forEach(id -> {
			MarketData.AuctionListing listing = auctions.get(id);
			player.sendSystemMessage(Component.literal("#" + id + " " + listing.stack().getHoverName().getString()
				+ " x" + listing.stack().getCount() + " — $" + formatAmount(listing.price())));
		});
		return 1;
	}

	private static int listAuction(ServerPlayer seller, String rawPrice) {
		if (!AccountAuth.isAuthenticated(seller.getUUID())) {
			seller.sendSystemMessage(Component.literal("Register or log in before using the auction house."));
			return 0;
		}
		long price;
		try {
			price = Long.parseLong(rawPrice);
		} catch (NumberFormatException exception) {
			seller.sendSystemMessage(Component.literal("Enter a whole-number price."));
			return 0;
		}
		if (price <= 0 || price > 1_000_000_000_000L) {
			seller.sendSystemMessage(Component.literal("Choose a price between $1 and $1,000,000,000,000."));
			return 0;
		}
		ItemStack held = seller.getMainHandItem();
		if (held.isEmpty()) {
			seller.sendSystemMessage(Component.literal("Hold the item you want to list."));
			return 0;
		}
		MarketData.initialize(seller.level().registryAccess());
		int count = held.getCount();
		int id = MarketData.createAuction(seller.getUUID(), held.copy(), price, seller.level().registryAccess());
		if (id == MarketData.ListResult.NO_SLOT) {
			seller.sendSystemMessage(Component.literal(
				"All " + MarketData.stallSlots(seller.getUUID()) + " of your stalls are in use."
					+ " Wait for a sale, or buy more stalls with /stall."));
			return 0;
		}
		if (id < 0) {
			seller.sendSystemMessage(Component.literal("Could not save the auction listing; your item was not taken."));
			return 0;
		}
		held.shrink(count);
		// A standing buy order may want exactly this: the sale completes on the
		// spot and the goods go to the buyer's mail if they are offline.
		int filled = MarketData.matchBuyOrder(id, seller.level().registryAccess());
		if (filled >= 0) {
			seller.sendSystemMessage(Component.literal(
				"Listed as auction #" + id + " and it sold instantly to buy order #" + filled
					+ " for $" + formatAmount(price) + " (you receive " + formatAmount(MarketData.auctionCut(price)) + ")."));
			return 1;
		}
		seller.sendSystemMessage(Component.literal(
			"Listed " + count + " item(s) as auction #" + id + " for $" + formatAmount(price)
				+ ". You will receive " + formatAmount(MarketData.auctionCut(price))
				+ " after the house cut; it expires in " + hoursText(MarketData.auctionMillis()) + "."));
		return 1;
	}

	/** "48h" from a millisecond span, rounding down to whole hours. */
	private static String hoursText(long millis) {
		long hours = Math.max(1, millis / 3_600_000L);
		return hours + "h";
	}

	// ---- Auction buy orders -------------------------------------------------

	/**
	 * Places a standing buy order. With no price given the player is asked to
	 * name one; with {@code maxTotal} as -1 the current shop price of the item
	 * is used as a sensible default so the command is usable without doing
	 * arithmetic in one's head.
	 */
	private static int buyOrderCommand(ServerPlayer buyer, String rawItem, int count, String rawMaxTotal) {
		if (!AccountAuth.isAuthenticated(buyer.getUUID())) {
			buyer.sendSystemMessage(Component.literal("Register or log in before using the auction house."));
			return 0;
		}
		MarketData.initialize(buyer.level().registryAccess());
		ShopValues.initialize(buyer.level().registryAccess());
		ShopValues.Entry entry = ShopSearch.search(rawItem, 1).stream().findFirst().orElse(null);
		if (entry == null) {
			buyer.sendSystemMessage(Component.literal("The shop does not know an item called \"" + rawItem + "\"."));
			return 0;
		}
		long maxTotal;
		if (rawMaxTotal == null || rawMaxTotal.equals("-1")) {
			// Fall back to what the shop itself charges for this many, so the
			// order is at least competitive without the player guessing.
			long unit = ShopValues.shopPrice(entry);
			maxTotal = unit <= 0 ? 0 : Math.max(1L, unit * count);
		} else {
			try {
				maxTotal = Long.parseLong(rawMaxTotal);
			} catch (NumberFormatException exception) {
				buyer.sendSystemMessage(Component.literal("Enter a whole-number total price."));
				return 0;
			}
		}
		if (maxTotal <= 0) {
			buyer.sendSystemMessage(Component.literal("Choose a positive total price."));
			return 0;
		}
		int id = MarketData.createBuyOrder(buyer.getUUID(), entry.item(), count, maxTotal,
			buyer.level().registryAccess());
		if (id == MarketData.OrderResult.INSUFFICIENT_FUNDS) {
			buyer.sendSystemMessage(Component.literal(
				"That order's ceiling is $" + formatAmount(maxTotal)
					+ " and you only have $" + formatAmount(MarketData.balance(buyer.getUUID()))
					+ ". The ceiling is held until the order is filled or cancelled."));
			return 0;
		}
		if (id < 0) {
			buyer.sendSystemMessage(Component.literal("Could not save the buy order."));
			return 0;
		}
		buyer.sendSystemMessage(Component.literal(
			"Order #" + id + ": up to " + count + "x " + ShopValues.displayName(entry.item())
				+ " for $" + formatAmount(maxTotal) + " total. It fills the moment somebody lists that."));
		return 1;
	}

	private static int listBuyOrders(ServerPlayer player) {
		MarketData.initialize(player.level().registryAccess());
		ShopValues.initialize(player.level().registryAccess());
		List<Map.Entry<Integer, MarketData.BuyOrder>> orders = MarketData.buyOrders();
		if (orders.isEmpty()) {
			player.sendSystemMessage(Component.literal("There are no open buy orders."));
			return 1;
		}
		player.sendSystemMessage(Component.literal("Open buy orders:"));
		for (Map.Entry<Integer, MarketData.BuyOrder> order : orders) {
			MarketData.BuyOrder value = order.getValue();
			String owner = PlayerStats.nameOf(value.buyerId());
			String marker = value.buyerId().equals(player.getUUID()) ? " (yours)" : "";
			player.sendSystemMessage(Component.literal(
				"#" + order.getKey() + " " + (owner == null || owner.isBlank() ? "?" : owner)
					+ marker + " wants " + value.count() + "x "
					+ ShopValues.displayName(value.item()) + " up to $"
					+ formatAmount(value.maxTotal())));
		}
		return 1;
	}

	private static int cancelBuyOrderCommand(ServerPlayer player, int orderId) {
		if (!AccountAuth.isAuthenticated(player.getUUID())) {
			player.sendSystemMessage(Component.literal("Register or log in before using the auction house."));
			return 0;
		}
		MarketData.initialize(player.level().registryAccess());
		if (!MarketData.cancelBuyOrder(player.getUUID(), orderId, player.level().registryAccess())) {
			player.sendSystemMessage(Component.literal("That buy order does not exist, or it is not yours."));
			return 0;
		}
		player.sendSystemMessage(Component.literal("Cancelled buy order #" + orderId + "; the escrow was refunded."));
		return 1;
	}

	// ---- Mail ---------------------------------------------------------------

	private static int showMail(ServerPlayer player) {
		if (!AccountAuth.isAuthenticated(player.getUUID())) {
			player.sendSystemMessage(Component.literal("Register or log in before using the economy."));
			return 0;
		}
		MarketData.initialize(player.level().registryAccess());
		List<MarketData.MailItem> items = MarketData.mailOf(player.getUUID());
		if (items.isEmpty()) {
			player.sendSystemMessage(Component.literal("Your mail is empty."));
			return 1;
		}
		player.sendSystemMessage(Component.literal("Your mail (" + items.size() + "):"));
		for (int index = 0; index < items.size(); index++) {
			MarketData.MailItem item = items.get(index);
			player.sendSystemMessage(Component.literal(
				(index + 1) + ". " + item.stack().getCount() + "x "
					+ item.stack().getHoverName().getString()
					+ (item.from().isBlank() ? "" : " - " + item.from())));
		}
		player.sendSystemMessage(Component.literal("Use /mail claim <n> to take one, or /mail claim to take the oldest."));
		return 1;
	}

	private static int claimMail(ServerPlayer player, int index) {
		if (!AccountAuth.isAuthenticated(player.getUUID())) {
			player.sendSystemMessage(Component.literal("Register or log in before using the economy."));
			return 0;
		}
		MarketData.initialize(player.level().registryAccess());
		List<MarketData.MailItem> items = MarketData.mailOf(player.getUUID());
		if (items.isEmpty()) {
			player.sendSystemMessage(Component.literal("Your mail is empty."));
			return 0;
		}
		if (index < 0) {
			index = 0; // /mail claim with no number takes the oldest
		}
		if (index >= items.size()) {
			player.sendSystemMessage(Component.literal("You only have " + items.size() + " piece(s) of mail."));
			return 0;
		}
		ItemStack stack = MarketData.claimMail(player.getUUID(), index, player.level().registryAccess());
		if (stack.isEmpty()) {
			player.sendSystemMessage(Component.literal("That piece of mail is no longer there."));
			return 0;
		}
		Compat.placeBack(player.getInventory(), stack);
		player.sendSystemMessage(Component.literal(
			"Claimed " + stack.getCount() + "x " + stack.getHoverName().getString() + "."));
		return 1;
	}

	private static int clearMail(ServerPlayer player) {
		MarketData.initialize(player.level().registryAccess());
		int before = MarketData.mailOf(player.getUUID()).size();
		for (int index = before - 1; index >= 0; index--) {
			MarketData.claimMail(player.getUUID(), index, player.level().registryAccess());
		}
		player.sendSystemMessage(Component.literal(
			before == 0 ? "Your mail was already empty." : "Cleared " + before + " piece(s) of mail."));
		return 1;
	}

	// ---- Stalls -------------------------------------------------------------

	private static int showStalls(ServerPlayer player) {
		MarketData.initialize(player.level().registryAccess());
		int slots = MarketData.stallSlots(player.getUUID());
		int used = MarketData.activeListings(player.getUUID());
		player.sendSystemMessage(Component.literal(
			"You have " + used + "/" + slots + " auction stalls in use."));
		if (slots < MarketData.MAX_STALL_SLOTS) {
			player.sendSystemMessage(Component.literal(
				"Next upgrade: " + MarketData.SLOTS_PER_STALL + " more slots for $"
					+ formatAmount(MarketData.stallPrice(player.getUUID()))
					+ " (/stall buy)."));
		} else {
			player.sendSystemMessage(Component.literal("You already own the maximum number of stalls."));
		}
		return 1;
	}

	private static int buyStall(ServerPlayer player) {
		if (!AccountAuth.isAuthenticated(player.getUUID())) {
			player.sendSystemMessage(Component.literal("Register or log in before using the economy."));
			return 0;
		}
		MarketData.initialize(player.level().registryAccess());
		if (MarketData.stallSlots(player.getUUID()) >= MarketData.MAX_STALL_SLOTS) {
			player.sendSystemMessage(Component.literal("You already own the maximum number of stalls."));
			return 0;
		}
		long price = MarketData.stallPrice(player.getUUID());
		if (!MarketData.buyStallSlots(player.getUUID(), price, player.level().registryAccess())) {
			player.sendSystemMessage(Component.literal(
				"That costs $" + formatAmount(price) + " and you have $"
					+ formatAmount(MarketData.balance(player.getUUID())) + "."));
			return 0;
		}
		player.sendSystemMessage(Component.literal(
			"Bought more stall space: you now have " + MarketData.stallSlots(player.getUUID()) + " slots."));
		return 1;
	}

	// ---- Shard <-> money conversion ----------------------------------------

	private static int showConvert(ServerPlayer player, String ignored) {
		long rate = Math.max(1L, Config.getLong("economy.shard_money_rate"));
		player.sendSystemMessage(Component.literal(
			"Shard conversion: 1 shard = $" + formatAmount(rate) + " (deliberately a bad rate -"
				+ " it exists so idle shards can be turned into cash, not as an income."));
		player.sendSystemMessage(Component.literal(
			"Use /convert <shards> to sell shards for money."));
		return 1;
	}

	private static int convertShards(ServerPlayer player, String rawAmount) {
		if (!AccountAuth.isAuthenticated(player.getUUID())) {
			player.sendSystemMessage(Component.literal("Register or log in before using the economy."));
			return 0;
		}
		long shards;
		try {
			shards = Long.parseLong(rawAmount);
		} catch (NumberFormatException exception) {
			player.sendSystemMessage(Component.literal("Enter a whole-number shard amount."));
			return 0;
		}
		if (shards <= 0) {
			player.sendSystemMessage(Component.literal("Convert a positive number of shards."));
			return 0;
		}
		MarketData.initialize(player.level().registryAccess());
		long rate = Math.max(1L, Config.getLong("economy.shard_money_rate"));
		long money;
		try {
			money = Math.multiplyExact(shards, rate);
		} catch (ArithmeticException exception) {
			player.sendSystemMessage(Component.literal("That is more shards than the economy can convert."));
			return 0;
		}
		// Charge the shards first; only once they are gone is money minted, so
		// a failure can never leave both balances up.
		String error = Shards.buy(player.getUUID(), shards);
		if (error != null) {
			player.sendSystemMessage(Component.literal(error));
			return 0;
		}
		if (!MarketData.credit(player.getUUID(), money, player.level().registryAccess())) {
			Shards.adminGive(player.getUUID(), shards); // hand the shards back
			player.sendSystemMessage(Component.literal("Your balance could not be updated; no shards were spent."));
			return 0;
		}
		Ledger.record(player.getUUID(), money, "convert", shards + " shard(s) at " + rate);
		player.sendSystemMessage(Component.literal(
			"Converted " + formatAmount(shards) + " shard(s) into $" + formatAmount(money) + "."));
		return 1;
	}

	// ---- Lottery ------------------------------------------------------------

	private static int showLottery(ServerPlayer player) {
		if (!Config.getBoolean("economy.lottery_enabled")) {
			player.sendSystemMessage(Component.literal("The lottery is disabled on this server."));
			return 0;
		}
		MarketData.initialize(player.level().registryAccess());
		long pot = Lottery.pot();
		int tickets = Lottery.totalTickets();
		long price = Lottery.ticketPrice();
		player.sendSystemMessage(Component.literal("§6§lLottery"));
		player.sendSystemMessage(Component.literal(
			"§7Pot: §f$" + formatAmount(pot) + " §7from " + tickets + " ticket(s)."));
		player.sendSystemMessage(Component.literal(
			"§7A ticket costs §f$" + formatAmount(price) + " §7and draws every "
				+ Lottery.drawMinutes() + " minutes."));
		player.sendSystemMessage(Component.literal(
			"§7Your tickets this round: §f" + Lottery.ticketsOf(player.getUUID())));
		player.sendSystemMessage(Component.literal(
			"§7The house burns " + Lottery.HOUSE_CUT_PERCENT + "% on each draw."));
		player.sendSystemMessage(Component.literal("§e/lottery buy <n> §7to enter."));
		for (String line : Lottery.history()) {
			player.sendSystemMessage(Component.literal("§8 - §7" + line));
		}
		return 1;
	}

	private static int buyLotteryTickets(ServerPlayer player, int tickets) {
		if (!Config.getBoolean("economy.lottery_enabled")) {
			player.sendSystemMessage(Component.literal("The lottery is disabled on this server."));
			return 0;
		}
		if (!AccountAuth.isAuthenticated(player.getUUID())) {
			player.sendSystemMessage(Component.literal("Register or log in before using the economy."));
			return 0;
		}
		MarketData.initialize(player.level().registryAccess());
		String error = Lottery.buy(player, tickets, Lottery.ticketPrice(), player.level().registryAccess());
		if (error != null) {
			player.sendSystemMessage(Component.literal(error));
			return 0;
		}
		player.sendSystemMessage(Component.literal(
			"Bought " + tickets + " lottery ticket(s). The pot is now $" + formatAmount(Lottery.pot())
				+ " and you hold " + Lottery.ticketsOf(player.getUUID()) + " ticket(s)."));
		return 1;
	}

	// ---- Quests and milestones ---------------------------------------------

	private static int showQuests(ServerPlayer player) {
		if (!Config.getBoolean("economy.quests_enabled")) {
			player.sendSystemMessage(Component.literal("Quests are disabled on this server."));
			return 0;
		}
		player.sendSystemMessage(Component.literal("§d§lQuests §7(reset on their own period)"));
		for (Quests.Period period : Quests.Period.values()) {
			player.sendSystemMessage(Component.literal(
				period == Quests.Period.DAILY ? "§eDaily:" : "§bWeekly:"));
			for (Quests.Quest quest : Quests.questsOf(period)) {
				long progress = Quests.progressOf(player.getUUID(), quest);
				boolean claimed = Quests.claimed(player.getUUID(), quest);
				String state = claimed ? "§a[claimed]"
					: progress >= quest.target() ? "§e[ready - /quests claim]"
						: "§7[" + formatAmount(progress) + "/" + formatAmount(quest.target()) + "]";
				player.sendSystemMessage(Component.literal(
					"§8 - §f" + quest.description() + " §7-> §d" + formatAmount(quest.shards())
						+ " shards " + state));
			}
		}
		player.sendSystemMessage(Component.literal("§e/quests claim <n> §7to collect a finished quest."));
		return 1;
	}

	// ---- Playtime milestones ------------------------------------------------

	private static int showMilestones(ServerPlayer player) {
		if (!Config.getBoolean("economy.milestones_enabled")) {
			player.sendSystemMessage(Component.literal("Milestones are disabled on this server."));
			return 0;
		}
		long hours = Milestones.hoursPlayed(player.getUUID());
		player.sendSystemMessage(Component.literal(
			"§d§lPlaytime milestones §7- you have played " + hours + "h"));
		for (Milestones.Milestone milestone : Milestones.LADDER) {
			boolean claimed = Milestones.claimed(player.getUUID(), milestone);
			boolean ready = Milestones.claimable(player.getUUID(), milestone);
			String state = claimed ? "§a[claimed]"
				: ready ? "§e[ready - /milestones claim]" : "§7[not reached]";
			player.sendSystemMessage(Component.literal(
				"§8 - §f" + milestone.label() + " §7(" + milestone.hours() + "h) §7-> §d"
					+ formatAmount(milestone.shards()) + " shards " + state));
		}
		player.sendSystemMessage(Component.literal("§e/milestones claim <n> §7to collect a reached milestone."));
		return 1;
	}

	/**
	 * Claims a finished daily or weekly quest. The index is the 1-based number
	 * the player sees in /quests for that period, so the same number always
	 * means the same quest until the period rolls over.
	 */
	private static int claimQuest(ServerPlayer player, int index) {
		if (!Config.getBoolean("economy.quests_enabled")) {
			player.sendSystemMessage(Component.literal("Quests are disabled on this server."));
			return 0;
		}
		// Present every quest in the same order /quests showed them, daily
		// block first, so the number the player picked maps to one quest.
		List<Quests.Quest> ordered = new ArrayList<>();
		ordered.addAll(Quests.questsOf(Quests.Period.DAILY));
		ordered.addAll(Quests.questsOf(Quests.Period.WEEKLY));
		if (index < 1 || index > ordered.size()) {
			player.sendSystemMessage(Component.literal("That quest number does not exist; see /quests."));
			return 0;
		}
		Quests.Quest quest = ordered.get(index - 1);
		String error = Quests.claim(player.getUUID(), quest);
		if (error != null) {
			player.sendSystemMessage(Component.literal(error));
			return 0;
		}
		player.sendSystemMessage(Component.literal(
			"§aClaimed \"" + quest.description() + "\" for " + formatAmount(quest.shards()) + " shards."));
		return 1;
	}

	private static int claimMilestone(ServerPlayer player, int index) {
		if (!Config.getBoolean("economy.milestones_enabled")) {
			player.sendSystemMessage(Component.literal("Milestones are disabled on this server."));
			return 0;
		}
		if (index < 1 || index > Milestones.LADDER.size()) {
			player.sendSystemMessage(Component.literal("That milestone number does not exist; see /milestones."));
			return 0;
		}
		Milestones.Milestone milestone = Milestones.LADDER.get(index - 1);
		String error = Milestones.claim(player.getUUID(), milestone);
		if (error != null) {
			player.sendSystemMessage(Component.literal(error));
			return 0;
		}
		player.sendSystemMessage(Component.literal(
			"§aClaimed the " + milestone.label() + " milestone for "
				+ formatAmount(milestone.shards()) + " shards."));
		return 1;
	}

	// ---- Crate keys ---------------------------------------------------------

	/** Redeems a held crate key. A no-op message when the hand is empty. */
	private static int openKey(ServerPlayer player) {
		if (!Config.getBoolean("economy.crate_keys_enabled")) {
			player.sendSystemMessage(Component.literal("Crate keys are disabled on this server."));
			return 0;
		}
		ItemStack held = player.getMainHandItem();
		if (held.isEmpty()) {
			player.sendSystemMessage(Component.literal("Hold a crate key and use /key, or just right-click it."));
			return 0;
		}
		String result = CrateKeys.open(player, held);
		if (result == null) {
			player.sendSystemMessage(Component.literal("That is not a crate key."));
			return 0;
		}
		player.sendSystemMessage(Component.literal("§d§l" + result));
		return 1;
	}

	// ---- Shard boosts -------------------------------------------------------

	private static int showBoost(ServerPlayer player) {
		if (!Config.getBoolean("economy.shard_boosts_enabled")) {
			player.sendSystemMessage(Component.literal("Shard boosts are disabled on this server."));
			return 0;
		}
		long left = ShardBoosts.secondsLeft(player.getUUID());
		player.sendSystemMessage(Component.literal("§d§lShard Boost"));
		player.sendSystemMessage(Component.literal(
			"§7Cost: §d" + formatAmount(ShardBoosts.BOOST_PRICE) + " shards §7for "
				+ ShardBoosts.BOOST_MINUTES + " minutes at §dx" + ShardBoosts.BOOST_MULTIPLIER + "§7."));
		if (left > 0) {
			player.sendSystemMessage(Component.literal(
				"§aActive §7- " + (left / 60) + "m " + (left % 60) + "s left."));
		} else {
			player.sendSystemMessage(Component.literal("§7Not active."));
		}
		player.sendSystemMessage(Component.literal("§e/boost buy §7to activate."));
		return 1;
	}

	private static int buyBoost(ServerPlayer player) {
		if (!Config.getBoolean("economy.shard_boosts_enabled")) {
			player.sendSystemMessage(Component.literal("Shard boosts are disabled on this server."));
			return 0;
		}
		String error = ShardBoosts.buy(player.getUUID(), player.level().registryAccess());
		if (error != null) {
			player.sendSystemMessage(Component.literal(error));
			return 0;
		}
		player.sendSystemMessage(Component.literal(
			"§aShard boost on: x" + ShardBoosts.BOOST_MULTIPLIER + " shards for "
				+ ShardBoosts.BOOST_MINUTES + " minutes."));
		return 1;
	}

	private static int buyAuction(ServerPlayer buyer, String rawId) {
		if (!AccountAuth.isAuthenticated(buyer.getUUID())) {
			buyer.sendSystemMessage(Component.literal("Register or log in before using the auction house."));
			return 0;
		}
		int id;
		try {
			id = Integer.parseInt(rawId);
		} catch (NumberFormatException exception) {
			buyer.sendSystemMessage(Component.literal("Enter a valid auction ID."));
			return 0;
		}
		MarketData.initialize(buyer.level().registryAccess());
		MarketData.PurchaseResult result = MarketData.purchase(buyer.getUUID(), id, buyer.level().registryAccess());
		if (result.status() != MarketData.BuyStatus.SUCCESS) {
			String message = switch (result.status()) {
				case NOT_FOUND -> "That auction does not exist.";
				case OWN_LISTING -> "You cannot buy your own listing.";
				case INSUFFICIENT_FUNDS -> "You do not have enough money.";
				case STORAGE_ERROR -> "Could not save the purchase; no money was charged.";
				case SUCCESS -> "Purchase complete.";
			};
			buyer.sendSystemMessage(Component.literal(message));
			return 0;
		}
		Compat.placeBack(buyer.getInventory(), result.stack());
		buyer.sendSystemMessage(Component.literal("Purchased auction #" + id + "."));
		return 1;
	}

	private static SimpleContainer createMenuContents() {
		SimpleContainer contents = new SimpleContainer(27);
		ItemStack pvpIcon = new ItemStack(Items.MACE);
		pvpIcon.set(DataComponents.CUSTOM_NAME, Component.literal("Chungy Kit"));
		contents.setItem(PVP_KIT_SLOT, pvpIcon);
		contents.setItem(KIT_SLOT, new ItemStack(Items.SMITHING_TABLE));
		ItemStack armorIcon = new ItemStack(Items.NETHERITE_CHESTPLATE);
		armorIcon.set(DataComponents.CUSTOM_NAME, Component.literal("Armor Kit"));
		contents.setItem(ARMOR_KIT_SLOT, armorIcon);
		ItemStack trapperIcon = new ItemStack(Items.ARMOR_STAND);
		trapperIcon.set(DataComponents.CUSTOM_NAME, Component.literal("Trapper Kit"));
		contents.setItem(TRAPPER_KIT_SLOT, trapperIcon);
		ItemStack maceIcon = new ItemStack(Items.MACE);
		maceIcon.set(DataComponents.CUSTOM_NAME, Component.literal("Mace & Wings Kit"));
		contents.setItem(MACE_KIT_SLOT, maceIcon);
		// The extra kits - named icons with a short lore list, so players can
		// tell what is inside before clicking.
		contents.setItem(TNT_CART_KIT_SLOT, kitIcon(Items.TNT_MINECART, "TNT Cart Kit",
			"§7Rails, TNT minecarts & raw boom.",
			"§7The PvP siege kit."));
		contents.setItem(ARCHER_KIT_SLOT, kitIcon(Items.BOW, "Archer Kit",
			"§7Enchanted bow & crossbow,",
			"§7arrows, gapples and mobility."));
		contents.setItem(CRYSTAL_KIT_SLOT, kitIcon(Items.END_CRYSTAL, "Crystal Kit",
			"§7End crystals, obsidian,",
			"§7totems and apples."));
		contents.setItem(MINER_KIT_SLOT, kitIcon(Items.NETHERITE_PICKAXE, "Miner Kit",
			"§7Fortune AND silk touch picks,",
			"§7tools, torches and a bucket."));
		contents.setItem(HEALING_KIT_SLOT, kitIcon(Items.GOLDEN_APPLE, "Healing Kit",
			"§7Gapples, egapples, totems,",
			"§7carrots and XP bottles."));
		return contents;
	}

	/** A named kit icon with lore lines explaining what the kit contains. */
	private static ItemStack kitIcon(Item item, String name, String... loreLines) {
		ItemStack icon = new ItemStack(item);
		icon.set(DataComponents.CUSTOM_NAME, Component.literal(name));
		List<Component> lore = new ArrayList<>();
		for (String line : loreLines) {
			lore.add(Component.literal(line));
		}
		icon.set(DataComponents.LORE, new ItemLore(lore));
		return icon;
	}

	private static SimpleContainer createAdminMenuContents() {
		SimpleContainer contents = new SimpleContainer(27);
		ItemStack opIcon = new ItemStack(Items.NETHERITE_SWORD);
		opIcon.set(DataComponents.CUSTOM_NAME, Component.literal("Admin Overkill Kit"));
		contents.setItem(ADMIN_OP_KIT_SLOT, opIcon);
		ItemStack suppliesIcon = new ItemStack(Items.BEACON);
		suppliesIcon.set(DataComponents.CUSTOM_NAME, Component.literal("Admin Supplies Kit"));
		contents.setItem(ADMIN_SUPPLIES_KIT_SLOT, suppliesIcon);
		return contents;
	}

	private static void givePvpKit(ServerPlayer player) {
		giveEnchantedItem(player, Items.MACE, Map.of(
			Enchantments.DENSITY, 5,
			Enchantments.WIND_BURST, 3,
			Enchantments.UNBREAKING, 3
		));
		giveEnchantedItem(player, Items.NETHERITE_SWORD, Map.of(
			Enchantments.SHARPNESS, 5,
			Enchantments.FIRE_ASPECT, 2,
			Enchantments.LOOTING, 3,
			Enchantments.SWEEPING_EDGE, 3,
			Enchantments.UNBREAKING, 3
		));
		giveEnchantedItem(player, Items.NETHERITE_AXE, Map.of(
			Enchantments.SHARPNESS, 5,
			Enchantments.UNBREAKING, 3,
			Enchantments.MENDING, 1
		));
		giveEnchantedItem(player, Items.BOW, Map.of(
			Enchantments.POWER, 5,
			Enchantments.FLAME, 1,
			Enchantments.PUNCH, 2,
			Enchantments.UNBREAKING, 3
		));
		giveEnchantedItem(player, Items.CROSSBOW, Map.of(
			Enchantments.QUICK_CHARGE, 3,
			Enchantments.MULTISHOT, 1,
			Enchantments.UNBREAKING, 3
		));
		giveEnchantedItem(player, Items.SHIELD, Map.of(
			Enchantments.UNBREAKING, 3,
			Enchantments.MENDING, 1
		));
		giveEnchantedItem(player, Items.NETHERITE_HELMET, Map.of(
			Enchantments.PROTECTION, 4,
			Enchantments.RESPIRATION, 3,
			Enchantments.AQUA_AFFINITY, 1,
			Enchantments.UNBREAKING, 3,
			Enchantments.MENDING, 1
		));
		giveEnchantedItem(player, Items.NETHERITE_CHESTPLATE, Map.of(
			Enchantments.PROTECTION, 4,
			Enchantments.THORNS, 3,
			Enchantments.UNBREAKING, 3,
			Enchantments.MENDING, 1
		));
		giveEnchantedItem(player, Items.NETHERITE_LEGGINGS, Map.of(
			Enchantments.PROTECTION, 4,
			Enchantments.THORNS, 3,
			Enchantments.UNBREAKING, 3,
			Enchantments.MENDING, 1
		));
		giveEnchantedItem(player, Items.NETHERITE_BOOTS, Map.of(
			Enchantments.PROTECTION, 4,
			Enchantments.FEATHER_FALLING, 4,
			Enchantments.DEPTH_STRIDER, 3,
			Enchantments.UNBREAKING, 3,
			Enchantments.MENDING, 1
		));
		giveItem(player, Items.TOTEM_OF_UNDYING, 1);
		giveItem(player, Items.ARROW, 64);
		giveItem(player, Items.GOLDEN_APPLE, 64);
		giveItem(player, Items.ENCHANTED_GOLDEN_APPLE, 16);
		giveItem(player, Items.ENDER_PEARL, 16);
		giveItem(player, Items.WIND_CHARGE, 64);
		giveItem(player, Items.OBSIDIAN, 64);
		giveItem(player, Items.END_CRYSTAL, 16);
		giveItem(player, Items.EXPERIENCE_BOTTLE, 64);
		giveItem(player, Items.WATER_BUCKET, 1);
		giveItem(player, Items.LAVA_BUCKET, 1);
	}

	private static void giveMaceKit(ServerPlayer player) {
		for (int i = 0; i < 4; i++) {
			giveEnchantedItem(player, Items.MACE, Map.of(
				Enchantments.DENSITY, 15,
				Enchantments.BREACH, 10,
				Enchantments.WIND_BURST, 10,
				Enchantments.UNBREAKING, 10,
				Enchantments.MENDING, 1
			));
		}
		giveEnchantedItem(player, Items.ELYTRA, Map.of(
			Enchantments.UNBREAKING, 10,
			Enchantments.MENDING, 1
		));
		giveItem(player, Items.FIREWORK_ROCKET, 64);
	}

	/** The PvP siege kit: rails, TNT minecarts, TNT and enough boom to end an argument. */
	private static void giveTntCartKit(ServerPlayer player) {
		giveItem(player, Items.TNT_MINECART, 64);
		giveItem(player, Items.TNT_MINECART, 64);
		giveItem(player, Items.MINECART, 16);
		giveItem(player, Items.RAIL, 64);
		giveItem(player, Items.POWERED_RAIL, 64);
		giveItem(player, Items.TNT, 64);
		giveItem(player, Items.OBSIDIAN, 64);
		giveEnchantedItem(player, Items.FLINT_AND_STEEL, Map.of(
			Enchantments.UNBREAKING, 3,
			Enchantments.MENDING, 1
		));
		giveItem(player, Items.WATER_BUCKET, 1);
	}

	/** Ranged duelist kit: bow + crossbow with ammo, mobility and sustain. */
	private static void giveArcherKit(ServerPlayer player) {
		giveEnchantedItem(player, Items.BOW, Map.of(
			Enchantments.POWER, 5,
			Enchantments.FLAME, 1,
			Enchantments.PUNCH, 2,
			Enchantments.INFINITY, 1,
			Enchantments.UNBREAKING, 3
		));
		giveEnchantedItem(player, Items.CROSSBOW, Map.of(
			Enchantments.QUICK_CHARGE, 3,
			Enchantments.MULTISHOT, 1,
			Enchantments.UNBREAKING, 3,
			Enchantments.MENDING, 1
		));
		giveItem(player, Items.ARROW, 64);
		giveItem(player, Items.SPECTRAL_ARROW, 64);
		giveItem(player, Items.WIND_CHARGE, 32);
		giveItem(player, Items.ENDER_PEARL, 16);
		giveItem(player, Items.GOLDEN_APPLE, 16);
		giveItem(player, Items.TOTEM_OF_UNDYING, 1);
	}

	/** Crystal-PvP kit: crystals, obsidian to place them on, and totems to survive them. */
	private static void giveCrystalKit(ServerPlayer player) {
		giveItem(player, Items.END_CRYSTAL, 64);
		giveItem(player, Items.OBSIDIAN, 64);
		giveItem(player, Items.TOTEM_OF_UNDYING, 4);
		giveItem(player, Items.GOLDEN_APPLE, 64);
		giveItem(player, Items.ENCHANTED_GOLDEN_APPLE, 16);
		giveItem(player, Items.WIND_CHARGE, 64);
		giveItem(player, Items.ENDER_PEARL, 16);
		giveItem(player, Items.WATER_BUCKET, 1);
		giveItem(player, Items.LAVA_BUCKET, 1);
	}

	/** Gathering kit: a fortune pick AND a silk-touch pick, plus tools and light. */
	private static void giveMinerKit(ServerPlayer player) {
		giveEnchantedItem(player, Items.NETHERITE_PICKAXE, Map.of(
			Enchantments.EFFICIENCY, 5,
			Enchantments.FORTUNE, 3,
			Enchantments.UNBREAKING, 3,
			Enchantments.MENDING, 1
		));
		giveEnchantedItem(player, Items.NETHERITE_PICKAXE, Map.of(
			Enchantments.EFFICIENCY, 5,
			Enchantments.SILK_TOUCH, 1,
			Enchantments.UNBREAKING, 3,
			Enchantments.MENDING, 1
		));
		giveEnchantedItem(player, Items.NETHERITE_SHOVEL, Map.of(
			Enchantments.EFFICIENCY, 5,
			Enchantments.UNBREAKING, 3,
			Enchantments.MENDING, 1
		));
		giveEnchantedItem(player, Items.NETHERITE_AXE, Map.of(
			Enchantments.SHARPNESS, 5,
			Enchantments.EFFICIENCY, 5,
			Enchantments.UNBREAKING, 3,
			Enchantments.MENDING, 1
		));
		giveEnchantedItem(player, Items.SHEARS, Map.of(
			Enchantments.UNBREAKING, 3
		));
		giveItem(player, Items.TORCH, 64);
		giveItem(player, Items.CRAFTING_TABLE, 1);
		giveItem(player, Items.WATER_BUCKET, 1);
		giveItem(player, Items.ENDER_PEARL, 8);
	}

	/** Sustain kit: every heal in the game, so a fight never ends for lack of apples. */
	private static void giveHealingKit(ServerPlayer player) {
		giveItem(player, Items.GOLDEN_APPLE, 64);
		giveItem(player, Items.ENCHANTED_GOLDEN_APPLE, 32);
		giveItem(player, Items.TOTEM_OF_UNDYING, 8);
		giveItem(player, Items.GOLDEN_CARROT, 64);
		giveItem(player, Items.EXPERIENCE_BOTTLE, 64);
		giveItem(player, Items.WATER_BUCKET, 1);
	}

	private static void giveAdminOverkillKit(ServerPlayer player) {
		giveEnchantedItem(player, Items.NETHERITE_SWORD, Map.of(
			Enchantments.SHARPNESS, 10,
			Enchantments.FIRE_ASPECT, 5,
			Enchantments.LOOTING, 10,
			Enchantments.SWEEPING_EDGE, 10,
			Enchantments.UNBREAKING, 10,
			Enchantments.MENDING, 1
		));
		giveEnchantedItem(player, Items.MACE, Map.of(
			Enchantments.DENSITY, 10,
			Enchantments.WIND_BURST, 3,
			Enchantments.UNBREAKING, 10,
			Enchantments.MENDING, 1
		));
		giveEnchantedItem(player, Items.NETHERITE_HELMET, Map.of(
			Enchantments.PROTECTION, 10,
			Enchantments.RESPIRATION, 10,
			Enchantments.AQUA_AFFINITY, 1,
			Enchantments.UNBREAKING, 10,
			Enchantments.MENDING, 1
		));
		giveEnchantedItem(player, Items.NETHERITE_CHESTPLATE, Map.of(
			Enchantments.PROTECTION, 10,
			Enchantments.THORNS, 10,
			Enchantments.UNBREAKING, 10,
			Enchantments.MENDING, 1
		));
		giveEnchantedItem(player, Items.NETHERITE_LEGGINGS, Map.of(
			Enchantments.PROTECTION, 10,
			Enchantments.THORNS, 10,
			Enchantments.UNBREAKING, 10,
			Enchantments.MENDING, 1
		));
		giveEnchantedItem(player, Items.NETHERITE_BOOTS, Map.of(
			Enchantments.PROTECTION, 10,
			Enchantments.FEATHER_FALLING, 10,
			Enchantments.DEPTH_STRIDER, 10,
			Enchantments.UNBREAKING, 10,
			Enchantments.MENDING, 1
		));
		giveItem(player, Items.TOTEM_OF_UNDYING, 64);
		giveItem(player, Items.ENCHANTED_GOLDEN_APPLE, 64);
		giveItem(player, Items.END_CRYSTAL, 64);
		giveItem(player, Items.OBSIDIAN, 64);
		giveItem(player, Items.ELYTRA, 1);
		giveItem(player, Items.FIREWORK_ROCKET, 64);
	}

	private static void giveAdminSuppliesKit(ServerPlayer player) {
		Compat.placeBack(player.getInventory(), createShulkerBox(ADMIN_SUPPLIES_BOX_ITEMS));
		giveItem(player, Items.NETHERITE_BLOCK, 64);
		giveItem(player, Items.BEACON, 64);
	}

	private static void giveItem(ServerPlayer player, Item item, int count) {
		Compat.placeBack(player.getInventory(), new ItemStack(item, count));
	}

	private static void giveEnchantedItem(ServerPlayer player, Item item, Map<ResourceKey<Enchantment>, Integer> enchantments) {
		ItemStack stack = new ItemStack(item);
		var enchantmentRegistry = player.level().registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
		EnchantmentHelper.updateEnchantments(stack, current -> enchantments.forEach((enchantment, level) ->
			current.set(enchantmentRegistry.getOrThrow(enchantment), level)
		));
		Compat.placeBack(player.getInventory(), stack);
	}

	private static void giveArmorKit(ServerPlayer player) {
		for (int i = 0; i < 9; i++) {
			giveItem(player, Items.NETHERITE_HELMET, 1);
			giveItem(player, Items.NETHERITE_CHESTPLATE, 1);
			giveItem(player, Items.NETHERITE_LEGGINGS, 1);
			giveItem(player, Items.NETHERITE_BOOTS, 1);
		}
	}

	private static void giveTrimsKit(ServerPlayer player) {
		Compat.placeBack(player.getInventory(), new ItemStack(Items.SMITHING_TABLE, 64));
		Compat.placeBack(player.getInventory(), createShulkerBox(ORE_BOX_ITEMS));
		Compat.placeBack(player.getInventory(), createShulkerBox(SUPPLIES_BOX_ITEMS));
		Compat.placeBack(player.getInventory(), createShulkerBox(TRIM_BOX_ITEMS));
	}

	private static ItemStack createShulkerBox(List<Item> items) {
		List<ItemStack> contents = items.stream().map(item -> new ItemStack(item, 64)).toList();
		ItemStack shulkerBox = new ItemStack(Items.SHULKER_BOX);
		shulkerBox.set(DataComponents.CONTAINER, ItemContainerContents.fromItems(contents));
		return shulkerBox;
	}

	private static ItemStack createTrapperShulkerBox() {
		List<ItemStack> contents = new ArrayList<>();
		contents.add(new ItemStack(Items.ARMOR_STAND, 16));
		TRAPPER_BOX_ITEMS.stream().map(item -> new ItemStack(item, 64)).forEach(contents::add);
		ItemStack shulkerBox = new ItemStack(Items.SHULKER_BOX);
		shulkerBox.set(DataComponents.CONTAINER, ItemContainerContents.fromItems(contents));
		return shulkerBox;
	}

	private static void giveTrapperKit(ServerPlayer player) {
		Compat.placeBack(player.getInventory(), createTrapperShulkerBox());
	}

	private static final class KitMenu extends ChestMenu {
		private boolean claimed;

		private KitMenu(int containerId, Inventory inventory, SimpleContainer contents) {
			super(MenuType.GENERIC_9x3, containerId, inventory, contents, 3);
		}

		@Override
		public void clicked(int slotIndex, int buttonNum, ContainerInput containerInput, Player player) {
			if (claimed || !(player instanceof ServerPlayer serverPlayer)) {
				return;
			}

			if (slotIndex == PVP_KIT_SLOT) {
				givePvpKit(serverPlayer);
			} else if (slotIndex == KIT_SLOT) {
				giveTrimsKit(serverPlayer);
			} else if (slotIndex == ARMOR_KIT_SLOT) {
				giveArmorKit(serverPlayer);
			} else if (slotIndex == TRAPPER_KIT_SLOT) {
				giveTrapperKit(serverPlayer);
			} else if (slotIndex == MACE_KIT_SLOT) {
				giveMaceKit(serverPlayer);
			} else if (slotIndex == TNT_CART_KIT_SLOT) {
				giveTntCartKit(serverPlayer);
			} else if (slotIndex == ARCHER_KIT_SLOT) {
				giveArcherKit(serverPlayer);
			} else if (slotIndex == CRYSTAL_KIT_SLOT) {
				giveCrystalKit(serverPlayer);
			} else if (slotIndex == MINER_KIT_SLOT) {
				giveMinerKit(serverPlayer);
			} else if (slotIndex == HEALING_KIT_SLOT) {
				giveHealingKit(serverPlayer);
			} else {
				return;
			}

			claimed = true;
			serverPlayer.closeContainer();
		}

		@Override
		public ItemStack quickMoveStack(Player player, int slotIndex) {
			// No shift-clicking the kit icons out of the menu.
			return ItemStack.EMPTY;
		}
	}

	private static final class AdminKitMenu extends ChestMenu {
		private boolean claimed;

		private AdminKitMenu(int containerId, Inventory inventory, SimpleContainer contents) {
			super(MenuType.GENERIC_9x3, containerId, inventory, contents, 3);
		}

		@Override
		public void clicked(int slotIndex, int buttonNum, ContainerInput containerInput, Player player) {
			if (claimed || !(player instanceof ServerPlayer serverPlayer)) {
				return;
			}

			if (slotIndex == ADMIN_OP_KIT_SLOT) {
				giveAdminOverkillKit(serverPlayer);
			} else if (slotIndex == ADMIN_SUPPLIES_KIT_SLOT) {
				giveAdminSuppliesKit(serverPlayer);
			} else {
				return;
			}

			claimed = true;
			serverPlayer.closeContainer();
		}

		@Override
		public ItemStack quickMoveStack(Player player, int slotIndex) {
			// No shift-clicking the admin kit icons out of the menu.
			return ItemStack.EMPTY;
		}
	}

	private record PendingTpa(UUID requesterId, long expiresAt) {
	}
}
