package com.kodari.trimskits;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;

/**
 * The shop half of {@code /buy}: every block and item the server sells, with
 * its price and how many you already own on the icon.
 *
 * <p>Clicking an item does not buy it - it opens {@link BuyAmountMenu}, because
 * buying a stack by accident is exactly the kind of thing that makes people
 * file refund tickets.
 */
final class BuyMenu extends ChestMenu {
	private static final int ROWS = 6;
	private static final int SIZE = ROWS * 9;
	/** First slot of the bottom control row. */
	private static final int BAR = (ROWS - 1) * 9;
	/** Number of item slots in the grid (everything above the control bar). */
	private static final int GRID = BAR;

	private static final int SLOT_PREVIOUS = BAR + 0;
	private static final int SLOT_NEXT = BAR + 1;
	private static final int SLOT_PAGE = BAR + 2;
	private static final int SLOT_CATEGORY = BAR + 3;
	private static final int SLOT_BALANCE = BAR + 4;
	private static final int SLOT_SORT = BAR + 5;
	private static final int SLOT_INFO = BAR + 6;
	private static final int SLOT_SEARCH = BAR + 7;
	private static final int SLOT_CLOSE = BAR + 8;

	/** How the listing is ordered. */
	private enum Sort {
		SHOP_ORDER("shop order"),
		CHEAPEST("cheapest first"),
		DEAREST("dearest first"),
		OWNED("what I already own");

		private final String label;

		Sort(String label) {
			this.label = label;
		}

		String label() {
			return label;
		}

		Sort next() {
			Sort[] all = values();
			return all[(ordinal() + 1) % all.length];
		}
	}

	private final ServerPlayer owner;
	private final SimpleContainer container;

	/** Entries currently browsed; rebuilt whenever the view changes. */
	private List<ShopValues.Entry> entries = List.of();
	/** Entry -> [units, protected units], tallied once per render. */
	private Map<ShopValues.Entry, long[]> carry = Map.of();
	/** Slot index -> category name while the category picker is open. */
	private final Map<Integer, String> pickerSlots = new HashMap<>();
	/**
	 * Where categories may be placed: every grid slot except the top-left
	 * "every category" button and the right-hand edge. Built once so the
	 * picker can page instead of silently running out of room.
	 */
	private static final List<Integer> PICKER_SLOTS = buildPickerSlots();

	private String category;
	private String searchQuery;
	private int categoryPage;
	private Sort sort = Sort.SHOP_ORDER;
	private boolean pickingCategory;
	private int page;

	private static List<Integer> buildPickerSlots() {
		List<Integer> slots = new ArrayList<>();
		for (int slot = 1; slot < GRID; slot++) {
			if (slot % 9 == 8) {
				continue;
			}
			slots.add(slot);
		}
		return List.copyOf(slots);
	}

	BuyMenu(int containerId, Inventory inventory, ServerPlayer owner) {
		super(MenuType.GENERIC_9x6, containerId, inventory, new SimpleContainer(SIZE), ROWS);
		this.owner = owner;
		this.container = (SimpleContainer) getContainer();
		render();
	}

	/** Overload for search results from chat capture. */
	BuyMenu(int containerId, Inventory inventory, ServerPlayer owner, String searchQuery, List<ShopValues.Entry> results) {
		super(MenuType.GENERIC_9x6, containerId, inventory, new SimpleContainer(SIZE), ROWS);
		this.owner = owner;
		this.container = (SimpleContainer) getContainer();
		this.searchQuery = searchQuery;
		this.entries = results;
		this.page = 0;
		renderSearchResults();
	}

	private int pageCount() {
		return Math.max(1, (entries.size() + GRID - 1) / GRID);
	}

	private void render() {
		// One inventory pass feeds every icon, instead of rescanning per item.
		carry = TrimKits.carryTally(owner);
		if (pickingCategory) {
			renderCategoryPicker();
		} else {
			entries = buildEntries();
			renderItems();
		}
		broadcastChanges();
	}

	private void renderSearchResults() {
		carry = TrimKits.carryTally(owner);
		renderItems();
	}

	private List<ShopValues.Entry> buildEntries() {
		List<ShopValues.Entry> source;
		if (searchQuery != null && !searchQuery.isBlank()) {
			source = ShopSearch.search(searchQuery);
		} else if (category == null) {
			source = ShopValues.all();
		} else {
			source = ShopValues.inCategory(category);
		}
		if (sort == Sort.SHOP_ORDER) {
			return source;
		}
		List<ShopValues.Entry> sorted = new ArrayList<>(source);
		// Stable sorts, so the shop's own grouping survives inside each group.
		// Prices are the live market (what the buy icons show), not the list price.
		switch (sort) {
			case CHEAPEST -> sorted.sort(Comparator.comparingLong((ShopValues.Entry entry) -> ShopValues.shopPrice(entry)));
			case DEAREST -> sorted.sort(Comparator.comparingLong((ShopValues.Entry entry) -> ShopValues.shopPrice(entry)).reversed());
			case OWNED -> sorted.sort(Comparator.comparingLong(entry -> {
				long[] counts = carry.get(entry);
				return counts == null ? 1 : 0;
			}));
			case SHOP_ORDER -> { }
		}
		return sorted;
	}

	private void renderItems() {
		clearGrid();
		pickerSlots.clear();

		if (page >= pageCount()) {
			page = pageCount() - 1;
		}
		if (page < 0) {
			page = 0;
		}

		int first = page * GRID;
		for (int offset = 0; offset < GRID; offset++) {
			int index = first + offset;
			if (index >= entries.size()) {
				break;
			}
			ShopValues.Entry entry = entries.get(index);
			long[] counts = carry.get(entry);
			container.setItem(offset, buyIcon(entry, counts == null ? 0 : counts[0]));
		}

		int pages = pageCount();
		container.setItem(SLOT_PREVIOUS, page > 0
			? button(Items.ARROW, "Previous page", ChatFormatting.YELLOW)
			: button(Items.STONE_BUTTON, "No previous page", ChatFormatting.DARK_GRAY));
		container.setItem(SLOT_NEXT, page + 1 < pages
			? button(Items.ARROW, "Next page", ChatFormatting.YELLOW)
			: button(Items.STONE_BUTTON, "No next page", ChatFormatting.DARK_GRAY));

		String pageTitle = searchQuery != null ? "Search: " + searchQuery
			: category == null ? "Every category" : "Category: " + category;
		container.setItem(SLOT_PAGE, button(Items.BOOK,
			"Page " + (page + 1) + " of " + pages, ChatFormatting.AQUA,
			TrimKits.formatAmount(entries.size()) + " item(s) listed here",
			"Showing: " + pageTitle,
			"",
			"Click to jump to the next page"));

		container.setItem(SLOT_CATEGORY, category == null
			? button(Items.LECTERN, "Categories", ChatFormatting.AQUA,
				"Browse one category at a time",
				"",
				TrimKits.formatAmount(ShopValues.categories().size()) + " categories available")
			: button(Items.LECTERN, "Category: " + category, ChatFormatting.AQUA,
				TrimKits.formatAmount(ShopValues.inCategory(category).size()) + " item(s) in this category",
				"",
				"Click to change category"));

		container.setItem(SLOT_BALANCE, button(Items.GOLD_BLOCK,
			"Balance: $" + TrimKits.formatAmount(MarketData.balance(owner.getUUID())), ChatFormatting.GOLD,
			"",
			"Use /baltop to see the richest players"));

		container.setItem(SLOT_SORT, button(Items.HOPPER, "Sort: " + sort.label(), ChatFormatting.AQUA,
			"Click to cycle the order",
			"",
			"Shop order, cheapest, dearest, owned"));

		container.setItem(SLOT_INFO, button(Items.WRITABLE_BOOK, "How buying works", ChatFormatting.AQUA,
			"Click any item to choose a quantity",
			"The total is shown before you confirm",
			"Items arrive in stacks of 64",
			"",
			"Nothing is charged until you press buy"));

		// Search button
		if (searchQuery != null && !searchQuery.isBlank()) {
			container.setItem(SLOT_SEARCH, button(Items.COMPASS,
				"Clear search", ChatFormatting.YELLOW,
				"Current query: " + searchQuery,
				"",
				"Click to show all items again"));
		} else {
			container.setItem(SLOT_SEARCH, button(Items.COMPASS,
				"Search", ChatFormatting.AQUA,
				"Type what you want to find",
				"",
				"Click, then type in chat"));
		}

		container.setItem(SLOT_CLOSE, button(Items.BARRIER, "Close", ChatFormatting.RED));
	}

	private void renderCategoryPicker() {
		clearGrid();
		pickerSlots.clear();

		container.setItem(0, button(Items.CHEST, "Every category", ChatFormatting.AQUA,
			TrimKits.formatAmount(ShopValues.all().size()) + " item(s) in total",
			"",
			"Click to browse everything"));

		List<String> categories = ShopValues.categories();
		int capacity = PICKER_SLOTS.size();
		int pages = Math.max(1, (categories.size() + capacity - 1) / capacity);
		if (categoryPage >= pages) {
			categoryPage = pages - 1;
		}
		if (categoryPage < 0) {
			categoryPage = 0;
		}
		int first = categoryPage * capacity;
		for (int offset = 0; offset < capacity; offset++) {
			int index = first + offset;
			if (index >= categories.size()) {
				break;
			}
			String name = categories.get(index);
			int slot = PICKER_SLOTS.get(offset);
			pickerSlots.put(slot, name);
			container.setItem(slot, ShopValues.categoryIcon(name));
		}

		container.setItem(SLOT_PREVIOUS, categoryPage > 0
			? button(Items.ARROW, "Previous categories", ChatFormatting.YELLOW)
			: button(Items.STONE_BUTTON, "No previous categories", ChatFormatting.DARK_GRAY));
		container.setItem(SLOT_NEXT, categoryPage + 1 < pages
			? button(Items.ARROW, "Next categories", ChatFormatting.YELLOW)
			: button(Items.STONE_BUTTON, "No next categories", ChatFormatting.DARK_GRAY));
		container.setItem(SLOT_PAGE, button(Items.BOOK,
			"Categories " + (categoryPage + 1) + " of " + pages, ChatFormatting.AQUA,
			TrimKits.formatAmount(categories.size()) + " categories in total",
			"",
			"Click a category to filter the shop"));
		container.setItem(SLOT_SORT, button(Items.HOPPER, "Sort: " + sort.label(), ChatFormatting.AQUA,
			"Click to switch"));
		container.setItem(SLOT_CATEGORY, button(Items.LECTERN, "Show everything", ChatFormatting.GREEN));
		container.setItem(SLOT_BALANCE, button(Items.GOLD_BLOCK,
			"Balance: $" + TrimKits.formatAmount(MarketData.balance(owner.getUUID())), ChatFormatting.GOLD));
		container.setItem(SLOT_INFO, button(Items.WRITABLE_BOOK, "How buying works", ChatFormatting.AQUA,
			"Click an item to pick a quantity"));
		container.setItem(SLOT_SEARCH, searchQuery != null && !searchQuery.isBlank()
			? button(Items.COMPASS, "Clear search", ChatFormatting.YELLOW)
			: button(Items.COMPASS, "Search", ChatFormatting.AQUA));
		container.setItem(SLOT_CLOSE, button(Items.BARRIER, "Close", ChatFormatting.RED));
	}

	private void clearGrid() {
		for (int slot = 0; slot < SIZE; slot++) {
			container.setItem(slot, ItemStack.EMPTY);
		}
	}

	/**
	 * Buy-side icon: price first, because that is what you are checking, then
	 * what you already own and whether you can afford a stack right now.
	 */
	private static ItemStack buyIcon(ShopValues.Entry entry, long owned) {
		ItemStack stack = entry.displayStack().copy();
		stack.set(DataComponents.CUSTOM_NAME, Component.literal(entry.name())
			.withStyle(owned > 0 ? ChatFormatting.GREEN : ChatFormatting.WHITE));

		List<Component> lore = new ArrayList<>();
		long unit = ShopValues.shopPrice(entry);
		lore.add(Component.literal("Buy price: $" + TrimKits.formatAmount(unit) + " each")
			.withStyle(ChatFormatting.GOLD));
		lore.add(Component.literal("Stack of 64: $" + TrimKits.formatAmount(unit * 64L))
			.withStyle(ChatFormatting.GOLD));
		lore.add(Component.literal("Category: " + entry.category())
			.withStyle(ChatFormatting.DARK_GRAY));
		lore.add(Component.empty());
		lore.add(Component.literal(owned > 0
				? "You own: " + TrimKits.formatAmount(owned)
				: "You own none")
			.withStyle(owned > 0 ? ChatFormatting.GREEN : ChatFormatting.DARK_GRAY));
		lore.add(Component.empty());
		lore.add(Component.literal("Click to choose how many")
			.withStyle(ChatFormatting.AQUA));
		stack.set(DataComponents.LORE, new ItemLore(lore));
		return stack;
	}

	private static ItemStack button(Item item, String title, ChatFormatting color, String... lore) {
		ItemStack stack = new ItemStack(item);
		stack.set(DataComponents.CUSTOM_NAME, Component.literal(title).withStyle(color));
		if (lore.length > 0) {
			List<Component> lines = new ArrayList<>();
			for (String line : lore) {
				lines.add(line.isEmpty() ? Component.empty() : Component.literal(line).withStyle(ChatFormatting.GRAY));
			}
			stack.set(DataComponents.LORE, new ItemLore(lines));
		}
		return stack;
	}

	@Override
	public void clicked(int slotIndex, int buttonNum, ContainerInput containerInput, Player player) {
		// Every container slot is display-only; never let the vanilla handler run
		// for them, otherwise players could pull the icons out and dupe them.
		if (slotIndex < 0 || slotIndex >= SIZE || !(player instanceof ServerPlayer serverPlayer)) {
			return;
		}

		if (slotIndex == SLOT_CLOSE) {
			serverPlayer.closeContainer();
			return;
		}
		if (slotIndex == SLOT_SORT) {
			sort = sort.next();
			render();
			return;
		}
		if (slotIndex == SLOT_BALANCE || slotIndex == SLOT_INFO) {
			return;
		}
		if (slotIndex == SLOT_CATEGORY) {
			pickingCategory = !pickingCategory;
			categoryPage = 0;
			page = 0;
			render();
			return;
		}
		if (slotIndex == SLOT_SEARCH) {
			if (searchQuery != null && !searchQuery.isBlank()) {
				// Clear search
				searchQuery = null;
				page = 0;
				render();
			} else {
				// Anvil-style search box, reopening this (buy) shop on confirm.
				TrimKits.openSearchPopup(owner, false, searchQuery);
			}
			return;
		}

		if (pickingCategory) {
			if (slotIndex == SLOT_PREVIOUS) {
				categoryPage--;
				render();
				return;
			}
			if (slotIndex == SLOT_NEXT) {
				categoryPage++;
				render();
				return;
			}
			if (slotIndex == SLOT_PAGE) {
				return;
			}
			if (slotIndex == 0) {
				category = null;
				searchQuery = null;
				pickingCategory = false;
				categoryPage = 0;
				page = 0;
				render();
				return;
			}
			String picked = pickerSlots.get(slotIndex);
			if (picked != null) {
				category = picked;
				searchQuery = null;
				pickingCategory = false;
				categoryPage = 0;
				page = 0;
				render();
			}
			return;
		}

		if (slotIndex == SLOT_PREVIOUS) {
			if (page > 0) {
				page--;
				render();
			}
			return;
		}
		if (slotIndex == SLOT_NEXT || slotIndex == SLOT_PAGE) {
			page = page + 1 < pageCount() ? page + 1 : 0;
			render();
			return;
		}

		// Grid slot: open the quantity picker for that item.
		if (slotIndex >= GRID) {
			return;
		}
		int index = page * GRID + slotIndex;
		if (index >= entries.size()) {
			return;
		}
		openAmount(entries.get(index));
	}

	/**
	 * Swapping menus inside a click handler would race the packet being
	 * processed, so the swap is deferred to the end of the server task queue.
	 * The guard stops us opening on top of a menu the player already left.
	 */
	private void openAmount(ShopValues.Entry entry) {
		MinecraftServer server = owner.level().getServer();
		Runnable action = () -> {
			if (owner.containerMenu == this) {
				TrimKits.openBuyAmount(owner, entry);
			}
		};
		if (server == null) {
			action.run();
		} else {
			server.execute(action);
		}
	}

	@Override
	public ItemStack quickMoveStack(Player player, int slotIndex) {
		// No shift-clicking in or out of the buy menu.
		return ItemStack.EMPTY;
	}
}
