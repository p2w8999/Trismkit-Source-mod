package com.kodari.trimskits;

import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;

/**
 * The actions for a single home - teleport to it, rename it, move it to where
 * you now stand, or delete it. Delete is a two-click confirm so nobody wipes a
 * home by accident.
 */
final class HomeActionsMenu extends ChestMenu {
	// 3 rows = 27 slots
	private static final int ROWS = 3;
	private static final int SIZE = ROWS * 9;

	private static final int INFO_SLOT = 4;
	private static final int TELEPORT_SLOT = 11;
	private static final int RENAME_SLOT = 12;
	private static final int SETHERE_SLOT = 13;
	private static final int DELETE_SLOT = 15;
	private static final int BACK_SLOT = 22;

	private final ServerPlayer owner;
	private final String homeName;
	private boolean confirmDelete;

	HomeActionsMenu(int containerId, Inventory inventory, ServerPlayer owner, String homeName) {
		super(MenuType.GENERIC_9x3, containerId, inventory, new SimpleContainer(SIZE), ROWS);
		this.owner = owner;
		this.homeName = homeName;
		build();
	}

	private void build() {
		SimpleContainer container = (SimpleContainer) getContainer();
		Homes.Home home = Homes.get(owner.getUUID(), homeName);

		// Border panes (top row, bottom row, and the two side columns).
		ItemStack pane = new ItemStack(Compat.pickItem("STAINED_GLASS_PANE", DyeColor.BLACK));
		pane.set(DataComponents.CUSTOM_NAME, Component.literal(" "));
		for (int i = 0; i < SIZE; i++) {
			int row = i / 9;
			int col = i % 9;
			if (row == 0 || row == ROWS - 1 || col == 0 || col == 8) {
				container.setItem(i, pane);
			}
		}

		if (home == null) {
			// The home vanished (deleted elsewhere) - just show a way back.
			ItemStack gone = new ItemStack(Items.BARRIER);
			gone.set(DataComponents.CUSTOM_NAME, Component.literal("§cHome not found").withStyle(ChatFormatting.RED));
			gone.set(DataComponents.LORE, new ItemLore(List.of(Component.literal("§7It may have been deleted."))));
			container.setItem(INFO_SLOT, gone);
			ItemStack back = backItem();
			container.setItem(BACK_SLOT, back);
			return;
		}

		// Info panel
		ItemStack info = new ItemStack(Items.PLAYER_HEAD);
		info.set(DataComponents.CUSTOM_NAME, Component.literal("§b" + home.name()).withStyle(ChatFormatting.AQUA));
		info.set(DataComponents.LORE, new ItemLore(List.of(
			Component.literal("§7" + home.dimensionLabel()),
			Component.literal(String.format("§7%.1f, %.1f, %.1f", home.x(), home.y(), home.z())),
			Component.empty(),
			Component.literal("§7Facing: §e" + Math.round(home.yaw()) + "° yaw, " + Math.round(home.pitch()) + "° pitch")
		)));
		container.setItem(INFO_SLOT, info);

		// Teleport
		ItemStack teleport = new ItemStack(Items.ENDER_PEARL);
		teleport.set(DataComponents.CUSTOM_NAME, Component.literal("§a§lTeleport").withStyle(ChatFormatting.GREEN));
		teleport.set(DataComponents.LORE, new ItemLore(List.of(
			Component.literal("§7Jump straight to this home."),
			Component.literal("§7Works from any distance and any"),
			Component.literal("§7dimension."),
			Component.empty(),
			Component.literal("§eClick to teleport")
		)));
		container.setItem(TELEPORT_SLOT, teleport);

		// Rename
		ItemStack rename = new ItemStack(Items.NAME_TAG);
		rename.set(DataComponents.CUSTOM_NAME, Component.literal("§e§lRename").withStyle(ChatFormatting.YELLOW));
		rename.set(DataComponents.LORE, new ItemLore(List.of(
			Component.literal("§7Give this home a new name."),
			Component.empty(),
			Component.literal("§eClick to rename")
		)));
		container.setItem(RENAME_SLOT, rename);

		// Set here (move)
		ItemStack setHere = new ItemStack(Items.COMPASS);
		setHere.set(DataComponents.CUSTOM_NAME, Component.literal("§b§lSet Here").withStyle(ChatFormatting.AQUA));
		setHere.set(DataComponents.LORE, new ItemLore(List.of(
			Component.literal("§7Move this home to where you"),
			Component.literal("§7are standing right now."),
			Component.empty(),
			Component.literal("§eClick to move the home here")
		)));
		container.setItem(SETHERE_SLOT, setHere);

		// Delete (two-click confirm)
		ItemStack delete;
		if (confirmDelete) {
			delete = new ItemStack(Items.LAVA_BUCKET);
			delete.set(DataComponents.CUSTOM_NAME, Component.literal("§c§lConfirm Delete?").withStyle(ChatFormatting.RED));
			delete.set(DataComponents.LORE, new ItemLore(List.of(
				Component.literal("§cThis cannot be undone."),
				Component.literal("§7Click again to permanently"),
				Component.literal("§7delete \"" + home.name() + "\"."),
				Component.empty(),
				Component.literal("§cClick to confirm delete")
			)));
		} else {
			delete = new ItemStack(Items.LAVA_BUCKET);
			delete.set(DataComponents.CUSTOM_NAME, Component.literal("§cDelete Home").withStyle(ChatFormatting.RED));
			delete.set(DataComponents.LORE, new ItemLore(List.of(
				Component.literal("§7Remove this home permanently."),
				Component.empty(),
				Component.literal("§eClick once more to confirm")
			)));
		}
		container.setItem(DELETE_SLOT, delete);

		// Back
		container.setItem(BACK_SLOT, backItem());
	}

	private ItemStack backItem() {
		ItemStack back = new ItemStack(Items.ARROW);
		back.set(DataComponents.CUSTOM_NAME, Component.literal("§eBack to Homes").withStyle(ChatFormatting.YELLOW));
		back.set(DataComponents.LORE, new ItemLore(List.of(Component.literal("§7Return to the home list."))));
		return back;
	}

	@Override
	public boolean stillValid(Player player) {
		return player == owner;
	}

	@Override
	public ItemStack quickMoveStack(Player player, int index) {
		return ItemStack.EMPTY;
	}

	@Override
	public void clicked(int slotId, int buttonNum, ContainerInput containerInput, Player player) {
		if (slotId < 0 || slotId >= SIZE) return;
		if (!(player instanceof ServerPlayer serverPlayer) || serverPlayer != owner) return;

		if (slotId == TELEPORT_SLOT) {
			teleport(serverPlayer);
			return;
		}
		if (slotId == RENAME_SLOT) {
			confirmDelete = false;
			TrimKits.openHomeRename(serverPlayer, homeName);
			return;
		}
		if (slotId == SETHERE_SLOT) {
			confirmDelete = false;
			setHere(serverPlayer);
			return;
		}
		if (slotId == DELETE_SLOT) {
			if (!confirmDelete) {
				confirmDelete = true;
				build();
			} else {
				deleteHome(serverPlayer);
			}
			return;
		}
		if (slotId == BACK_SLOT) {
			confirmDelete = false;
			TrimKits.openHomes(serverPlayer, 0);
			return;
		}
		// Border panes, info, etc: ignore.
	}

	private void teleport(ServerPlayer player) {
		Homes.Home home = Homes.get(player.getUUID(), homeName);
		if (home == null) {
			player.sendSystemMessage(Component.literal("That home no longer exists."));
			TrimKits.openHomes(player, 0);
			return;
		}
		if (!Homes.teleport(player, home)) {
			player.sendSystemMessage(Component.literal("That dimension no longer exists."));
			return;
		}
		player.sendSystemMessage(Component.literal("Teleported to home §b" + home.name() + "§r."));
		player.closeContainer();
	}

	private void setHere(ServerPlayer player) {
		boolean ok = Homes.move(player.getUUID(), homeName, player.level().dimension(),
			player.getX(), player.getY(), player.getZ(), player.getYRot(), player.getXRot());
		if (ok) {
			player.sendSystemMessage(Component.literal("Home §b" + homeName + "§r moved to your current location."));
			build();
		} else {
			player.sendSystemMessage(Component.literal("Could not move that home; it may be gone."));
			TrimKits.openHomes(player, 0);
		}
	}

	private void deleteHome(ServerPlayer player) {
		if (Homes.remove(player.getUUID(), homeName)) {
			player.sendSystemMessage(Component.literal("Deleted home §b" + homeName + "§r."));
			TrimKits.openHomes(player, 0);
		} else {
			player.sendSystemMessage(Component.literal("Could not delete that home; it may already be gone."));
			TrimKits.openHomes(player, 0);
		}
	}
}
