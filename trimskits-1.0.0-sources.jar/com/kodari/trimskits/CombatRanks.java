package com.kodari.trimskits;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;
import net.minecraft.ChatFormatting;
import net.minecraft.core.RegistryAccess;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The two crystal ladders: one climbed by killing mobs, the other by beating
 * other players.
 *
 * <p>They sit beside the playtime ladder rather than inside it, so a veteran
 * miner and a veteran fighter are each recognised for what they actually do.
 * Every crystal is earned from kills or bought outright, is permanent, and
 * needs the crystal below it first - buying can skip the grind, never the
 * order.
 *
 * <p>Unlike the playtime ranks these pay nothing out, deliberately: a payout on
 * a kill ladder would make killing (or farming tame mobs) a money printer.
 */
final class CombatRanks {
	private static final Logger LOGGER = LoggerFactory.getLogger("trimskits");
	private static final Path DATA_FILE = Path.of("config", "trimskits-crystals.properties");
	/** A version tag so a future format change can be spotted on load. */
	private static final String FORMAT = "v1";

	/** Which ladder a crystal belongs to. */
	enum Ladder {
		MOB("Mob", "mobs you have killed"),
		PVP("PvP", "players you have beaten");

		private final String label;
		private final String how;

		Ladder(String label, String how) {
			this.label = label;
			this.how = how;
		}

		/** Short display label, e.g. "Mob". */
		String label() {
			return label;
		}

		/** What counts towards this ladder, for lore lines. */
		String how() {
			return how;
		}

		/** The kills that count towards this ladder. */
		long progress(UUID playerId) {
			return switch (this) {
				case MOB -> PlayerStats.mobKills(playerId);
				case PVP -> PlayerStats.kills(playerId);
			};
		}
	}

	/** One rung of a crystal ladder. */
	record Crystal(int tier, String name, ChatFormatting colour, long kills, long price) {
		boolean owned(int effectiveTier) {
			return effectiveTier >= tier;
		}

		/** Why this crystal is not up for sale right now, or null when it is. */
		String blocked(int effectiveTier, Ladder ladder) {
			if (tier == 0) {
				return "Everyone starts here.";
			}
			if (owned(effectiveTier)) {
				return "You already have this crystal.";
			}
			if (tier != effectiveTier + 1) {
				return "Earn or buy " + get(ladder, effectiveTier + 1).name() + " first.";
			}
			return null;
		}
	}

	/** Tier 1-9 names: three low tiers, three mid, three high. */
	private static final String[] BANDS = {
		"LTW 1", "LTW 2", "LTW 3", "MTW 1", "MTW 2", "MTW 3", "HTW 1", "HTW 2", "HTW 3"
	};
	/** Grey for the base, then a colour that climbs with the band. */
	private static final ChatFormatting[] COLOURS = {
		ChatFormatting.WHITE, ChatFormatting.GREEN, ChatFormatting.AQUA,
		ChatFormatting.BLUE, ChatFormatting.LIGHT_PURPLE, ChatFormatting.GOLD,
		ChatFormatting.RED, ChatFormatting.DARK_RED, ChatFormatting.DARK_AQUA
	};
	/** Mob kills per rung - mobs are plentiful, so the ladder runs higher. */
	private static final long[] MOB_KILLS = {
		25L, 75L, 200L, 500L, 1_200L, 3_000L, 7_500L, 18_000L, 40_000L
	};
	/** Player kills per rung - far rarer, so the counts are much lower. */
	private static final long[] PVP_KILLS = {
		5L, 15L, 40L, 100L, 250L, 600L, 1_500L, 3_500L, 8_000L
	};
	/** Buy prices, starting near the $500 starting balance. */
	private static final long[] MOB_PRICES = {
		500L, 1_500L, 4_000L, 10_000L, 25_000L, 60_000L, 150_000L, 400_000L, 1_000_000L
	};
	private static final long[] PVP_PRICES = {
		1_000L, 3_000L, 8_000L, 20_000L, 50_000L, 125_000L, 320_000L, 800_000L, 2_000_000L
	};

	private static final List<Crystal> MOB_TIERS = build("Mob", MOB_KILLS, MOB_PRICES);
	private static final List<Crystal> PVP_TIERS = build("PvP", PVP_KILLS, PVP_PRICES);

	private static List<Crystal> build(String label, long[] kills, long[] prices) {
		List<Crystal> ladder = new ArrayList<>();
		ladder.add(new Crystal(0, "Unranked", ChatFormatting.GRAY, 0L, 0L));
		for (int i = 0; i < BANDS.length; i++) {
			ladder.add(new Crystal(i + 1, label + " Crystal " + BANDS[i], COLOURS[i], kills[i], prices[i]));
		}
		return List.copyOf(ladder);
	}

	/** UUID -> {mob tier, pvp tier}. Ladder.ordinal() indexes this array. */
	private static final Map<UUID, long[]> OWNERSHIP = new HashMap<>();
	/**
	 * UUID -> {mob tier, pvp tier} already announced this session, so a
	 * rank-up is shouted about once rather than on every single kill.
	 */
	private static final Map<UUID, int[]> ANNOUNCED = new HashMap<>();
	private static boolean loaded;
	private static boolean readable = true;

	private CombatRanks() {
	}

	static List<Crystal> tiers(Ladder ladder) {
		return ladder == Ladder.MOB ? MOB_TIERS : PVP_TIERS;
	}

	static Crystal get(Ladder ladder, int tier) {
		List<Crystal> ladderTiers = tiers(ladder);
		return ladderTiers.get(Math.max(0, Math.min(ladderTiers.size() - 1, tier)));
	}

	static synchronized int purchasedTier(Ladder ladder, UUID playerId) {
		load();
		long[] record = OWNERSHIP.get(playerId);
		return record == null ? 0 : (int) record[ladder.ordinal()];
	}

	static synchronized int earnedTier(Ladder ladder, UUID playerId) {
		long progress = ladder.progress(playerId);
		int tier = 0;
		for (Crystal crystal : tiers(ladder)) {
			if (progress >= crystal.kills()) {
				tier = crystal.tier();
			}
		}
		return tier;
	}

	/** The crystal they actually hold, whichever way they got it. */
	static synchronized int effectiveTier(Ladder ladder, UUID playerId) {
		return Math.max(earnedTier(ladder, playerId), purchasedTier(ladder, playerId));
	}

	static synchronized String nameOf(Ladder ladder, UUID playerId) {
		return get(ladder, effectiveTier(ladder, playerId)).name();
	}

	static synchronized ChatFormatting colourOf(Ladder ladder, UUID playerId) {
		return get(ladder, effectiveTier(ladder, playerId)).colour();
	}

	/** "12 / 75 kills", or the count once the ladder is topped out. */
	static synchronized String progressText(Ladder ladder, UUID playerId) {
		long have = ladder.progress(playerId);
		int tier = effectiveTier(ladder, playerId);
		if (tier >= tiers(ladder).size() - 1) {
			return TrimKits.formatAmount(have) + " kills - top of the ladder";
		}
		long next = get(ladder, tier + 1).kills();
		return TrimKits.formatAmount(have) + " / " + TrimKits.formatAmount(next) + " kills";
	}

	/**
	 * Buys the next rung of a crystal ladder.
	 *
	 * @return null on success, or the reason it did not happen
	 */
	static synchronized String purchase(ServerPlayer player, Ladder ladder, int tier, RegistryAccess registries) {
		load();
		UUID playerId = player.getUUID();
		Crystal crystal = get(ladder, tier);
		int effective = effectiveTier(ladder, playerId);

		String blocked = crystal.blocked(effective, ladder);
		if (blocked != null) {
			return blocked;
		}
		if (!MarketData.debit(playerId, crystal.price(), registries)) {
			return "That crystal costs $" + TrimKits.formatAmount(crystal.price())
				+ " and you have $" + TrimKits.formatAmount(MarketData.balance(playerId)) + ".";
		}

		long previous = purchasedTier(ladder, playerId);
		long[] record = OWNERSHIP.computeIfAbsent(playerId, key -> new long[] {0, 0});
		record[ladder.ordinal()] = tier;
		if (!save()) {
			// Roll the money back rather than charging for a crystal that did not save.
			record[ladder.ordinal()] = previous;
			MarketData.credit(playerId, crystal.price(), registries);
			return "Your crystal could not be saved. You were not charged.";
		}
		// Bought outright: do not announce it again on the next kill.
		int[] seen = ANNOUNCED.get(playerId);
		if (seen != null) {
			seen[ladder.ordinal()] = Math.max(seen[ladder.ordinal()], tier);
		}
		return null;
	}

	/**
	 * Admin: grants a crystal outright on one ladder, without charging.
	 *
	 * <p>Like the playtime ladder, the crystal a player holds is the higher of
	 * the one their kills earned and the one that was bought, so this raises a
	 * player's standing rather than demoting a veteran.
	 *
	 * @return null on success, or the reason it did not happen
	 */
	static synchronized String adminSetTier(Ladder ladder, UUID playerId, int tier) {
		load();
		int max = tiers(ladder).size() - 1;
		if (tier < 0 || tier > max) {
			return ladder.label() + " crystals run from 0 to " + max + ".";
		}
		long[] record = OWNERSHIP.get(playerId);
		boolean fresh = record == null;
		if (fresh) {
			record = new long[] {0, 0};
		}
		long previous = record[ladder.ordinal()];
		record[ladder.ordinal()] = tier;
		OWNERSHIP.put(playerId, record);
		if (!save()) {
			if (fresh) {
				OWNERSHIP.remove(playerId);
			} else {
				record[ladder.ordinal()] = previous;
			}
			return "That change could not be saved. Nothing was changed.";
		}
		// Do not shout about a crystal that was simply handed over.
		int[] seen = ANNOUNCED.get(playerId);
		if (seen == null) {
			seen = new int[Ladder.values().length];
			ANNOUNCED.put(playerId, seen);
		}
		seen[ladder.ordinal()] = Math.max(seen[ladder.ordinal()], effectiveTier(ladder, playerId));
		return null;
	}

	/** Starts tracking this player's crystal announcements. */
	static synchronized void beginSession(UUID playerId) {
		load();
		ANNOUNCED.put(playerId, new int[] {
			effectiveTier(Ladder.MOB, playerId),
			effectiveTier(Ladder.PVP, playerId)
		});
	}

	static synchronized void endSession(UUID playerId) {
		ANNOUNCED.remove(playerId);
	}

	/** Shouts about a crystal the player just crossed into, once. */
	static synchronized void announce(ServerPlayer player, Ladder ladder) {
		UUID playerId = player.getUUID();
		int tier = effectiveTier(ladder, playerId);
		int[] seen = ANNOUNCED.get(playerId);
		if (seen == null) {
			// No tracked session (first kill after a restart): record the tier
			// quietly instead of shouting about a crystal they already held.
			ANNOUNCED.put(playerId, new int[] {tier, tier});
			return;
		}
		if (tier <= seen[ladder.ordinal()]) {
			return;
		}
		seen[ladder.ordinal()] = tier;
		Crystal crystal = get(ladder, tier);
		player.sendSystemMessage(Component.literal("Rank up: ")
				.withStyle(ChatFormatting.GOLD)
				.append(Component.literal(crystal.name()).withStyle(crystal.colour()))
				.append(Component.literal("  (" + progressText(ladder, playerId) + ")")
					.withStyle(ChatFormatting.GRAY)));
	}

	private static synchronized void load() {
		if (loaded) {
			return;
		}
		loaded = true;
		if (!Files.exists(DATA_FILE)) {
			return;
		}
		Properties properties = new Properties();
		try (InputStream input = Files.newInputStream(DATA_FILE)) {
			properties.load(input);
		} catch (IOException exception) {
			readable = false;
			LOGGER.warn("Could not read {}; crystal ranks stay in memory only.", DATA_FILE);
			return;
		}
		for (String key : properties.stringPropertyNames()) {
			try {
				String[] fields = properties.getProperty(key).split("\\|", -1);
				if (fields.length != 3 || !FORMAT.equals(fields[0])) {
					continue;
				}
				UUID playerId = UUID.fromString(key);
				OWNERSHIP.put(playerId, new long[] {
					Long.parseLong(fields[1]),
					Long.parseLong(fields[2])
				});
			} catch (RuntimeException ignored) {
				// Skip a damaged line instead of failing the whole file.
			}
		}
	}

	private static synchronized boolean save() {
		if (!readable) {
			return false;
		}
		Properties properties = new Properties();
		for (Map.Entry<UUID, long[]> record : OWNERSHIP.entrySet()) {
			properties.setProperty(record.getKey().toString(), String.join("|",
				FORMAT,
				Long.toString(record.getValue()[0]),
				Long.toString(record.getValue()[1])));
		}

		Path temporaryFile = DATA_FILE.resolveSibling("trimskits-crystals.tmp");
		try {
			Files.createDirectories(DATA_FILE.getParent());
			try (OutputStream output = Files.newOutputStream(temporaryFile)) {
				properties.store(output, "Trim Kits purchased crystal ranks");
			}
			try {
				Files.move(temporaryFile, DATA_FILE, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
			} catch (AtomicMoveNotSupportedException exception) {
				Files.move(temporaryFile, DATA_FILE, StandardCopyOption.REPLACE_EXISTING);
			}
			return true;
		} catch (IOException exception) {
			LOGGER.warn("Could not save crystal ranks: {}", exception.getMessage());
			return false;
		}
	}
}
