package com.kodari.trimskits;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Web-store order delivery ({@code /buyranks} and the GitHub Pages shop in
 * https://github.com/p2w8999/Trims-kit-Ranks-shop - the "Git Ranks Web"
 * folder is uploaded there and published with Pages).
 *
 * <p>Orders come from two places, and both are delivered identically:
 * <ul>
 *   <li><b>config/orders.json</b> - a local file this mod creates on the very
 *       first start, with instructions inside. Paste the JSON the website
 *       prints (single order, array, or {"orders": [...]}) right into it -
 *       no GitHub account, token or internet needed. Works in singleplayer
 *       (.minecraft/config/) and on dedicated servers (config/).</li>
 *   <li><b>The website's orders.json</b> - polled from its raw URL
 *       (webstore.orders_url) every few minutes, so store purchases arrive
 *       on their own.</li>
 * </ul>
 *
 * <p>Delivered order types:
 * <ul>
 *   <li>{@code rank} - a tab rank, granted by id or display name (vip, MVP+...),</li>
 *   <li>{@code money} - credited to the /money balance,</li>
 *   <li>{@code shards} - credited to the shard balance,</li>
 *   <li>{@code keys} - crate key items (delivered once the player is online;
 *       they need an inventory to land in).</li>
 * </ul>
 * Rank, money and shard orders are keyed by UUID, so they also deliver while
 * the buyer is offline - exactly like the /rank and /money admin commands.
 *
 * <p>Order format (everything optional except user and type):
 * <pre>{"id": "1734567890123", "user": "Notch", "type": "rank", "value": "vip"}</pre>
 *
 * <p>Every processed order id is remembered in
 * config/trimskits-webstore-deliveries.json (atomic write, same discipline as
 * the password vault), so one purchase can never pay out twice. Orders are
 * only paid out to an online buyer (a join triggers a fresh poll, so anything
 * bought while away lands the moment they connect). An order with an unknown
 * type or value is logged and left unprocessed - fix the file and it retries
 * on the next poll.
 */
final class WebStore {
	private static final Logger LOGGER = LoggerFactory.getLogger("trimskits");
	private static final Gson GSON = new GsonBuilder().create();
	private static final Path DATA_FILE = Path.of("config", "trimskits-webstore-deliveries.json");
	/** Where hand-pasted order JSON lives; created with instructions on first start. */
	private static final Path LOCAL_FILE = Path.of("config", "orders.json");
	/** How many processed ids the file remembers; the oldest fall off. */
	private static final int MAX_REMEMBERED = 500;

	/** Ids already delivered or deliberately skipped. Insertion order = newest last. */
	private static final Set<String> PROCESSED = new LinkedHashSet<>();
	private static boolean loaded = false;
	private static volatile boolean fetching = false;
	private static volatile String localStatus = "Not checked yet";
	private static volatile String remoteStatus = "";

	private WebStore() {
	}

	// ---- Persistent processed ids -----------------------------------------

	private static synchronized void initialize() {
		if (loaded) return;
		loaded = true;
		ensureLocalFile();
		if (!Files.exists(DATA_FILE)) {
			return;
		}
		try {
			JsonObject root = JsonParser.parseString(Files.readString(DATA_FILE)).getAsJsonObject();
			for (JsonElement element : root.getAsJsonArray("delivered")) {
				String id = element.getAsString().trim();
				if (!id.isEmpty()) PROCESSED.add(id);
			}
		} catch (Exception exception) {
			// A damaged file only means possible re-delivery, never data loss:
			// quarantine it and start remembering from scratch.
			LOGGER.warn("Could not read {}: {}", DATA_FILE, exception.getMessage());
			quarantine();
		}
	}

	private static synchronized void save() {
		try {
			// Trim from the front so the file can never grow without bound.
			while (PROCESSED.size() > MAX_REMEMBERED) {
				String oldest = PROCESSED.iterator().next();
				PROCESSED.remove(oldest);
			}
			JsonObject root = new JsonObject();
			JsonArray ids = new JsonArray();
			for (String id : PROCESSED) ids.add(id);
			root.add("delivered", ids);
			if (DATA_FILE.getParent() != null) {
				Files.createDirectories(DATA_FILE.getParent());
			}
			Path temp = DATA_FILE.resolveSibling(DATA_FILE.getFileName() + ".tmp");
			Files.writeString(temp, GSON.toJson(root));
			try {
				Files.move(temp, DATA_FILE, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
			} catch (AtomicMoveNotSupportedException exception) {
				Files.move(temp, DATA_FILE, StandardCopyOption.REPLACE_EXISTING);
			}
		} catch (IOException exception) {
			LOGGER.error("Could not save {}: {}", DATA_FILE, exception.getMessage());
		}
	}

	private static void quarantine() {
		try {
			Files.move(DATA_FILE, DATA_FILE.resolveSibling("trimskits-webstore-deliveries.corrupt.json"),
				StandardCopyOption.REPLACE_EXISTING);
		} catch (IOException ignored) {
			// Nothing to move or it is locked - the next save overwrites it.
		}
		PROCESSED.clear();
	}

	private static synchronized boolean isProcessed(String id) {
		initialize();
		return PROCESSED.contains(id);
	}

	private static synchronized void markProcessed(String id) {
		initialize();
		PROCESSED.add(id);
		save();
	}

	// ---- Local orders.json -------------------------------------------------

	/**
	 * Creates config/orders.json with instructions the first time the server
	 * starts, so there is always a known place to paste the JSON the website
	 * prints - no GitHub, token or internet involved. Never overwrites an
	 * existing file.
	 */
	private static synchronized void ensureLocalFile() {
		if (Files.exists(LOCAL_FILE)) return;
		try {
			if (LOCAL_FILE.getParent() != null) {
				Files.createDirectories(LOCAL_FILE.getParent());
			}
			Files.writeString(LOCAL_FILE, """
				{
				  "_help": [
				    "Paste web-store order JSON here, then restart or wait for the next check.",
				    "Each order looks like:",
				    "{\\"id\\": \\"any-unique-id\\", \\"user\\": \\"Notch\\", \\"type\\": \\"rank\\", \\"value\\": \\"vip\\"}",
				    "type = rank | money | shards | keys (aliases: tabrank, cash, shard, key).",
				    "value = rank id/name (vip, MVP+...), an amount for money/shards, or 1-64 for keys.",
				    "You can paste one order, a whole array [ ... ], or {\\"orders\\": [ ... ]}.",
				    "The id must be unique per purchase - the mod uses it to never deliver twice.",
				    "The buyer must be online (or join later); delivery also happens on join.",
				    "Everything the website orders is delivered automatically too - this file is the manual way."
				  ],
				  "orders": []
				}
				""");
			LOGGER.info("Created {} - paste web-store order JSON there.", LOCAL_FILE);
		} catch (IOException exception) {
			LOGGER.warn("Could not create {}: {}", LOCAL_FILE, exception.getMessage());
		}
	}

	/** Reads the local orders.json; empty list when missing or unreadable. */
	private static List<JsonObject> readLocalOrders() {
		try {
			if (!Files.exists(LOCAL_FILE)) return List.of();
			String text = Files.readString(LOCAL_FILE);
			List<String> blocks = codeFences(text);
			if (blocks.isEmpty()) {
				return parseOrders(text);
			}
			// One or more ``` blocks: the site prints one block per order, so
			// read each separately and merge. Pasted junk is skipped by the
			// per-block try/catch instead of poisoning the whole file.
			List<JsonObject> orders = new ArrayList<>();
			for (String block : blocks) {
				try {
					orders.addAll(parseOrders(block));
				} catch (RuntimeException ignored) {
					// This block is not valid JSON; the others still count.
				}
			}
			return orders;
		} catch (Exception exception) {
			localStatus = "Could not read " + LOCAL_FILE + ": " + exception.getMessage();
			LOGGER.warn("Could not read {}: {}", LOCAL_FILE, exception.getMessage());
			return List.of();
		}
	}

	/**
	 * Every markdown code-fenced block in the text (the website prints order
	 * JSON as ```json ... ```), each returned without its fences. Empty list
	 * when the text has no fences.
	 */
	private static List<String> codeFences(String text) {
		List<String> blocks = new ArrayList<>();
		if (text == null || !text.contains("```")) return blocks;
		int cursor = 0;
		while (true) {
			int open = text.indexOf("```", cursor);
			if (open < 0) break;
			int start = text.indexOf('\n', open);
			if (start < 0) break;
			int end = text.indexOf("```", start + 1);
			if (end < 0) end = text.length();
			String block = text.substring(start + 1, end).trim();
			if (!block.isEmpty()) blocks.add(block);
			if (end >= text.length()) break;
			cursor = end + 3;
		}
		return blocks;
	}

	// ---- Polling -----------------------------------------------------------

	/** Cheapest possible cadence for the local paste file (5 seconds). */
	private static final int LOCAL_INTERVAL_TICKS = 100;

	/** Poll interval tick, called from the shared server tick. Cheap no-op when disabled. */
	static void tick(MinecraftServer server, long tickCount) {
		if (!Config.getBoolean("webstore.enabled")) return;
		initialize();
		// The local file is a tiny read, so it is checked constantly - pasting
		// an order should land in game within seconds, no restart needed.
		if (tickCount % LOCAL_INTERVAL_TICKS == 0) {
			pollLocal(server);
		}
		long interval = Config.getLong("webstore.poll_interval_ticks");
		if (interval <= 0) return;
		if (tickCount % interval != 0) return;
		pollWeb(server);
	}

	/** Delivers from both sources: manual check, GUI button and player joins. */
	static void poll(MinecraftServer server) {
		pollLocal(server);
		pollWeb(server);
	}

	/** Hand-pasted orders from config/orders.json - synchronous, offline-capable. */
	private static void pollLocal(MinecraftServer server) {
		if (!Config.getBoolean("webstore.enabled")) {
			localStatus = "Web store is disabled in the config.";
			return;
		}
		initialize();
		List<JsonObject> local = readLocalOrders();
		int delivered = deliverPending(server, local);
		int waiting = countWaiting(local);
		if (delivered > 0 || waiting > 0) {
			localStatus = "config/orders.json: " + delivered + " delivered, " + waiting + " waiting.";
		} else {
			localStatus = "config/orders.json: nothing new (" + local.size() + " total).";
		}
	}

	/** The website's orders.json - fetched async, so a dead host never lags the tick. */
	private static void pollWeb(MinecraftServer server) {
		if (!Config.getBoolean("webstore.enabled")) {
			remoteStatus = "Web store is disabled in the config.";
			return;
		}
		String url = Config.getString("webstore.orders_url");
		if (url == null || url.isBlank() || url.equalsIgnoreCase("disabled")) {
			remoteStatus = "Website sync off (no orders_url).";
			return;
		}
		if (fetching) return;
		fetching = true;
		CompletableFuture.supplyAsync(() -> fetch(url)).whenComplete((text, error) -> {
			fetching = false;
			if (error != null || text == null) {
				return; // status already recorded by fetch()
			}
			try {
				List<JsonObject> orders = parseOrders(text);
				server.execute(() -> {
					int webDelivered = deliverPending(server, orders);
					int webWaiting = countWaiting(orders);
					remoteStatus = "Website: " + webDelivered + " delivered, " + webWaiting + " waiting.";
				});
			} catch (Exception exception) {
				remoteStatus = "Could not read website orders: " + exception.getMessage();
				LOGGER.warn("Web store orders unreadable: {}", exception.getMessage());
			}
		});
	}

	private static String fetch(String url) {
		try {
			URI uri = URI.create(url);
			HttpURLConnection connection = (HttpURLConnection) uri.toURL().openConnection();
			connection.setConnectTimeout(5000);
			connection.setReadTimeout(5000);
			connection.setRequestMethod("GET");
			connection.setRequestProperty("User-Agent", "TrimKits-Minecraft-Mod");

			int code = connection.getResponseCode();
			if (code != 200) {
				remoteStatus = "HTTP " + code + " error fetching " + url;
				return null;
			}

			StringBuilder text = new StringBuilder();
			try (BufferedReader reader = new BufferedReader(
					new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8))) {
				String line;
				while ((line = reader.readLine()) != null) {
					text.append(line).append('\n');
				}
			}
			return text.toString();
		} catch (Exception exception) {
			remoteStatus = "Website fetch failed: " + exception.getMessage();
			return null;
		}
	}

	/**
	 * Accepts a bare array, {"orders": [...]}, or one order object on its own
	 * (what the website prints for a single purchase); anything else is empty.
	 * The local file's "_help" comments are ignored naturally - only objects
	 * with a "user" count as orders.
	 */
	private static List<JsonObject> parseOrders(String text) {
		List<JsonObject> orders = new ArrayList<>();
		String trimmed = text == null ? "" : text.trim();
		if (trimmed.isEmpty()) return orders;
		JsonElement root = JsonParser.parseString(trimmed);
		if (root.isJsonArray()) {
			for (JsonElement element : root.getAsJsonArray()) {
				addOrder(orders, element);
			}
		} else if (root.isJsonObject()) {
			JsonObject object = root.getAsJsonObject();
			if (object.has("orders") && object.get("orders").isJsonArray()) {
				for (JsonElement element : object.getAsJsonArray("orders")) {
					addOrder(orders, element);
				}
			} else {
				// A single pasted order: {"id":..., "user":..., "type":..., "value":...}
				addOrder(orders, object);
			}
		}
		return orders;
	}

	/** Adds the element when it is an object that names a user. */
	private static void addOrder(List<JsonObject> orders, JsonElement element) {
		if (!element.isJsonObject()) return;
		JsonObject object = element.getAsJsonObject();
		if (!object.has("user")) return; // skips _help and other notes
		orders.add(object);
	}

	// ---- Delivery ----------------------------------------------------------

	/**
	 * Hands every undelivered order to its online buyer.
	 *
	 * @return how many orders were delivered in this pass
	 */
	private static int deliverPending(MinecraftServer server, List<JsonObject> orders) {
		int delivered = 0;
		for (JsonObject order : orders) {
			String id = orderId(order);
			if (isProcessed(id)) continue;
			String user = jsonText(order, "user");
			ServerPlayer player = findOnline(server, user);
			if (player == null) {
				continue; // buyer offline: retried on their join or next poll
			}
			String result = deliver(server, player, order);
			if (result != null) {
				LOGGER.warn("Web store order {} for {} not delivered: {}", id, user, result);
				continue;
			}
			markProcessed(id);
			delivered++;
		}
		return delivered;
	}

	/** How many of these orders are not delivered yet (buyer offline or invalid). */
	private static int countWaiting(List<JsonObject> orders) {
		int waiting = 0;
		for (JsonObject order : orders) {
			if (!isProcessed(orderId(order))) waiting++;
		}
		return waiting;
	}

	/** Called when a player joins: hand over anything bought while they were away. */
	static void onJoin(ServerPlayer player) {
		if (!Config.getBoolean("webstore.enabled")) return;
		initialize();
		// The join event fires once the player is in the player list, so a plain
		// poll finds them too - ranks, money, shards and even inventory keys all
		// land right here without a second code path.
		MinecraftServer server = player.level().getServer();
		if (server == null) return;
		poll(server);
	}

	/**
	 * Pays one order out to the buyer.
	 *
	 * @return null on success, or the reason it did not happen (the order then
	 *         stays unprocessed and is retried on a later poll)
	 */
	private static String deliver(MinecraftServer server, ServerPlayer player, JsonObject order) {
		String type = jsonText(order, "type").toLowerCase(Locale.ROOT).replace("_", "").replace("-", "");
		String value = jsonText(order, "value");
		UUID id = player.getUUID();

		switch (type) {
			case "rank", "tabrank", "ranks" -> {
				TabRanks.RankDef rank = TabRanks.findRank(value);
				if (rank == null) {
					return "unknown tab rank \"" + value + "\"";
				}
				TabRanks.grantRank(id, rank.id());
				TabRanks.setActiveRank(id, rank.id());
				TabRanks.applyPlayerTab(player);
				player.sendSystemMessage(Component.literal(
					"§d§l[Store] §aDelivered: " + rank.format() + rank.sign() + " "
						+ rank.displayName() + "§a rank!"));
				return null;
			}
			case "money", "cash" -> {
				long amount = parseLong(value);
				if (amount <= 0) {
					return "money value must be a positive number, got \"" + value + "\"";
				}
				// Initialize first: crediting an un-loaded store would wipe it.
				MarketData.initialize(server.registryAccess());
				if (!MarketData.credit(id, amount, server.registryAccess())) {
					return "money credit of " + amount + " was refused (balance limit?)";
				}
				player.sendSystemMessage(Component.literal(
					"§d§l[Store] §aDelivered: §e$" + TrimKits.formatAmount(amount) + "§a!"));
				return null;
			}
			case "shards", "shard" -> {
				long amount = parseLong(value);
				if (amount <= 0) {
					return "shard value must be a positive number, got \"" + value + "\"";
				}
				String problem = Shards.adminGive(id, amount);
				if (problem != null) {
					return problem;
				}
				player.sendSystemMessage(Component.literal(
					"§d§l[Store] §aDelivered: §d" + TrimKits.formatAmount(amount) + " shards§a!"));
				return null;
			}
			case "keys", "key", "cratekey" -> {
				long count = parseLong(value);
				if (count < 1 || count > 64) {
					return "key count must be 1-64, got \"" + value + "\"";
				}
				for (long i = 0; i < count; i++) {
					Compat.placeBack(player.getInventory(), CrateKeys.key());
				}
				player.sendSystemMessage(Component.literal(
					"§d§l[Store] §aDelivered: §d" + count + " crate key" + (count == 1 ? "" : "s") + "§a!"));
				return null;
			}
			default -> {
				return "unknown type \"" + type + "\"";
			}
		}
	}

	// ---- Small helpers -----------------------------------------------------

	/** An order id, or a stable stand-in when the site forgot to write one. */
	private static String orderId(JsonObject order) {
		String id = jsonText(order, "id");
		if (!id.isEmpty()) return id;
		// Same content -> same id, so a re-fetch never double-delivers.
		return "auto-" + Integer.toHexString(order.toString().hashCode());
	}

	/** Case-insensitive match of an order's user against the online players. */
	private static ServerPlayer findOnline(MinecraftServer server, String user) {
		if (user.isEmpty()) return null;
		for (ServerPlayer player : server.getPlayerList().getPlayers()) {
			if (player.getName().getString().equalsIgnoreCase(user)) {
				return player;
			}
		}
		return null;
	}

	/** A text field of a JSON object, trimmed; "" when missing or not text. */
	private static String jsonText(JsonObject object, String key) {
		JsonElement element = object.get(key);
		if (element == null || !element.isJsonPrimitive()) return "";
		return element.getAsString().trim();
	}

	private static long parseLong(String text) {
		try {
			return Long.parseLong(text.replace(",", "").replace("$", "").trim());
		} catch (NumberFormatException exception) {
			return -1;
		}
	}

	/**
	 * One line for the /buyranks GUI: both sources side by side, e.g.
	 * "config/orders.json: 1 delivered, 0 waiting. Website: 0 delivered...".
	 */
	static String getLastStatus() {
		String remote = remoteStatus.isBlank() ? "" : " " + remoteStatus;
		return localStatus + "." + remote;
	}
}
