package com.kodari.trimskits;

import com.google.gson.JsonParser;
import com.mojang.serialization.JsonOps;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.RegistryAccess;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

final class MarketData {
	private static final Path DATA_FILE = Path.of("config", "trimskits-market.properties");
	private static final Map<UUID, Long> BALANCES = new HashMap<>();
	private static final Map<Integer, AuctionListing> AUCTIONS = new HashMap<>();
	/** Standing buy orders, matched automatically the moment a listing appears. */
	private static final Map<Integer, BuyOrder> BUY_ORDERS = new HashMap<>();
	/** Unclaimed goods: expired listings, filled buy orders, auction payouts. */
	private static final Map<UUID, List<MailItem>> MAIL = new HashMap<>();
	/** Extra auction listing slots bought from the stall market. */
	private static final Map<UUID, Integer> STALL_SLOTS = new HashMap<>();
	private static int nextAuctionId = 1;
	private static int nextOrderId = 1;
	private static boolean loaded;
	private static boolean readable = true;

	/** Listing slots a player gets without paying for any. */
	static final int BASE_STALL_SLOTS = 5;
	/** Extra slots granted by one stall purchase, and the most one player may hold. */
	static final int SLOTS_PER_STALL = 5;
	static final int MAX_STALL_SLOTS = 25;

	private MarketData() {
	}

	static synchronized void initialize(RegistryAccess registries) {
		if (loaded) {
			return;
		}
		loaded = true;
		if (!Files.exists(DATA_FILE)) {
			return;
		}

		Properties properties = new Properties();
		try (InputStream input = Files.newInputStream(DATA_FILE)) {
			properties.load(input);
		} catch (IOException | RuntimeException exception) {
			readable = false;
			System.err.println("[TrimKits] Could not read " + DATA_FILE + ", market data stays in memory only.");
			return;
		}

		try {
			nextAuctionId = Math.max(1, Integer.parseInt(properties.getProperty("next-id", "1")));
		} catch (NumberFormatException ignored) {
			nextAuctionId = 1;
		}
		try {
			nextOrderId = Math.max(1, Integer.parseInt(properties.getProperty("next-order-id", "1")));
		} catch (NumberFormatException ignored) {
			nextOrderId = 1;
		}

		var ops = registries.createSerializationContext(JsonOps.INSTANCE);
		for (String key : properties.stringPropertyNames()) {
			String value = properties.getProperty(key);
			try {
				if (key.startsWith("balance.")) {
					long balance = Long.parseLong(value);
					if (balance >= 0) {
						BALANCES.put(UUID.fromString(key.substring("balance.".length())), balance);
					}
				} else if (key.startsWith("listing.")) {
					int id = Integer.parseInt(key.substring("listing.".length()));
					// The third field used to be the item; it is now the
					// expiry, and the item follows. A three-field line is a
					// listing from before expiry existed, which gets the full
					// window again rather than expiring the moment it loads.
					String[] fields = value.split("\\|", -1);
					if (id > 0 && (fields.length == 3 || fields.length == 4)) {
						UUID seller = UUID.fromString(fields[0]);
						long price = Long.parseLong(fields[1]);
						String encodedStack = fields[fields.length - 1];
						long expires = fields.length == 4
							? Long.parseLong(fields[2])
							: System.currentTimeMillis() + auctionMillis();
						String json = new String(Base64.getDecoder().decode(encodedStack), StandardCharsets.UTF_8);
						ItemStack stack = ItemStack.CODEC.parse(ops, JsonParser.parseString(json)).result().orElse(ItemStack.EMPTY);
						if (price > 0 && !stack.isEmpty()) {
							AUCTIONS.put(id, new AuctionListing(seller, price, stack, expires));
							nextAuctionId = Math.max(nextAuctionId, id + 1);
						}
					}
				} else if (key.startsWith("order.")) {
					int id = Integer.parseInt(key.substring("order.".length()));
					String[] fields = value.split("\\|", -1);
					if (id > 0 && fields.length == 4) {
						UUID buyer = UUID.fromString(fields[0]);
						String itemKey = fields[1];
						int count = Integer.parseInt(fields[2]);
						long maxTotal = Long.parseLong(fields[3]);
						// tryParse returns null for a malformed id, which simply
					// reads as "no such item" rather than a crash on load.
					Identifier itemId = Identifier.tryParse(itemKey);
					Item item = itemId == null ? Items.AIR
						: BuiltInRegistries.ITEM.get(itemId)
							.map(reference -> (Item) reference.value())
							.orElse(Items.AIR);
						if (count > 0 && maxTotal > 0 && item != Items.AIR) {
							BUY_ORDERS.put(id, new BuyOrder(buyer, item, count, maxTotal));
							nextOrderId = Math.max(nextOrderId, id + 1);
						}
					}
				} else if (key.startsWith("mail.")) {
					String[] fields = value.split("\\|", -1);
					if (fields.length >= 2) {
						UUID ownerId = UUID.fromString(fields[0]);
						for (String entry : java.util.Arrays.copyOfRange(fields, 1, fields.length)) {
							// Each entry is from~stack, where "from" may itself
							// contain tildes - only the first one splits.
							int separator = entry.indexOf('~');
							if (separator < 0) {
								continue;
							}
							String from = entry.substring(0, separator);
							String json = new String(Base64.getDecoder().decode(entry.substring(separator + 1)), StandardCharsets.UTF_8);
							ItemStack stack = ItemStack.CODEC.parse(ops, JsonParser.parseString(json)).result().orElse(ItemStack.EMPTY);
							if (!stack.isEmpty()) {
								MAIL.computeIfAbsent(ownerId, ignored -> new ArrayList<>()).add(new MailItem(stack, from));
							}
						}
					}
				} else if (key.startsWith("slots.")) {
					int slots = Integer.parseInt(value);
					if (slots >= BASE_STALL_SLOTS) {
						STALL_SLOTS.put(UUID.fromString(key.substring("slots.".length())), slots);
					}
				}
			} catch (RuntimeException ignored) {
				// Skip a damaged line instead of failing the whole file.
			}
		}
	}

	static synchronized long balance(UUID playerId) {
		return BALANCES.getOrDefault(playerId, 0L);
	}

	static synchronized List<BalanceEntry> topBalances(int limit) {
		List<BalanceEntry> ordered = new ArrayList<>();
		BALANCES.forEach((playerId, amount) -> {
			if (amount > 0) {
				ordered.add(new BalanceEntry(playerId, amount));
			}
		});
		ordered.sort((left, right) -> Long.compare(right.amount(), left.amount()));
		return ordered.size() <= limit ? ordered : new ArrayList<>(ordered.subList(0, limit));
	}

	/**
	 * Everything a player is worth on paper: cash plus the net of every stall
	 * they have up. Shards are deliberately excluded - a second currency with a
	 * different earn curve would only muddy the money ladder.
	 */
	static synchronized long netWorth(UUID playerId) {
		long worth = balance(playerId);
		for (AuctionListing listing : AUCTIONS.values()) {
			if (listing.sellerId().equals(playerId)) {
				worth += auctionCut(listing.price());
			}
		}
		return worth;
	}

	/** The net-worth ladder behind /baltop worth. */
	static synchronized List<BalanceEntry> topNetWorth(int limit) {
		List<BalanceEntry> ordered = new ArrayList<>();
		for (UUID playerId : unionAll()) {
			long worth = netWorth(playerId);
			if (worth > 0) {
				ordered.add(new BalanceEntry(playerId, worth));
			}
		}
		ordered.sort((left, right) -> Long.compare(right.amount(), left.amount()));
		return ordered.size() <= limit ? ordered : new ArrayList<>(ordered.subList(0, limit));
	}

	/** Every UUID the economy knows about - holders, sellers, mail recipients. */
	private static Set<UUID> unionAll() {
		Set<UUID> all = new HashSet<>(BALANCES.keySet());
		for (AuctionListing listing : AUCTIONS.values()) {
			all.add(listing.sellerId());
		}
		all.addAll(MAIL.keySet());
		return all;
	}

	// ---- Interest -----------------------------------------------------------

	/**
	 * Pays every balance its share of the daily interest rate. Interest is the
	 * counterweight to the tax burn: money leaves circulation through fees and
	 * returns slowly here, so the total supply breathes instead of only
	 * shrinking. Balances over the configured cap earn nothing - being rich is
	 * still the point, but unbounded growth is not.
	 *
	 * @return how many balances received anything
	 */
	static synchronized int payInterest(RegistryAccess registries) {
		long perDay = Config.getLong("economy.interest_percent_per_day");
		long cap = Config.getLong("economy.interest_cap");
		if (perDay <= 0) {
			return 0;
		}
		// The payout runs on a timer rather than once a day, so each run pays
		// its slice: a bit of interest every interval instead of a windfall at
		// midnight for whoever happened to be online.
		long payoutsPerDay = Math.max(1, (24 * 60)
			/ Math.max(1, Config.getLong("economy.interest_payout_minutes")));
		int paid = 0;
		for (Map.Entry<UUID, Long> entry : BALANCES.entrySet()) {
			long amount = entry.getValue();
			if (amount <= 0 || amount >= cap) {
				continue;
			}
			long slice = amount * perDay / 100 / payoutsPerDay;
			if (slice <= 0) {
				continue;
			}
			entry.setValue(amount + slice);
			Ledger.record(entry.getKey(), slice, "interest", "rate " + perDay + "%/day");
			paid++;
		}
		if (paid > 0 && !save(registries)) {
			// Interest is a gift, not a debt: if it cannot be written down it
			// is simply not paid, rather than rolled back mid-flight.
			return 0;
		}
		return paid;
	}

	// ---- Buy orders ---------------------------------------------------------

	/**
	 * Registers a standing order to buy {@code count} of an item for at most
	 * {@code maxTotal} altogether. The ceiling is escrowed on the spot, so an
	 * order can never be matched against money that has since been spent, and
	 * orders survive restarts.
	 *
	 * @return the order id, or a negative {@link OrderResult} code
	 */
	static synchronized int createBuyOrder(UUID buyerId, Item item, int count, long maxTotal, RegistryAccess registries) {
		if (item == null || item == Items.AIR || count <= 0 || maxTotal <= 0) {
			return OrderResult.INVALID;
		}
		if (!debit(buyerId, maxTotal, registries)) {
			return OrderResult.INSUFFICIENT_FUNDS;
		}
		int id = nextOrderId++;
		BUY_ORDERS.put(id, new BuyOrder(buyerId, item, count, maxTotal));
		if (!save(registries)) {
			BUY_ORDERS.remove(id);
			nextOrderId = id;
			credit(buyerId, maxTotal, registries);
			return OrderResult.STORAGE_ERROR;
		}
		Ledger.record(buyerId, -maxTotal, "order-open", count + "x " + BuiltInRegistries.ITEM.getKey(item)
			+ " up to $" + maxTotal);
		return id;
	}

	/** Negative codes {@link #createBuyOrder} reports instead of an id. */
	static final class OrderResult {
		static final int INVALID = -1;
		static final int INSUFFICIENT_FUNDS = -2;
		static final int STORAGE_ERROR = -3;

		private OrderResult() {
		}
	}

	/** Cancels an order and refunds the whole escrow. */
	static synchronized boolean cancelBuyOrder(UUID buyerId, int orderId, RegistryAccess registries) {
		BuyOrder order = BUY_ORDERS.get(orderId);
		if (order == null || !order.buyerId().equals(buyerId)) {
			return false;
		}
		BUY_ORDERS.remove(orderId);
		if (!save(registries)) {
			BUY_ORDERS.put(orderId, order);
			return false;
		}
		credit(buyerId, order.maxTotal(), registries);
		Ledger.record(buyerId, order.maxTotal(), "order-cancel", Integer.toString(orderId));
		return true;
	}

	/** Every open buy order, lowest id first. */
	static synchronized List<Map.Entry<Integer, BuyOrder>> buyOrders() {
		List<Map.Entry<Integer, BuyOrder>> ordered = new ArrayList<>(BUY_ORDERS.entrySet());
		ordered.sort(Map.Entry.comparingByKey());
		return ordered;
	}

	/**
	 * Tries to fill a fresh listing against every open order. A listing wins
	 * when its item and count match exactly and its price is at or under the
	 * order's ceiling; the buyer pays the listing price (never more than they
	 * allowed), the seller receives the cut of it, and the goods wait in the
	 * buyer's mail if they are offline.
	 *
	 * @return the matched order id, or -1 when the listing stays public
	 */
	static synchronized int matchBuyOrder(int auctionId, RegistryAccess registries) {
		AuctionListing listing = AUCTIONS.get(auctionId);
		if (listing == null) {
			return -1;
		}
		for (Map.Entry<Integer, BuyOrder> candidate : buyOrders()) {
			BuyOrder order = candidate.getValue();
			if (order.item() != listing.stack().getItem() || order.count() != listing.stack().getCount()) {
				continue;
			}
			if (listing.price() > order.maxTotal() || order.buyerId().equals(listing.sellerId())) {
				continue;
			}
			BUY_ORDERS.remove(candidate.getKey());
			AUCTIONS.remove(auctionId);
			long proceeds = auctionCut(listing.price());
			credit(listing.sellerId(), proceeds, registries);
			// The escrow held the ceiling; the difference comes straight back.
			credit(order.buyerId(), order.maxTotal() - listing.price(), registries);
			deliver(order.buyerId(), listing.stack().copy(), "buy order " + candidate.getKey(), registries);
			save(registries);
			Ledger.record(listing.sellerId(), proceeds, "ah-sell", "filled order " + candidate.getKey());
			return candidate.getKey();
		}
		return -1;
	}

	// ---- Mail ---------------------------------------------------------------

	/**
	 * Parks an item for a player who is not around to receive it - an expired
	 * listing, or goods from a buy order filled while they were offline.
	 * /mail claims it.
	 */
	static synchronized void deliver(UUID ownerId, ItemStack stack, String from, RegistryAccess registries) {
		if (stack.isEmpty()) {
			return;
		}
		MAIL.computeIfAbsent(ownerId, ignored -> new ArrayList<>()).add(new MailItem(stack.copy(), from));
		save(registries);
	}

	/** Everything waiting for a player. */
	static synchronized List<MailItem> mailOf(UUID playerId) {
		return List.copyOf(MAIL.getOrDefault(playerId, List.of()));
	}

	/** Claims one piece of mail by index; empty when the slot is not there. */
	static synchronized ItemStack claimMail(UUID playerId, int index, RegistryAccess registries) {
		List<MailItem> items = MAIL.get(playerId);
		if (items == null || index < 0 || index >= items.size()) {
			return ItemStack.EMPTY;
		}
		MailItem item = items.remove(index);
		if (items.isEmpty()) {
			MAIL.remove(playerId);
		}
		save(registries);
		Ledger.record(playerId, 0, "mail-claim", item.from());
		return item.stack();
	}

	// ---- Expiry -------------------------------------------------------------

	/**
	 * Returns every listing whose time is up to its seller's mail. Runs off the
	 * server tick, so a stall nobody bought from cannot sit there forever
	 * occupying a slot.
	 *
	 * @return how many listings expired
	 */
	static synchronized int expireStaleListings(RegistryAccess registries) {
		if (AUCTIONS.isEmpty()) {
			return 0;
		}
		long now = System.currentTimeMillis();
		List<Integer> stale = new ArrayList<>();
		for (Map.Entry<Integer, AuctionListing> entry : AUCTIONS.entrySet()) {
			if (entry.getValue().expiresAtMillis() <= now) {
				stale.add(entry.getKey());
			}
		}
		if (stale.isEmpty()) {
			return 0;
		}
		for (int id : stale) {
			AuctionListing listing = AUCTIONS.remove(id);
			deliver(listing.sellerId(), listing.stack(), "expired listing #" + id, registries);
			Ledger.record(listing.sellerId(), 0, "ah-expire", "id " + id);
		}
		save(registries);
		return stale.size();
	}

	static synchronized boolean credit(UUID playerId, long amount, RegistryAccess registries) {
		if (amount <= 0) {
			return false;
		}
		long oldBalance = balance(playerId);
		long newBalance;
		try {
			newBalance = Math.addExact(oldBalance, amount);
		} catch (ArithmeticException exception) {
			return false;
		}
		BALANCES.put(playerId, newBalance);
		if (!save(registries)) {
			restoreBalance(playerId, oldBalance);
			return false;
		}
		return true;
	}

	static synchronized boolean debit(UUID playerId, long amount, RegistryAccess registries) {
		if (amount <= 0) {
			return false;
		}
		long oldBalance = balance(playerId);
		if (oldBalance < amount) {
			return false;
		}
		long newBalance = oldBalance - amount;
		BALANCES.put(playerId, newBalance);
		if (!save(registries)) {
			restoreBalance(playerId, oldBalance);
			return false;
		}
		return true;
	}

	/**
	 * Sets a balance to an exact figure, replacing whatever was there. This is
	 * the admin /money command's "set" - it does not check what the player can
	 * afford, because the whole point is to put a number there directly.
	 *
	 * @return false when the amount is invalid or it could not be saved
	 */
	static synchronized boolean setBalance(UUID playerId, long amount, RegistryAccess registries) {
		if (amount < 0) {
			return false;
		}
		long oldBalance = balance(playerId);
		if (oldBalance == amount) {
			return true;
		}
		BALANCES.put(playerId, amount);
		if (!save(registries)) {
			restoreBalance(playerId, oldBalance);
			return false;
		}
		return true;
	}

	static synchronized boolean canAfford(UUID playerId, long amount) {
		return amount > 0 && balance(playerId) >= amount;
	}

	static synchronized TransferStatus transfer(UUID fromId, UUID toId, long amount, RegistryAccess registries) {
		if (amount <= 0) {
			return TransferStatus.INVALID_AMOUNT;
		}
		if (fromId.equals(toId)) {
			return TransferStatus.SELF_TRANSFER;
		}
		long fromBalance = balance(fromId);
		if (fromBalance < amount) {
			return TransferStatus.INSUFFICIENT_FUNDS;
		}
		long toBalance = balance(toId);
		// The tax is burned, not credited to anyone: a payment that has to
		// clear two balances is the cheapest inflation sink available.
		long tax = taxOf(amount, Config.getLong("economy.pay_tax_percent"));
		long received = amount - tax;
		long newToBalance;
		try {
			newToBalance = Math.addExact(toBalance, received);
		} catch (ArithmeticException exception) {
			return TransferStatus.STORAGE_ERROR;
		}

		BALANCES.put(fromId, fromBalance - amount);
		BALANCES.put(toId, newToBalance);
		if (!save(registries)) {
			restoreBalance(fromId, fromBalance);
			restoreBalance(toId, toBalance);
			return TransferStatus.STORAGE_ERROR;
		}
		Ledger.record(fromId, -amount, "pay", "to " + toId + " (tax " + tax + ")");
		Ledger.record(toId, received, "pay", "from " + fromId);
		if (tax > 0) {
			Ledger.record(null, -tax, "tax", "pay burn");
		}
		return TransferStatus.SUCCESS;
	}

	/** The tax owed on a gross amount, never rounding up past the amount itself. */
	private static long taxOf(long gross, long percent) {
		if (percent <= 0 || gross <= 0) {
			return 0;
		}
		return Math.min(gross, Math.max(0, gross * percent / 100));
	}

	/** How much of a gross payment survives its tax - the /pay preview. */
	static long afterTax(long gross) {
		return gross - taxOf(gross, Config.getLong("economy.pay_tax_percent"));
	}

	/** The auction house's cut of a sale price - the /ah sell preview. */
	static long auctionCut(long price) {
		return price - taxOf(price, Config.getLong("economy.ah_tax_percent"));
	}

	/**
	 * Lists an item, if the seller has a free stall.
	 *
	 * @return the listing id, or a negative {@link ListResult} code
	 */
	static synchronized int createAuction(UUID sellerId, ItemStack stack, long price, RegistryAccess registries) {
		if (stack.isEmpty() || price <= 0) {
			return ListResult.INVALID;
		}
		if (activeListings(sellerId) >= stallSlots(sellerId)) {
			return ListResult.NO_SLOT;
		}
		int id = nextAuctionId++;
		AUCTIONS.put(id, new AuctionListing(sellerId, price, stack.copy(), System.currentTimeMillis() + auctionMillis()));
		if (!save(registries)) {
			AUCTIONS.remove(id);
			nextAuctionId = id;
			return ListResult.STORAGE_ERROR;
		}
		Ledger.record(sellerId, 0, "ah-list", "id " + id + " for $" + price);
		return id;
	}

	/** Negative codes {@link #createAuction} reports instead of an id. */
	static final class ListResult {
		static final int INVALID = -1;
		static final int NO_SLOT = -2;
		static final int STORAGE_ERROR = -3;

		private ListResult() {
		}
	}

	/** How long a listing stays up, from the config, never less than an hour. */
	static long auctionMillis() {
		return Math.max(1L, Config.getLong("economy.auction_hours")) * 60L * 60L * 1000L;
	}

	/** How many stalls one player is currently using. */
	static synchronized int activeListings(UUID sellerId) {
		int used = 0;
		for (AuctionListing listing : AUCTIONS.values()) {
			if (listing.sellerId().equals(sellerId)) {
				used++;
			}
		}
		return used;
	}

	/** The listing slots a player has, free ones included. */
	static synchronized int stallSlots(UUID playerId) {
		int bought = STALL_SLOTS.getOrDefault(playerId, BASE_STALL_SLOTS);
		return Math.max(BASE_STALL_SLOTS, Math.min(MAX_STALL_SLOTS, bought));
	}

	/** Rent more stall space; each purchase adds {@link #SLOTS_PER_STALL}. */
	static synchronized boolean buyStallSlots(UUID playerId, long price, RegistryAccess registries) {
		int current = stallSlots(playerId);
		if (current >= MAX_STALL_SLOTS) {
			return false;
		}
		if (!debit(playerId, price, registries)) {
			return false;
		}
		STALL_SLOTS.put(playerId, current + SLOTS_PER_STALL);
		if (!save(registries)) {
			STALL_SLOTS.put(playerId, current);
			credit(playerId, price, registries);
			return false;
		}
		Ledger.record(playerId, -price, "stall", "now " + stallSlots(playerId) + " slots");
		return true;
	}

	/** The price of the next stall upgrade - rises while slots are scarce. */
	static long stallPrice(UUID playerId) {
		return 25_000L * Math.max(1, stallSlots(playerId) / BASE_STALL_SLOTS);
	}

	static synchronized Map<Integer, AuctionListing> auctions() {
		return Map.copyOf(AUCTIONS);
	}

	static synchronized PurchaseResult purchase(UUID buyerId, int auctionId, RegistryAccess registries) {
		AuctionListing listing = AUCTIONS.get(auctionId);
		if (listing == null) {
			return new PurchaseResult(BuyStatus.NOT_FOUND, ItemStack.EMPTY);
		}
		if (listing.sellerId().equals(buyerId)) {
			return new PurchaseResult(BuyStatus.OWN_LISTING, ItemStack.EMPTY);
		}
		long buyerBalance = balance(buyerId);
		if (buyerBalance < listing.price()) {
			return new PurchaseResult(BuyStatus.INSUFFICIENT_FUNDS, ItemStack.EMPTY);
		}
		// The house takes its cut; the seller sees the net figure wherever they
		// are shown a sale - here, and in the expiry mail.
		long proceeds = auctionCut(listing.price());
		long sellerBalance = balance(listing.sellerId());
		long newSellerBalance;
		try {
			newSellerBalance = Math.addExact(sellerBalance, proceeds);
		} catch (ArithmeticException exception) {
			return new PurchaseResult(BuyStatus.STORAGE_ERROR, ItemStack.EMPTY);
		}

		BALANCES.put(buyerId, buyerBalance - listing.price());
		BALANCES.put(listing.sellerId(), newSellerBalance);
		AUCTIONS.remove(auctionId);
		if (!save(registries)) {
			restoreBalance(buyerId, buyerBalance);
			restoreBalance(listing.sellerId(), sellerBalance);
			AUCTIONS.put(auctionId, listing);
			return new PurchaseResult(BuyStatus.STORAGE_ERROR, ItemStack.EMPTY);
		}
		Ledger.record(buyerId, -listing.price(), "ah-buy", "id " + auctionId);
		Ledger.record(listing.sellerId(), proceeds, "ah-sell", "id " + auctionId + " (cut "
			+ (listing.price() - proceeds) + ")");
		return new PurchaseResult(BuyStatus.SUCCESS, listing.stack().copy());
	}

	private static boolean save(RegistryAccess registries) {
		if (!readable) {
			try {
				Files.move(DATA_FILE, DATA_FILE.resolveSibling("trimskits-market.bak"), StandardCopyOption.REPLACE_EXISTING);
			} catch (IOException ignored) {
				return false;
			}
			readable = true;
		}
		Properties properties = new Properties();
		properties.setProperty("next-id", Integer.toString(nextAuctionId));
		properties.setProperty("next-order-id", Integer.toString(nextOrderId));
		BALANCES.forEach((playerId, balance) -> properties.setProperty("balance." + playerId, Long.toString(balance)));
		var ops = registries.createSerializationContext(JsonOps.INSTANCE);
		for (Map.Entry<Integer, AuctionListing> entry : AUCTIONS.entrySet()) {
			var encoded = ItemStack.CODEC.encodeStart(ops, entry.getValue().stack()).result();
			if (encoded.isEmpty()) {
				return false;
			}
			String stack = Base64.getEncoder().encodeToString(encoded.get().toString().getBytes(StandardCharsets.UTF_8));
			AuctionListing listing = entry.getValue();
			properties.setProperty("listing." + entry.getKey(),
				listing.sellerId() + "|" + listing.price() + "|" + listing.expiresAtMillis() + "|" + stack);
		}
		for (Map.Entry<Integer, BuyOrder> entry : BUY_ORDERS.entrySet()) {
			BuyOrder order = entry.getValue();
			// The item is stored by its registry name - an order asks for a
			// kind of item, not for one particular enchanted stack.
			String itemKey = BuiltInRegistries.ITEM.getKey(order.item()).toString();
			properties.setProperty("order." + entry.getKey(),
				order.buyerId() + "|" + itemKey + "|" + order.count() + "|" + order.maxTotal());
		}
		for (Map.Entry<UUID, List<MailItem>> entry : MAIL.entrySet()) {
			List<String> encodedEntries = new ArrayList<>();
			for (MailItem item : entry.getValue()) {
				var encoded = ItemStack.CODEC.encodeStart(ops, item.stack()).result();
				if (encoded.isEmpty()) {
					continue;
				}
				String stack = Base64.getEncoder().encodeToString(
					encoded.get().toString().getBytes(StandardCharsets.UTF_8));
				// "from" may contain spaces but never a pipe, so ~ splits safely.
				encodedEntries.add(item.from().replace('|', ' ') + "~" + stack);
			}
			if (!encodedEntries.isEmpty()) {
				properties.setProperty("mail." + entry.getKey(),
					entry.getKey() + "|" + String.join("|", encodedEntries));
			}
		}
		STALL_SLOTS.forEach((playerId, slots) -> {
			if (slots > BASE_STALL_SLOTS) {
				properties.setProperty("slots." + playerId, Integer.toString(slots));
			}
		});

		Path temporaryFile = DATA_FILE.resolveSibling("trimskits-market.tmp");
		try {
			Files.createDirectories(DATA_FILE.getParent());
			try (OutputStream output = Files.newOutputStream(temporaryFile)) {
				properties.store(output, "Trim Kits economy and auction listings");
			}
			try {
				Files.move(temporaryFile, DATA_FILE, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
			} catch (AtomicMoveNotSupportedException exception) {
				// Some filesystems cannot rename atomically. Without this
				// fallback every transaction would report STORAGE_ERROR and
				// roll back, so the whole economy would stop working.
				Files.move(temporaryFile, DATA_FILE, StandardCopyOption.REPLACE_EXISTING);
			}
			return true;
		} catch (IOException exception) {
			return false;
		}
	}

	private static void restoreBalance(UUID playerId, long balance) {
		if (balance == 0) {
			BALANCES.remove(playerId);
		} else {
			BALANCES.put(playerId, balance);
		}
	}

	enum BuyStatus {
		SUCCESS,
		NOT_FOUND,
		OWN_LISTING,
		INSUFFICIENT_FUNDS,
		STORAGE_ERROR
	}

	enum TransferStatus {
		SUCCESS,
		INVALID_AMOUNT,
		SELF_TRANSFER,
		INSUFFICIENT_FUNDS,
		STORAGE_ERROR
	}

	record BalanceEntry(UUID playerId, long amount) {
	}

	/**
	 * One stall. {@code expiresAtMillis} is a wall-clock deadline rather than a
	 * duration, so a listing's remaining time survives restarts unchanged.
	 */
	record AuctionListing(UUID sellerId, long price, ItemStack stack, long expiresAtMillis) {
	}

	/**
	 * A standing order to buy. Stored by item <em>type</em> and count - an order
	 * asks for a kind of goods, not for one particular enchanted stack - and
	 * its {@code maxTotal} is held in escrow from the moment it is placed.
	 */
	record BuyOrder(UUID buyerId, Item item, int count, long maxTotal) {
	}

	/** One piece of a player's unclaimed mail, with where it came from. */
	record MailItem(ItemStack stack, String from) {
	}

	record PurchaseResult(BuyStatus status, ItemStack stack) {
	}
}