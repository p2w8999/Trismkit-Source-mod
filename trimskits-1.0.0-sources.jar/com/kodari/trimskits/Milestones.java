package com.kodari.trimskits;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Playtime milestones: a one-off shard bonus for every stretch of time spent
 * on the server.
 *
 * <p>The thresholds are pure hours played, taken from the same counter the
 * sidebar and /shards use, so a milestone cannot be farmed by dying or
 * relogging - only by actually being around. Each is claimed once, and the
 * claim is stored per player, so the bonus is a genuine reward rather than a
 * rate that a long session would run away with.
 *
 * <p>Rewards are paid as a shard bonus through {@link Shards#adminGive}, so
 * they show up as a top-up beside earned shards instead of being folded into
 * the play-derived figure and making /shards lie.
 */
final class Milestones {
	private static final Logger LOGGER = LoggerFactory.getLogger("trimskits");
	private static final Path DATA_FILE = Path.of("config", "trimskits-milestones.properties");

	/** One milestone: hours played, and the shards it pays. */
	record Milestone(long hours, long shards, String label) {
	}

	/** The ladder. Spaced so the early ones arrive in an evening. */
	static final List<Milestone> LADDER = List.of(
		new Milestone(1, 25, "First hour"),
		new Milestone(5, 75, "Settling in"),
		new Milestone(10, 150, "Regular"),
		new Milestone(25, 400, "Committed"),
		new Milestone(50, 900, "Veteran"),
		new Milestone(100, 2000, "Centurion"),
		new Milestone(200, 4500, "Lifer"),
		new Milestone(500, 12000, "Server pillar")
	);

	/** UUID -> the highest milestone index already claimed. */
	private static final Map<UUID, Integer> CLAIMED = new HashMap<>();
	private static boolean loaded;
	private static boolean readable = true;

	private Milestones() {
	}

	/** How many hours this player has played. */
	static long hoursPlayed(UUID playerId) {
		return PlayerStats.playtimeSeconds(playerId) / 3600L;
	}

	/** True when this milestone is reached but not yet claimed. */
	static boolean claimable(UUID playerId, Milestone milestone) {
		return hoursPlayed(playerId) >= milestone.hours() && !claimed(playerId, milestone);
	}

	/** True once a milestone has been paid out. */
	static boolean claimed(UUID playerId, Milestone milestone) {
		load();
		return CLAIMED.getOrDefault(playerId, -1) >= indexOf(milestone);
	}

	/** The index of a milestone in the ladder. */
	private static int indexOf(Milestone milestone) {
		int index = LADDER.indexOf(milestone);
		return index < 0 ? Integer.MAX_VALUE : index;
	}

	/**
	 * Pays out one milestone, once.
	 *
	 * @return null on success, or the reason it did not happen
	 */
	static synchronized String claim(UUID playerId, Milestone milestone) {
		load();
		if (hoursPlayed(playerId) < milestone.hours()) {
			return "Play for " + milestone.hours() + " hours to unlock this.";
		}
		if (claimed(playerId, milestone)) {
			return "You already claimed that milestone.";
		}
		String error = Shards.adminGive(playerId, milestone.shards());
		if (error != null) {
			return error;
		}
		CLAIMED.put(playerId, Math.max(CLAIMED.getOrDefault(playerId, -1), indexOf(milestone)));
		save();
		return null;
	}

	/** The next milestone still to claim, or null when the ladder is done. */
	static Milestone nextUnclaimed(UUID playerId) {
		for (Milestone milestone : LADDER) {
			if (!claimed(playerId, milestone)) {
				return milestone;
			}
		}
		return null;
	}

	// ---- Persistence --------------------------------------------------------

	private static void load() {
		if (loaded) {
			return;
		}
		loaded = true;
		if (!Files.exists(DATA_FILE)) {
			return;
		}
		Properties properties = new Properties();
		try (InputStream input = Files.newInputStream(DATA_FILE)) {
			properties.load(input);
		} catch (IOException exception) {
			readable = false;
			LOGGER.warn("Could not read {}; milestones stay in memory only.", DATA_FILE);
			return;
		}
		for (String key : properties.stringPropertyNames()) {
			try {
				if (key.startsWith("claimed.")) {
					CLAIMED.put(UUID.fromString(key.substring("claimed.".length())),
						Integer.parseInt(properties.getProperty(key)));
				}
			} catch (RuntimeException ignored) {
				// Skip a damaged line.
			}
		}
	}

	private static boolean save() {
		if (!readable) {
			return false;
		}
		Properties properties = new Properties();
		CLAIMED.forEach((playerId, index) ->
			properties.setProperty("claimed." + playerId, Integer.toString(index)));
		Path temporaryFile = DATA_FILE.resolveSibling("trimskits-milestones.tmp");
		try {
			Files.createDirectories(DATA_FILE.getParent());
			try (OutputStream output = Files.newOutputStream(temporaryFile)) {
				properties.store(output, "Trim Kits playtime milestones");
			}
			try {
				Files.move(temporaryFile, DATA_FILE, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
			} catch (AtomicMoveNotSupportedException exception) {
				Files.move(temporaryFile, DATA_FILE, StandardCopyOption.REPLACE_EXISTING);
			}
			return true;
		} catch (IOException exception) {
			LOGGER.warn("Could not save milestones: {}", exception.getMessage());
			return false;
		}
	}
}
