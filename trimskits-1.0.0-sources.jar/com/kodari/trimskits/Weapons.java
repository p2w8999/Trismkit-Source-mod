package com.kodari.trimskits;

import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.core.Registry;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlotGroup;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.component.ItemAttributeModifiers;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Alpha event weapons - four custom items shipped with their own textures,
 * models and names inside the mod's assets, so no resource pack is needed.
 *
 * <p>Every item API used here has an identical descriptor on 26.1, 26.2 and
 * 26.3 (verified with javap against each deobf jar), so this file is
 * version-safe as-is; the only drifting surface - the entity type constants
 * used by the Thunder Axe's on-hit lightning - goes through
 * {@link Compat#spawnEntity}.</p>
 *
 * <p>Stats are alpha placeholders and can be tuned freely; the ids
 * {@code trimskits:void_blade} etc. must not change once players own the
 * items. Obtainable via {@code /sfmode weapons} and the combat creative tab.
 * The on-hit effects only ADD to the vanilla attack (the callback always
 * returns PASS), so plain damage, sounds and knockback stay intact.</p>
 */
final class Weapons {
	/** Dark violet blade with a cyan-gem guard; on hit: Wither II 5s. Fireproof. */
	public static final Item VOID_BLADE = register("void_blade", 11.0, -2.6, 2200, true);

	/** Golden head with a blue lightning crack; on hit: lightning on the target. */
	public static final Item THUNDER_AXE = register("thunder_axe", 9.0, -3.0, 1800, false);

	/** Short icy blade; fast; on hit: Slowness III 5s. */
	public static final Item FROST_DAGGER = register("frost_dagger", 5.0, -1.2, 1200, false);

	/** Slow and massive; on hit: launches the target away from the attacker. */
	public static final Item WAR_HAMMER = register("war_hammer", 14.0, -3.4, 1600, false);

	private Weapons() {
	}

	/**
	 * Called once from {@code TrimKits.onInitialize}. The items themselves
	 * already registered in their static initializers above; this adds the
	 * on-hit effect callback.
	 */
	static void register() {
		AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
			onHit(player, world, hand, entity);
			// PASS keeps the vanilla attack (damage, sound, particles) intact.
			return InteractionResult.PASS;
		});
	}

	/**
	 * Registers one weapon. The damage modifier is the advertised total minus
	 * the one point of base unarmed damage - exactly how vanilla tools do it -
	 * so the tooltip reads the intended number.
	 */
	private static Item register(String path, double damage, double speed, int durability, boolean fireproof) {
		Identifier id = Identifier.fromNamespaceAndPath("trimskits", path);
		Item.Properties properties = new Item.Properties()
			.setId(ResourceKey.create(Registries.ITEM, id))
			.stacksTo(1)
			.durability(durability)
			.rarity(Rarity.EPIC)
			// Epic purple name plus the enchant shine, without enchantments.
			.component(DataComponents.ENCHANTMENT_GLINT_OVERRIDE, Boolean.TRUE)
			.attributes(ItemAttributeModifiers.builder()
				.add(Attributes.ATTACK_DAMAGE, new AttributeModifier(
					Identifier.fromNamespaceAndPath("trimskits", path + "_damage"),
					damage - 1.0, AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.MAINHAND)
				.add(Attributes.ATTACK_SPEED, new AttributeModifier(
					Identifier.fromNamespaceAndPath("trimskits", path + "_speed"),
					speed, AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.MAINHAND)
				.build());
		if (fireproof) {
			properties.fireResistant();
		}
		return Registry.register(BuiltInRegistries.ITEM, id, new Item(properties));
	}

	/** Applies the weapon's extra effect on top of the vanilla attack. */
	private static void onHit(Player player, Level world, InteractionHand hand, Entity target) {
		if (world.isClientSide() || target == player || !(target instanceof LivingEntity victim)) {
			return;
		}
		Item held = player.getItemInHand(hand).getItem();
		if (held == VOID_BLADE) {
			victim.addEffect(new MobEffectInstance(MobEffects.WITHER, 100, 1));
		} else if (held == THUNDER_AXE) {
			if (world instanceof ServerLevel serverLevel) {
				Compat.spawnEntity(serverLevel, victim.getX(), victim.getY(), victim.getZ(), "LIGHTNING_BOLT");
			}
		} else if (held == FROST_DAGGER) {
			victim.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 100, 2));
		} else if (held == WAR_HAMMER) {
			Vec3 away = victim.position().subtract(player.position());
			double length = Math.sqrt(away.x * away.x + away.z * away.z);
			if (length > 1.0e-3) {
				away = away.scale(1.0 / length);
			}
			victim.push(away.x * 2.4, 0.55, away.z * 2.4);
			victim.needsSync = true; // resend velocity to clients
		}
	}
}
