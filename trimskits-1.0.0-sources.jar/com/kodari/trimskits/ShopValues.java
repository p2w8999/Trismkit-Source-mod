package com.kodari.trimskits;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.ChatFormatting;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.RegistryAccess;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.ItemEnchantments;

/**
 * Price list for /sell, /worth and /prices.
 *
 * <p>Two layers of pricing:
 * <ol>
 *   <li>A curated list of the items that matter most (ores, food, mob drops, gear).
 *       These are declared first so their prices win and stay stable — existing
 *       balances and auction listings keep their meaning across updates.</li>
 *   <li>Every other item in the game - blocks, tools, armour, food and mob drops
 *       alike - is priced automatically from {@link #PRICE_RULES} (plus a
 *       material &times; slot formula for tools and armour), matched against its
 *       registry id. That is what makes literally everything buyable and sellable
 *       without hand-writing thousands of entries.</li>
 * </ol>
 *
 * <p>Entries keep their declaration order, which is the order the sell GUI shows
 * them in, so related blocks and ores sit next to each other.
 */
final class ShopValues {
	/**
	 * One thing the shop trades.
	 *
	 * <p>{@code template} is null for ordinary items. It is set for anything
	 * whose identity lives in components - enchanted books, and the
	 * custom-enchanted gear - so the shop can tell "Sharpness V" from
	 * "Sharpness III" even though both are the same enchanted book item, and so
	 * a buyer receives the real thing rather than a plain copy.
	 *
	 * <p>{@code name} is what search matches and what the GUI shows. It is not
	 * always the item's own name, for exactly the reason above.
	 */
	record Entry(Item item, long price, String category, ItemStack template, String name) {
		Entry(Item item, long price, String category) {
			this(item, price, category, null, displayName(item));
		}

		/** The stack handed to a buyer, components intact. */
		ItemStack createStack(int count) {
			return template == null
				? new ItemStack(item, Math.max(1, count))
				: template.copyWithCount(Math.max(1, count));
		}

		/** The stack drawn as an icon; the template with its own name on it. */
		ItemStack displayStack() {
			return template == null ? new ItemStack(item) : template.copy();
		}
	}

	private static final Map<Item, List<Entry>> BY_ITEM = new LinkedHashMap<>();
	/** Insertion-ordered list backing the GUI and /worth lookups. */
	private static final List<Entry> ALL = new ArrayList<>();
	/** Categories in display order, filled as entries are added. */
	private static final List<String> CATEGORY_ORDER = new ArrayList<>();

	/**
	 * The live market multiplier on each entry's list price, keyed by entry
	 * identity. An entry rolls its factor the first time anyone looks at it;
	 * {@link #tickMarket} re-rolls a quarter of the shop every minute after
	 * that, so prices never sit still and the occasional jackpot window turns
	 * a $200 block into millions for as long as it lasts.
	 *
	 * <p>Books swing along with everything else. That is safe only because an
	 * enchant's sell bonus is <em>defined</em> as its book's current price
	 * (see {@link #enchantWorth}), so every trade that mixes a book with gear
	 * still nets out to exactly zero on the same tick.
	 */
	private static final Map<Entry, Double> MARKET = new IdentityHashMap<>();
	/**
	 * Admin price overrides from {@code /trimskits admin setprice}, keyed by
	 * item id and persisted to {@code config/trimskits-prices.properties}.
	 *
	 * <p>These win over the rolling market factor so an admin can pin an item
	 * to a specific value (or remove it from trade with 0). They are stored by
	 * stable item id rather than by entry, so the pin survives a reload and
	 * applies to every variant of the item.
	 */
	private static final Map<String, Long> PRICE_OVERRIDES = new HashMap<>();
	private static final java.nio.file.Path PRICE_FILE =
		java.nio.file.Path.of("config", "trimskits-prices.properties");
	private static boolean pricesLoaded;
	/** Every level of every vanilla enchant book, so bonuses track book prices. */
	private static final Map<BookKey, Entry> VANILLA_BOOKS = new HashMap<>();
	/** This server's custom enchant books (one per type, always max level). */
	private static final Map<CustomEnchants.Type, Entry> CUSTOM_BOOKS = new HashMap<>();

	/** One quarter of the shop re-rolls each interval (60 seconds of ticks). */
	private static final long MARKET_INTERVAL_TICKS = 1_200L;
	private static final int MARKET_SLICES = 4;
	/** Sanity ceiling so a jackpot on a pricey entry cannot crowd out totals. */
	private static final long MARKET_MAX = 1_000_000_000_000L;

	/**
	 * One level of one enchantment's book. Registry holders are singletons per
	 * server, so this record matches the holder on a priced stack against the
	 * one the book was registered under.
	 */
	private record BookKey(Holder<Enchantment> enchant, int level) { }

	/**
	 * Blocks that are never sold: they hold other items, they are administrative,
	 * or losing one would be a disaster rather than a trade.
	 */
	private static final Set<String> NEVER_SOLD = Set.of(
		"air", "cave_air", "void_air", "barrier", "light", "light_block", "structure_void",
		"bedrock", "command_block", "chain_command_block", "repeating_command_block",
		"structure_block", "jigsaw", "moving_piston", "piston_head",
		"spawner", "trial_spawner", "reinforced_deepslate",
		"shulker_box", "ender_chest", "decorated_pot", "banner"
	);

	/**
	 * Non-block items whose value lives in data rather than the item itself: a
	 * written book, a filled map, a potion with NBT or a stack of spawn eggs
	 * cannot be priced by id alone, so they stay out of the shop.
	 */
	private static final Set<String> NEVER_SOLD_ITEMS = Set.of(
		"spawn_egg", "potion", "splash_potion", "lingering_potion", "tipped_arrow",
		"written_book", "knowledge_book", "filled_map", "enchanted_book",
		"player_head", "banner_pattern", "goat_horn", "suspicious_stew",
		"suspicious_sand", "suspicious_gravel", "debug_stick", "ominous_bottle",
		"ominous_trial_key", "trial_key", "name_tag"
	);

	/**
	 * Flat sell bonus granted per level of a custom (lore) enchant on gear.
	 *
	 * <p>Deliberately kept under the resale ceiling of the cheapest pre-made
	 * gear ({@code Explorer's Blade}: 130 + 2 x 2,900 = 5,930 &lt; 6,000) so
	 * buying shop gear and selling it straight back can never turn a profit,
	 * while enchanted items still fetch several times the plain price.
	 */
	private static final long CUSTOM_ENCHANT_SELL_BONUS = 2_900L;

	/**
	 * Money price of one level of a custom enchant book. The buy menu charges
	 * the same per level, so adding an enchant there and reselling the item is
	 * always a loss rather than a money printer.
	 */
	private static final long CUSTOM_BOOK_PRICE = 4_000L;

	/**
	 * Ordered, substring-matched pricing rules for anything not in the curated
	 * list. First match wins, so the most specific rule comes first — this is
	 * why "sandstone" is listed before the broad "stone" rule, and why gear is
	 * matched before the material it is made from.
	 */
	private record BlockRule(String needle, long price, String category) {
	}

	/** Base price per material, used to price tools and armour consistently. */
	private record GearMaterial(String prefix, long price) {
	}

	/** Which gear slot an id ends with, and how that slot scales the material. */
	private record GearSlot(String suffix, double factor, String category) {
	}

	private static final List<GearMaterial> GEAR_MATERIALS = List.of(
		// Netherite gear is endgame treasure: a netherite sword lands at ~$1.5M
		// and a chestplate at ~$3.3M, so a full set is a genuine millions-level
		// asset rather than pocket change.
		new GearMaterial("netherite", 1_500_000),
		new GearMaterial("diamond", 130),
		new GearMaterial("copper", 15),
		new GearMaterial("golden", 25),
		new GearMaterial("iron", 40),
		new GearMaterial("chainmail", 45),
		new GearMaterial("stone", 20),
		new GearMaterial("wooden", 10),
		new GearMaterial("leather", 8),
		new GearMaterial("turtle", 300)
	);

	private static final List<GearSlot> GEAR_SLOTS = List.of(
		new GearSlot("sword", 1.0, "Weapons"),
		new GearSlot("pickaxe", 1.2, "Tools"),
		new GearSlot("axe", 0.9, "Tools"),
		new GearSlot("shovel", 0.5, "Tools"),
		new GearSlot("hoe", 0.6, "Tools"),
		new GearSlot("helmet", 1.4, "Armor"),
		new GearSlot("chestplate", 2.2, "Armor"),
		new GearSlot("leggings", 1.9, "Armor"),
		new GearSlot("boots", 1.5, "Armor")
	);

	private static final List<BlockRule> PRICE_RULES = List.of(
		// --- gear with no material prefix, before anything else ---
		new BlockRule("trident", 900, "Weapons"),
		new BlockRule("mace", 1_200, "Weapons"),
		new BlockRule("crossbow", 180, "Weapons"),
		new BlockRule("bow", 150, "Weapons"),
		new BlockRule("shield", 80, "Weapons"),
		new BlockRule("spectral_arrow", 4, "Weapons"),
		new BlockRule("arrow", 3, "Weapons"),
		new BlockRule("firework_rocket", 3, "Weapons"),
		new BlockRule("fishing_rod", 30, "Tools"),
		new BlockRule("flint_and_steel", 25, "Tools"),
		new BlockRule("carrot_on_a_stick", 25, "Tools"),
		new BlockRule("warped_fungus_on_a_stick", 30, "Tools"),
		new BlockRule("shears", 30, "Tools"),
		new BlockRule("brush", 20, "Tools"),
		new BlockRule("spyglass", 60, "Tools"),
		new BlockRule("recovery_compass", 200, "Tools"),
		new BlockRule("compass", 40, "Tools"),
		new BlockRule("clock", 60, "Tools"),
		new BlockRule("saddle", 300, "Tools"),
		new BlockRule("horse_armor", 150, "Tools"),
		new BlockRule("lead", 4, "Tools"),
		new BlockRule("painting", 15, "Decoration"),
		new BlockRule("item_frame", 30, "Decoration"),
		new BlockRule("armor_stand", 40, "Decoration"),
		new BlockRule("flower_pot", 8, "Decoration"),
		new BlockRule("leather", 5, "Mob Drops"),

		// --- minerals, most valuable first ---
		new BlockRule("netherite", 1_500_000, "Netherite"),
		new BlockRule("ancient_debris", 600_000, "Netherite"),
		new BlockRule("diamond", 150, "Diamond"),
		new BlockRule("emerald", 55, "Emerald"),
		new BlockRule("amethyst", 15, "Amethyst"),
		new BlockRule("lapis", 18, "Lapis"),
		new BlockRule("redstone", 12, "Redstone"),
		new BlockRule("gilded", 30, "Gold"),
		new BlockRule("gold", 25, "Gold"),
		new BlockRule("iron", 12, "Iron"),
		new BlockRule("copper", 5, "Copper"),
		new BlockRule("coal", 6, "Coal"),
		new BlockRule("quartz", 9, "Quartz"),

		// --- sea ---
		new BlockRule("sea_lantern", 30, "Sea"),
		new BlockRule("prismarine", 12, "Sea"),
		new BlockRule("sponge", 60, "Sea"),
		new BlockRule("conduit", 5_000, "Sea"),
		new BlockRule("coral", 6, "Sea"),
		new BlockRule("sea_pickle", 8, "Sea"),
		new BlockRule("kelp", 1, "Sea"),

		// --- wood, every shape of every species ---
		new BlockRule("pale_oak", 2, "Wood"),
		new BlockRule("dark_oak", 2, "Wood"),
		new BlockRule("mangrove", 2, "Wood"),
		new BlockRule("cherry", 2, "Wood"),
		new BlockRule("bamboo", 1, "Wood"),
		new BlockRule("spruce", 2, "Wood"),
		new BlockRule("birch", 2, "Wood"),
		new BlockRule("jungle", 2, "Wood"),
		new BlockRule("acacia", 2, "Wood"),
		new BlockRule("oak", 2, "Wood"),

		// --- nether ---
		new BlockRule("nether_brick", 10, "Nether"),
		new BlockRule("netherrack", 1, "Nether"),
		new BlockRule("blackstone", 3, "Nether"),
		new BlockRule("basalt", 2, "Nether"),
		new BlockRule("soul_sand", 3, "Nether"),
		new BlockRule("soul_soil", 3, "Nether"),
		new BlockRule("soul_", 3, "Nether"),
		new BlockRule("magma", 25, "Nether"),
		new BlockRule("crimson", 2, "Nether"),
		new BlockRule("warped", 2, "Nether"),
		new BlockRule("glowstone", 15, "Nether"),
		new BlockRule("shroomlight", 12, "Nether"),
		new BlockRule("obsidian", 40, "Nether"),
		new BlockRule("nether_wart", 6, "Nether"),
		new BlockRule("nether", 4, "Nether"),

		// --- end ---
		new BlockRule("end_stone", 4, "End"),
		new BlockRule("purpur", 10, "End"),
		new BlockRule("chorus", 12, "End"),
		new BlockRule("end_rod", 10, "End"),
		new BlockRule("dragon", 120, "End"),
		new BlockRule("end_", 6, "End"),

		// --- stone materials ---
		new BlockRule("sandstone", 3, "Stone & Sand"),
		new BlockRule("deepslate", 3, "Stone & Sand"),
		new BlockRule("tuff", 2, "Stone & Sand"),
		new BlockRule("granite", 2, "Stone & Sand"),
		new BlockRule("diorite", 2, "Stone & Sand"),
		new BlockRule("andesite", 2, "Stone & Sand"),
		new BlockRule("mossy", 2, "Stone & Sand"),
		new BlockRule("cobblestone", 1, "Stone & Sand"),
		new BlockRule("bricks", 4, "Stone & Sand"),

		// --- functional blocks ---
		new BlockRule("blast_furnace", 12, "Utility"),
		new BlockRule("crafting_table", 8, "Utility"),
		new BlockRule("stonecutter", 10, "Utility"),
		new BlockRule("smithing_table", 20, "Utility"),
		new BlockRule("cartography_table", 10, "Utility"),
		new BlockRule("fletching_table", 10, "Utility"),
		new BlockRule("enchanting_table", 120, "Utility"),
		new BlockRule("brewing_stand", 40, "Utility"),
		new BlockRule("grindstone", 15, "Utility"),
		new BlockRule("furnace", 10, "Utility"),
		new BlockRule("smoker", 12, "Utility"),
		new BlockRule("composter", 6, "Utility"),
		new BlockRule("lectern", 12, "Utility"),
		new BlockRule("campfire", 8, "Utility"),
		new BlockRule("barrel", 8, "Utility"),
		new BlockRule("beacon", 2_000_000, "Utility"),
		new BlockRule("anvil", 40, "Utility"),
		new BlockRule("chest", 10, "Utility"),
		new BlockRule("ladder", 1, "Utility"),
		new BlockRule("bell", 60, "Utility"),
		new BlockRule("tnt", 30, "Utility"),

		// --- redstone ---
		new BlockRule("daylight_detector", 15, "Redstone"),
		new BlockRule("note_block", 10, "Redstone"),
		new BlockRule("dispenser", 20, "Redstone"),
		new BlockRule("observer", 25, "Redstone"),
		new BlockRule("repeater", 10, "Redstone"),
		new BlockRule("comparator", 12, "Redstone"),
		new BlockRule("dropper", 15, "Redstone"),
		new BlockRule("hopper", 40, "Redstone"),
		new BlockRule("piston", 15, "Redstone"),
		new BlockRule("redstone_torch", 6, "Redstone"),
		new BlockRule("pressure_plate", 2, "Redstone"),
		new BlockRule("tripwire", 2, "Redstone"),
		new BlockRule("target", 8, "Redstone"),
		new BlockRule("rail", 4, "Redstone"),
		new BlockRule("lever", 2, "Redstone"),

		// --- loose items: foods, drops and materials that are not blocks ---
		new BlockRule("golden_apple", 900, "Food"),
		new BlockRule("glistering_melon_slice", 45, "Food"),
		new BlockRule("golden_carrot", 120, "Food"),
		new BlockRule("mushroom_stew", 12, "Food"),
		new BlockRule("beetroot_soup", 12, "Food"),
		new BlockRule("rabbit_stew", 20, "Food"),
		new BlockRule("bread", 8, "Food"),
		new BlockRule("baked_potato", 6, "Food"),
		new BlockRule("cookie", 5, "Food"),
		new BlockRule("cake", 40, "Food"),
		new BlockRule("honey_bottle", 8, "Food"),
		new BlockRule("honeycomb", 6, "Food"),
		new BlockRule("apple", 4, "Food"),
		new BlockRule("melon_slice", 3, "Food"),
		new BlockRule("sweet_berries", 3, "Food"),
		new BlockRule("glow_berries", 4, "Food"),
		new BlockRule("chorus_fruit", 6, "Food"),
		new BlockRule("popped_chorus_fruit", 8, "Food"),
		new BlockRule("beetroot", 4, "Food"),
		new BlockRule("carrot", 4, "Food"),
		new BlockRule("potato", 4, "Food"),
		new BlockRule("wheat", 3, "Crops"),
		new BlockRule("seeds", 1, "Crops"),
		new BlockRule("cocoa_beans", 5, "Crops"),
		new BlockRule("sugar_cane", 2, "Crops"),
		new BlockRule("nether_wart", 6, "Crops"),
		new BlockRule("magma_cream", 12, "Mob Drops"),
		new BlockRule("blaze_powder", 12, "Mob Drops"),
		new BlockRule("blaze_rod", 24, "Mob Drops"),
		new BlockRule("ghast_tear", 40, "Mob Drops"),
		new BlockRule("ender_pearl", 20, "Mob Drops"),
		new BlockRule("ender_eye", 15, "Mob Drops"),
		new BlockRule("dragon_breath", 120, "Mob Drops"),
		new BlockRule("shulker_shell", 500_000, "Mob Drops"),
		new BlockRule("slime_ball", 10, "Mob Drops"),
		new BlockRule("spider_eye", 4, "Mob Drops"),
		new BlockRule("rotten_flesh", 1, "Mob Drops"),
		new BlockRule("gunpowder", 5, "Mob Drops"),
		new BlockRule("bone_meal", 2, "Mob Drops"),
		new BlockRule("bone", 4, "Mob Drops"),
		new BlockRule("string", 4, "Mob Drops"),
		new BlockRule("leather", 5, "Mob Drops"),
		new BlockRule("feather", 3, "Mob Drops"),
		new BlockRule("rabbit_hide", 2, "Mob Drops"),
		new BlockRule("rabbit_foot", 15, "Mob Drops"),
		new BlockRule("nautilus_shell", 300, "Mob Drops"),
		new BlockRule("prismarine_crystals", 16, "Mob Drops"),
		new BlockRule("prismarine_shard", 8, "Mob Drops"),
		new BlockRule("experience_bottle", 25, "Mob Drops"),
		new BlockRule("glowstone_dust", 4, "Mob Drops"),
		new BlockRule("nether_star", 5_000_000, "Nether & End"),
		new BlockRule("totem_of_undying", 2_000_000, "Nether & End"),
		new BlockRule("end_crystal", 1_000_000, "Nether & End"),
		new BlockRule("smithing_template", 1_500, "Rare"),
		new BlockRule("water_bucket", 20, "Utility"),
		new BlockRule("lava_bucket", 60, "Utility"),
		new BlockRule("milk_bucket", 10, "Utility"),
		new BlockRule("bucket", 5, "Utility"),
		new BlockRule("flint", 3, "Utility"),
		new BlockRule("clay_ball", 4, "Utility"),

		// --- shapes, for anything not already claimed by a material ---
		new BlockRule("trapdoor", 3, "Building Blocks"),
		new BlockRule("fence_gate", 3, "Building Blocks"),
		new BlockRule("stairs", 2, "Building Blocks"),
		new BlockRule("fence", 2, "Building Blocks"),
		new BlockRule("door", 3, "Building Blocks"),
		new BlockRule("button", 1, "Building Blocks"),
		new BlockRule("sign", 2, "Building Blocks"),
		new BlockRule("glass_pane", 1, "Building Blocks"),
		new BlockRule("glass", 2, "Building Blocks"),
		new BlockRule("carpet", 2, "Colored Blocks"),
		new BlockRule("wool", 3, "Colored Blocks"),
		new BlockRule("slab", 1, "Building Blocks"),
		new BlockRule("wall", 2, "Building Blocks"),

		// --- broad terrain, deliberately last ---
		new BlockRule("grass", 2, "Nature"),
		new BlockRule("podzol", 4, "Nature"),
		new BlockRule("mycelium", 5, "Nature"),
		new BlockRule("leaves", 1, "Nature"),
		new BlockRule("sapling", 2, "Nature"),
		new BlockRule("roots", 3, "Nature"),
		new BlockRule("moss", 4, "Nature"),
		new BlockRule("vine", 2, "Nature"),
		new BlockRule("dirt", 1, "Nature"),
		new BlockRule("mud", 2, "Nature"),
		new BlockRule("snow", 3, "Nature"),
		new BlockRule("ice", 5, "Nature"),
		new BlockRule("sand", 2, "Stone & Sand"),
		new BlockRule("gravel", 2, "Stone & Sand"),
		new BlockRule("clay", 4, "Stone & Sand"),
		new BlockRule("stone", 1, "Stone & Sand")
	);

	/** Icon used by the category picker in the sell GUI. */
	private static final Map<String, Item> CATEGORY_ICONS = new LinkedHashMap<>();

	private ShopValues() {
	}

	static {
		// --- Netherite ---
		// Endgame treasure: a netherite ingot is worth millions and a full block
		// tens of millions, so mining ancient debris actually pays off.
		add(Items.NETHERITE_BLOCK, 9_000_000, "Netherite");
		add(Items.NETHERITE_INGOT, 1_000_000, "Netherite");
		add(Items.NETHERITE_SCRAP, 250_000, "Netherite");
		add(Items.ANCIENT_DEBRIS, 600_000, "Netherite");

		// --- Diamond ---
		add(Items.DIAMOND_BLOCK, 800, "Diamond");
		add(Items.DIAMOND, 100, "Diamond");

		// --- Emerald ---
		add(Items.EMERALD_BLOCK, 350, "Emerald");
		add(Items.EMERALD, 40, "Emerald");

		// --- Gold ---
		add(Items.GOLD_BLOCK, 180, "Gold");
		add(Items.GOLD_INGOT, 20, "Gold");
		add(Items.GOLD_NUGGET, 3, "Gold");
		add(Items.RAW_GOLD_BLOCK, 170, "Gold");
		add(Items.RAW_GOLD, 18, "Gold");
		add(Items.NETHER_GOLD_ORE, 22, "Gold");
		add(Items.GILDED_BLACKSTONE, 30, "Gold");

		// --- Iron ---
		add(Items.IRON_BLOCK, 90, "Iron");
		add(Items.IRON_INGOT, 10, "Iron");
		add(Items.IRON_NUGGET, 2, "Iron");
		add(Items.RAW_IRON_BLOCK, 85, "Iron");
		add(Items.RAW_IRON, 9, "Iron");

		// --- Copper ---
		add(Items.COPPER_INGOT, 5, "Copper");
		add(Items.RAW_COPPER_BLOCK, 25, "Copper");
		add(Items.RAW_COPPER, 3, "Copper");
		add(Items.COPPER_ORE, 6, "Copper");
		add(Items.DEEPSLATE_COPPER_ORE, 6, "Copper");

		// --- Redstone ---
		add(Items.REDSTONE_BLOCK, 18, "Redstone");
		add(Items.REDSTONE, 2, "Redstone");
		add(Items.REDSTONE_ORE, 4, "Redstone");
		add(Items.DEEPSLATE_REDSTONE_ORE, 4, "Redstone");

		// --- Lapis ---
		add(Items.LAPIS_BLOCK, 27, "Lapis");
		add(Items.LAPIS_LAZULI, 3, "Lapis");
		add(Items.LAPIS_ORE, 6, "Lapis");
		add(Items.DEEPSLATE_LAPIS_ORE, 6, "Lapis");

		// --- Coal ---
		add(Items.COAL_BLOCK, 18, "Coal");
		add(Items.COAL, 2, "Coal");
		add(Items.COAL_ORE, 4, "Coal");
		add(Items.DEEPSLATE_COAL_ORE, 4, "Coal");

		// --- Quartz ---
		add(Items.QUARTZ_BLOCK, 72, "Quartz");
		add(Items.QUARTZ, 8, "Quartz");
		add(Items.NETHER_QUARTZ_ORE, 9, "Quartz");

		// --- Amethyst ---
		add(Items.AMETHYST_BLOCK, 45, "Amethyst");
		add(Items.AMETHYST_SHARD, 5, "Amethyst");

		// --- Ores (block value for the ore itself) ---
		add(Items.DIAMOND_ORE, 105, "Diamond");
		add(Items.DEEPSLATE_DIAMOND_ORE, 105, "Diamond");
		add(Items.EMERALD_ORE, 45, "Emerald");
		add(Items.DEEPSLATE_EMERALD_ORE, 45, "Emerald");
		add(Items.IRON_ORE, 12, "Iron");
		add(Items.DEEPSLATE_IRON_ORE, 12, "Iron");
		add(Items.GOLD_ORE, 26, "Gold");
		add(Items.DEEPSLATE_GOLD_ORE, 26, "Gold");

		// --- Crops ---
		add(Items.WHEAT, 3, "Crops");
		add(Items.WHEAT_SEEDS, 1, "Crops");
		add(Items.CARROT, 4, "Crops");
		add(Items.POTATO, 4, "Crops");
		add(Items.BAKED_POTATO, 6, "Crops");
		add(Items.BEETROOT, 4, "Crops");
		add(Items.BEETROOT_SEEDS, 1, "Crops");
		add(Items.MELON, 5, "Crops");
		add(Items.MELON_SLICE, 3, "Crops");
		add(Items.PUMPKIN, 6, "Crops");
		add(Items.PUMPKIN_SEEDS, 1, "Crops");
		add(Items.SUGAR_CANE, 2, "Crops");
		add(Items.CACTUS, 3, "Crops");
		add(Items.NETHER_WART, 6, "Crops");
		add(Items.COCOA_BEANS, 5, "Crops");
		add(Items.SWEET_BERRIES, 3, "Crops");
		add(Items.GLOW_BERRIES, 4, "Crops");
		add(Items.BAMBOO, 1, "Crops");
		add(Items.KELP, 1, "Crops");
		add(Items.HAY_BLOCK, 27, "Crops");
		add(Items.BROWN_MUSHROOM, 2, "Crops");
		add(Items.RED_MUSHROOM, 2, "Crops");

		// --- Food ---
		add(Items.BREAD, 8, "Food");
		add(Items.COOKIE, 5, "Food");
		add(Items.CAKE, 40, "Food");
		add(Items.MUSHROOM_STEW, 12, "Food");
		add(Items.BEETROOT_SOUP, 12, "Food");
		add(Items.RABBIT_STEW, 20, "Food");
		add(Items.GLISTERING_MELON_SLICE, 45, "Food");
		add(Items.GOLDEN_CARROT, 120, "Food");
		add(Items.GOLDEN_APPLE, 900, "Food");
		add(Items.ENCHANTED_GOLDEN_APPLE, 12_000, "Food");
		add(Items.HONEY_BOTTLE, 8, "Food");
		add(Items.APPLE, 4, "Food");
		add(Items.CHICKEN, 3, "Food");
		add(Items.BEEF, 3, "Food");
		add(Items.PORKCHOP, 3, "Food");
		add(Items.MUTTON, 3, "Food");
		add(Items.COD, 2, "Food");
		add(Items.SALMON, 3, "Food");
		add(Items.TROPICAL_FISH, 3, "Food");
		add(Items.PUFFERFISH, 2, "Food");
		add(Items.RABBIT, 3, "Food");

		// --- Mob drops ---
		add(Items.BONE, 4, "Mob Drops");
		add(Items.BONE_MEAL, 2, "Mob Drops");
		add(Items.STRING, 4, "Mob Drops");
		add(Items.GUNPOWDER, 5, "Mob Drops");
		add(Items.SPIDER_EYE, 4, "Mob Drops");
		add(Items.ROTTEN_FLESH, 1, "Mob Drops");
		add(Items.LEATHER, 5, "Mob Drops");
		add(Items.FEATHER, 3, "Mob Drops");
		add(Items.BLAZE_ROD, 24, "Mob Drops");
		add(Items.BLAZE_POWDER, 12, "Mob Drops");
		add(Items.GHAST_TEAR, 40, "Mob Drops");
		add(Items.MAGMA_CREAM, 12, "Mob Drops");
		add(Items.ENDER_PEARL, 20, "Mob Drops");
		add(Items.SHULKER_SHELL, 500_000, "Mob Drops");
		add(Items.SLIME_BALL, 10, "Mob Drops");
		add(Items.SLIME_BLOCK, 90, "Mob Drops");
		add(Items.RABBIT_HIDE, 2, "Mob Drops");
		add(Items.RABBIT_FOOT, 15, "Mob Drops");
		add(Items.PRISMARINE_SHARD, 8, "Mob Drops");
		add(Items.PRISMARINE_CRYSTALS, 16, "Mob Drops");
		add(Items.NAUTILUS_SHELL, 300, "Mob Drops");
		add(Items.HEART_OF_THE_SEA, 1_500, "Mob Drops");
		add(Items.CHORUS_FRUIT, 6, "Mob Drops");
		add(Items.POPPED_CHORUS_FRUIT, 8, "Mob Drops");
		add(Items.EXPERIENCE_BOTTLE, 25, "Mob Drops");
		add(Items.GLOWSTONE_DUST, 4, "Mob Drops");
		add(Items.GLOWSTONE, 15, "Mob Drops");
		add(Items.DRAGON_BREATH, 250_000, "Mob Drops");
		add(Items.ENDER_EYE, 15, "Mob Drops");
		add(Items.FERMENTED_SPIDER_EYE, 6, "Mob Drops");

		// --- Nether / End ---
		add(Items.OBSIDIAN, 40, "Nether & End");
		add(Items.CRYING_OBSIDIAN, 60, "Nether & End");
		add(Items.NETHER_BRICKS, 12, "Nether & End");
		add(Items.NETHER_STAR, 5_000_000, "Nether & End");
		add(Items.TOTEM_OF_UNDYING, 2_000_000, "Nether & End");
		add(Items.ELYTRA, 5_000_000, "Nether & End");
		add(Items.NETHERITE_UPGRADE_SMITHING_TEMPLATE, 2_500_000, "Nether & End");
		add(Items.LAVA_BUCKET, 60, "Nether & End");
		add(Items.WATER_BUCKET, 20, "Nether & End");
		add(Items.MILK_BUCKET, 10, "Nether & End");
		add(Items.END_CRYSTAL, 1_000_000, "Nether & End");
		add(Items.FIREWORK_ROCKET, 3, "Nether & End");
		add(Items.TNT, 30, "Nether & End");
		add(Items.BEACON, 2_000_000, "Nether & End");
		add(Items.CONDUIT, 1_500_000, "Nether & End");
		add(Items.SPONGE, 60, "Nether & End");
		add(Items.WET_SPONGE, 60, "Nether & End");

		// --- Building blocks ---
		add(Items.COBBLESTONE, 1, "Building Blocks");
		add(Items.STONE, 1, "Building Blocks");
		add(Items.DEEPSLATE, 2, "Building Blocks");
		add(Items.TUFF, 2, "Building Blocks");
		add(Items.SAND, 2, "Building Blocks");
		add(Items.RED_SAND, 2, "Building Blocks");
		add(Items.GRAVEL, 2, "Building Blocks");
		add(Items.DIRT, 1, "Building Blocks");
		add(Items.GRASS_BLOCK, 2, "Building Blocks");
		add(Items.ROOTED_DIRT, 3, "Building Blocks");
		add(Items.MOSS_BLOCK, 4, "Building Blocks");
		add(Items.PODZOL, 4, "Building Blocks");
		add(Items.MYCELIUM, 5, "Building Blocks");
		add(Items.SNOW_BLOCK, 3, "Building Blocks");
		add(Items.ICE, 4, "Building Blocks");
		add(Items.PACKED_ICE, 12, "Building Blocks");
		add(Items.BLUE_ICE, 60, "Building Blocks");
		add(Items.OAK_LOG, 2, "Building Blocks");
		add(Items.CLAY_BALL, 4, "Building Blocks");
		add(Items.FLINT, 3, "Building Blocks");
		add(Items.SEA_LANTERN, 30, "Building Blocks");
		add(Items.PURPUR_BLOCK, 10, "Building Blocks");
		add(Items.END_STONE, 4, "Building Blocks");
		add(Items.SCULK, 15, "Building Blocks");
		add(Items.ECHO_SHARD, 400, "Building Blocks");
		add(Items.DISC_FRAGMENT_5, 250, "Building Blocks");
		add(Items.SANDSTONE, 3, "Building Blocks");
		add(Items.BRICKS, 4, "Building Blocks");
		add(Items.STONE_BRICKS, 2, "Building Blocks");
		add(Items.MOSSY_COBBLESTONE, 2, "Building Blocks");
		add(Items.NETHERRACK, 1, "Building Blocks");
		add(Items.BLACKSTONE, 3, "Building Blocks");
		add(Items.BASALT, 2, "Building Blocks");
		add(Items.POLISHED_BASALT, 3, "Building Blocks");
		add(Items.SMOOTH_BASALT, 3, "Building Blocks");
		add(Items.TERRACOTTA, 3, "Building Blocks");
		add(Compat.pickItem("DYED_TERRACOTTA", DyeColor.WHITE), 3, "Building Blocks");
		add(Items.GLASS, 2, "Building Blocks");
		add(Items.GLASS_PANE, 1, "Building Blocks");
		add(Items.BOOKSHELF, 12, "Building Blocks");
		add(Items.CRAFTING_TABLE, 8, "Building Blocks");
		add(Items.FURNACE, 10, "Building Blocks");
		add(Items.LADDER, 1, "Building Blocks");
		add(Items.TORCH, 1, "Building Blocks");
		add(Items.LANTERN, 5, "Building Blocks");
		add(Items.SOUL_TORCH, 2, "Building Blocks");
		add(Items.SOUL_LANTERN, 8, "Building Blocks");

		// --- Copper ---
		addCopperFamily();

		// --- Wood, every species ---
		addWoodFamily();

		// --- Colored blocks, every dye colour ---
		addColorFamily();

		// --- Everything else: blocks, tools, armour, food, drops ---
		addEveryRemainingItem();
	}

	/**
	 * Copper blocks weather through four states, each with a waxed twin, so the
	 * whole family is generated instead of hand-listed.
	 */
	private static void addCopperFamily() {
		List<Item> copper = new ArrayList<>();
		copper.addAll(Compat.collectionItems("COPPER_BLOCK"));
		copper.addAll(Compat.collectionItems("CHISELED_COPPER"));
		copper.addAll(Compat.collectionItems("CUT_COPPER"));
		copper.addAll(Compat.collectionItems("CUT_COPPER_STAIRS"));
		copper.addAll(Compat.collectionItems("CUT_COPPER_SLAB"));
		copper.addAll(Compat.collectionItems("COPPER_BARS"));
		copper.addAll(Compat.collectionItems("COPPER_CHAIN"));
		copper.addAll(Compat.collectionItems("COPPER_DOOR"));
		copper.addAll(Compat.collectionItems("COPPER_TRAPDOOR"));
		copper.addAll(Compat.collectionItems("COPPER_LANTERN"));
		copper.addAll(Compat.collectionItems("COPPER_GRATE"));
		copper.addAll(Compat.collectionItems("COPPER_BULB"));
		copper.addAll(Compat.collectionItems("COPPER_CHEST"));
		copper.addAll(Compat.collectionItems("COPPER_GOLEM_STATUE"));
		for (Item item : copper) {
			add(item, 5, "Copper");
		}
	}

	/** Planks, logs, stripped variants, signs, boats and every shape per species. */
	private static void addWoodFamily() {
		addMany(2, "Wood",
			Items.OAK_PLANKS, Items.SPRUCE_PLANKS, Items.BIRCH_PLANKS, Items.JUNGLE_PLANKS,
			Items.ACACIA_PLANKS, Items.DARK_OAK_PLANKS, Items.MANGROVE_PLANKS,
			Items.CHERRY_PLANKS, Items.PALE_OAK_PLANKS, Items.BAMBOO_PLANKS, Items.BAMBOO_MOSAIC,
			Items.OAK_LOG, Items.SPRUCE_LOG, Items.BIRCH_LOG, Items.JUNGLE_LOG,
			Items.ACACIA_LOG, Items.DARK_OAK_LOG, Items.MANGROVE_LOG, Items.CHERRY_LOG,
			Items.PALE_OAK_LOG, Items.BAMBOO_BLOCK,
			Items.OAK_WOOD, Items.SPRUCE_WOOD, Items.BIRCH_WOOD, Items.JUNGLE_WOOD,
			Items.ACACIA_WOOD, Items.DARK_OAK_WOOD, Items.MANGROVE_WOOD, Items.CHERRY_WOOD,
			Items.PALE_OAK_WOOD,
			Items.STRIPPED_OAK_LOG, Items.STRIPPED_SPRUCE_LOG, Items.STRIPPED_BIRCH_LOG,
			Items.STRIPPED_JUNGLE_LOG, Items.STRIPPED_ACACIA_LOG, Items.STRIPPED_DARK_OAK_LOG,
			Items.STRIPPED_MANGROVE_LOG, Items.STRIPPED_CHERRY_LOG, Items.STRIPPED_PALE_OAK_LOG,
			Items.STRIPPED_BAMBOO_BLOCK,
			Items.STRIPPED_OAK_WOOD, Items.STRIPPED_SPRUCE_WOOD, Items.STRIPPED_BIRCH_WOOD,
			Items.STRIPPED_JUNGLE_WOOD, Items.STRIPPED_ACACIA_WOOD, Items.STRIPPED_DARK_OAK_WOOD,
			Items.STRIPPED_MANGROVE_WOOD, Items.STRIPPED_CHERRY_WOOD, Items.STRIPPED_PALE_OAK_WOOD);
		addMany(1, "Wood",
			Items.OAK_SAPLING, Items.SPRUCE_SAPLING, Items.BIRCH_SAPLING, Items.JUNGLE_SAPLING,
			Items.ACACIA_SAPLING, Items.DARK_OAK_SAPLING, Items.CHERRY_SAPLING,
			Items.PALE_OAK_SAPLING, Items.MANGROVE_PROPAGULE, Items.BAMBOO,
			Items.OAK_LEAVES, Items.SPRUCE_LEAVES, Items.BIRCH_LEAVES, Items.JUNGLE_LEAVES,
			Items.ACACIA_LEAVES, Items.DARK_OAK_LEAVES, Items.CHERRY_LEAVES,
			Items.PALE_OAK_LEAVES, Items.MANGROVE_LEAVES);
		addMany(3, "Wood",
			Items.OAK_FENCE, Items.SPRUCE_FENCE, Items.BIRCH_FENCE, Items.JUNGLE_FENCE,
			Items.ACACIA_FENCE, Items.DARK_OAK_FENCE, Items.MANGROVE_FENCE,
			Items.CHERRY_FENCE, Items.PALE_OAK_FENCE, Items.BAMBOO_FENCE,
			Items.OAK_FENCE_GATE, Items.SPRUCE_FENCE_GATE, Items.BIRCH_FENCE_GATE,
			Items.JUNGLE_FENCE_GATE, Items.ACACIA_FENCE_GATE, Items.DARK_OAK_FENCE_GATE,
			Items.MANGROVE_FENCE_GATE, Items.CHERRY_FENCE_GATE, Items.PALE_OAK_FENCE_GATE,
			Items.BAMBOO_FENCE_GATE);
		addMany(4, "Wood",
			Items.OAK_DOOR, Items.SPRUCE_DOOR, Items.BIRCH_DOOR, Items.JUNGLE_DOOR,
			Items.ACACIA_DOOR, Items.DARK_OAK_DOOR, Items.MANGROVE_DOOR,
			Items.CHERRY_DOOR, Items.PALE_OAK_DOOR, Items.BAMBOO_DOOR,
			Items.OAK_TRAPDOOR, Items.SPRUCE_TRAPDOOR, Items.BIRCH_TRAPDOOR,
			Items.JUNGLE_TRAPDOOR, Items.ACACIA_TRAPDOOR, Items.DARK_OAK_TRAPDOOR,
			Items.MANGROVE_TRAPDOOR, Items.CHERRY_TRAPDOOR, Items.PALE_OAK_TRAPDOOR,
			Items.BAMBOO_TRAPDOOR);
	}

	/** The sixteen dye colours, expanded across every coloured block family. */
	private static void addColorFamily() {
		addManyCollection(3, "Colored Blocks", Compat.collectionItems("WOOL"));
		addManyCollection(2, "Colored Blocks", Compat.collectionItems("CARPET"));
		addManyCollection(2, "Colored Blocks", Compat.collectionItems("CONCRETE"));
		addManyCollection(1, "Colored Blocks", Compat.collectionItems("CONCRETE_POWDER"));
		addManyCollection(3, "Colored Blocks", Compat.collectionItems("DYED_TERRACOTTA"));
		addManyCollection(4, "Colored Blocks", Compat.collectionItems("GLAZED_TERRACOTTA"));
		addManyCollection(2, "Colored Blocks", Compat.collectionItems("STAINED_GLASS"));
		addManyCollection(1, "Colored Blocks", Compat.collectionItems("STAINED_GLASS_PANE"));
		addManyCollection(4, "Colored Blocks", Compat.collectionItems("BED"));
		addManyCollection(6, "Colored Blocks", Compat.collectionItems("DYED_CANDLE"));
		for (DyeColor color : DyeColor.values()) {
			add(Compat.pickItem("DYE", color), 2, "Dyes");
		}
	}

	/**
	 * Catches every item that is left: stairs, slabs, walls, all the one-off
	 * blocks nobody would think to list, plus tools, armour, food and mob drops.
	 * This is what makes /sell and /buy accept literally everything in the game.
	 */
	private static void addEveryRemainingItem() {
		for (Item item : BuiltInRegistries.ITEM) {
			if (BY_ITEM.containsKey(item)) {
				continue;
			}
			String id = BuiltInRegistries.ITEM.getKey(item).getPath();
			if (isNeverSold(id)) {
				continue;
			}
			// Gear is priced by material and slot, before the material rules can
			// swallow "diamond_sword" and price it like a diamond.
			if (tryAddGear(item, id)) {
				continue;
			}
			for (BlockRule rule : PRICE_RULES) {
				if (id.contains(rule.needle())) {
					add(item, rule.price(), rule.category());
					break;
				}
			}
			if (!BY_ITEM.containsKey(item)) {
				add(item, item instanceof BlockItem ? 1 : 2, "Misc");
			}
		}
	}

	/**
	 * Prices tools and armour from the material they are made of multiplied by
	 * what the slot is worth, so a wooden sword and a netherite sword both land
	 * somewhere sensible without listing every combination.
	 *
	 * @return true when the id was recognised as gear and priced
	 */
	private static boolean tryAddGear(Item item, String id) {
		GearSlot slot = null;
		for (GearSlot candidate : GEAR_SLOTS) {
			if (id.endsWith("_" + candidate.suffix())) {
				slot = candidate;
				break;
			}
		}
		if (slot == null) {
			return false;
		}
		for (GearMaterial material : GEAR_MATERIALS) {
			if (id.startsWith(material.prefix() + "_")) {
				long price = Math.max(1, Math.round(material.price() * slot.factor()));
				add(item, price, slot.category());
				return true;
			}
		}
		// Unrecognised prefix (horse armour, armour stands with a suffix, etc.)
		return false;
	}

	private static boolean isNeverSold(String id) {
		if (NEVER_SOLD.contains(id) || NEVER_SOLD_ITEMS.contains(id)) {
			return true;
		}
		if (id.endsWith("_shulker_box") || id.endsWith("_banner")) {
			return true;
		}
		// Anything that can hold items must never be auto-sold.
		return id.contains("shulker_box") || id.contains("bundle");
	}

	private static void add(Item item, long price, String category) {
		if (item == null || BY_ITEM.containsKey(item)) {
			return;
		}
		register(new Entry(item, price, category));
	}

	/**
	 * Adds something whose identity lives in its components: an enchanted book
	 * at a particular level, or gear carrying a custom enchant.
	 *
	 * @param name what the player sees in the GUI and types into search
	 * @return the registered entry, or null when the name was already taken
	 */
	private static Entry add(ItemStack template, long price, String category, String name) {
		if (template == null || template.isEmpty() || name == null || name.isBlank()) {
			return null;
		}
		List<Entry> existing = BY_ITEM.get(template.getItem());
		if (existing != null) {
			for (Entry entry : existing) {
				if (entry.name().equals(name)) {
					return null;
				}
			}
		}
		Entry entry = new Entry(template.getItem(), price, category, template.copy(), name);
		register(entry);
		return entry;
	}

	private static void register(Entry entry) {
		BY_ITEM.computeIfAbsent(entry.item(), key -> new ArrayList<>()).add(entry);
		ALL.add(entry);
		if (!CATEGORY_ORDER.contains(entry.category())) {
			CATEGORY_ORDER.add(entry.category());
		}
	}

	private static void addMany(long price, String category, Item... items) {
		for (Item item : items) {
			add(item, price, category);
		}
	}

	private static void addManyCollection(long price, String category, List<Item> collection) {
		for (Item item : collection) {
			add(item, price, category);
		}
	}

	/** Price for a single unit of this item, or null if it cannot be sold. */
	static Long priceOf(Item item) {
		Entry entry = entryOf(item);
		return entry == null ? null : entry.price();
	}

	/** Price for exactly this stack - the right one when books are involved. */
	static Long priceOf(ItemStack stack) {
		Entry entry = entryFor(stack);
		return entry == null ? null : entry.price();
	}

	/**
	 * Sell price for this stack <em>including</em> a bonus for the enchantments
	 * actually on it, so enchanted gear is worth more than the plain item.
	 *
	 * <p>Both halves ride the live market: the base is this entry's current
	 * price, and the enchantment bonus is what the enchant's book currently
	 * costs (enchanted books themselves sell for their own market price).
	 */
	static Long sellPrice(ItemStack stack) {
		Entry entry = entryFor(stack);
		if (entry == null) {
			return null;
		}
		if (stack != null && stack.getItem() == Items.ENCHANTED_BOOK) {
			return marketPrice(entry);
		}
		try {
			return Math.addExact(marketPrice(entry), enchantBonus(stack));
		} catch (ArithmeticException exception) {
			return Long.MAX_VALUE;
		}
	}

	/** Extra value added by the enchantments actually on a piece of gear. */
	private static long enchantBonus(ItemStack stack) {
		if (stack == null || stack.isEmpty()) {
			return 0;
		}
		long bonus = 0;
		ItemEnchantments applied = stack.get(DataComponents.ENCHANTMENTS);
		if (applied != null) {
			for (var record : applied.entrySet()) {
				bonus += enchantWorth(record.getKey(), record.getIntValue());
			}
		}
		for (CustomEnchants.Type type : CustomEnchants.Type.values()) {
			int level = CustomEnchants.levelOf(stack, type);
			if (level > 0) {
				bonus += customEnchantWorth(type, level);
			}
		}
		return Math.max(0, bonus);
	}

	/**
	 * What one vanilla enchant is worth on gear <em>right now</em>: exactly the
	 * current market price of its book. Because both sides of an anvil trade
	 * move together, buying a book, applying it and reselling the item nets out
	 * to zero on the same tick - no matter how wildly either price swings.
	 */
	static long enchantWorth(Holder<Enchantment> holder, int level) {
		long flat = vanillaEnchantValue(holder, level);
		Entry book = VANILLA_BOOKS.get(new BookKey(holder, level));
		return book == null ? flat : marketPrice(book);
	}

	/**
	 * What one level of a custom enchant adds: always 72.5% of its book's
	 * market price (2,900 of the 4,000 each level costs), so the book route
	 * stays a small loss for every factor the market can throw at it.
	 */
	static long customEnchantWorth(CustomEnchants.Type type, int level) {
		long flat = customEnchantBonus(level);
		Entry book = CUSTOM_BOOKS.get(type);
		long ceiling = CUSTOM_BOOK_PRICE * (long) type.maxLevel();
		if (book == null || ceiling <= 0) {
			return flat;
		}
		return Math.round(marketPrice(book) * (double) flat / ceiling);
	}

	/** What adding a custom enchant costs at buy time: its book's market price. */
	static long customBookPrice(CustomEnchants.Type type) {
		Entry book = CUSTOM_BOOKS.get(type);
		return book == null ? customEnchantCost(type.maxLevel()) : marketPrice(book);
	}

	/** This entry's market multiplier; a fresh entry rolls one on first sight. */
	private static double factor(Entry entry) {
		return MARKET.computeIfAbsent(entry, key -> rollFactor());
	}

	/**
	 * Mostly gentle drift with a heavy tail: about one roll in two hundred is a
	 * spike worth holding out for, topping out at x100,000 - so a $200 item can
	 * briefly be worth $20,000,000 when the window lands on it.
	 */
	private static double rollFactor() {
		ThreadLocalRandom random = ThreadLocalRandom.current();
		double roll = random.nextDouble();
		if (roll < 0.50) {
			return random.nextDouble(0.80, 1.20);
		}
		if (roll < 0.78) {
			return random.nextBoolean()
				? random.nextDouble(0.50, 0.80)
				: random.nextDouble(1.20, 3.00);
		}
		if (roll < 0.92) {
			return random.nextDouble(3.00, 20.00);
		}
		if (roll < 0.975) {
			return random.nextDouble(20.00, 500.00);
		}
		if (roll < 0.995) {
			return random.nextDouble(500.00, 5_000.00);
		}
		return random.nextDouble(5_000.00, 100_000.00);
	}

	/** This entry's list price with the market multiplier applied. */
	static long marketPrice(Entry entry) {
		if (entry == null) {
			return 0;
		}
		// An explicit admin pin beats the rolling market, so /setprice is
		// predictable and a disabled item (0) genuinely never trades.
		Long pinned = priceOverride(entry.item());
		if (pinned != null) {
			return Math.max(0L, Math.min(pinned, MARKET_MAX));
		}
		double scaled = entry.price() * factor(entry);
		if (scaled >= MARKET_MAX) {
			return MARKET_MAX;
		}
		long value = Math.round(scaled);
		return entry.price() > 0 ? Math.max(1, value) : Math.max(0, value);
	}

	/**
	 * What one unit costs on the buy side. Plain items and books trade at their
	 * market price; pre-made enchanted gear also carries a floor - it can never
	 * be bought for less than its own stack would sell for, which is what keeps
	 * buy-then-resell impossible even though each entry has its own factor.
	 */
	static long shopPrice(Entry entry) {
		if (entry == null) {
			return 0;
		}
		long market = marketPrice(entry);
		if (entry.template() == null || entry.item() == Items.ENCHANTED_BOOK) {
			return market;
		}
		Long sell = sellPrice(entry.displayStack());
		return sell == null ? market : Math.max(market, sell);
	}

	/**
	 * Re-rolls a quarter of the shop once a minute, driven by the server tick.
	 * Everything - blocks, gear and enchant books alike - drifts and occasionally
	 * spikes, so there is always something lucky to be holding when it happens.
	 */
	static void tickMarket(long tickCount) {
		if (tickCount % MARKET_INTERVAL_TICKS != 0 || ALL.isEmpty()) {
			return;
		}
		int slice = (int) ((tickCount / MARKET_INTERVAL_TICKS) % MARKET_SLICES);
		for (int index = 0; index < ALL.size(); index++) {
			if (index % MARKET_SLICES == slice) {
				MARKET.put(ALL.get(index), rollFactor());
			}
		}
		// Once an hour, take the market's temperature for the /prices trend
		// view. Every minute would be noise; an hour shows the shape of a day.
		if (Config.getBoolean("economy.price_history_enabled")
			&& tickCount % (MARKET_INTERVAL_TICKS * 60) == 0) {
			PriceHistory.record(averageFactor());
		}
	}

	/** The mean market multiplier across the whole catalogue right now. */
	private static double averageFactor() {
		if (ALL.isEmpty()) {
			return 1.0;
		}
		double total = 0;
		for (Entry entry : ALL) {
			total += factor(entry);
		}
		return total / ALL.size();
	}

	/**
	 * What one level of a vanilla enchant costs as a flat list price. The live
	 * values flow through {@link #enchantWorth}, which applies this book's
	 * current market factor - this is the pre-market fallback.
	 */
	static long vanillaEnchantValue(Holder<Enchantment> holder, int level) {
		return rarityPrice(holder.value().getWeight()) * (long) Math.max(1, level);
	}

	/** What one level of a custom enchant costs to add at buy time. */
	static long customEnchantCost(int level) {
		return CUSTOM_BOOK_PRICE * (long) Math.max(1, level);
	}

	/** Flat sell bonus one level of a custom enchant adds to gear. */
	static long customEnchantBonus(int level) {
		return CUSTOM_ENCHANT_SELL_BONUS * (long) Math.max(1, level);
	}

	/** The first entry for an item, or null if it cannot be sold. */
	static Entry entryOf(Item item) {
		List<Entry> entries = BY_ITEM.get(item);
		return entries == null || entries.isEmpty() ? null : entries.get(0);
	}

	/**
	 * The entry that describes this exact stack.
	 *
	 * <p>Items with several variants (every enchanted book) are matched on
	 * their components; everything else matches on the item alone, which keeps
	 * renamed or differently-named copies behaving the way players expect.
	 */
	static Entry entryFor(ItemStack stack) {
		if (stack == null || stack.isEmpty()) {
			return null;
		}
		List<Entry> candidates = BY_ITEM.get(stack.getItem());
		if (candidates == null || candidates.isEmpty()) {
			return null;
		}
		if (candidates.size() == 1) {
			return candidates.get(0);
		}
		for (Entry entry : candidates) {
			// Entries for plain gear carry no template (see matches() below), so
			// they can only be matched on the item - passing null to
			// isSameItemSameComponents dereferences it and throws.
			boolean same = entry.template() == null
				? stack.getItem() == entry.item()
				: ItemStack.isSameItemSameComponents(stack, entry.template());
			if (same) {
				return entry;
			}
		}
		return null;
	}

	/** Does this stack belong to this entry? */
	static boolean matches(Entry entry, ItemStack stack) {
		if (entry == null || stack == null || stack.isEmpty()) {
			return false;
		}
		return entry.template() == null
			? stack.getItem() == entry.item()
			: ItemStack.isSameItemSameComponents(stack, entry.template());
	}

	/** "DIAMOND_BLOCK" -> "Diamond Block". Falls back to the raw id. */
	static String displayName(Item item) {
		return titleCase(BuiltInRegistries.ITEM.getKey(item).getPath());
	}

	/** "sea_pickle" -> "Sea Pickle". */
	private static String titleCase(String key) {
		StringBuilder name = new StringBuilder();
		for (String word : key.split("_")) {
			if (word.isEmpty()) {
				continue;
			}
			if (!name.isEmpty()) {
				name.append(' ');
			}
			name.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1));
		}
		return name.isEmpty() ? key : name.toString();
	}

	/** Every sellable entry, ordered so the GUI groups categories together. */
	static List<Entry> all() {
		return ALL;
	}

	/** Distinct categories in display order. */
	static List<String> categories() {
		return CATEGORY_ORDER;
	}

	/** Entries belonging to one category, in display order. */
	static List<Entry> inCategory(String category) {
		List<Entry> filtered = new ArrayList<>();
		for (Entry entry : ALL) {
			if (entry.category().equals(category)) {
				filtered.add(entry);
			}
		}
		return filtered;
	}

	/** Highest-priced entries first, used by /worth and the sell-all preview. */
	static List<Entry> top(int limit) {
		List<Entry> ordered = new ArrayList<>(ALL);
		ordered.sort(Comparator.comparingLong((Entry entry) -> marketPrice(entry)).reversed());
		return ordered.size() <= limit ? ordered : new ArrayList<>(ordered.subList(0, limit));
	}

	/** A display-only stack showing the item, its price and how many you carry. */
	static ItemStack iconFor(Entry entry) {
		return iconFor(entry, 0, 0);
	}

	/**
	 * A display-only stack showing the item, its price and what the player is
	 * actually carrying. Owned items get a green name so they stand out on a
	 * wall of hundreds of blocks.
	 */
	static ItemStack iconFor(Entry entry, long owned, long protectedCount) {
		ItemStack stack = entry.displayStack();
		// Read the worth before the GUI name goes on, so template matching on
		// custom gear stays exact - this is the per-unit payout the click pays.
		Long unitWorth = sellPrice(stack);
		long sellValue = unitWorth != null ? unitWorth : marketPrice(entry);
		stack.set(DataComponents.CUSTOM_NAME, Component.literal(entry.name())
			.withStyle(owned > 0 ? ChatFormatting.GREEN : ChatFormatting.WHITE));

		List<Component> lore = new ArrayList<>();
		lore.add(Component.literal("Sell price: $" + TrimKits.formatAmount(sellValue) + " each")
			.withStyle(ChatFormatting.GOLD));
		lore.add(Component.literal("Category: " + entry.category())
			.withStyle(ChatFormatting.DARK_GRAY));
		lore.add(Component.empty());
		if (owned > 0) {
			lore.add(Component.literal("In inventory: " + TrimKits.formatAmount(owned)
					+ "  (=$" + TrimKits.formatAmount(owned * sellValue) + ")")
				.withStyle(ChatFormatting.GREEN));
		} else {
			lore.add(Component.literal("In inventory: none").withStyle(ChatFormatting.DARK_GRAY));
		}
		if (protectedCount > 0) {
			lore.add(Component.literal("Protected: " + TrimKits.formatAmount(protectedCount)
					+ " (renamed - hold one and /sell hand)")
				.withStyle(ChatFormatting.YELLOW));
		}
		lore.add(Component.empty());
		lore.add(Component.literal(owned > 0
				? "Click to sell all of these"
				: "You are not carrying any of these")
			.withStyle(owned > 0 ? ChatFormatting.GREEN : ChatFormatting.GRAY));
		stack.set(DataComponents.LORE, new ItemLore(lore));
		return stack;
	}

	/**
	 * Adds the two categories that cannot be built from the item registry
	 * alone: enchanted books (which come from data packs, so they only exist
	 * once the server has loaded its registries) and this server's own
	 * custom-enchanted gear.
	 *
	 * <p>Called once, lazily, the first time anything needs the price list.
	 */
	static synchronized void initialize(RegistryAccess registries) {
		if (!pricesLoaded) {
			loadPriceOverrides();
			pricesLoaded = true;
		}
		if (registries != null) {
			if (!vanillaBooksLoaded) {
				addEnchantBooks(registries);
				vanillaBooksLoaded = true;
			}
		}
		if (!customGearLoaded) {
			addCustomGear();
			customGearLoaded = true;
		}
	}

	private static boolean vanillaBooksLoaded;
	private static boolean customGearLoaded;

	// ---- Admin price overrides --------------------------------------------

	/**
	 * The admin-pinned price for an item, or null when it trades at market.
	 * A pin of {@code 0} means "untradeable" and is distinct from no pin.
	 */
	static synchronized Long priceOverride(Item item) {
		if (item == null || PRICE_OVERRIDES.isEmpty()) {
			return null;
		}
		return PRICE_OVERRIDES.get(BuiltInRegistries.ITEM.getKey(item).toString());
	}

	/**
	 * Pins an item to a price, or clears the pin with a negative value.
	 *
	 * @return true when the change was applied and persisted
	 */
	static synchronized boolean setPriceOverride(Item item, long price) {
		if (item == null) {
			return false;
		}
		String id = BuiltInRegistries.ITEM.getKey(item).toString();
		if (price < 0) {
			PRICE_OVERRIDES.remove(id);
		} else {
			PRICE_OVERRIDES.put(id, Math.min(price, MARKET_MAX));
		}
		return savePriceOverrides();
	}

	/** Reads {@code config/trimskits-prices.properties}; tolerates a broken file. */
	private static void loadPriceOverrides() {
		if (!java.nio.file.Files.exists(PRICE_FILE)) {
			return;
		}
		java.util.Properties properties = new java.util.Properties();
		try (java.io.InputStream input = java.nio.file.Files.newInputStream(PRICE_FILE)) {
			properties.load(input);
		} catch (java.io.IOException exception) {
			TrimKits.LOGGER.warn("Could not read {}; admin price pins ignored.", PRICE_FILE);
			return;
		}
		for (String key : properties.stringPropertyNames()) {
			try {
				long value = Long.parseLong(properties.getProperty(key).trim());
				if (value >= 0) {
					PRICE_OVERRIDES.put(key, Math.min(value, MARKET_MAX));
				}
			} catch (NumberFormatException ignored) {
				// Skip a damaged line.
			}
		}
	}

	/** Atomically writes the price pins; returns false when it could not save. */
	private static boolean savePriceOverrides() {
		java.util.Properties properties = new java.util.Properties();
		PRICE_OVERRIDES.forEach((id, price) -> properties.setProperty(id, Long.toString(price)));
		java.nio.file.Path temporary = PRICE_FILE.resolveSibling("trimskits-prices.tmp");
		try {
			java.nio.file.Files.createDirectories(PRICE_FILE.getParent());
			try (java.io.OutputStream output = java.nio.file.Files.newOutputStream(temporary)) {
				properties.store(output, "Trim Kits admin price pins (0 = untradeable)");
			}
			try {
				java.nio.file.Files.move(temporary, PRICE_FILE,
					java.nio.file.StandardCopyOption.ATOMIC_MOVE,
					java.nio.file.StandardCopyOption.REPLACE_EXISTING);
			} catch (java.nio.file.AtomicMoveNotSupportedException fallback) {
				java.nio.file.Files.move(temporary, PRICE_FILE,
					java.nio.file.StandardCopyOption.REPLACE_EXISTING);
			}
			return true;
		} catch (java.io.IOException exception) {
			TrimKits.LOGGER.warn("Could not save price pins: {}", exception.getMessage());
			return false;
		}
	}

	/** One book per enchantment per level, priced by how rare the enchant is. */
	private static void addEnchantBooks(RegistryAccess registries) {
		Registry<Enchantment> registry;
		try {
			registry = registries.lookupOrThrow(Registries.ENCHANTMENT);
		} catch (RuntimeException exception) {
			// Without enchantments there is simply nothing to list.
			return;
		}
		for (var candidate : registry.entrySet()) {
			Holder<Enchantment> holder = registry.get(candidate.getKey()).orElse(null);
			if (holder == null) {
				continue;
			}
			int maxLevel = holder.value().getMaxLevel();
			if (maxLevel < 1) {
				continue;
			}
			long base = rarityPrice(holder.value().getWeight());
			String title = titleCase(candidate.getKey().identifier().getPath());
			for (int level = 1; level <= maxLevel; level++) {
				String name = maxLevel > 1 ? title + " " + CustomEnchants.roman(level) : title;
				ItemStack book = new ItemStack(Items.ENCHANTED_BOOK);
				ItemEnchantments.Mutable stored =
					new ItemEnchantments.Mutable(ItemEnchantments.EMPTY);
				stored.set(holder, level);
				book.set(DataComponents.STORED_ENCHANTMENTS, stored.toImmutable());
				Entry added = add(book, base * level, "Enchants", name);
				if (added != null) {
					// Remember which entry is this enchant's book: the gear
					// bonus and the buy-menu price both follow its market.
					VANILLA_BOOKS.put(new BookKey(holder, level), added);
				}
			}
		}
	}

	/**
	 * Rarity weights are 1 (very rare), 2 (rare), 5 (uncommon) and 10 (common),
	 * so a weight is a ready-made price ladder. These numbers set BOTH what an
	 * enchant book costs and what an item gains in sell bonus when enchanted —
	 * they always move together, which is what keeps the book -&gt; anvil -&gt;
	 * resell loop from ever paying out more than it cost.
	 */
	private static long rarityPrice(int weight) {
		return switch (weight) {
			case 1 -> 1_500;
			case 2 -> 600;
			case 5 -> 250;
			default -> 100;
		};
	}

	/**
	 * The custom-enchanted gear - the only way to get the enchants in
	 * {@link CustomEnchants}. It is named and glows so it is obvious in an
	 * inventory which pickaxes are the good ones.
	 */
	private static void addCustomGear() {
		add(gear(Items.DIAMOND_PICKAXE, CustomEnchants.Type.SMELTER, 3, "Smelter Pickaxe"),
			12_000, "Custom Enchants", "Smelter Pickaxe");
		add(gear(Items.DIAMOND_SHOVEL, CustomEnchants.Type.TELEKINESIS, 1, "Telekinesis Shovel"),
			8_000, "Custom Enchants", "Telekinesis Shovel");
		add(gear(Items.DIAMOND_SWORD, CustomEnchants.Type.LUCKY, 3, "Lucky Blade"),
			15_000, "Custom Enchants", "Lucky Blade");
		add(gear(Items.DIAMOND_SWORD, CustomEnchants.Type.HASTE, 2, "Haste Blade"),
			10_000, "Custom Enchants", "Haste Blade");
		add(gear(Items.DIAMOND_PICKAXE, CustomEnchants.Type.AUTO_REPAIR, 3, "Self-Mending Pickaxe"),
			9_000, "Custom Enchants", "Self-Mending Pickaxe");
		add(gear(Items.DIAMOND_SWORD, CustomEnchants.Type.NIGHT_VISION, 2, "Explorer's Blade"),
			6_000, "Custom Enchants", "Explorer's Blade");

		// One book per custom enchant, so any compatible tool - wooden pickaxe
		// through netherite - can be enchanted, not just the pre-made gear.
		for (CustomEnchants.Type type : CustomEnchants.Type.values()) {
			Entry added = add(CustomEnchants.book(type, type.maxLevel()),
				CUSTOM_BOOK_PRICE * type.maxLevel(), "Custom Enchants", type.displayName() + " Book");
			if (added != null) {
				CUSTOM_BOOKS.put(type, added);
			}
		}
	}

	private static ItemStack gear(Item item, CustomEnchants.Type type, int level, String name) {
		ItemStack stack = new ItemStack(item);
		stack.set(DataComponents.CUSTOM_NAME, Component.literal(name).withStyle(type.colour()));
		CustomEnchants.apply(stack, type, level);
		return stack;
	}

	/** Icon for the category picker. */
	static ItemStack categoryIcon(String category) {
		Item item = CATEGORY_ICONS.get(category);
		if (item == null) {
			item = Items.BOOK;
		}
		ItemStack stack = new ItemStack(item);
		stack.set(DataComponents.CUSTOM_NAME, Component.literal(category).withStyle(ChatFormatting.AQUA));
		List<Component> lore = new ArrayList<>();
		lore.add(Component.literal(TrimKits.formatAmount(inCategory(category).size()) + " item(s)")
			.withStyle(ChatFormatting.GRAY));
		lore.add(Component.empty());
		lore.add(Component.literal("Click to browse this category").withStyle(ChatFormatting.GREEN));
		stack.set(DataComponents.LORE, new ItemLore(lore));
		return stack;
	}

	/** A display-only stack for an auction listing. */
	static ItemStack auctionIcon(ItemStack listing, long price, String seller, boolean own) {
		ItemStack stack = listing.copy();
		List<Component> lore = new ArrayList<>();
		lore.add(Component.literal("Price: $" + TrimKits.formatAmount(price))
			.withStyle(ChatFormatting.GOLD));
		lore.add(Component.literal("Seller: " + seller)
			.withStyle(ChatFormatting.GRAY));
		lore.add(Component.literal("Amount: " + listing.getCount())
			.withStyle(ChatFormatting.GRAY));
		lore.add(Component.empty());
		lore.add(Component.literal(own ? "This is your listing" : "Click to buy")
			.withStyle(own ? ChatFormatting.YELLOW : ChatFormatting.GREEN));
		stack.set(DataComponents.LORE, new ItemLore(lore));
		return stack;
	}

	static {
		CATEGORY_ICONS.put("Netherite", Items.NETHERITE_SCRAP);
		CATEGORY_ICONS.put("Diamond", Items.DIAMOND);
		CATEGORY_ICONS.put("Emerald", Items.EMERALD);
		CATEGORY_ICONS.put("Gold", Items.GOLD_INGOT);
		CATEGORY_ICONS.put("Iron", Items.IRON_INGOT);
		CATEGORY_ICONS.put("Copper", Items.COPPER_INGOT);
		CATEGORY_ICONS.put("Coal", Items.COAL);
		CATEGORY_ICONS.put("Quartz", Items.QUARTZ);
		CATEGORY_ICONS.put("Amethyst", Items.AMETHYST_SHARD);
		CATEGORY_ICONS.put("Lapis", Items.LAPIS_LAZULI);
		CATEGORY_ICONS.put("Redstone", Items.REDSTONE);
		CATEGORY_ICONS.put("Crops", Items.WHEAT);
		CATEGORY_ICONS.put("Food", Items.BREAD);
		CATEGORY_ICONS.put("Mob Drops", Items.BONE);
		CATEGORY_ICONS.put("Sea", Items.PRISMARINE_SHARD);
		CATEGORY_ICONS.put("Nether", Items.NETHERRACK);
		CATEGORY_ICONS.put("Nether & End", Items.OBSIDIAN);
		CATEGORY_ICONS.put("End", Items.END_STONE);
		CATEGORY_ICONS.put("Wood", Items.OAK_LOG);
		CATEGORY_ICONS.put("Colored Blocks", Compat.pickItem("WOOL", DyeColor.WHITE));
		CATEGORY_ICONS.put("Stone & Sand", Items.COBBLESTONE);
		CATEGORY_ICONS.put("Nature", Items.MOSS_BLOCK);
		CATEGORY_ICONS.put("Utility", Items.CRAFTING_TABLE);
		CATEGORY_ICONS.put("Building Blocks", Items.BRICKS);
		CATEGORY_ICONS.put("Dyes", Compat.pickItem("DYE", DyeColor.WHITE));
		CATEGORY_ICONS.put("Weapons", Items.IRON_SWORD);
		CATEGORY_ICONS.put("Tools", Items.IRON_PICKAXE);
		CATEGORY_ICONS.put("Armor", Items.IRON_CHESTPLATE);
		CATEGORY_ICONS.put("Decoration", Items.PAINTING);
		CATEGORY_ICONS.put("Rare", Items.NETHER_STAR);
		CATEGORY_ICONS.put("Misc", Items.BUNDLE);
		CATEGORY_ICONS.put("Enchants", Items.ENCHANTED_BOOK);
		CATEGORY_ICONS.put("Custom Enchants", Items.COMPASS);
	}
}
