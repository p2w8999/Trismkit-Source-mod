package com.kodari.trimskits;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;

/**
 * "Add enchantments to this order" screen behind the buy amount picker.
 *
 * <p>Every offer is something the item can genuinely take: this server's
 * custom enchants first, then the vanilla ones its material supports. Clicking
 * toggles it on for <em>every</em> item in the order — selected offers glow as
 * enchanted books — and the per-item surcharge is shown on each icon and on
 * the summary, so the number on the confirm button never hides a cost.
 *
 * <p>The selection is a shared list handed back to {@link BuyAmountMenu} on
 * "Done", which is why nothing here is ever charged: prices are only collected
 * when the order itself is bought.
 */
final class BuyEnchantMenu extends ChestMenu {
	private static final int ROWS = 6;
	private static final int SIZE = ROWS * 9;
	/** First slot of the bottom control row. */
	private static final int BAR = (ROWS - 1) * 9;
	/** Everything above the bar is the offer grid. */
	private static final int GRID = BAR;

	/** Instruction card; offers start right after it. */
	private static final int HEADER_SLOT = 0;

	private static final int SLOT_PREVIOUS = BAR + 0;
	private static final int SLOT_NEXT = BAR + 1;
	private static final int SLOT_PAGE = BAR + 2;
	private static final int SLOT_CLEAR = BAR + 3;
	private static final int SLOT_SUMMARY = BAR + 4;
	private static final int SLOT_BALANCE = BAR + 5;
	private static final int SLOT_PANE = BAR + 6;
	private static final int SLOT_DONE = BAR + 7;
	private static final int SLOT_CLOSE = BAR + 8;

	/** Offer slots per page: the whole grid except the instruction card. */
	private static final int PER_PAGE = GRID - 1;

	private static final Item PANE = Compat.pickItem("STAINED_GLASS_PANE", DyeColor.CYAN);

	private final ServerPlayer owner;
	private final ShopValues.Entry entry;
	/** Shared with BuyAmountMenu; this screen adds and removes in place. */
	private final List<EnchantOffer> selection;
	private final List<EnchantOffer> offers;
	private final SimpleContainer container;

	private int page;

	BuyEnchantMenu(int containerId, Inventory inventory, ServerPlayer owner,
			ShopValues.Entry entry, List<EnchantOffer> selection) {
		super(MenuType.GENERIC_9x6, containerId, inventory, new SimpleContainer(SIZE), ROWS);
		this.owner = owner;
		this.entry = entry;
		this.selection = selection;
		this.offers = EnchantOffer.offersFor(owner.level().registryAccess(), entry.displayStack());
		this.container = (SimpleContainer) getContainer();
		render();
	}

	private int pageCount() {
		return Math.max(1, (offers.size() + PER_PAGE - 1) / PER_PAGE);
	}

	private boolean isSelected(EnchantOffer offer) {
		for (EnchantOffer chosen : selection) {
			if (chosen.id().equals(offer.id())) {
				return true;
			}
		}
		return false;
	}

	/** Extra cost the current selection adds to every item in the order. */
	private long surcharge() {
		long sum = 0;
		for (EnchantOffer offer : selection) {
			sum += offer.price();
		}
		return sum;
	}

	private void render() {
		for (int slot = 0; slot < SIZE; slot++) {
			container.setItem(slot, ItemStack.EMPTY);
		}
		renderGrid();
		renderBar();
		broadcastChanges();
	}

	private void renderGrid() {
		int pages = pageCount();
		if (page >= pages) {
			page = pages - 1;
		}
		if (page < 0) {
			page = 0;
		}

		container.setItem(HEADER_SLOT, button(Items.BOOK,
			"Enchant: " + entry.name(), ChatFormatting.AQUA,
			"Click an enchantment to add it to your order",
			"You pay its price for every item you buy",
			"Click a glowing one again to remove it",
			"",
			"Selected: " + TrimKits.formatAmount(selection.size())
				+ " (+$" + TrimKits.formatAmount(surcharge()) + " each)"));

		int first = page * PER_PAGE;
		for (int offset = 0; offset < PER_PAGE; offset++) {
			int index = first + offset;
			if (index >= offers.size()) {
				break;
			}
			container.setItem(1 + offset, icon(offers.get(index)));
		}
	}

	private ItemStack icon(EnchantOffer offer) {
		boolean selected = isSelected(offer);
		// Selected offers glow: enchanted book for on, plain book for off.
		ItemStack stack = new ItemStack(selected ? Items.ENCHANTED_BOOK : Items.BOOK);
		stack.set(DataComponents.CUSTOM_NAME, offer.label());

		List<Component> lore = new ArrayList<>();
		lore.add(Component.literal("Cost: $" + TrimKits.formatAmount(offer.price()) + " per item")
			.withStyle(ChatFormatting.GOLD));
		if (offer.isCustom()) {
			lore.add(Component.literal(offer.customType().blurb()).withStyle(ChatFormatting.GRAY));
			lore.add(Component.literal(offer.customType().detail()).withStyle(ChatFormatting.DARK_GRAY));
		} else {
			lore.add(Component.literal("Vanilla enchantment, level "
					+ CustomEnchants.roman(offer.level()))
				.withStyle(ChatFormatting.DARK_GRAY));
		}
		lore.add(Component.empty());
		lore.add(Component.literal(selected
				? "Applied - click to remove"
				: "Click to add to the order")
			.withStyle(selected ? ChatFormatting.GREEN : ChatFormatting.AQUA));
		stack.set(DataComponents.LORE, new ItemLore(lore));
		return stack;
	}

	private void renderBar() {
		int pages = pageCount();
		container.setItem(SLOT_PREVIOUS, page > 0
			? button(Items.ARROW, "Previous page", ChatFormatting.YELLOW)
			: button(Items.STONE_BUTTON, "No previous page", ChatFormatting.DARK_GRAY));
		container.setItem(SLOT_NEXT, page + 1 < pages
			? button(Items.ARROW, "Next page", ChatFormatting.YELLOW)
			: button(Items.STONE_BUTTON, "No next page", ChatFormatting.DARK_GRAY));
		container.setItem(SLOT_PAGE, button(Items.WRITABLE_BOOK,
			"Page " + (page + 1) + " of " + pages, ChatFormatting.AQUA,
			TrimKits.formatAmount(offers.size()) + " enchantment(s) fit " + entry.name(),
			"",
			"Click the arrows to browse"));
		container.setItem(SLOT_CLEAR, selection.isEmpty()
			? button(Compat.pickItem("DYE", DyeColor.GRAY), "Nothing selected yet", ChatFormatting.DARK_GRAY)
			: button(Compat.pickItem("DYE", DyeColor.GRAY), "Clear selection", ChatFormatting.YELLOW,
				"Removes all " + TrimKits.formatAmount(selection.size()) + " enchantment(s)",
				"",
				"Click to start over"));
		container.setItem(SLOT_SUMMARY, button(Items.GOLD_INGOT,
			"Enchantments: " + TrimKits.formatAmount(selection.size()), ChatFormatting.GOLD,
			"+$" + TrimKits.formatAmount(surcharge()) + " per item",
			"Applied to every item in the order",
			"",
			"Nothing is charged until you press Buy"));
		container.setItem(SLOT_BALANCE, button(Items.GOLD_BLOCK,
			"Balance: $" + TrimKits.formatAmount(MarketData.balance(owner.getUUID())),
			ChatFormatting.GOLD));
		container.setItem(SLOT_PANE, new ItemStack(PANE));
		container.setItem(SLOT_DONE, button(Items.NETHER_STAR, "Done", ChatFormatting.GREEN,
			"Back to the amount screen",
			"Your " + TrimKits.formatAmount(selection.size()) + " enchantment(s) are kept",
			"",
			"Click to confirm the selection"));
		container.setItem(SLOT_CLOSE, button(Items.BARRIER, "Close", ChatFormatting.RED));
	}

	private static ItemStack button(Item item, String title, ChatFormatting color, String... lore) {
		ItemStack stack = new ItemStack(item);
		stack.set(DataComponents.CUSTOM_NAME, Component.literal(title).withStyle(color));
		List<Component> lines = new ArrayList<>();
		for (String line : lore) {
			lines.add(line.isEmpty() ? Component.empty() : Component.literal(line).withStyle(ChatFormatting.GRAY));
		}
		if (!lines.isEmpty()) {
			stack.set(DataComponents.LORE, new ItemLore(lines));
		}
		return stack;
	}

	@Override
	public void clicked(int slotIndex, int buttonNum, ContainerInput containerInput, Player player) {
		// Every slot is display-only; never let the vanilla handler run,
		// or players could pull the icons out of the GUI.
		if (slotIndex < 0 || slotIndex >= SIZE || !(player instanceof ServerPlayer serverPlayer)) {
			return;
		}

		switch (slotIndex) {
			case SLOT_CLOSE -> serverPlayer.closeContainer();
			case SLOT_DONE -> done();
			case SLOT_CLEAR -> {
				if (!selection.isEmpty()) {
					selection.clear();
					render();
				}
			}
			case SLOT_PREVIOUS -> {
				if (page > 0) {
					page--;
					render();
				}
			}
			case SLOT_NEXT -> {
				page = page + 1 < pageCount() ? page + 1 : 0;
				render();
			}
			// Page info, summary, balance, filler and the instruction card.
			case SLOT_PAGE, SLOT_SUMMARY, SLOT_BALANCE, SLOT_PANE, HEADER_SLOT -> { }
			default -> toggle(slotIndex);
		}
	}

	private void toggle(int slotIndex) {
		if (slotIndex < 1 || slotIndex >= GRID) {
			return;
		}
		int index = page * PER_PAGE + (slotIndex - 1);
		if (index < 0 || index >= offers.size()) {
			return;
		}
		EnchantOffer offer = offers.get(index);
		if (isSelected(offer)) {
			selection.removeIf(chosen -> chosen.id().equals(offer.id()));
			render();
			return;
		}
		if (!EnchantOffer.compatibleWith(selection, offer)) {
			owner.sendSystemMessage(Component.literal(
				offer.label().getString() + " conflicts with an enchantment you already picked."));
			return;
		}
		selection.add(offer);
		render();
	}

	/**
	 * Swapping menus inside a click handler would race the packet being
	 * processed, so the swap is deferred to the end of the server task queue.
	 */
	private void done() {
		MinecraftServer server = owner.level().getServer();
		Runnable action = () -> {
			if (owner.containerMenu == this) {
				TrimKits.openBuyAmount(owner, entry, selection);
			}
		};
		if (server == null) {
			action.run();
		} else {
			server.execute(action);
		}
	}

	@Override
	public ItemStack quickMoveStack(Player player, int slotIndex) {
		// No shift-clicking in or out of this menu.
		return ItemStack.EMPTY;
	}
}
