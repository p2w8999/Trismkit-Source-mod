package com.kodari.trimskits;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.ItemEnchantments;

/**
 * The shard shop GUI: end-game gear, the liquidation tools, and every custom
 * enchant book, paid for in shards instead of money.
 *
 * <p>The grid is filled with panes first and then overwritten, so a catalogue
 * shorter than the grid leaves blank panes rather than the icon of whatever was
 * sold last. Buying rebuilds the menu in place - the balance icon and the
 * red/green price colours follow the player's new balance - and never reopens
 * it, so a buyer's eye stays on the row they were reading.
 */
final class ShardShopMenu extends ChestMenu {
	// 6 rows = 54 slots
	private static final int ROWS = 6;
	private static final int SIZE = ROWS * 9;

	/**
	 * Offer slots: rows 1-4, columns 1-7 (columns 0 and 8 are border panes),
	 * which is the same block the money shop and the ranks ladder use.
	 */
	private static final List<Integer> OFFER_SLOTS = buildOfferSlots();

	/** Bottom row: balance, how to earn, and the exit. */
	private static final int BALANCE_SLOT = 45;
	private static final int INFO_SLOT = 46;
	private static final int CLOSE_SLOT = 53;

	private final ServerPlayer owner;
	private final List<ShardShop.Offer> offers;

	ShardShopMenu(int containerId, Inventory inventory, ServerPlayer owner) {
		super(MenuType.GENERIC_9x6, containerId, inventory, new SimpleContainer(SIZE), ROWS);
		this.owner = owner;
		this.offers = ShardShop.offers(owner.level().registryAccess());
		build();
	}

	private void build() {
		SimpleContainer container = (SimpleContainer) getContainer();

		// Fill the whole grid with panes first: a catalogue shorter than the
		// grid then shows blank panes, never the leftover icon of an offer
		// that is no longer there.
		ItemStack pane = new ItemStack(Compat.pickItem("STAINED_GLASS_PANE", DyeColor.BLACK));
		pane.set(DataComponents.CUSTOM_NAME, Component.literal(" "));
		for (int slot = 0; slot < SIZE; slot++) {
			container.setItem(slot, pane);
		}

		// Title row
		ItemStack head = new ItemStack(Items.PLAYER_HEAD);
		head.set(DataComponents.CUSTOM_NAME,
			Component.literal("SHARD SHOP").withStyle(ChatFormatting.LIGHT_PURPLE, ChatFormatting.BOLD));
		head.set(DataComponents.LORE, new ItemLore(List.of(
			Component.literal("§7End-game gear, paid for with shards."),
			Component.literal("§7Hover your balance for the earn rates."))));
		container.setItem(4, head);

		long balance = Shards.balance(owner.getUUID());

		// Balance button - the rates live on its tooltip
		ItemStack balanceIcon = new ItemStack(Items.AMETHYST_SHARD);
		List<Component> balanceLore = new ArrayList<>();
		balanceLore.add(Component.literal("§d" + TrimKits.formatAmount(balance) + " shards"));
		balanceLore.add(Component.literal(""));
		balanceLore.add(Component.literal("§6You earn:"));
		for (String line : Shards.rateLines()) {
			balanceLore.add(Component.literal("§8 - §f" + line));
		}
		balanceLore.add(Component.literal(""));
		balanceLore.add(Component.literal("§8Earned " + TrimKits.formatAmount(Shards.earned(owner.getUUID()))
			+ ", spent " + TrimKits.formatAmount(Shards.spent(owner.getUUID()))));
		balanceIcon.set(DataComponents.CUSTOM_NAME,
			Component.literal("Your shards").withStyle(ChatFormatting.LIGHT_PURPLE, ChatFormatting.BOLD));
		balanceIcon.set(DataComponents.LORE, new ItemLore(balanceLore));
		container.setItem(BALANCE_SLOT, balanceIcon);

		// Info button - sends the rates to chat
		ItemStack info = new ItemStack(Items.BOOK);
		info.set(DataComponents.CUSTOM_NAME,
			Component.literal("How to earn shards").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD));
		List<Component> infoLore = new ArrayList<>();
		infoLore.add(Component.literal("§7Shards come from playing:"));
		for (String line : Shards.rateLines()) {
			infoLore.add(Component.literal("§8 - §f" + line));
		}
		infoLore.add(Component.literal(""));
		infoLore.add(Component.literal("§8Click to see it in chat."));
		info.set(DataComponents.LORE, new ItemLore(infoLore));
		container.setItem(INFO_SLOT, info);

		// The offers themselves
		for (int index = 0; index < OFFER_SLOTS.size() && index < offers.size(); index++) {
			container.setItem(OFFER_SLOTS.get(index), icon(offers.get(index), balance));
		}
	}

	/**
	 * What a buyer is handed: the item exactly as sold, with none of the price
	 * lore the display copy carries. Package-private so the purchase path and
	 * the icon builder cannot drift apart.
	 */
	static ItemStack product(ShardShop.Offer offer) {
		return offer.stack().copy();
	}

	// These must match AbstractContainerMenu exactly (Player/ContainerInput).
	// Declaring an overload instead of an override silently disables the
	// buttons and hands the display icons to the player - a straight dupe.

	@Override
	public boolean stillValid(Player player) {
		return player == owner;
	}

	@Override
	public ItemStack quickMoveStack(Player player, int index) {
		// No shift-clicking in or out of the shard shop.
		return ItemStack.EMPTY;
	}

	@Override
	public void clicked(int slotId, int buttonNum, ContainerInput containerInput, Player player) {
		// Never let the vanilla handler run: the icons are real items and could
		// otherwise be pulled out of the menu.
		if (slotId < 0 || slotId >= SIZE) return;
		if (!(player instanceof ServerPlayer serverPlayer) || serverPlayer != owner) return;

		if (slotId == CLOSE_SLOT) {
			serverPlayer.closeContainer();
			return;
		}
		if (slotId == INFO_SLOT || slotId == BALANCE_SLOT) {
			TrimKits.showShardInfo(serverPlayer);
			return;
		}

		int index = OFFER_SLOTS.indexOf(slotId);
		if (index >= 0 && index < offers.size() && buttonNum == 0) {
			buy(offers.get(index));
		}
	}

	/** Charges the shards and hands the item over, or says why it did not happen. */
	private void buy(ShardShop.Offer offer) {
		MinecraftServer server = owner.level().getServer();
		if (server == null) {
			return;
		}
		server.execute(() -> {
			// The player may have closed the GUI between the click and this task.
			if (owner.containerMenu != this) {
				return;
			}
			String problem = Shards.buy(owner.getUUID(), offer.shards());
			if (problem != null) {
				owner.sendSystemMessage(Component.literal("§c" + problem));
				return;
			}
			// A boost is a service, not a thing: buying it starts the window
			// straight away rather than handing over the placeholder shard.
			if (offer.name().startsWith("Shard Boost")) {
				long left = ShardBoosts.secondsLeft(owner.getUUID());
				// Stack onto whatever is left so buying twice is never wasted.
				if (!ShardBoosts.extend(owner.getUUID(), ShardBoosts.BOOST_MINUTES)) {
					// The window could not be written down; hand the shards
					// back rather than sell a boost that a restart would eat.
					Shards.adminGive(owner.getUUID(), offer.shards());
					owner.sendSystemMessage(Component.literal(
						"§cThe boost could not be saved; you were not charged."));
					build();
					broadcastChanges();
					return;
				}
				owner.sendSystemMessage(Component.literal("§aShard boost active: x"
					+ ShardBoosts.BOOST_MULTIPLIER + " for " + ShardBoosts.BOOST_MINUTES
					+ " minutes" + (left > 0 ? ", on top of the " + (left / 60) + "m you had left." : ".")));
				TrimKits.syncInventory(owner);
				build();
				broadcastChanges();
				return;
			}
			Compat.placeBack(owner.getInventory(), product(offer));
			owner.sendSystemMessage(Component.literal("§aBought " + offer.name() + " for "
				+ TrimKits.formatAmount(offer.shards()) + " shards."));
			TrimKits.syncInventory(owner);
			// Refresh in place: the balance moved, so the price colours did too.
			build();
			broadcastChanges();
		});
	}

	/** The enchantments actually on a stack, spelled out the way vanilla would. */
	private static List<Component> enchantmentLines(ItemStack stack) {
		List<Component> lines = new ArrayList<>();
		ItemEnchantments applied = stack.get(DataComponents.ENCHANTMENTS);
		if (applied != null) {
			for (var record : applied.entrySet()) {
				lines.add(Enchantment.getFullname(record.getKey(), record.getIntValue())
					.copy().withStyle(ChatFormatting.GREEN));
			}
		}
		return lines;
	}

	private static ItemStack icon(ShardShop.Offer offer, long balance) {
		ItemStack stack = product(offer);
		boolean affordable = offer.affordable(balance);

		List<Component> lore = new ArrayList<>(enchantmentLines(stack));
		ItemLore existing = stack.get(DataComponents.LORE);
		if (existing != null) {
			for (Component line : existing.lines()) {
				lore.add(line);
			}
		}
		lore.add(Component.literal(""));
		lore.add(Component.literal(affordable
			? "§bCost: " + TrimKits.formatAmount(offer.shards()) + " shards"
			: "§cCost: " + TrimKits.formatAmount(offer.shards()) + " shards"));
		lore.add(affordable
			? Component.literal("§a§lClick to buy!")
			: Component.literal("§cNot enough shards"));

		stack.set(DataComponents.CUSTOM_NAME, Component.literal(offer.name())
			.withStyle(affordable ? ChatFormatting.WHITE : ChatFormatting.GRAY));
		stack.set(DataComponents.LORE, new ItemLore(lore));
		return stack;
	}

	/** Rows 1-4, columns 1-7, left to right and top to bottom. */
	private static List<Integer> buildOfferSlots() {
		List<Integer> slots = new ArrayList<>();
		for (int row = 1; row < ROWS - 1; row++) {
			for (int column = 1; column < 8; column++) {
				slots.add(row * 9 + column);
			}
		}
		return slots;
	}
}
