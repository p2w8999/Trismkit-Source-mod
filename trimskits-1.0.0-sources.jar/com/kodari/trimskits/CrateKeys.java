package com.kodari.trimskits;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;

/**
 * Crate keys: a shard-bought key that opens into a roll of rewards.
 *
 * <p>A key is a plain item wearing a lore line, exactly like the sell tools -
 * the marker lives in lore, which an anvil cannot forge. Right-click (or
 * /keyopen) to redeem it: the key is consumed, a weighted roll picks a prize,
 * and the prize is credited on the spot. Money goes to the balance, shards go
 * to the shard balance, and physical items land in the inventory.
 *
 * <p>The weights are deliberately lopsided: mostly small money, occasionally a
 * big win, so a key is a small thrill rather than a reliable income. That
 * keeps it a side reward for people who enjoy a flutter, not a replacement for
 * selling to the shop.
 */
final class CrateKeys {
	/** The lore line marking a crate key; detection matches this exact text. */
	static final String KEY_HINT = "Right-click to open a random reward.";

	/** One possible prize, and how likely it is relative to the others. */
	record Prize(String name, long weight, Runnable grant) {
	}

	private CrateKeys() {
	}

	/** Builds a crate key item. */
	static ItemStack key() {
		ItemStack stack = new ItemStack(Items.TRIPWIRE_HOOK);
		stack.set(DataComponents.CUSTOM_NAME, Component.literal("Crate Key").withStyle(
			net.minecraft.ChatFormatting.LIGHT_PURPLE));
		stack.set(DataComponents.LORE, new ItemLore(List.of(
			Component.literal(KEY_HINT).withStyle(net.minecraft.ChatFormatting.YELLOW),
			Component.literal("Bought with shards in /shardshop.").withStyle(net.minecraft.ChatFormatting.GRAY))));
		return stack;
	}

	static boolean isKey(ItemStack stack) {
		if (stack == null || stack.isEmpty()) {
			return false;
		}
		ItemLore lore = stack.get(DataComponents.LORE);
		if (lore == null) {
			return false;
		}
		for (Component line : lore.lines()) {
			if (KEY_HINT.equals(line.getString())) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Consumes one key from the player's hand and pays out a rolled prize.
	 *
	 * <p>The grant callbacks write directly to the player's balances, so the
	 * prize is applied exactly once and never touches the key stack again.
	 *
	 * @return a message describing what was won
	 */
	static String open(ServerPlayer player, ItemStack keyStack) {
		if (!isKey(keyStack)) {
			return null; // not a key: not ours to handle
		}
		List<Prize> prizes = prizes(player);
		long totalWeight = 0;
		for (Prize prize : prizes) {
			totalWeight += prize.weight();
		}
		long roll = (long) (Math.random() * totalWeight);
		Prize winner = prizes.get(prizes.size() - 1);
		long seen = 0;
		for (Prize prize : prizes) {
			seen += prize.weight();
			if (roll < seen) {
				winner = prize;
				break;
			}
		}
		// Shrink the key only once the prize is chosen, so a failed roll never
		// eats a key for nothing.
		winner.grant().run();
		keyStack.shrink(1);
		return "You opened a crate key and won: " + winner.name() + "!";
	}

	/**
	 * The prize table. Money prizes are closures over the player so the same
	 * table can be reused for every key without special-casing balances.
	 */
	private static List<Prize> prizes(ServerPlayer player) {
		List<Prize> prizes = new ArrayList<>();
		prizes.add(new Prize("$100", 30, () -> pay(player, 100)));
		prizes.add(new Prize("$250", 22, () -> pay(player, 250)));
		prizes.add(new Prize("$500", 16, () -> pay(player, 500)));
		prizes.add(new Prize("$1,000", 10, () -> pay(player, 1000)));
		prizes.add(new Prize("$2,500", 6, () -> pay(player, 2500)));
		prizes.add(new Prize("$5,000", 3, () -> pay(player, 5000)));
		prizes.add(new Prize("25 shards", 8, () -> shards(player, 25)));
		prizes.add(new Prize("75 shards", 3, () -> shards(player, 75)));
		prizes.add(new Prize("a Totem of Undying", 1, () -> give(player, new ItemStack(Items.TOTEM_OF_UNDYING))));
		prizes.add(new Prize("an Enchanted Golden Apple", 1, () ->
			give(player, new ItemStack(Items.ENCHANTED_GOLDEN_APPLE, 2))));
		return prizes;
	}

	private static void pay(ServerPlayer player, long amount) {
		MarketData.credit(player.getUUID(), amount, player.level().registryAccess());
		Ledger.record(player.getUUID(), amount, "crate", "money prize");
	}

	private static void shards(ServerPlayer player, long amount) {
		Shards.adminGive(player.getUUID(), amount);
	}

	private static void give(ServerPlayer player, ItemStack stack) {
		Compat.placeBack(player.getInventory(), stack);
	}
}
