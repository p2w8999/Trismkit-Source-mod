package com.kodari.trimskits;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.RegistryAccess;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.inventory.PlayerEnderChestContainer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemContainerContents;
import net.minecraft.world.item.component.ItemLore;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.enchantment.ItemEnchantments;
import net.minecraft.world.item.equipment.trim.ArmorTrim;
import net.minecraft.world.item.equipment.trim.TrimMaterials;
import net.minecraft.world.item.equipment.trim.TrimPatterns;

/**
 * The {@code /ender} command: drops a set of themed, named, enchanted shulker
 * boxes straight into the player's ender chest.
 *
 * <p>Four boxes make up the set — armour, weapons, tools and supplies — so the
 * whole kit fits in the first four ender-chest slots without shuffling anything
 * the player already keeps there. Every box is fully kitted: netherite armour
 * trimmed and enchanted, PvP weapons (maces, tridents, swords, axes), masterwork
 * tools, and a supplies box carrying breeze rods, enchanted golden apples,
 * totems, end crystals and friends. Every named piece is genuinely named, not
 * just enchanted, so the gear reads as bespoke loot rather than flat creative
 * filler.
 *
 * <h2>Why direct {@code setItem} is safe here</h2>
 * Vanilla blocks shulker boxes from being <em>inserted</em> into an ender chest
 * through the menu, via {@code Item#canFitInsideContainerItems}. That check only
 * runs on the click/drag path. Writing with
 * {@link PlayerEnderChestContainer#setItem} is a plain data write that never
 * consults the menu, so the boxes land in the ender chest cleanly — and because
 * removal is not restricted (only insertion is), the player can always take them
 * back out again. Nothing here mutates or clears existing contents.
 *
 * <h2>Safety</h2> If the ender chest has no room, the overflow goes to the
 * player's inventory via {@code placeItemBackInInventory} rather than being
 * dropped or destroyed, so a full ender chest can never eat the kit. Trim and
 * enchant application are individually guarded: a registry hiccup on one piece
 * degrades that one piece instead of aborting the whole command.
 */
final class EnderKits {

	/** Categories accepted by {@code /ender <category>}. */
	private enum Box {
		ARMOR("armor"), WEAPONS("weapons"), TOOLS("tools"), SUPPLIES("supplies");

		private final String id;

		Box(String id) {
			this.id = id;
		}

		static Box byId(String raw) {
			if (raw == null) {
				return null;
			}
			String text = raw.trim().toLowerCase(java.util.Locale.ROOT);
			for (Box box : values()) {
				if (box.id.equals(text)) {
					return box;
				}
			}
			return null;
		}
	}

	private EnderKits() {
	}

	// ---- Command entry points ---------------------------------------------

	/** {@code /ender} — hands over all four boxes. */
	static int giveAll(ServerPlayer player) {
		RegistryAccess registries = player.level().registryAccess();
		int placed = deposit(player, List.of(
			armorBox(registries), weaponsBox(registries), toolsBox(registries), suppliesBox()));
		announce(player, placed, 4);
		return 1;
	}

	/** {@code /ender <category>} — hands over a single themed box. */
	static int giveOne(ServerPlayer player, String rawCategory) {
		Box box = Box.byId(rawCategory);
		if (box == null) {
			player.sendSystemMessage(Component.literal(
				"§cUnknown box: " + rawCategory + "§7. Use /ender with no argument for all four,"));
			player.sendSystemMessage(Component.literal(
				"§7or one of: §farmor§7, §fweapons§7, §ftools§7, §fsupplies§7."));
			return 0;
		}
		RegistryAccess registries = player.level().registryAccess();
		ItemStack built = switch (box) {
			case ARMOR -> armorBox(registries);
			case WEAPONS -> weaponsBox(registries);
			case TOOLS -> toolsBox(registries);
			case SUPPLIES -> suppliesBox();
		};
		int placed = deposit(player, List.of(built));
		announce(player, placed, 1);
		return 1;
	}

	/**
	 * Places each box into the first free ender-chest slot, spilling any that do
	 * not fit into the inventory. Returns how many landed in the ender chest.
	 */
	private static int deposit(ServerPlayer player, List<ItemStack> boxes) {
		PlayerEnderChestContainer enderChest = player.getEnderChestInventory();
		int placed = 0;
		for (ItemStack box : boxes) {
			if (box == null || box.isEmpty()) {
				continue;
			}
			int slot = firstFreeSlot(enderChest);
			if (slot < 0) {
				// Ender chest full: never destroy the kit, hand it over instead.
				Compat.placeBack(player.getInventory(), box.copy());
				continue;
			}
			enderChest.setItem(slot, box.copy());
			placed++;
		}
		// Reflect the change to anyone currently looking at the ender chest.
		enderChest.setChanged();
		return placed;
	}

	/** First empty ender-chest slot, or -1 when it is completely full. */
	private static int firstFreeSlot(PlayerEnderChestContainer enderChest) {
		for (int slot = 0; slot < enderChest.getContainerSize(); slot++) {
			if (enderChest.getItem(slot).isEmpty()) {
				return slot;
			}
		}
		return -1;
	}

	private static void announce(ServerPlayer player, int placed, int requested) {
		if (placed == requested) {
			player.sendSystemMessage(Component.literal(
				"§aDeposited " + placed + " kit box" + (placed == 1 ? "" : "es") + " into your ender chest."));
			player.sendSystemMessage(Component.literal("§7Open your ender chest to unpack them."));
		} else if (placed > 0) {
			player.sendSystemMessage(Component.literal(
				"§eOnly " + placed + " of " + requested + " fit in your ender chest —"));
			player.sendSystemMessage(Component.literal("§7the rest went to your inventory."));
		} else {
			player.sendSystemMessage(Component.literal(
				"§7Your ender chest is full, so the kit went to your inventory."));
		}
	}

	// ---- The four boxes ---------------------------------------------------

	/** Full trimmed, enchanted netherite armour set. */
	private static ItemStack armorBox(RegistryAccess registries) {
		List<ItemStack> contents = new ArrayList<>();
		contents.add(gear(registries, Items.NETHERITE_HELMET, "Crown of the End",
			Map.of(Enchantments.PROTECTION, 4, Enchantments.UNBREAKING, 3, Enchantments.MENDING, 1,
				Enchantments.RESPIRATION, 3, Enchantments.AQUA_AFFINITY, 1, Enchantments.THORNS, 3,
				Enchantments.SWIFT_SNEAK, 3),
			TrimPatterns.SPIRE, TrimMaterials.NETHERITE));
		contents.add(gear(registries, Items.NETHERITE_CHESTPLATE, "Aegis of Ruin",
			Map.of(Enchantments.PROTECTION, 4, Enchantments.UNBREAKING, 3, Enchantments.MENDING, 1,
				Enchantments.THORNS, 3),
			TrimPatterns.WARD, TrimMaterials.NETHERITE));
		contents.add(gear(registries, Items.NETHERITE_LEGGINGS, "Greaves of the Void",
			Map.of(Enchantments.PROTECTION, 4, Enchantments.UNBREAKING, 3, Enchantments.MENDING, 1,
				Enchantments.THORNS, 3, Enchantments.SWIFT_SNEAK, 3),
			TrimPatterns.RIB, TrimMaterials.NETHERITE));
		contents.add(gear(registries, Items.NETHERITE_BOOTS, "Treads of the Deep",
			Map.of(Enchantments.PROTECTION, 4, Enchantments.UNBREAKING, 3, Enchantments.MENDING, 1,
				Enchantments.FEATHER_FALLING, 4, Enchantments.DEPTH_STRIDER, 3, Enchantments.SOUL_SPEED, 3),
			TrimPatterns.DUNE, TrimMaterials.NETHERITE));
		return shulker("§5§lDragonforged Armour",
			"§7Trimmed netherite, enchanted to the hilt.",
			"§8Protection IV · Thorns III · Mending", contents);
	}

	/** PvP weapons: maces, tridents, swords, an axe and a bow. */
	private static ItemStack weaponsBox(RegistryAccess registries) {
		List<ItemStack> contents = new ArrayList<>();
		contents.add(gear(registries, Items.MACE, "Earthshatter",
			Map.of(Enchantments.DENSITY, 5, Enchantments.BREACH, 4, Enchantments.WIND_BURST, 3,
				Enchantments.UNBREAKING, 10, Enchantments.MENDING, 1), null, null));
		contents.add(gear(registries, Items.MACE, "Stormcall",
			Map.of(Enchantments.DENSITY, 10, Enchantments.BREACH, 5, Enchantments.WIND_BURST, 5,
				Enchantments.UNBREAKING, 10, Enchantments.MENDING, 1), null, null));
		contents.add(gear(registries, Items.TRIDENT, "Tidefang",
			Map.of(Enchantments.LOYALTY, 3, Enchantments.CHANNELING, 1, Enchantments.IMPALING, 5,
				Enchantments.UNBREAKING, 10, Enchantments.MENDING, 1), null, null));
		contents.add(gear(registries, Items.TRIDENT, "Stormpiercer",
			Map.of(Enchantments.LOYALTY, 3, Enchantments.IMPALING, 5, Enchantments.UNBREAKING, 10,
				Enchantments.MENDING, 1), null, null));
		contents.add(gear(registries, Items.NETHERITE_SWORD, "Soulreaper",
			Map.of(Enchantments.SHARPNESS, 10, Enchantments.FIRE_ASPECT, 2, Enchantments.LOOTING, 3,
				Enchantments.SWEEPING_EDGE, 3, Enchantments.KNOCKBACK, 2, Enchantments.UNBREAKING, 10,
				Enchantments.MENDING, 1), null, null));
		contents.add(gear(registries, Items.NETHERITE_AXE, "Timberfall",
			Map.of(Enchantments.SHARPNESS, 7, Enchantments.EFFICIENCY, 5, Enchantments.FIRE_ASPECT, 2,
				Enchantments.LOOTING, 3, Enchantments.UNBREAKING, 10, Enchantments.MENDING, 1), null, null));
		contents.add(gear(registries, Items.BOW, "Skyrender",
			Map.of(Enchantments.POWER, 5, Enchantments.FLAME, 1, Enchantments.PUNCH, 2,
				Enchantments.UNBREAKING, 10, Enchantments.MENDING, 1), null, null));
		contents.add(gear(registries, Items.CROSSBOW, "Boltsplitter",
			Map.of(Enchantments.QUICK_CHARGE, 3, Enchantments.PIERCING, 4, Enchantments.UNBREAKING, 10,
				Enchantments.MENDING, 1), null, null));
		return shulker("§c§lWarlord's Arsenal",
			"§7Maces, tridents and blades for open war.",
			"§8Density X · Loyalty III · Sharpness X", contents);
	}

	/** Masterwork netherite tools, including both a silk-touch and a fortune pick. */
	private static ItemStack toolsBox(RegistryAccess registries) {
		List<ItemStack> contents = new ArrayList<>();
		contents.add(gear(registries, Items.NETHERITE_PICKAXE, "Worldbite",
			Map.of(Enchantments.EFFICIENCY, 10, Enchantments.FORTUNE, 3, Enchantments.UNBREAKING, 10,
				Enchantments.MENDING, 1), null, null));
		contents.add(gear(registries, Items.NETHERITE_PICKAXE, "Delver of Glass",
			Map.of(Enchantments.EFFICIENCY, 10, Enchantments.SILK_TOUCH, 1, Enchantments.UNBREAKING, 10,
				Enchantments.MENDING, 1), null, null));
		contents.add(gear(registries, Items.NETHERITE_SHOVEL, "Gravelbane",
			Map.of(Enchantments.EFFICIENCY, 10, Enchantments.FORTUNE, 3, Enchantments.UNBREAKING, 10,
				Enchantments.MENDING, 1), null, null));
		contents.add(gear(registries, Items.NETHERITE_HOE, "Reapstorm",
			Map.of(Enchantments.EFFICIENCY, 10, Enchantments.FORTUNE, 3, Enchantments.UNBREAKING, 10,
				Enchantments.MENDING, 1), null, null));
		return shulker("§b§lMasterwork Tools",
			"§7Netherite tools, both fortune and silk touch.",
			"§8Efficiency X · Unbreaking X · Mending", contents);
	}

	/** The "everything else" box: breeze rods, golden apples and general treasure. */
	private static ItemStack suppliesBox() {
		List<ItemStack> contents = new ArrayList<>();
		contents.add(named(Items.BREEZE_ROD, 64, "§bStorm Rod",
			"§7Cut from a breeze. Crack it for wind."));
		contents.add(new ItemStack(Items.WIND_CHARGE, 64));
		contents.add(named(Items.ENCHANTED_GOLDEN_APPLE, 64, "§6Ambrosia",
			"§7The enchanted golden apple, in bulk."));
		contents.add(new ItemStack(Items.GOLDEN_APPLE, 64));
		contents.add(new ItemStack(Items.TOTEM_OF_UNDYING, 64));
		contents.add(new ItemStack(Items.END_CRYSTAL, 64));
		contents.add(named(Items.NETHER_STAR, 16, "§fFallen Star",
			"§7Sixteen of them. Build a beacon forest."));
		contents.add(new ItemStack(Items.EXPERIENCE_BOTTLE, 64));
		contents.add(new ItemStack(Items.ENDER_PEARL, 64));
		contents.add(new ItemStack(Items.FIREWORK_ROCKET, 64));
		contents.add(new ItemStack(Items.SHULKER_SHELL, 64));
		contents.add(named(Items.ELYTRA, 1, "§dWings of the Rift",
			"§7Pair with the rockets in this box."));
		return shulker("§6§lStormcaller's Cache",
			"§7Breeze rods, enchanted apples and treasure.",
			"§8Totems · End crystals · Elytra", contents);
	}

	// ---- Item builders ----------------------------------------------------

	/**
	 * Wraps a list of stacks into a named, lore-tagged shulker box.
	 *
	 * <p>The box carries no {@code MAX_STACK_SIZE} override, so it keeps the
	 * vanilla stack size of 1 — shulker boxes are meant to be handled one at a
	 * time, and letting them stack would invite dupe-shaped edge cases.
	 */
	private static ItemStack shulker(String title, String lineOne, String lineTwo,
			List<ItemStack> contents) {
		ItemStack box = new ItemStack(Items.SHULKER_BOX);
		box.set(DataComponents.CUSTOM_NAME, Component.literal(title));
		box.set(DataComponents.LORE, new ItemLore(List.of(
			Component.literal(lineOne), Component.literal(lineTwo))));
		// Guard against a null entry so a bad build never yields a broken box.
		List<ItemStack> safe = contents.stream().filter(stack -> stack != null && !stack.isEmpty()).toList();
		box.set(DataComponents.CONTAINER, ItemContainerContents.fromItems(safe));
		return box;
	}

	/**
	 * Builds one named, enchanted (and optionally trimmed) piece of gear.
	 *
	 * @param pattern trim pattern key, or null to leave the piece untrimmed
	 * @param material trim material key, or null to leave the piece untrimmed
	 */
	private static ItemStack gear(RegistryAccess registries, Item item, String name,
			Map<ResourceKey<Enchantment>, Integer> enchantments,
			ResourceKey<net.minecraft.world.item.equipment.trim.TrimPattern> pattern,
			ResourceKey<net.minecraft.world.item.equipment.trim.TrimMaterial> material) {
		ItemStack stack = new ItemStack(item);
		stack.set(DataComponents.CUSTOM_NAME, Component.literal(name));
		applyEnchantments(registries, stack, enchantments);
		if (pattern != null && material != null) {
			applyTrim(registries, stack, pattern, material);
		}
		return stack;
	}

	/**
	 * Stamps enchantments onto a stack via the component API.
	 *
	 * <p>Levels above vanilla caps (Unbreaking X, Density X, Sharpness X) are
	 * deliberate: this is a giveaway kit, and the component API accepts any
	 * level without validation, so nothing here depends on an anvil ever having
	 * produced the item.
	 */
	private static void applyEnchantments(RegistryAccess registries, ItemStack stack,
			Map<ResourceKey<Enchantment>, Integer> enchantments) {
		if (enchantments == null || enchantments.isEmpty()) {
			return;
		}
		try {
			Registry<Enchantment> registry = registries.lookupOrThrow(Registries.ENCHANTMENT);
			ItemEnchantments.Mutable stored = new ItemEnchantments.Mutable(ItemEnchantments.EMPTY);
			for (Map.Entry<ResourceKey<Enchantment>, Integer> entry : enchantments.entrySet()) {
				Holder<Enchantment> holder = registry.get(entry.getKey()).orElse(null);
				if (holder == null) {
					// A datapack that removes this enchant skips it rather than
					// failing the whole piece.
					continue;
				}
				stored.set(holder, Math.max(1, entry.getValue()));
			}
			stack.set(DataComponents.ENCHANTMENTS, stored.toImmutable());
		} catch (RuntimeException exception) {
			TrimKits.LOGGER.warn("Could not enchant {}: {}", stack.getItem(), exception.getMessage());
		}
	}

	/**
	 * Applies an armour trim. Best-effort: a failure logs and leaves the piece
	 * untrimmed, because a missing trim should never cost the player the item.
	 */
	private static void applyTrim(RegistryAccess registries, ItemStack stack,
			ResourceKey<net.minecraft.world.item.equipment.trim.TrimPattern> pattern,
			ResourceKey<net.minecraft.world.item.equipment.trim.TrimMaterial> material) {
		try {
			Registry<net.minecraft.world.item.equipment.trim.TrimPattern> patterns =
				registries.lookupOrThrow(Registries.TRIM_PATTERN);
			Registry<net.minecraft.world.item.equipment.trim.TrimMaterial> materials =
				registries.lookupOrThrow(Registries.TRIM_MATERIAL);
			Holder<net.minecraft.world.item.equipment.trim.TrimPattern> patternHolder =
				patterns.get(pattern).orElse(null);
			Holder<net.minecraft.world.item.equipment.trim.TrimMaterial> materialHolder =
				materials.get(material).orElse(null);
			if (patternHolder == null || materialHolder == null) {
				return;
			}
			stack.set(DataComponents.TRIM, new ArmorTrim(materialHolder, patternHolder));
		} catch (RuntimeException exception) {
			TrimKits.LOGGER.warn("Could not trim {}: {}", stack.getItem(), exception.getMessage());
		}
	}

	/** A plain named stack, for supplies that need a title but no enchanting. */
	private static ItemStack named(Item item, int count, String name, String lore) {
		ItemStack stack = new ItemStack(item, Math.max(1, count));
		stack.set(DataComponents.CUSTOM_NAME, Component.literal(name));
		stack.set(DataComponents.LORE, new ItemLore(List.of(Component.literal(lore))));
		return stack;
	}
}
