package com.kodari.trimskits;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * Manages the config/OPS.json file that controls which players have admin and
 * /sfmode permissions.
 *
 * <p>The JSON structure looks like:
 * <pre>{@code
 * {
 *   "ops": [
 *     {
 *       "username": "vadim154655",
 *       "permissions": ["admin", "sfmode"]
 *     },
 *     {
 *       "username": "SomeOtherPlayer",
 *       "permissions": ["sfmode"]
 *     }
 *   ]
 * }
 * }</pre>
 *
 * <p>Permissions:
 * <ul>
 *   <li><b>admin</b> – full admin commands (/money, /rank, /shards, /crystal, /spawnstash, etc.)</li>
 *   <li><b>sfmode</b> – allowed to toggle admin mode via /sfmode</li>
 * </ul>
 *
 * <p>A player with "admin" implicitly also has "sfmode".
 *
 * <p>Three conveniences, all learned the hard way from servers where the file
 * "did not work":
 * <ul>
 *   <li>The file lives in <b>config/</b> - the folder the mod's other settings
 *       already use. Older builds looked in configs/ (plural), so a legacy
 *       file found there is read once and migrated to the new folder.</li>
 *   <li>An entry may say "username" or "name", and may be nested under "ops"
 *       or sit at the root as a plain array - the shapes people actually
 *       paste in.</li>
 *   <li>A vanilla-shaped entry (the one the game's own ops.json uses, keyed
 *       by name/uuid with a numeric "level") is accepted too: level 4 reads as
 *       admin, level 1 and above as sfmode. A server owner who points this at
 *       a vanilla file keeps working instead of silently losing access.</li>
 * </ul>
 * A file that cannot be parsed leaves the list empty rather than throwing, but
 * it is never overwritten - the next /opsreload can still fix it by hand.
 */
public final class OpsConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_DIR = Path.of("config");
    private static final Path OPS_FILE = CONFIG_DIR.resolve("OPS.json");
    /** Where builds before this one looked. Only read, to migrate. */
    private static final Path LEGACY_FILE = Path.of("configs", "OPS.json");
    /** Vanilla's ops.json spells a top-level entry "name" and levels it 0-4. */
    private static final int VANILLA_ADMIN_LEVEL = 4;
    private static final int VANILLA_SFMODE_LEVEL = 1;

    /** Permission constant for full admin access. */
    public static final String PERM_ADMIN = "admin";
    /** Permission constant for /sfmode toggle access. */
    public static final String PERM_SFMODE = "sfmode";

    /** Cached list of operator entries, loaded once and reloadable. */
    private static List<OpEntry> entries = Collections.emptyList();
    private static boolean loaded = false;

    private OpsConfig() {}

    /** A single operator entry. */
    public record OpEntry(String username, List<String> permissions) {
        public boolean hasPermission(String perm) {
            // "admin" implies "sfmode"
            if (PERM_SFMODE.equals(perm) && permissions.contains(PERM_ADMIN)) {
                return true;
            }
            return permissions.contains(perm);
        }
    }

    /**
     * Loads (or creates) the configs/OPS.json file.
     * Called once during mod initialization.
     */
    public static synchronized void load() {
        if (loaded) return;
        loaded = true;

        try {
            Files.createDirectories(CONFIG_DIR);
        } catch (IOException e) {
            TrimKits.LOGGER.warn("Failed to create config directory: {}", e.getMessage());
        }

        // A file left in the old plural folder wins only when config/ has none,
        // and is moved across so the next load finds it in the right place.
        if (!Files.exists(OPS_FILE) && Files.exists(LEGACY_FILE)) {
            try {
                Files.createDirectories(LEGACY_FILE.getParent());
                Files.move(LEGACY_FILE, OPS_FILE);
                TrimKits.LOGGER.info("Migrated OPS.json from {} to {}.", LEGACY_FILE, OPS_FILE);
            } catch (IOException e) {
                TrimKits.LOGGER.warn("Could not move legacy OPS.json, reading it in place: {}", e.getMessage());
            }
        }

        Path source = Files.exists(OPS_FILE) ? OPS_FILE : LEGACY_FILE;
        if (Files.exists(source)) {
            try {
                String content = Files.readString(source);
                entries = parseEntries(content);
                TrimKits.LOGGER.info("Loaded {} operator(s) from {}", entries.size(), source);
            } catch (IOException | RuntimeException e) {
                TrimKits.LOGGER.warn("Failed to read {} ({}), using empty ops list - the file was left untouched.",
                    source, e.getMessage());
                entries = new ArrayList<>();
            }
        } else {
            // Create a default OPS.json with the configured admin username
            String defaultAdmin = Config.getString("admin.username", "vadim154655").trim();
            if (defaultAdmin.isEmpty()) defaultAdmin = "vadim154655";

            entries = new ArrayList<>();
            entries.add(new OpEntry(defaultAdmin, List.of(PERM_ADMIN, PERM_SFMODE)));
            save();
            TrimKits.LOGGER.info("Created default OPS.json with admin '{}'", defaultAdmin);
        }
    }

    /**
     * Force-reloads OPS.json from disk. Useful for a /opsreload command.
     */
    public static synchronized void reload() {
        loaded = false;
        load();
    }

    /**
     * Saves the current entries back to configs/OPS.json.
     */
    public static synchronized void save() {
        JsonObject root = new JsonObject();
        JsonArray opsArray = new JsonArray();
        for (OpEntry entry : entries) {
            JsonObject obj = new JsonObject();
            obj.addProperty("username", entry.username());
            JsonArray perms = new JsonArray();
            for (String p : entry.permissions()) {
                perms.add(p);
            }
            obj.add("permissions", perms);
            opsArray.add(obj);
        }
        root.add("ops", opsArray);

        try {
            Files.createDirectories(CONFIG_DIR);
            Files.writeString(OPS_FILE, GSON.toJson(root));
        } catch (IOException e) {
            TrimKits.LOGGER.warn("Failed to save OPS.json: {}", e.getMessage());
        }
    }

    /**
     * Checks if a player (by username) has a specific permission.
     *
     * @param username the player's scoreboard name
     * @param permission one of {@link #PERM_ADMIN} or {@link #PERM_SFMODE}
     * @return true if the player has the given permission in OPS.json
     */
    public static boolean hasPermission(String username, String permission) {
        if (username == null) return false;
        load();
        for (OpEntry entry : entries) {
            if (entry.username().equalsIgnoreCase(username)) {
                return entry.hasPermission(permission);
            }
        }
        return false;
    }

    /**
     * Checks if a username is listed in OPS.json at all (with any permissions).
     */
    public static boolean isOperator(String username) {
        if (username == null) return false;
        load();
        for (OpEntry entry : entries) {
            if (entry.username().equalsIgnoreCase(username)) {
                return true;
            }
        }
        return false;
    }

    /** Returns an unmodifiable copy of the current operator entries. */
    public static List<OpEntry> getEntries() {
        load();
        return Collections.unmodifiableList(entries);
    }

    /**
     * Grants permissions to a player in OPS.json, creating or extending their
     * entry as needed. Used when a staff application is accepted in
     * {@code /modlogs}. The file is re-read from disk first so a hand-edited
     * (but valid) OPS.json is respected, and an unparseable file is never
     * overwritten - the grant is refused with a warning instead.
     *
     * @param username    the player's name
     * @param permissions {@link #PERM_ADMIN} and/or {@link #PERM_SFMODE}
     * @return true if something changed on disk
     */
    public static synchronized boolean grant(String username, String... permissions) {
        if (username == null || username.isBlank()) return false;
        load();
        // Work from the file on disk, not the cache: a hand edit made while
        // the server runs must not be thrown away by a later save.
        List<OpEntry> current;
        try {
            Path source = Files.exists(OPS_FILE) ? OPS_FILE : LEGACY_FILE;
            current = Files.exists(source) ? parseEntries(Files.readString(source)) : new ArrayList<>(entries);
        } catch (IOException | RuntimeException e) {
            TrimKits.LOGGER.warn("Not granting permissions to '{}': OPS.json could not be parsed ({}). "
                + "The file was left untouched; fix or delete it, then /opsreload.", username, e.getMessage());
            return false;
        }
        boolean changed = false;
        boolean found = false;
        for (int i = 0; i < current.size(); i++) {
            OpEntry entry = current.get(i);
            if (!entry.username().equalsIgnoreCase(username)) continue;
            found = true;
            List<String> merged = new ArrayList<>(entry.permissions());
            for (String permission : permissions) {
                if (permission != null && !permission.isBlank() && !merged.contains(permission)) {
                    merged.add(permission);
                    changed = true;
                }
            }
            if (changed) {
                current.set(i, new OpEntry(entry.username(), List.copyOf(merged)));
            }
        }
        if (!found) {
            List<String> merged = new ArrayList<>();
            for (String permission : permissions) {
                if (permission != null && !permission.isBlank()) merged.add(permission);
            }
            if (!merged.isEmpty()) {
                current.add(new OpEntry(username, List.copyOf(merged)));
                changed = true;
            }
        }
        if (changed) {
            entries = current;
            save();
        }
        return changed;
    }

    // ---- Parsing ----

    /**
     * Reads whichever shape the file is in. Anything unrecognised is skipped
     * line by line rather than aborting, so one bad entry cannot lock every
     * operator out of the server.
     */
    private static List<OpEntry> parseEntries(String json) {
        List<OpEntry> result = new ArrayList<>();
        JsonElement parsed = JsonParser.parseString(json);
        JsonArray opsArray;
        if (parsed.isJsonArray()) {
            // A bare [ ... ] array, as some tools export it.
            opsArray = parsed.getAsJsonArray();
        } else if (parsed.isJsonObject() && parsed.getAsJsonObject().has("ops")) {
            opsArray = parsed.getAsJsonObject().getAsJsonArray("ops");
        } else {
            throw new IllegalArgumentException("expected an \"ops\" array or a top-level array");
        }
        for (JsonElement elem : opsArray) {
            if (!elem.isJsonObject()) continue;
            JsonObject obj = elem.getAsJsonObject();
            // "username" is this mod's spelling, "name" is vanilla's.
            String username = firstString(obj, "username", "name");
            if (username == null || username.isBlank()) continue;
            List<String> perms = new ArrayList<>();
            if (obj.has("permissions") && obj.get("permissions").isJsonArray()) {
                for (JsonElement p : obj.getAsJsonArray("permissions")) {
                    if (p.isJsonPrimitive()) {
                        String perm = p.getAsString().toLowerCase(Locale.ROOT);
                        // Tolerate the common "admin:" / "sfmode " slips.
                        perm = perm.replace("perm:", "").trim();
                        if (!perm.isEmpty()) perms.add(perm);
                    }
                }
            } else if (obj.has("level") && obj.get("level").isJsonPrimitive()) {
                // Vanilla ops.json levels: 4 is full op, 1+ may run commands.
                try {
                    int level = obj.get("level").getAsInt();
                    if (level >= VANILLA_ADMIN_LEVEL) {
                        perms.add(PERM_ADMIN);
                    } else if (level >= VANILLA_SFMODE_LEVEL) {
                        perms.add(PERM_SFMODE);
                    }
                } catch (RuntimeException ignored) {
                    // A non-numeric level simply grants nothing.
                }
            }
            result.add(new OpEntry(username, Collections.unmodifiableList(perms)));
        }
        return result;
    }

    /** The first present, non-blank string among the given keys. */
    private static String firstString(JsonObject obj, String... keys) {
        for (String key : keys) {
            if (obj.has(key) && obj.get(key).isJsonPrimitive()) {
                String value = obj.get(key).getAsString();
                if (!value.isBlank()) {
                    return value.trim();
                }
            }
        }
        return null;
    }
}
