package com.kodari.trimskits;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;
import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;
import net.minecraft.world.item.component.ResolvableProfile;

/**
 * A stats screen worth looking at: a bordered chest with your skin on top,
 * every number on its own icon, a rank ladder you climb with playtime, both
 * kill-crystal ladders, and a live leaderboard you can flip between balance,
 * kills, mob kills, blocks, items sold and playtime.
 *
 * <p>It opens for yourself with /stats and for anyone else with /stats &lt;player&gt;.
 */
final class StatsMenu extends ChestMenu {
	private static final int ROWS = 6;
	private static final int SIZE = ROWS * 9;

	private static final int SLOT_HEAD = 4;

	private static final int SLOT_KILLS = 10;
	private static final int SLOT_DEATHS = 11;
	private static final int SLOT_KD = 12;
	private static final int SLOT_BLOCKS = 13;
	private static final int SLOT_SOLD = 14;
	private static final int SLOT_BALANCE = 15;
	private static final int SLOT_RANK = 16;

	private static final int SLOT_PLAYTIME = 20;
	private static final int SLOT_FIRST_SEEN = 21;
	private static final int SLOT_STATUS = 22;
	/** The framed strip: mob kills, the crystal ladders, and shards. */
	private static final int SLOT_MOB_KILLS = 23;
	private static final int SLOT_CRYSTALS = 24;
	private static final int SLOT_SHARDS = 25;

	/** Leaderboard rows: the two middle rows, seven usable slots each. */
	private static final int[] LEADERBOARD_SLOTS = {
		28, 29, 30, 31, 32, 33, 34,
		37, 38, 39, 40, 41, 42, 43
	};

	private static final int BAR = (ROWS - 1) * 9;
	private static final int SLOT_CLOSE = BAR + 0;
	private static final int SLOT_REFRESH = BAR + 1;
	private static final int SLOT_METRIC = BAR + 2;

	private static final Item PANE = Compat.pickItem("STAINED_GLASS_PANE", DyeColor.CYAN);

	/** Playtime ladder, in seconds, matching TrimKits.rankOf. */
	private static final long[] RANK_THRESHOLDS = {
		0L, 3_600L, 18_000L, 72_000L, 180_000L, 360_000L, 900_000L, 1_800_000L
	};
	private static final String[] RANK_NAMES = {
		"Newcomer", "Miner", "Trader", "Veteran", "Elite", "Champion", "Master", "Legend"
	};

	/** What the leaderboard ranks players by. */
	enum Metric {
		BALANCE("Balance", Items.GOLD_BLOCK),
		SHARDS("Shards", Items.AMETHYST_SHARD),
		KILLS("Kills", Items.IRON_SWORD),
		MOB_KILLS("Mob kills", Items.ROTTEN_FLESH),
		BLOCKS("Blocks mined", Items.DIAMOND_PICKAXE),
		SOLD("Items sold", Items.EMERALD),
		PLAYTIME("Playtime", Items.CLOCK);

		private final String label;
		private final Item icon;

		Metric(String label, Item icon) {
			this.label = label;
			this.icon = icon;
		}

		String label() {
			return label;
		}

		Item icon() {
			return icon;
		}

		Metric next() {
			Metric[] all = values();
			return all[(ordinal() + 1) % all.length];
		}

		long valueFor(UUID playerId) {
			return switch (this) {
				case BALANCE -> MarketData.balance(playerId);
				case SHARDS -> Shards.balance(playerId);
				case KILLS -> PlayerStats.kills(playerId);
				case MOB_KILLS -> PlayerStats.mobKills(playerId);
				case BLOCKS -> PlayerStats.blocksBroken(playerId);
				case SOLD -> PlayerStats.itemsSold(playerId);
				case PLAYTIME -> PlayerStats.playtimeSeconds(playerId);
			};
		}

		String format(UUID playerId) {
			long value = valueFor(playerId);
			return this == PLAYTIME ? PlayerStats.playtimeText(playerId) : TrimKits.formatAmount(value);
		}
	}

	private final ServerPlayer owner;
	private final UUID targetId;
	private final String targetName;
	private final SimpleContainer container;

	private Metric metric = Metric.BALANCE;

	StatsMenu(int containerId, Inventory inventory, ServerPlayer owner, UUID targetId, String targetName) {
		super(MenuType.GENERIC_9x6, containerId, inventory, new SimpleContainer(SIZE), ROWS);
		this.owner = owner;
		this.targetId = targetId;
		this.targetName = targetName;
		this.container = (SimpleContainer) getContainer();
		render();
	}

	private void render() {
		MarketData.initialize(owner.level().registryAccess());

		for (int slot = 0; slot < SIZE; slot++) {
			container.setItem(slot, ItemStack.EMPTY);
		}
		for (int slot = 0; slot < SIZE; slot++) {
			if (isBorder(slot)) {
				container.setItem(slot, pane());
			}
		}

		renderHeader();
		renderCombatRow();
		renderProfileRow();
		renderLeaderboard();
		renderBar();

		broadcastChanges();
	}

	/** The outer frame, skipping the slots that carry real content. */
	private static boolean isBorder(int slot) {
		int row = slot / 9;
		int column = slot % 9;
		if (row == 0) {
			return slot != SLOT_HEAD;
		}
		if (row == ROWS - 1) {
			return column >= 3 && column <= 7;
		}
		return column == 0 || column == 8;
	}

	private static ItemStack pane() {
		return new ItemStack(PANE);
	}

	private void renderHeader() {
		ItemStack head = new ItemStack(Items.PLAYER_HEAD);
		head.set(DataComponents.PROFILE, ResolvableProfile.createUnresolved(targetId));

		boolean self = targetId.equals(owner.getUUID());
		int tier = RankShop.effectiveTier(targetId, PlayerStats.playtimeSeconds(targetId));
		ChatFormatting rankColour = RankShop.colourOf(targetId, PlayerStats.playtimeSeconds(targetId));
		head.set(DataComponents.CUSTOM_NAME, Component.literal(targetName)
			.withStyle(rankColour)
			.append(Component.literal(self ? "  (you)" : "").withStyle(ChatFormatting.DARK_GRAY)));

		List<Component> lore = new ArrayList<>();
		lore.add(Component.literal("Rank: " + RankShop.nameOf(targetId, PlayerStats.playtimeSeconds(targetId)))
			.withStyle(rankColour));
		lore.add(Component.literal("Mob crystal: " + CombatRanks.nameOf(CombatRanks.Ladder.MOB, targetId))
			.withStyle(CombatRanks.colourOf(CombatRanks.Ladder.MOB, targetId)));
		lore.add(Component.literal("PvP crystal: " + CombatRanks.nameOf(CombatRanks.Ladder.PVP, targetId))
			.withStyle(CombatRanks.colourOf(CombatRanks.Ladder.PVP, targetId)));
		lore.add(Component.empty());
		lore.add(Component.literal("Balance: $" + TrimKits.formatAmount(MarketData.balance(targetId)))
			.withStyle(ChatFormatting.GOLD));
		lore.add(Component.literal("Shards: " + TrimKits.formatAmount(Shards.balance(targetId)))
			.withStyle(ChatFormatting.LIGHT_PURPLE));
		lore.add(Component.literal("Playtime: " + PlayerStats.playtimeText(targetId))
			.withStyle(ChatFormatting.AQUA));
		lore.add(Component.empty());
		lore.add(Component.literal(isOnline(targetId) ? "Currently online" : "Currently offline")
			.withStyle(isOnline(targetId) ? ChatFormatting.GREEN : ChatFormatting.GRAY));
		head.set(DataComponents.LORE, new ItemLore(lore));
		container.setItem(SLOT_HEAD, head);
	}

	private void renderCombatRow() {
		long kills = PlayerStats.kills(targetId);
		long deaths = PlayerStats.deaths(targetId);

		container.setItem(SLOT_KILLS, stat(Items.IRON_SWORD, "Kills",
			TrimKits.formatAmount(kills), ChatFormatting.RED,
			"Players you have taken down"));
		container.setItem(SLOT_DEATHS, stat(Items.SKELETON_SKULL, "Deaths",
			TrimKits.formatAmount(deaths), ChatFormatting.DARK_GRAY,
			"Times you have died"));
		container.setItem(SLOT_KD, stat(Items.BONE, "Kill / death",
			TrimKits.ratio(kills, deaths), ChatFormatting.AQUA,
			"Kills divided by deaths", "Deaths do not count against you"));

		container.setItem(SLOT_BLOCKS, stat(Items.DIAMOND_PICKAXE, "Blocks mined",
			TrimKits.formatAmount(PlayerStats.blocksBroken(targetId)), ChatFormatting.GREEN,
			"Blocks broken since tracking began"));
		container.setItem(SLOT_SOLD, stat(Items.EMERALD, "Items sold",
			TrimKits.formatAmount(PlayerStats.itemsSold(targetId)), ChatFormatting.GREEN,
			"Units sold through /sell"));
		container.setItem(SLOT_BALANCE, stat(Items.GOLD_BLOCK, "Balance",
			"$" + TrimKits.formatAmount(MarketData.balance(targetId)), ChatFormatting.GOLD,
			"Use /baltop to see the richest players"));

		// Combat extras, in the framed strip below the first row.
		container.setItem(SLOT_MOB_KILLS, stat(Items.ROTTEN_FLESH, "Mob kills",
			TrimKits.formatAmount(PlayerStats.mobKills(targetId)), ChatFormatting.RED,
			"Mobs you have taken down",
			"Climbs the Mob Crystal ladder"));
		container.setItem(SLOT_CRYSTALS, crystalRanks());
		container.setItem(SLOT_SHARDS, stat(Items.AMETHYST_SHARD, "Shards",
			TrimKits.formatAmount(Shards.balance(targetId)), ChatFormatting.LIGHT_PURPLE,
			"Earned from kills, mining and playtime",
			"Spend them in /shardshop"));

		int tier = RankShop.effectiveTier(targetId, PlayerStats.playtimeSeconds(targetId));
		ChatFormatting rankColour = RankShop.colourOf(targetId, PlayerStats.playtimeSeconds(targetId));
		ItemStack rank = stat(Items.NETHER_STAR, "Rank",
			RankShop.nameOf(targetId, PlayerStats.playtimeSeconds(targetId)), rankColour,
			"Earned by playing or bought, shown on the sidebar");
		List<Component> rankLore = new ArrayList<>(rank.getOrDefault(DataComponents.LORE, ItemLore.EMPTY).lines());
		rankLore.addAll(this.rankLore());
		rank.set(DataComponents.LORE, new ItemLore(rankLore));
		container.setItem(SLOT_RANK, rank);
	}

	/** Both kill ladders in one icon: the crystal held and the progress made. */
	private ItemStack crystalRanks() {
		CombatRanks.Ladder mob = CombatRanks.Ladder.MOB;
		CombatRanks.Ladder pvp = CombatRanks.Ladder.PVP;

		ItemStack stack = new ItemStack(Items.AMETHYST_SHARD);
		stack.set(DataComponents.CUSTOM_NAME,
			Component.literal("Crystal ranks").withStyle(ChatFormatting.WHITE));
		List<Component> lore = new ArrayList<>();
		lore.add(Component.literal("Mob: " + CombatRanks.nameOf(mob, targetId))
			.withStyle(CombatRanks.colourOf(mob, targetId)));
		lore.add(Component.literal("PvP: " + CombatRanks.nameOf(pvp, targetId))
			.withStyle(CombatRanks.colourOf(pvp, targetId)));
		lore.add(Component.empty());
		lore.add(Component.literal("Mob progress: " + CombatRanks.progressText(mob, targetId))
			.withStyle(ChatFormatting.GRAY));
		lore.add(Component.literal("PvP progress: " + CombatRanks.progressText(pvp, targetId))
			.withStyle(ChatFormatting.GRAY));
		lore.add(Component.empty());
		lore.add(Component.literal("Earn them with kills, or buy them in /ranks")
			.withStyle(ChatFormatting.DARK_GRAY));
		stack.set(DataComponents.LORE, new ItemLore(lore));
		return stack;
	}

	private void renderProfileRow() {
		long firstSeen = PlayerStats.firstSeen(targetId);
		container.setItem(SLOT_PLAYTIME, stat(Items.CLOCK, "Playtime",
			PlayerStats.playtimeText(targetId), ChatFormatting.LIGHT_PURPLE,
			"Total time spent on the server"));
		container.setItem(SLOT_FIRST_SEEN, stat(Items.RECOVERY_COMPASS, "First seen",
			firstSeen <= 0 ? "never" : TrimKits.timeAgo(firstSeen), ChatFormatting.YELLOW,
			"When this player first joined"));

		boolean online = isOnline(targetId);
		Item statusItem = online
			? Compat.pickItem("STAINED_GLASS_PANE", DyeColor.LIME)
			: Compat.pickItem("STAINED_GLASS_PANE", DyeColor.GRAY);
		container.setItem(SLOT_STATUS, stat(statusItem,
			"Status", online ? "Online" : "Offline",
			online ? ChatFormatting.GREEN : ChatFormatting.GRAY,
			online ? "Playing right now" : "Not currently connected"));

		// Frame the strip so the empty gaps read as decoration, not leftovers.
		for (int slot = 19; slot <= 25; slot++) {
			if (container.getItem(slot).isEmpty()) {
				container.setItem(slot, pane());
			}
		}
	}

	/** The full rank ladder, with the current rung picked out. */
	private List<Component> rankLore() {
		int current = RankShop.effectiveTier(targetId, PlayerStats.playtimeSeconds(targetId));
		List<Component> lines = new ArrayList<>();
		lines.add(Component.literal("Ranks").withStyle(ChatFormatting.GOLD));
		for (RankShop.Rank rank : RankShop.RANKS) {
			String threshold = rank.tier() == 0 ? "start" : RankShop.formatTime(rank.playtimeSeconds());
			ChatFormatting color = rank.tier() == current ? ChatFormatting.GREEN : ChatFormatting.DARK_GRAY;
			lines.add(Component.literal((rank.tier() == current ? " > " : "   ") + rank.name()
					+ "  (" + threshold + ")")
				.withStyle(color));
		}
		lines.add(Component.empty());
		if (current + 1 < RankShop.RANKS.size()) {
			RankShop.Rank next = RankShop.get(current + 1);
			long remaining = Math.max(0, next.playtimeSeconds() - PlayerStats.playtimeSeconds(targetId));
			lines.add(Component.literal("Next earned rank: " + next.colour() + next.name() + "§r in " + RankShop.formatTime(remaining))
				.withStyle(ChatFormatting.AQUA));
		} else {
			lines.add(Component.literal("You have reached the top rank!").withStyle(ChatFormatting.GOLD));
		}
		return lines;
	}

	private void renderLeaderboard() {
		List<UUID> ranked = topPlayers(metric, LEADERBOARD_SLOTS.length);
		for (int place = 0; place < LEADERBOARD_SLOTS.length && place < ranked.size(); place++) {
			container.setItem(LEADERBOARD_SLOTS[place], leaderboardEntry(place + 1, ranked.get(place)));
		}
	}

	private ItemStack leaderboardEntry(int place, UUID id) {
		ItemStack head = new ItemStack(Items.PLAYER_HEAD);
		head.set(DataComponents.PROFILE, ResolvableProfile.createUnresolved(id));

		ChatFormatting medal = switch (place) {
			case 1 -> ChatFormatting.GOLD;
			case 2 -> ChatFormatting.WHITE;
			case 3 -> ChatFormatting.RED;
			default -> ChatFormatting.GRAY;
		};
		String name = PlayerStats.nameOf(id);
		if (name == null || name.isBlank()) {
			name = id.toString();
		}
		boolean you = id.equals(owner.getUUID());
		head.set(DataComponents.CUSTOM_NAME, Component.literal("#" + place + " " + name)
			.withStyle(medal)
			.append(Component.literal(you ? "  (you)" : "").withStyle(ChatFormatting.GREEN)));

		List<Component> lore = new ArrayList<>();
		lore.add(Component.literal(metric.label() + ": " + metric.format(id))
			.withStyle(ChatFormatting.GOLD));
		lore.add(Component.empty());
		lore.add(Component.literal("Balance: $" + TrimKits.formatAmount(MarketData.balance(id)))
			.withStyle(ChatFormatting.GRAY));
		lore.add(Component.literal("Kills: " + TrimKits.formatAmount(PlayerStats.kills(id))
				+ "  Deaths: " + TrimKits.formatAmount(PlayerStats.deaths(id)))
			.withStyle(ChatFormatting.GRAY));
		lore.add(Component.literal("Playtime: " + PlayerStats.playtimeText(id))
			.withStyle(ChatFormatting.GRAY));
		head.set(DataComponents.LORE, new ItemLore(lore));
		return head;
	}

	private List<UUID> topPlayers(Metric selected, int limit) {
		List<UUID> ids = new ArrayList<>(PlayerStats.knownPlayers());
		MinecraftServer server = owner.level().getServer();
		if (server != null) {
			for (ServerPlayer online : server.getPlayerList().getPlayers()) {
				if (!ids.contains(online.getUUID())) {
					ids.add(online.getUUID());
				}
			}
		}
		ids.sort(Comparator.comparingLong(selected::valueFor).reversed());
		if (limit > 0 && ids.size() > limit) {
			return new ArrayList<>(ids.subList(0, limit));
		}
		return ids;
	}

	private void renderBar() {
		container.setItem(SLOT_CLOSE, button(Items.BARRIER, "Close", ChatFormatting.RED));
		container.setItem(SLOT_REFRESH, button(Items.COMPASS, "Refresh", ChatFormatting.AQUA,
			"Pulls the latest numbers"));
		container.setItem(SLOT_METRIC, button(metric.icon(),
			"Leaderboard: " + metric.label(), ChatFormatting.GREEN,
			"Top players by " + metric.label().toLowerCase(),
			"",
			"Click to switch metric"));
	}

	private static ItemStack stat(Item item, String label, String value, ChatFormatting color, String... detail) {
		ItemStack stack = new ItemStack(item);
		stack.set(DataComponents.CUSTOM_NAME, Component.literal(label).withStyle(ChatFormatting.WHITE)
			.append(Component.literal("  " + value).withStyle(color)));
		List<Component> lore = new ArrayList<>();
		for (String line : detail) {
			lore.add(Component.literal(line).withStyle(ChatFormatting.GRAY));
		}
		stack.set(DataComponents.LORE, new ItemLore(lore));
		return stack;
	}

	private static ItemStack button(Item item, String title, ChatFormatting color, String... lore) {
		ItemStack stack = new ItemStack(item);
		stack.set(DataComponents.CUSTOM_NAME, Component.literal(title).withStyle(color));
		if (lore.length > 0) {
			List<Component> lines = new ArrayList<>();
			for (String line : lore) {
				lines.add(line.isEmpty() ? Component.empty() : Component.literal(line).withStyle(ChatFormatting.GRAY));
			}
			stack.set(DataComponents.LORE, new ItemLore(lines));
		}
		return stack;
	}

	private boolean isOnline(UUID id) {
		MinecraftServer server = owner.level().getServer();
		return server != null && server.getPlayerList().getPlayer(id) != null;
	}

	@Override
	public void clicked(int slotIndex, int buttonNum, ContainerInput containerInput, Player player) {
		// Display-only menu: never let the vanilla handler move the icons.
		if (slotIndex < 0 || slotIndex >= SIZE || !(player instanceof ServerPlayer serverPlayer)) {
			return;
		}

		if (slotIndex == SLOT_CLOSE) {
			serverPlayer.closeContainer();
			return;
		}
		if (slotIndex == SLOT_REFRESH) {
			render();
			return;
		}
		if (slotIndex == SLOT_METRIC) {
			metric = metric.next();
			render();
			return;
		}
		// Clicking a stat makes the leaderboard rank by that stat.
		Metric picked = switch (slotIndex) {
			case SLOT_KILLS, SLOT_DEATHS, SLOT_KD -> Metric.KILLS;
			case SLOT_MOB_KILLS -> Metric.MOB_KILLS;
			case SLOT_BLOCKS -> Metric.BLOCKS;
			case SLOT_SOLD -> Metric.SOLD;
			case SLOT_BALANCE -> Metric.BALANCE;
			case SLOT_RANK, SLOT_PLAYTIME -> Metric.PLAYTIME;
			default -> null;
		};
		if (picked != null && picked != metric) {
			metric = picked;
			render();
		}
	}

	@Override
	public ItemStack quickMoveStack(Player player, int slotIndex) {
		// No shift-clicking in the stats screen.
		return ItemStack.EMPTY;
	}
}
