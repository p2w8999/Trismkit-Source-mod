package com.kodari.trimskits;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.ServerScoreboard;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.scores.PlayerTeam;
import net.minecraft.world.scores.Team;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Tablist and nametag rank cosmetic system (/tabranks).
 *
 * <p>Supports purchasable and online/GitHub-granted ranks with customizable:
 * <ul>
 *   <li>Badge sign (e.g. ✦, ✪, ⚔, 👑, $, etc.)</li>
 *   <li>Unique rank color and team glow/nametag color</li>
 *   <li>Position preference: PREFIX (before name) or SUFFIX (after name)</li>
 *   <li>Purchasing with in-game balance</li>
 *   <li>Free Web/GitHub grant sync (online HTTP fetch from raw JSON/Gist)</li>
 * </ul>
 */
public final class TabRanks {
	private static final Logger LOGGER = LoggerFactory.getLogger("trimskits");
	private static final Path DATA_FILE = Path.of("config", "trimskits-tabranks.properties");
	private static final String TEAM_PREFIX = "tr_";

	public enum Position {
		PREFIX("Prefix (Before Name)"),
		SUFFIX("Suffix (After Name)");

		private final String label;

		Position(String label) {
			this.label = label;
		}

		public String label() {
			return label;
		}
	}

	public record RankDef(
		String id,
		String displayName,
		String sign,
		ChatFormatting format,
		String teamColor,
		long price,
		Item icon,
		String description,
		boolean webGrantsEnabled
	) {
		public Component formatBadge() {
			return Component.literal(sign + " " + displayName)
				.withStyle(format, ChatFormatting.BOLD);
		}
	}

	private static final Map<String, RankDef> RANKS_BY_ID = new HashMap<>();
	private static final List<RankDef> ALL_RANKS = new ArrayList<>();

	// Default rank definitions
	static {
		register(new RankDef("player", "Player", "•", ChatFormatting.GRAY, "gray", 0L, Compat.pickItem("DYE", net.minecraft.world.item.DyeColor.GRAY), "Default starting rank for everyone.", false));
		register(new RankDef("member", "Member", "✦", ChatFormatting.BLUE, "blue", 25_000L, Items.LAPIS_LAZULI, "Recognized server community member.", true));
		register(new RankDef("vip", "VIP", "★", ChatFormatting.GREEN, "green", 100_000L, Items.EMERALD, "Very Important Player status.", true));
		register(new RankDef("vip_plus", "VIP+", "★+", ChatFormatting.DARK_GREEN, "dark_green", 250_000L, Items.EMERALD_BLOCK, "Enhanced VIP privileges and emerald flair.", true));
		register(new RankDef("mvp", "MVP", "✪", ChatFormatting.AQUA, "aqua", 750_000L, Items.DIAMOND, "Most Valuable Player status.", true));
		register(new RankDef("mvp_plus", "MVP+", "✪+", ChatFormatting.DARK_AQUA, "dark_aqua", 1_500_000L, Items.DIAMOND_BLOCK, "High-tier champion badge.", true));
		register(new RankDef("dono", "Dono", "❤", ChatFormatting.LIGHT_PURPLE, "light_purple", 3_000_000L, Items.GOLDEN_APPLE, "Generous supporter badge.", true));
		register(new RankDef("sponsor", "Sponsor", "♦", ChatFormatting.YELLOW, "yellow", 7_500_000L, Items.GOLD_BLOCK, "Server patron & elite sponsor rank.", true));
		register(new RankDef("champion", "Champion", "⚔", ChatFormatting.RED, "red", 15_000_000L, Items.NETHERITE_SWORD, "Arena conqueror and warrior title.", true));
		register(new RankDef("hero", "Hero", "⚡", ChatFormatting.GOLD, "gold", 35_000_000L, Items.BEACON, "Hero of the server realm.", true));
		register(new RankDef("legend", "Legend", "👑", ChatFormatting.DARK_RED, "dark_red", 75_000_000L, Items.TOTEM_OF_UNDYING, "Legendary prestige status.", true));
		register(new RankDef("mythic", "Mythic", "✦✧", ChatFormatting.DARK_PURPLE, "dark_purple", 150_000_000L, Items.NETHER_STAR, "Mythical aura and regal nametag.", true));
		register(new RankDef("titan", "Titan", "▲", ChatFormatting.BLUE, "dark_blue", 300_000_000L, Items.ECHO_SHARD, "Colossal presence on the tablist.", true));
		register(new RankDef("celestial", "Celestial", "☼", ChatFormatting.WHITE, "white", 600_000_000L, Items.DRAGON_HEAD, "Divine celestial radiance.", true));
		register(new RankDef("godlike", "Godlike", "⚡👑⚡", ChatFormatting.GOLD, "gold", 1_000_000_000L, Items.ENCHANTED_GOLDEN_APPLE, "Ultimate apex rank.", true));
	}

	private static void register(RankDef rank) {
		RANKS_BY_ID.put(rank.id().toLowerCase(Locale.ROOT), rank);
		ALL_RANKS.add(rank);
	}

	public static List<RankDef> ranks() {
		return Collections.unmodifiableList(ALL_RANKS);
	}

	public static RankDef getRank(String id) {
		if (id == null) return RANKS_BY_ID.get("player");
		return RANKS_BY_ID.getOrDefault(id.toLowerCase(Locale.ROOT), RANKS_BY_ID.get("player"));
	}

	/**
	 * Resolves a rank by id (vip_plus) or display name (VIP+), returning null
	 * when nothing matches - unlike {@link #getRank}, which falls back to the
	 * default "player" rank. Used by /rank and the web store, where an unknown
	 * name has to be an error rather than a silent default.
	 */
	public static RankDef findRank(String raw) {
		if (raw == null) return null;
		String wanted = raw.trim().toLowerCase(Locale.ROOT);
		if (wanted.isEmpty()) return null;
		RankDef byId = RANKS_BY_ID.get(wanted);
		if (byId != null) return byId;
		for (RankDef rank : ALL_RANKS) {
			if (rank.displayName().toLowerCase(Locale.ROOT).equals(wanted)) {
				return rank;
			}
		}
		return null;
	}

	// Persistent player data
	private static final Map<UUID, Set<String>> UNLOCKED_RANKS = new HashMap<>();
	private static final Map<UUID, String> ACTIVE_RANK = new HashMap<>();
	private static final Map<UUID, Position> ACTIVE_POSITION = new HashMap<>();
	private static final Set<UUID> DIRTY = new HashSet<>();
	private static boolean loaded = false;

	// Online Web sync cache
	private static final Set<String> WEB_FREE_USERS = ConcurrentHashMap.newKeySet();
	private static volatile String lastWebStatus = "Not checked yet";

	public static synchronized void initialize() {
		if (loaded) return;
		loaded = true;
		if (!Files.exists(DATA_FILE)) {
			return;
		}
		Properties props = new Properties();
		try (var in = Files.newInputStream(DATA_FILE)) {
			props.load(in);
			for (String key : props.stringPropertyNames()) {
				String val = props.getProperty(key, "").trim();
				if (key.endsWith(".unlocked")) {
					String uuidStr = key.substring(0, key.indexOf('.'));
					try {
						UUID id = UUID.fromString(uuidStr);
						Set<String> set = UNLOCKED_RANKS.computeIfAbsent(id, k -> new HashSet<>());
						for (String part : val.split(",")) {
							part = part.trim().toLowerCase(Locale.ROOT);
							if (!part.isEmpty()) set.add(part);
						}
					} catch (Exception ignored) {}
				} else if (key.endsWith(".active")) {
					String uuidStr = key.substring(0, key.indexOf('.'));
					try {
						UUID id = UUID.fromString(uuidStr);
						ACTIVE_RANK.put(id, val.toLowerCase(Locale.ROOT));
					} catch (Exception ignored) {}
				} else if (key.endsWith(".position")) {
					String uuidStr = key.substring(0, key.indexOf('.'));
					try {
						UUID id = UUID.fromString(uuidStr);
						ACTIVE_POSITION.put(id, Position.valueOf(val.toUpperCase(Locale.ROOT)));
					} catch (Exception ignored) {}
				}
			}
		} catch (Exception e) {
			LOGGER.error("Failed to load tabranks data: {}", e.getMessage());
		}
	}

	public static synchronized void save() {
		if (DIRTY.isEmpty()) return;
		try {
			if (DATA_FILE.getParent() != null) {
				Files.createDirectories(DATA_FILE.getParent());
			}
			Properties props = new Properties();
			for (Map.Entry<UUID, Set<String>> entry : UNLOCKED_RANKS.entrySet()) {
				props.setProperty(entry.getKey() + ".unlocked", String.join(",", entry.getValue()));
			}
			for (Map.Entry<UUID, String> entry : ACTIVE_RANK.entrySet()) {
				props.setProperty(entry.getKey() + ".active", entry.getValue());
			}
			for (Map.Entry<UUID, Position> entry : ACTIVE_POSITION.entrySet()) {
				props.setProperty(entry.getKey() + ".position", entry.getValue().name());
			}

			Path temp = DATA_FILE.resolveSibling(DATA_FILE.getFileName() + ".tmp");
			try (var out = Files.newOutputStream(temp)) {
				props.store(out, "TrimKits TabRanks data");
			}
			try {
				Files.move(temp, DATA_FILE, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
			} catch (AtomicMoveNotSupportedException e) {
				Files.move(temp, DATA_FILE, StandardCopyOption.REPLACE_EXISTING);
			}
			DIRTY.clear();
		} catch (Exception e) {
			LOGGER.error("Failed to save tabranks data: {}", e.getMessage());
		}
	}

	public static synchronized boolean hasRank(ServerPlayer player, String rankId) {
		initialize();
		if ("player".equalsIgnoreCase(rankId)) return true;
		UUID id = player.getUUID();
		Set<String> set = UNLOCKED_RANKS.get(id);
		if (set != null && set.contains(rankId.toLowerCase(Locale.ROOT))) {
			return true;
		}
		// Check web free grants (by username or UUID)
		String name = player.getScoreboardName().toLowerCase(Locale.ROOT);
		String uid = id.toString().toLowerCase(Locale.ROOT);
		String prefix = rankId.toLowerCase(Locale.ROOT) + ":";
		for (String grant : WEB_FREE_USERS) {
			if (grant.equals(name) || grant.equals(uid) || grant.equals(prefix + name) || grant.equals(prefix + uid) || grant.equals("all:" + name)) {
				return true;
			}
		}
		return false;
	}

	public static synchronized boolean grantRank(UUID id, String rankId) {
		initialize();
		Set<String> set = UNLOCKED_RANKS.computeIfAbsent(id, k -> new HashSet<>());
		boolean added = set.add(rankId.toLowerCase(Locale.ROOT));
		if (added) {
			DIRTY.add(id);
			save();
		}
		return added;
	}

	public static synchronized boolean revokeRank(UUID id, String rankId) {
		initialize();
		Set<String> set = UNLOCKED_RANKS.get(id);
		if (set != null && set.remove(rankId.toLowerCase(Locale.ROOT))) {
			if (rankId.equalsIgnoreCase(ACTIVE_RANK.get(id))) {
				ACTIVE_RANK.put(id, "player");
			}
			DIRTY.add(id);
			save();
			return true;
		}
		return false;
	}

	public static synchronized RankDef getActiveRank(UUID id) {
		initialize();
		String rankId = ACTIVE_RANK.getOrDefault(id, "player");
		return getRank(rankId);
	}

	public static synchronized void setActiveRank(UUID id, String rankId) {
		initialize();
		ACTIVE_RANK.put(id, rankId.toLowerCase(Locale.ROOT));
		DIRTY.add(id);
		save();
	}

	public static synchronized Position getPosition(UUID id) {
		initialize();
		return ACTIVE_POSITION.getOrDefault(id, Position.PREFIX);
	}

	public static synchronized void setPosition(UUID id, Position pos) {
		initialize();
		ACTIVE_POSITION.put(id, pos == null ? Position.PREFIX : pos);
		DIRTY.add(id);
		save();
	}

	public static synchronized void togglePosition(UUID id) {
		Position cur = getPosition(id);
		setPosition(id, cur == Position.PREFIX ? Position.SUFFIX : Position.PREFIX);
	}

	/**
	 * Purchases a tabrank with the player's balance.
	 */
	public static String purchase(ServerPlayer player, String rankId, net.minecraft.core.RegistryAccess registries) {
		initialize();
		RankDef def = getRank(rankId);
		if (def == null) return "Unknown rank.";
		if (hasRank(player, def.id())) {
			return "You already own the " + def.format() + def.displayName() + "§r rank!";
		}
		if (def.price() <= 0) {
			grantRank(player.getUUID(), def.id());
			return null;
		}

		long balance = MarketData.balance(player.getUUID());
		if (balance < def.price()) {
			return "You need §c$" + TrimKits.formatAmount(def.price())
				+ "§r to buy " + def.format() + def.displayName()
				+ "§r (you have §c$" + TrimKits.formatAmount(balance) + "§r).";
		}

		if (!MarketData.debit(player.getUUID(), def.price(), registries)) {
			return "Could not process transaction; balance unchanged.";
		}

		grantRank(player.getUUID(), def.id());
		setActiveRank(player.getUUID(), def.id());
		applyPlayerTab(player);
		return null;
	}

	/**
	 * Updates the scoreboard team for the player so that their nametag and
	 * tablist list item receive the rank color and badge.
	 */
	public static void applyPlayerTab(ServerPlayer player) {
		if (player == null) return;
		MinecraftServer server = player.level().getServer();
		if (server == null) return;
		ServerScoreboard scoreboard = server.getScoreboard();

		RankDef rank = getActiveRank(player.getUUID());
		Position pos = getPosition(player.getUUID());

		// Team name: deterministic 16 char max team name per player
		String teamName = TEAM_PREFIX + player.getScoreboardName();
		if (teamName.length() > 16) {
			teamName = teamName.substring(0, 16);
		}

		PlayerTeam team = scoreboard.getPlayerTeam(teamName);
		if (team == null) {
			team = scoreboard.addPlayerTeam(teamName);
		}

		// Configure team options to ensure standard PVP/SMP gameplay is unchanged
		team.setAllowFriendlyFire(true);
		team.setSeeFriendlyInvisibles(false);
		team.setNameTagVisibility(Team.Visibility.ALWAYS);
		team.setDeathMessageVisibility(Team.Visibility.ALWAYS);
		team.setCollisionRule(Team.CollisionRule.ALWAYS);

		// Glow & nametag color
		Compat.setTeamColor(team, rank.teamColor());

		if (pos == Position.PREFIX) {
			MutableComponent prefix = Component.literal("[" + rank.sign() + " " + rank.displayName() + "] ")
				.withStyle(rank.format(), ChatFormatting.BOLD);
			team.setPlayerPrefix(prefix);
			team.setPlayerSuffix(Component.empty());
		} else {
			team.setPlayerPrefix(Component.empty());
			MutableComponent suffix = Component.literal(" [" + rank.sign() + " " + rank.displayName() + "]")
				.withStyle(rank.format(), ChatFormatting.BOLD);
			team.setPlayerSuffix(suffix);
		}

		scoreboard.addPlayerToTeam(player.getScoreboardName(), team);
	}

	/**
	 * Fetches free rank grants from a GitHub raw URL or custom endpoint.
	 * Format can be a JSON array of usernames or grant objects:
	 * Example: ["notch", "jeb_", "member:vadim154655", "vip:alice"]
	 */
	public static CompletableFuture<String> syncWebGrants(MinecraftServer server) {
		return CompletableFuture.supplyAsync(() -> {
			String url = Config.getString("tabranks.web_url", "https://raw.githubusercontent.com/vadim154655/tabranks/main/ranks.json");
			if (url == null || url.isBlank() || url.equals("disabled")) {
				lastWebStatus = "Web sync disabled in config.";
				return lastWebStatus;
			}
			try {
				URI uri = URI.create(url);
				HttpURLConnection conn = (HttpURLConnection) uri.toURL().openConnection();
				conn.setConnectTimeout(5000);
				conn.setReadTimeout(5000);
				conn.setRequestMethod("GET");
				conn.setRequestProperty("User-Agent", "TrimKits-Minecraft-Mod");

				int code = conn.getResponseCode();
				if (code != 200) {
					lastWebStatus = "HTTP " + code + " error fetching " + url;
					return lastWebStatus;
				}

				StringBuilder sb = new StringBuilder();
				try (BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
					String line;
					while ((line = reader.readLine()) != null) {
						sb.append(line).append('\n');
					}
				}

				String text = sb.toString().trim();
				Set<String> newGrants = new HashSet<>();
				if (text.startsWith("[")) {
					JsonArray arr = JsonParser.parseString(text).getAsJsonArray();
					for (JsonElement el : arr) {
						if (el.isJsonPrimitive()) {
							newGrants.add(el.getAsString().trim().toLowerCase(Locale.ROOT));
						} else if (el.isJsonObject()) {
							JsonObject obj = el.getAsJsonObject();
							String user = obj.has("user") ? obj.get("user").getAsString().trim().toLowerCase(Locale.ROOT) : "";
							String r = obj.has("rank") ? obj.get("rank").getAsString().trim().toLowerCase(Locale.ROOT) : "member";
							if (!user.isEmpty()) {
								newGrants.add(r + ":" + user);
							}
						}
					}
				} else if (text.startsWith("{")) {
					JsonObject obj = JsonParser.parseString(text).getAsJsonObject();
					for (String k : obj.keySet()) {
						JsonElement el = obj.get(k);
						if (el.isJsonArray()) {
							for (JsonElement item : el.getAsJsonArray()) {
								newGrants.add(k.toLowerCase(Locale.ROOT) + ":" + item.getAsString().trim().toLowerCase(Locale.ROOT));
							}
						}
					}
				} else {
					for (String line : text.split("\\r?\\n")) {
						line = line.trim();
						if (!line.isEmpty() && !line.startsWith("#")) {
							newGrants.add(line.toLowerCase(Locale.ROOT));
						}
					}
				}

				WEB_FREE_USERS.clear();
				WEB_FREE_USERS.addAll(newGrants);
				lastWebStatus = "Synced " + newGrants.size() + " web grant(s) from " + url;

				if (server != null) {
					server.execute(() -> {
						for (ServerPlayer player : server.getPlayerList().getPlayers()) {
							applyPlayerTab(player);
						}
					});
				}
				return lastWebStatus;
			} catch (Exception e) {
				lastWebStatus = "Web sync failed: " + e.getMessage();
				return lastWebStatus;
			}
		});
	}

	public static String getLastWebStatus() {
		return lastWebStatus;
	}
}
