package com.kodari.trimskits;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.Item;

/**
 * Typo-tolerant search over the shop.
 *
 * <p>Nobody is going to spell "Sea Pickle" correctly on the first try, and the
 * shop now sells thousands of things, so search matches on words rather than
 * characters and forgives a small edit distance. "sea peackle", "sea pickle"
 * and "pickel" all land on Sea Pickle; "zzz" lands on nothing.
 *
 * <p>Matching is done against the registry id, which is the same text the
 * player sees in the item's display name, so the two always agree.
 */
final class ShopSearch {
	/** How far apart two words may be and still count as the same word. */
	private static final int MAX_EDIT_DISTANCE = 2;

	/** One search result and how strongly it matched. */
	record Hit(ShopValues.Entry entry, int score) {
	}

	private ShopSearch() {
	}

	/** "Sea Pickle" -> "sea pickle". Anything non-alphanumeric becomes a space. */
	static String normalise(String text) {
		if (text == null) {
			return "";
		}
		return text.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", " ").trim();
	}

	static List<String> words(String text) {
		String normalised = normalise(text);
		if (normalised.isEmpty()) {
			return List.of();
		}
		return List.of(normalised.split(" +"));
	}

	/**
	 * Score one wanted word against one word from an id.
	 *
	 * @return 0 when they are unrelated, more the closer the match
	 */
	private static int wordScore(String wanted, String have) {
		if (wanted.equals(have)) {
			return 100;
		}
		if (have.startsWith(wanted)) {
			// "sea" should beat "seagrass" which should beat "seasoned..."
			return Math.max(40, 80 - (have.length() - wanted.length()) * 2);
		}
		if (have.contains(wanted)) {
			return 40;
		}
		int distance = editDistance(wanted, have, MAX_EDIT_DISTANCE);
		if (distance >= 0) {
			return 60 - distance * 25;
		}
		return 0;
	}

	/**
	 * How well one query matches an item, or 0 when it does not match at all.
	 * Every word in the query has to find a home; a single miss rules the item
	 * out, which stops "sea diamond" matching every block containing "sea".
	 */
	static int score(String query, Item item) {
		return score(query, words(BuiltInRegistries.ITEM.getKey(item).getPath()));
	}

	/**
	 * Same, but for a whole shop entry: the registry id, the display name and
	 * the category all count, so searching "mace", "smelter" or "tools" lands
	 * on the right things even when the raw id would not.
	 */
	static int score(String query, ShopValues.Entry entry) {
		List<String> have = new ArrayList<>(words(BuiltInRegistries.ITEM.getKey(entry.item()).getPath()));
		have.addAll(words(entry.name()));
		have.addAll(words(entry.category()));
		return score(query, have);
	}

	private static int score(String query, List<String> have) {
		List<String> wanted = words(query);
		if (wanted.isEmpty()) {
			return 1;
		}

		int total = 0;
		for (String word : wanted) {
			int best = 0;
			for (String candidate : have) {
				best = Math.max(best, wordScore(word, candidate));
			}
			if (best == 0) {
				return 0;
			}
			total += best;
		}
		// A query that matches the very first word of the id is usually what
		// the player meant, so it outranks an equal-scoring incidental match.
		if (have.isEmpty() || !have.get(0).startsWith(wanted.get(0))) {
			return total;
		}
		return total + 25;
	}

	/** Every shop entry that matches, best match first, then cheapest first. */
	static List<ShopValues.Entry> search(String query) {
		List<Hit> hits = new ArrayList<>();
		for (ShopValues.Entry entry : ShopValues.all()) {
			int score = score(query, entry);
			if (score > 0) {
				hits.add(new Hit(entry, score));
			}
		}
		hits.sort(Comparator.comparingInt(Hit::score).reversed()
			.thenComparingLong(hit -> ShopValues.marketPrice(hit.entry())));
		List<ShopValues.Entry> results = new ArrayList<>(hits.size());
		for (Hit hit : hits) {
			results.add(hit.entry());
		}
		return results;
	}

	/** Same as {@link #search}, trimmed to what fits in a chat message. */
	static List<ShopValues.Entry> search(String query, int limit) {
		List<ShopValues.Entry> results = search(query);
		if (limit <= 0 || results.size() <= limit) {
			return results;
		}
		return new ArrayList<>(results.subList(0, limit));
	}

	/**
	 * Bounded Levenshtein distance.
	 *
	 * @return the distance, or -1 when it is already worse than the cap
	 */
	static int editDistance(String left, String right, int cap) {
		if (Math.abs(left.length() - right.length()) > cap) {
			return -1;
		}
		int[] previous = new int[right.length() + 1];
		int[] current = new int[right.length() + 1];
		for (int column = 0; column <= right.length(); column++) {
			previous[column] = column;
		}
		for (int row = 1; row <= left.length(); row++) {
			current[0] = row;
			int best = current[0];
			for (int column = 1; column <= right.length(); column++) {
				int cost = left.charAt(row - 1) == right.charAt(column - 1) ? 0 : 1;
				current[column] = Math.min(Math.min(
					current[column - 1] + 1,
					previous[column] + 1),
					previous[column - 1] + cost);
				best = Math.min(best, current[column]);
			}
			if (best > cap) {
				return -1;
			}
			int[] swap = previous;
			previous = current;
			current = swap;
		}
		return previous[right.length()] <= cap ? previous[right.length()] : -1;
	}
}
