package com.kodari.trimskits;

import java.util.Optional;
import java.util.concurrent.CompletableFuture;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.permissions.Permissions;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.ItemEnchantments;

/**
 * The "infinite enchantments" toggle (alpha): an admin can stamp <b>any</b>
 * enchantment onto the held item at <b>any</b> level, ignoring the
 * enchantment's own max - Knockback 25, Sharpness 255, Protection 200, every
 * enchantment in the registry (vanilla and datapack alike).
 *
 * <p>It ships as data-pack functions plus plain commands, so an admin can
 * flip it several ways. Minecraft <b>resource locations are lowercase-only</b>
 * (the vanilla {@code /function} argument parses through
 * {@code Identifier.read}, which rejects any {@code [A-Z]} before it even
 * looks the function up - so {@code /function InfEnchantstrue} can never
 * resolve, exactly like {@code /give @p Minecraft:stone} fails). The
 * datapack files are therefore named in lowercase:</p>
 *
 * <ul>
 *   <li>{@code /function infenchantstrue} - turn the mode ON</li>
 *   <li>{@code /function infenchantsfalse} - back to vanilla caps</li>
 *   <li>{@code /infenchants [true|false]} - the same toggle as a plain
 *       command (this is what the .mcfunction files call)</li>
 *   <li>{@code /InfEnchantstrue} / {@code /InfEnchantsfalse} - the exact
 *       capitalised spelling as a literal command, for convenience; a
 *       Brigadier literal may contain capitals even though an identifier
 *       may not</li>
 *   <li>{@code /sfmode enchant <enchantment> <level>} - apply it to the item
 *       in the main hand; tab-completes every enchantment id</li>
 * </ul>
 *
 * <p>While the toggle is OFF the apply command refuses anything above the
 * enchantment's own max, exactly like vanilla {@code /enchant}; while it is
 * ON the ceiling is {@code infenchants.max_level} (default 32767 - levels
 * are plain ints in the {@code minecraft:enchantments} component, there is
 * no hidden 8/16-bit limit once the max-level check is lifted). State lives
 * in the existing {@code config/trimskits.json} and survives restarts.</p>
 *
 * <p>Everything here uses item/registry APIs that are byte-identical on
 * 26.1/26.2/26.3 (verified with javap), so the jar stays cross-version safe.
 * The enchanting shop, anvils and the vanilla /enchant command are
 * untouched - this only adds a new gated command.</p>
 */
final class InfEnchants {
	/** Config keys (defaults are seeded by {@link Config#load()}). */
	private static final String KEY_ENABLED = "infenchants.enabled";
	private static final String KEY_MAX_LEVEL = "infenchants.max_level";

	/** Fallback ceiling if the config value is missing or nonsense. */
	static final int DEFAULT_MAX_LEVEL = 32767;

	private InfEnchants() {
	}

	// ---- state ----

	/** True when enchant levels above each enchantment's own max are allowed. */
	static boolean enabled() {
		return Config.getBoolean(KEY_ENABLED);
	}

	/** The hard ceiling applied while the toggle is ON (default 32767). */
	static int maxLevel() {
		int configured = Config.getInt(KEY_MAX_LEVEL);
		return configured > 0 ? configured : DEFAULT_MAX_LEVEL;
	}

	// ---- registration ----

	/**
	 * Adds {@code /infenchants [true|false]} (the toggle itself, called by the
	 * shipped data-pack functions) and {@code /sfmode enchant
	 * <enchantment> <level>} (the apply command, admin-mode gated like every
	 * other /sfmode sub-command). Called from the same command-registration
	 * callback as the other sub-commands, before guardAllCommands wraps
	 * every leaf.
	 */
	static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
		dispatcher.register(Commands.literal("infenchants")
			.requires(InfEnchants::canToggle)
			.executes(InfEnchants::showStatus)
			.then(Commands.literal("true").executes(context -> setEnabled(context, true)))
			.then(Commands.literal("false").executes(context -> setEnabled(context, false))));

		// Exact-spelling convenience aliases. A Brigadier literal is a plain
		// string, so capitals are fine here (unlike an /function identifier).
		// Gated identically, so /function-averse admins can just type the name.
		dispatcher.register(Commands.literal("InfEnchantstrue")
			.requires(InfEnchants::canToggle)
			.executes(context -> setEnabled(context, true)));
		dispatcher.register(Commands.literal("InfEnchantsfalse")
			.requires(InfEnchants::canToggle)
			.executes(context -> setEnabled(context, false)));

		dispatcher.register(Commands.literal("sfmode")
			.then(Commands.literal("enchant")
				.then(Commands.argument("enchantment", StringArgumentType.word())
					.suggests(InfEnchants::suggestEnchantments)
					.then(Commands.argument("level", IntegerArgumentType.integer(1))
						.executes(InfEnchants::runEnchant)))));
	}

	/**
	 * The same owner gate as /clearchat and /modlogs: console, vanilla op,
	 * OPS.json admin, or the configured admin.username. The data-pack
	 * functions run through this too, so only the owner can flip the mode.
	 */
	private static boolean canToggle(CommandSourceStack source) {
		return source.getEntity() == null
			|| source.permissions().hasPermission(Permissions.COMMANDS_ADMIN)
			|| OpsConfig.hasPermission(source.getTextName(), OpsConfig.PERM_ADMIN)
			|| source.getTextName().equalsIgnoreCase(TrimKits.adminUsername());
	}

	/** Tab-completes every enchantment id in the registry (vanilla + datapack). */
	private static CompletableFuture<Suggestions> suggestEnchantments(
			CommandContext<CommandSourceStack> context, SuggestionsBuilder builder) {
		try {
			var registry = context.getSource().getServer()
				.registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
			for (Identifier id : registry.keySet()) {
				builder.suggest(id.toString());
			}
		} catch (RuntimeException ignored) {
			// Registry not ready yet - leave the suggestions empty.
		}
		return builder.buildFuture();
	}

	// ---- toggle ----

	/** /infenchants - report the current state. */
	private static int showStatus(CommandContext<CommandSourceStack> context) {
		CommandSourceStack source = context.getSource();
		source.sendSuccess(() -> Component.literal(enabled()
			? "§aInfEnchants is ON - enchant levels above each enchantment's max are allowed up to "
				+ maxLevel() + ". Apply with /sfmode enchant <enchantment> <level>."
			: "§eInfEnchants is OFF - levels are capped at each enchantment's vanilla max. "
				+ "Turn it on with /function infenchantstrue."), true);
		return enabled() ? 1 : 0;
	}

	/** /infenchants <true|false> - flip the mode (also what the functions call). */
	private static int setEnabled(CommandContext<CommandSourceStack> context, boolean value) {
		CommandSourceStack source = context.getSource();
		Config.set(KEY_ENABLED, value);
		source.sendSuccess(() -> Component.literal(value
			? "§aInfEnchants ON - enchant levels above each enchantment's max are now allowed (up to "
				+ maxLevel() + "). Apply them with /sfmode enchant <enchantment> <level>."
			: "§eInfEnchants OFF - enchant levels are back to each enchantment's vanilla max."), true);
		return 1;
	}

	// ---- apply ----

	/**
	 * /sfmode enchant <enchantment> <level>: stamps the enchantment onto the
	 * item in the admin's main hand, capped by the toggle state.
	 */
	private static int runEnchant(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
		CommandSourceStack source = context.getSource();
		ServerPlayer admin = source.getPlayerOrException();
		if (!ChaosCommands.isAdminMode(source, admin)) {
			return 0;
		}
		String typed = StringArgumentType.getString(context, "enchantment");
		int requested = IntegerArgumentType.getInteger(context, "level");

		ItemStack held = admin.getMainHandItem();
		if (held.isEmpty()) {
			admin.sendSystemMessage(Component.literal(
				"§cHold the item you want to enchant in your main hand."));
			return 0;
		}

		Identifier id = Identifier.tryParse(typed.contains(":") ? typed : "minecraft:" + typed);
		if (id == null) {
			admin.sendSystemMessage(Component.literal("§c'" + typed + "' is not a valid enchantment id."));
			return 0;
		}
		var registry = admin.level().registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
		Optional<Holder.Reference<Enchantment>> found = registry.get(id);
		if (found.isEmpty()) {
			admin.sendSystemMessage(Component.literal("§cUnknown enchantment '" + typed + "'."));
			return 0;
		}
		Holder<Enchantment> holder = found.get();
		Enchantment enchantment = holder.value();

		// The level ceiling: lifted while the toggle is ON, vanilla otherwise.
		int cap = enabled() ? maxLevel() : enchantment.getMaxLevel();
		if (requested > cap) {
			admin.sendSystemMessage(Component.literal(
				"§c" + typed + " is capped at " + cap + " right now. "
				+ (enabled()
					? "Raise infenchants.max_level in config/trimskits.json."
					: "Turn on infinite enchants with /function infenchantstrue.")));
			return 0;
		}

		applyEnchantment(held, holder, requested);
		admin.sendSystemMessage(Component.literal(
			"§aApplied " + typed + " " + requested + " to your held item."));
		return 1;
	}

	/**
	 * Writes one enchantment level into the item's
	 * {@code minecraft:enchantments} component; the level is a plain int, so
	 * very high values need no special handling.
	 */
	private static void applyEnchantment(ItemStack stack, Holder<Enchantment> holder, int level) {
		ItemEnchantments current = stack.getOrDefault(DataComponents.ENCHANTMENTS, ItemEnchantments.EMPTY);
		ItemEnchantments.Mutable mutable = new ItemEnchantments.Mutable(current);
		mutable.set(holder, level);
		stack.set(DataComponents.ENCHANTMENTS, mutable.toImmutable());
	}
}
