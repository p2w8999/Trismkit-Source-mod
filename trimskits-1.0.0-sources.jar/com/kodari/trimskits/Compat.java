package com.kodari.trimskits;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Stream;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemContainerContents;
import net.minecraft.world.scores.PlayerTeam;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Cross-version compatibility for Minecraft <b>26.1 / 26.2 / 26.3</b>.
 *
 * <p>The mod is compiled once (against 26.2) and the same jar has to run on
 * all three releases. Most vanilla API is identical across the family, but a
 * handful of surfaces changed, and any one of them would break the jar with
 * NoSuchFieldError/NoSuchMethodError at runtime:</p>
 *
 * <ul>
 *   <li><b>Item collection fields</b> - in 26.2+ {@code Items.WOOL},
 *       {@code Items.COPPER_DOOR} etc. are {@code ColorCollection} /
 *       {@code WeatheringCopperCollection} records with {@code asList()} and
 *       {@code pick(DyeColor)}; in 26.1 they are plain {@code Item}
 *       constants ({@code WHITE_WOOL}...), {@code WeatheringCopperItems},
 *       or simply do not exist ({@code Items.WOOL}). The field's <i>type</i>
 *       is part of its bytecode descriptor, so even 26.2/26.3 vs 26.1 field
 *       access must not be linked statically - it is resolved reflectively.</li>
 *   <li><b>Team color</b> - {@code PlayerTeam.setColor} takes
 *       {@code Optional<TeamColor>} in 26.2/26.3 but a plain
 *       {@code ChatFormatting} in 26.1 (where TeamColor does not exist).</li>
 *   <li><b>Inventory give-back</b> - 26.3 replaced
 *       {@code placeItemBackInInventory(ItemStack)} with
 *       {@code placeItemBackInInventory(ItemStack, Prediction)}; vanilla's
 *       server-side callers pass {@code Prediction.SERVER_ONLY}.</li>
 *   <li><b>Shulker contents stream</b> - 26.3 renamed
 *       {@code ItemContainerContents.allItemsCopyStream()} to
 *       {@code itemCopies()}.</li>
 *   <li><b>Entity type constants</b> - 26.2 moved {@code LIGHTNING_BOLT},
 *       {@code WITHER}, {@code ARROW}... off {@code EntityType} into a new
 *       {@code EntityTypes} holder class; 26.1 has only the old form.</li>
 * </ul>
 *
 * <p>Every lookup here is done reflectively at call time (resolved once by the
 * JVM), so this file itself compiles unchanged against all three versions and
 * never links a version-specific descriptor into the shipped jar.</p>
 */
final class Compat {
	private static final Logger LOGGER = LoggerFactory.getLogger("trimskits");

	/** The Items collection fields whose constant is absent in 26.1. */
	private static final Set<String> COLOR_FIELDS = Set.of(
		"BED", "CARPET", "CONCRETE", "CONCRETE_POWDER", "DYE", "DYED_CANDLE",
		"DYED_TERRACOTTA", "GLAZED_TERRACOTTA", "STAINED_GLASS",
		"STAINED_GLASS_PANE", "WOOL"
	);

	/** 26.1 plain-constant prefixes for a weathering-copper family. */
	private static final String[] OXIDATION_PREFIXES = {
		"", "EXPOSED_", "WEATHERED_", "OXIDIZED_",
		"WAXED_", "WAXED_EXPOSED_", "WAXED_WEATHERED_", "WAXED_OXIDIZED_"
	};

	private Compat() {
	}

	// ---- Items collection fields (26.1 vs 26.2/26.3 layouts) ----

	/**
	 * Every item of an Items collection field ({@code Items.WOOL},
	 * {@code Items.COPPER_DOOR}, ...) in a version-independent way:
	 * 26.2/26.3 collection record -&gt; asList()/forEach(); 26.1 plain Item -&gt;
	 * its oxidation/color family; 26.1 missing color field -&gt; expanded
	 * {@code <COLOR>_<FIELD>} constants.
	 */
	static List<Item> collectionItems(String field) {
		List<Item> items = new ArrayList<>(16);
		Object value = itemsField(field);

		if (value instanceof Item base) {
			addOxidationFamily(items, field, base);
			return items;
		}
		if (value != null && (addFromAsList(value, items) || addFromForEach(value, items))) {
			return items;
		}
		if (value != null) {
			LOGGER.warn("Compat: collection {} exposes no asList/forEach on this version", field);
			return items;
		}
		if (COLOR_FIELDS.contains(field)) {
			addColorFamily(items, field);
			return items;
		}
		LOGGER.warn("Compat: Items.{} does not exist on this Minecraft version", field);
		return items;
	}

	/**
	 * One item out of an Items collection ({@code Compat.pickItem("DYE", color)}),
	 * falling back to the plain {@code <COLOR>_<FIELD>} constant on 26.1.
	 */
	static Item pickItem(String field, DyeColor color) {
		Object value = itemsField(field);
		if (value != null) {
			try {
				Method pick = value.getClass().getMethod("pick", DyeColor.class);
				Object picked = pick.invoke(value, color);
				if (picked instanceof Item item) {
					return item;
				}
			} catch (NoSuchMethodException absent) {
				// No pick() on this version - use the plain constant below.
			} catch (ReflectiveOperationException exception) {
				LOGGER.warn("Compat: {}.pick({}) failed: {}", field, color, exception.toString());
			}
		}
		try {
			return (Item) Items.class.getField(colorField(color, field)).get(null);
		} catch (ReflectiveOperationException exception) {
			LOGGER.warn("Compat: no item for {} / {} ({})", field, color, exception.toString());
			return Items.AIR;
		}
	}

	/** Reads {@code Items.<field>}; null when this version has no such field. */
	private static Object itemsField(String field) {
		try {
			return Items.class.getField(field).get(null);
		} catch (ReflectiveOperationException absent) {
			return null;
		}
	}

	/** 26.1 constant name for one color of a collection ({@code WHITE_WOOL}...). */
	private static String colorField(DyeColor color, String field) {
		String colorName = color.getName().toUpperCase(Locale.ROOT);
		return switch (field) {
			case "DYED_TERRACOTTA" -> colorName + "_TERRACOTTA";
			case "DYED_CANDLE" -> colorName + "_CANDLE";
			default -> colorName + "_" + field;
		};
	}

	/** All colors of a collection via their 26.1 plain constants. */
	private static void addColorFamily(List<Item> items, String field) {
		for (DyeColor color : DyeColor.values()) {
			try {
				Item item = (Item) Items.class.getField(colorField(color, field)).get(null);
				items.add(item);
			} catch (ReflectiveOperationException ignored) {
				// Not every color exists for every field on every version.
			}
		}
	}

	/** The eight weathering/waxed variants of a plain 26.1 copper Item. */
	private static void addOxidationFamily(List<Item> items, String field, Item base) {
		for (String prefix : OXIDATION_PREFIXES) {
			try {
				Item item = (Item) Items.class.getField(prefix + field).get(null);
				items.add(item);
			} catch (ReflectiveOperationException absent) {
				if (prefix.isEmpty()) {
					items.add(base);
				}
				// Some families lack a variant on this version - skip it.
			}
		}
	}

	/** Invokes {@code asList()} on a 26.2/26.3 collection record. */
	private static boolean addFromAsList(Object collection, List<Item> items) {
		try {
			Object list = collection.getClass().getMethod("asList").invoke(collection);
			if (list instanceof List<?> values) {
				for (Object value : values) {
					if (value instanceof Item item) {
						items.add(item);
					}
				}
				return true;
			}
		} catch (NoSuchMethodException absent) {
			// 26.1's WeatheringCopperItems has no asList() - try forEach().
		} catch (ReflectiveOperationException exception) {
			LOGGER.warn("Compat: collection asList() failed: {}", exception.toString());
		}
		return false;
	}

	/** Invokes {@code forEach(Consumer)} on a 26.1 WeatheringCopperItems. */
	private static boolean addFromForEach(Object collection, List<Item> items) {
		try {
			@SuppressWarnings("unchecked")
			Consumer<Item> sink = items::add;
			collection.getClass().getMethod("forEach", Consumer.class).invoke(collection, sink);
			return true;
		} catch (NoSuchMethodException absent) {
			return false;
		} catch (ReflectiveOperationException exception) {
			LOGGER.warn("Compat: collection forEach() failed: {}", exception.toString());
			return false;
		}
	}

	// ---- Scoreboard team color ----

	/**
	 * Sets a team's nametag/glow color by its lowercase name
	 * ({@code "dark_blue"}...). 26.2/26.3: {@code setColor(Optional<TeamColor>)};
	 * 26.1: {@code setColor(ChatFormatting)} - the names match one to one, so
	 * a rank keeps exactly the same color on every supported version.
	 */
	static void setTeamColor(PlayerTeam team, String colorName) {
		try {
			try {
				Method setter = PlayerTeam.class.getMethod("setColor", Optional.class);
				Class<?> teamColorClass = Class.forName("net.minecraft.world.scores.TeamColor");
				Object teamColor = teamColorClass.getField(colorName.toUpperCase(Locale.ROOT)).get(null);
				setter.invoke(team, Optional.of(teamColor));
			} catch (NoSuchMethodException absentInThisVersion) {
				// 26.1 has no TeamColor; setColor takes ChatFormatting directly.
				Method setter = PlayerTeam.class.getMethod("setColor", ChatFormatting.class);
				setter.invoke(team, chatFormatting(colorName));
			}
		} catch (ReflectiveOperationException exception) {
			LOGGER.warn("Compat: could not set team color {}: {}", colorName, exception.toString());
		}
	}

	/**
	 * Resolves a lowercase formatting name ({@code "dark_blue"}) to the
	 * ChatFormatting constant. 26.1 exposes {@code getByName(String)}; that
	 * helper was removed later, so fall back to the enum/static-constant
	 * forms - whichever this version has.
	 */
	private static Object chatFormatting(String colorName) throws ReflectiveOperationException {
		Class<?> type = ChatFormatting.class;
		String constant = colorName.toUpperCase(Locale.ROOT);
		try {
			return type.getMethod("getByName", String.class).invoke(null, colorName);
		} catch (NoSuchMethodException absent) {
			// Not on this version - try the other forms below.
		}
		try {
			return type.getMethod("valueOf", String.class).invoke(null, constant);
		} catch (NoSuchMethodException notAnEnum) {
			return type.getField(constant).get(null);
		}
	}

	// ---- Inventory give-back ----

	/**
	 * Puts an item back into the inventory, dropping it if there is no room -
	 * the vanilla {@code placeItemBackInInventory(ItemStack)} behaviour.
	 * 26.3 moved to an overload taking a Prediction; its server-side callers
	 * pass {@code SERVER_ONLY}, so this does the same.
	 */
	static void placeBack(Inventory inventory, ItemStack stack) {
		try {
			try {
				Inventory.class.getMethod("placeItemBackInInventory", ItemStack.class)
					.invoke(inventory, stack);
			} catch (NoSuchMethodException absentInThisVersion) {
				Class<?> prediction = Class.forName("net.minecraft.util.Prediction");
				Object serverOnly = prediction.getField("SERVER_ONLY").get(null);
				Inventory.class.getMethod("placeItemBackInInventory", ItemStack.class, prediction)
					.invoke(inventory, stack, serverOnly);
			}
		} catch (ReflectiveOperationException exception) {
			LOGGER.warn("Compat: could not place item back in inventory: {}", exception.toString());
		}
	}

	// ---- Shulker box contents ----

	/**
	 * A stream of item copies stored in a shulker box component.
	 * 26.3 renamed {@code allItemsCopyStream()} to {@code itemCopies()};
	 * the element semantics (all slots, copies) are unchanged.
	 */
	@SuppressWarnings("unchecked")
	static Stream<ItemStack> containerItemStream(ItemContainerContents contents) {
		try {
			try {
				return (Stream<ItemStack>) contents.getClass()
					.getMethod("allItemsCopyStream").invoke(contents);
			} catch (NoSuchMethodException renamedInThisVersion) {
				return (Stream<ItemStack>) contents.getClass()
					.getMethod("itemCopies").invoke(contents);
			}
		} catch (ReflectiveOperationException exception) {
			LOGGER.warn("Compat: could not read container contents: {}", exception.toString());
			return Stream.empty();
		}
	}

	// ---- Entity type constants ----

	/**
	 * Spawns an entity of one of the named vanilla type constants
	 * ({@code "LIGHTNING_BOLT"}, {@code "WITHER"}, {@code "ARROW"}...) at
	 * exact coordinates and returns it, or null when this version has none of
	 * the names. 26.2 moved the constants from {@code EntityType} to the new
	 * {@code EntityTypes} holder class, so the field is resolved reflectively
	 * and both locations are tried.
	 */
	static Entity spawnEntity(ServerLevel level, double x, double y, double z, String... names) {
		for (String name : names) {
			Object type = staticField("net.minecraft.world.entity.EntityTypes", name);
			if (type == null) {
				type = staticField("net.minecraft.world.entity.EntityType", name);
			}
			if (type instanceof EntityType<?> entityType) {
				Entity entity = entityType.spawn(level, BlockPos.containing(x, y, z), EntitySpawnReason.TRIGGERED);
				if (entity != null) {
					entity.setPos(x, y, z);
					return entity;
				}
			}
		}
		LOGGER.warn("Compat: could not spawn any of {}", List.of(names));
		return null;
	}

	/** Reads a public static field; null when the class or field is absent. */
	private static Object staticField(String className, String field) {
		try {
			return Class.forName(className).getField(field).get(null);
		} catch (ReflectiveOperationException absent) {
			return null;
		}
	}
}
