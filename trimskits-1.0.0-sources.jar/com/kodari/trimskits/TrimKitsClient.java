package com.kodari.trimskits;

import java.util.List;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;

public class TrimKitsClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		ItemTooltipCallback.EVENT.register((stack, tooltipContext, tooltipType, lines) -> {
			if (stack == null || stack.isEmpty()) {
				return;
			}
			Minecraft client = Minecraft.getInstance();
			if (client.level != null) {
				ShopValues.initialize(client.level.registryAccess());
			} else {
				ShopValues.initialize(null);
			}

			Long sellPrice = ShopValues.sellPrice(stack);
			if (sellPrice != null && sellPrice > 0) {
				Component priceLine = Component.literal("$").withStyle(ChatFormatting.GREEN)
					.append(Component.literal(TrimKits.formatAmount(sellPrice)).withStyle(ChatFormatting.GREEN));
				if (lines.isEmpty()) {
					lines.add(priceLine);
				} else {
					lines.add(1, priceLine);
				}
			}
		});

		// Alpha event weapons in the vanilla combat creative tab, so staff
		// can grab them while testing (they also come from /sfmode weapons).
		ResourceKey<CreativeModeTab> combatTab = ResourceKey.create(
			Registries.CREATIVE_MODE_TAB, Identifier.parse("minecraft:combat"));
		CreativeModeTabEvents.modifyOutputEvent(combatTab).register(output -> {
			output.accept(new ItemStack(Weapons.VOID_BLADE));
			output.accept(new ItemStack(Weapons.THUNDER_AXE));
			output.accept(new ItemStack(Weapons.FROST_DAGGER));
			output.accept(new ItemStack(Weapons.WAR_HAMMER));
		});
	}
}
