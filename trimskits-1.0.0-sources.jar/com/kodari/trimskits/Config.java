package com.kodari.trimskits;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

/**
 * Configuration system using JSON file in config/trimskits.json
 */
public final class Config {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_FILE = Path.of("config", "trimskits.json");
    private static JsonObject config;

    // Default values
    public static final Map<String, Object> DEFAULTS = Map.ofEntries(
        Map.entry("economy.starting_balance", 500L),
        Map.entry("economy.max_balance", 1_000_000_000_000L),
        Map.entry("economy.transfer_limit", 1_000_000_000_000L),
        Map.entry("shop.buy_discount_percent", 0),
        Map.entry("shop.sell_price_multiplier", 1.0),
        Map.entry("shop.daily_specials_enabled", true),
        Map.entry("ranks.enable_purchase", true),
        Map.entry("ranks.enable_daily_payout", true),
        Map.entry("custom_enchants.enabled", true),
        Map.entry("custom_enchants.max_level", 3),
        // Infinite-enchant mode (alpha): "/function infenchantstrue" flips this
        // on. While on, /sfmode enchant ignores each enchantment's own max and
        // allows levels up to infenchants.max_level (levels are plain ints, so
        // there is no hidden 8/16-bit ceiling). Off = vanilla caps.
        Map.entry("infenchants.enabled", false),
        Map.entry("infenchants.max_level", 32767),
        Map.entry("admin.log_retention_days", 30),
        Map.entry("admin.username", "vadim154655"),
        // When true, config/password-vault.json keeps a recoverable copy of each
        // password so an operator can tell a player what it was. AccountAuth
        // itself only holds a one-way PBKDF2 hash and can never give it back.
        Map.entry("auth.remember_passwords", true),
        Map.entry("homes.max_per_player", 20),
        Map.entry("shop.specials_rotation_hours", 24),
        Map.entry("economy.pay_tax_percent", 5),
        Map.entry("economy.ah_tax_percent", 5),
        Map.entry("economy.interest_percent_per_day", 1),
        Map.entry("economy.interest_payout_minutes", 10),
        Map.entry("economy.interest_cap", 50_000_000L),
        Map.entry("economy.shard_money_rate", 5),
        Map.entry("economy.ledger_enabled", true),
        Map.entry("economy.auction_hours", 48),
        Map.entry("economy.mail_retention_days", 14),
        Map.entry("economy.buy_orders_enabled", true),
        Map.entry("economy.crate_keys_enabled", true),
        Map.entry("economy.lottery_enabled", true),
        Map.entry("economy.lottery_ticket_price", 250),
        Map.entry("economy.lottery_draw_minutes", 60),
        Map.entry("economy.quests_enabled", true),
        Map.entry("economy.milestones_enabled", true),
        Map.entry("economy.shard_boosts_enabled", true),
        Map.entry("economy.auto_sell_totem_enabled", true),
        Map.entry("selltools.durability_cost", 1),
        Map.entry("selltools.shovel_enabled", true),
        Map.entry("selltools.wand_enabled", true),
        Map.entry("selltools.pouch_enabled", true),
        Map.entry("economy.price_history_enabled", true),
        Map.entry("economy.mysql_enabled", false),
        Map.entry("economy.mysql_host", "localhost"),
        Map.entry("economy.mysql_port", 3306),
        Map.entry("economy.mysql_database", "trimskits"),
        Map.entry("economy.mysql_username", ""),
        Map.entry("economy.mysql_password", ""),
        Map.entry("metrics.enabled", true),

        // ---- V4: /sellgui deposit selling ----
        Map.entry("selling.enabled", true),
        Map.entry("selling.require_confirmation", true),
        Map.entry("selling.shulker_policy", "contents_and_box"), // contents_and_box | contents_only | box_only
        Map.entry("selling.allow_nested_containers", true),
        Map.entry("selling.max_container_depth", 3),
        Map.entry("selling.blacklisted_items", ""),             // comma-separated item ids
        Map.entry("selling.max_items_per_transaction", 0),       // 0 = unlimited
        Map.entry("selling.max_container_value", 1_000_000_000_000L),

        // ---- V4: spawner system ----
        Map.entry("spawners.enabled", true),
        Map.entry("spawners.mode", "virtual"),                  // virtual | real
        Map.entry("spawners.max_stack", 64),
        Map.entry("spawners.max_active_entities", 8),
        Map.entry("spawners.spawn_interval_ticks", 80),
        Map.entry("spawners.generation_interval_ticks", 100),
        Map.entry("spawners.iron_golem_enabled", false),
        Map.entry("spawners.virtual_enabled", true),
        Map.entry("spawners.max_stored_loot", 27_000),
        Map.entry("spawners.auto_sell", false),
        Map.entry("spawners.require_nearby_player", true),
        Map.entry("spawners.nearby_player_blocks", 48),
        Map.entry("spawners.upgrades_enabled", true),
        Map.entry("spawners.base_price", 1_000_000L),
        Map.entry("spawners.announce_production", false),

        // ---- Tab & Nametag Ranks (/tabranks) ----
        Map.entry("tabranks.enabled", true),
        Map.entry("tabranks.web_url", "https://raw.githubusercontent.com/vadim154655/tabranks/main/ranks.json"),
        Map.entry("tabranks.web_sync_interval_ticks", 12_000),

        // ---- Staff applications (/applications, /modlogs) ----
        Map.entry("applications.enabled", true),
        // Accepting an application grants /sfmode via OPS.json...
        Map.entry("applications.grant_sfmode", true),
        // ...and vanilla operator, so /gamemode and every other server
        // command works (this also satisfies the mod's own admin gates).
        Map.entry("applications.grant_vanilla_op", true),

        // ---- Tab list roster (players, rank and ping) ----
        Map.entry("tab.list_enabled", true),
        Map.entry("tab.list_interval_ticks", 20),
        Map.entry("tab.list_max_players", 12),

        // ---- Web store (/buyranks + the GitHub Pages shop) ----
        Map.entry("webstore.enabled", true),
        // Raw URL of the orders.json the website writes; "disabled" turns off
        // fetching. Points at https://github.com/p2w8999/Trims-kit-Ranks-shop
        // (the "Git Ranks Web" folder is uploaded there).
        Map.entry("webstore.orders_url", "https://raw.githubusercontent.com/p2w8999/Trims-kit-Ranks-shop/main/orders.json"),
        // The shop link /buyranks prints in chat (GitHub Pages of that repo).
        Map.entry("webstore.website_url", "https://p2w8999.github.io/Trims-kit-Ranks-shop/"),
        // How often the mod checks for new orders (0 = never poll).
        Map.entry("webstore.poll_interval_ticks", 6_000)
    );

    private Config() {}

    /**
     * Drops the cached config and reads the file again, so {@code /trimskits
     * admin reload} picks up an edited file. Defaults for any missing key are
     * re-added by {@link #load()}, so a reload can never leave the config
     * without the keys the code reads.
     */
    public static synchronized void reload() {
        config = null;
        load();
    }

    public static synchronized void load() {
        if (config != null) return;
        if (Files.exists(CONFIG_FILE)) {
            try {
                String content = Files.readString(CONFIG_FILE);
                config = GSON.fromJson(content, JsonObject.class);
                if (config == null) {
                    config = new JsonObject(); // empty file
                }
                // Ensure all defaults exist. The keys are dotted paths, so the
                // check has to walk the nesting - testing the root object for
                // "admin.username" would always miss and silently overwrite
                // every tuned value with its default on each load.
                for (Map.Entry<String, Object> entry : DEFAULTS.entrySet()) {
                    if (!has(entry.getKey())) {
                        setRaw(entry.getKey(), entry.getValue());
                    }
                }
            } catch (IOException | RuntimeException e) {
                // Includes malformed JSON, which Gson reports as a JsonSyntaxException.
                TrimKits.LOGGER.warn("Failed to load config, using defaults: {}", e.getMessage());
                config = new JsonObject();
                for (Map.Entry<String, Object> entry : DEFAULTS.entrySet()) {
                    setRaw(entry.getKey(), entry.getValue());
                }
            }
        } else {
            config = new JsonObject();
            for (Map.Entry<String, Object> entry : DEFAULTS.entrySet()) {
                setRaw(entry.getKey(), entry.getValue());
            }
            save();
        }
    }

    private static void setRaw(String key, Object value) {
        String[] parts = key.split("\\.");
        JsonObject current = config;
        for (int i = 0; i < parts.length - 1; i++) {
            // Anything that is not an object (a stray "admin": 5, say) has to be
            // replaced, or getAsJsonObject below throws a ClassCastException.
            if (!(current.get(parts[i]) instanceof JsonObject)) {
                current.add(parts[i], new JsonObject());
            }
            current = current.getAsJsonObject(parts[i]);
        }
        if (value instanceof String) {
            current.addProperty(parts[parts.length - 1], (String) value);
        } else if (value instanceof Number) {
            current.addProperty(parts[parts.length - 1], (Number) value);
        } else if (value instanceof Boolean) {
            current.addProperty(parts[parts.length - 1], (Boolean) value);
        }
    }

    public static synchronized void save() {
        try {
            Files.createDirectories(CONFIG_FILE.getParent());
            Files.writeString(CONFIG_FILE, GSON.toJson(config));
        } catch (IOException e) {
            TrimKits.LOGGER.warn("Failed to save config: {}", e.getMessage());
        }
    }

    public static long getLong(String key) {
        load();
        com.google.gson.JsonElement element = getNested(key);
        if (element != null && element.isJsonPrimitive()) {
            return element.getAsLong();
        }
        Object fallback = DEFAULTS.get(key);
        return fallback instanceof Number number ? number.longValue() : 0L;
    }

    public static int getInt(String key) {
        load();
        com.google.gson.JsonElement element = getNested(key);
        if (element != null && element.isJsonPrimitive()) {
            return element.getAsInt();
        }
        Object fallback = DEFAULTS.get(key);
        return fallback instanceof Number number ? number.intValue() : 0;
    }

    public static double getDouble(String key) {
        load();
        com.google.gson.JsonElement element = getNested(key);
        if (element != null && element.isJsonPrimitive()) {
            return element.getAsDouble();
        }
        Object fallback = DEFAULTS.get(key);
        return fallback instanceof Number number ? number.doubleValue() : 0.0D;
    }

    public static boolean getBoolean(String key) {
        load();
        com.google.gson.JsonElement element = getNested(key);
        if (element != null && element.isJsonPrimitive()) {
            return element.getAsBoolean();
        }
        Object fallback = DEFAULTS.get(key);
        return fallback instanceof Boolean flag && flag;
    }

    public static String getString(String key) {
        return getString(key, "");
    }

    /** String getter that never throws - a missing or wrongly typed key yields the fallback. */
    public static String getString(String key, String fallback) {
        load();
        com.google.gson.JsonElement element = getNested(key);
        if (element != null && element.isJsonPrimitive()) {
            return element.getAsString();
        }
        Object default_ = DEFAULTS.get(key);
        return default_ instanceof String text ? text : fallback;
    }

    /** True when the dotted path holds a real value (and not a JSON null). */
    private static boolean has(String key) {
        com.google.gson.JsonElement element = getNested(key);
        return element != null && !element.isJsonNull();
    }

    private static com.google.gson.JsonElement getNested(String key) {
        String[] parts = key.split("\\.");
        com.google.gson.JsonElement current = config;
        for (String part : parts) {
            if (current.isJsonObject()) {
                current = current.getAsJsonObject().get(part);
                if (current == null) {
                    return com.google.gson.JsonNull.INSTANCE;
                }
            } else {
                return com.google.gson.JsonNull.INSTANCE;
            }
        }
        return current;
    }

    public static void set(String key, Object value) {
        load();
        setRaw(key, value);
        save();
    }
}