package com.kodari.trimskits;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

/**
 * Manages {@code config/password-vault.json}: a recoverable record of each
 * player's password, so an operator can tell a player what their password was
 * after they forgot it.
 *
 * <p>This exists <b>because the main account store cannot do this job</b>.
 * {@link AccountAuth} keeps only a PBKDF2 hash (210k iterations, per-account
 * salt). That is the correct way to store a password — and the reason it is
 * correct is that it is one-way: the original cannot be read back out. So a
 * forgotten password is unrecoverable by design there. This vault is the
 * deliberate exception: a second store that keeps the password readable, used
 * only when an operator has to hand it back.
 *
 * <h2>Read this before you rely on it</h2>
 * <b>Anyone who reads this file can read every stored password.</b> The
 * passwords are held reversibly on purpose, so they can be shown again. That
 * makes this file far more sensitive than {@code trimskits-accounts.properties}:
 * <ul>
 *   <li>Keep the whole {@code config/} folder out of public reach.</li>
 *   <li>Do not commit it to a public repository or share it in tickets.</li>
 *   <li>Assume players reuse passwords across sites, as people do.</li>
 * </ul>
 * If you would rather not keep recoverable passwords at all, set
 * {@code auth.remember_passwords} to {@code false} in the config: the vault
 * then stops recording, the file stops changing, and accounts keep working
 * exactly as before (they still cannot be recovered, same as any hashed auth).
 *
 * <p>The file is created on join, the same way {@code OPS.json} is, so it is
 * always present and always current. Every write is atomic (temp file, then
 * move) so a crash mid-write cannot leave a half-written vault behind, and a
 * file that cannot be parsed is read as empty <em>but never overwritten</em> —
 * the operator can still fix it by hand.
 *
 * <p>Entries are keyed by {@code uuid} (stable across name changes) and also
 * carry the {@code username} for lookups. Re-registering or logging in refreshes
 * the entry, so the vault follows the password rather than freezing the first
 * one ever set.
 */
final class PasswordVault {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_DIR = Path.of("config");
    private static final Path VAULT_FILE = CONFIG_DIR.resolve("password-vault.json");

    /** Cached entries, keyed by nothing in particular - a flat list is plenty. */
    private static List<VaultEntry> entries = Collections.emptyList();
    private static boolean loaded = false;

    private PasswordVault() {}

    /**
     * One recoverable credential.
     *
     * @param username the player's name at last record, for display/lookup
     * @param uuid     the stable id, so a name change cannot orphan the entry
     * @param password the password, held reversibly so it can be shown again
     * @param updated  epoch millis of the last time this was recorded
     */
    record VaultEntry(String username, UUID uuid, String password, long updated) {}

    // ---- Reads -------------------------------------------------------------

    /**
     * The stored password for this name, or null when there is no record.
     *
     * <p>Lookup is by username (case-insensitive, the way people type it) but
     * falls back to the uuid, so a renamed player can still be found.
     */
    static synchronized String lookup(String username, UUID playerId) {
        load();
        if (playerId != null) {
            for (VaultEntry entry : entries) {
                if (entry.uuid().equals(playerId)) {
                    return entry.password();
                }
            }
        }
        if (username == null) {
            return null;
        }
        for (VaultEntry entry : entries) {
            if (entry.username() != null && entry.username().equalsIgnoreCase(username)) {
                return entry.password();
            }
        }
        return null;
    }

    /** Every entry, for an operator listing what is on file. */
    static synchronized List<VaultEntry> all() {
        load();
        return List.copyOf(entries);
    }

    /** How many passwords are on file. */
    static synchronized int size() {
        load();
        return entries.size();
    }

    /**
     * Makes sure the vault file exists on disk, creating an empty one if not.
     *
     * <p>Called on join so the file is always present, the same way
     * {@code OPS.json} appears on first run. It does not alter any stored
     * password — it only guarantees the file is there to be looked in.
     */
    static synchronized void ensureFile() {
        load();
    }

    // ---- Writes ------------------------------------------------------------

    /**
     * Records (or refreshes) a password against this player.
     *
     * <p>Respects {@code auth.remember_passwords}: when that is off, this does
     * nothing at all, so turning the feature off really does stop the file from
     * growing rather than merely hiding it.
     */
    static synchronized void record(UUID playerId, String username, String password) {
        if (!Config.getBoolean("auth.remember_passwords")) {
            return;
        }
        if (playerId == null || password == null || password.isEmpty()) {
            return;
        }
        load();
        List<VaultEntry> updated = new ArrayList<>(entries.size() + 1);
        boolean replaced = false;
        for (VaultEntry entry : entries) {
            // One entry per player: match on uuid first (stable), then by name,
            // so a re-register or a rename updates in place instead of piling
            // up stale rows that would shadow the real password.
            boolean samePlayer = entry.uuid().equals(playerId)
                || (username != null && entry.username() != null
                    && entry.username().equalsIgnoreCase(username));
            if (samePlayer) {
                updated.add(new VaultEntry(username, playerId, password, System.currentTimeMillis()));
                replaced = true;
            } else {
                updated.add(entry);
            }
        }
        if (!replaced) {
            updated.add(new VaultEntry(username, playerId, password, System.currentTimeMillis()));
        }
        entries = updated;
        save();
    }

    /**
     * Forgets a single player's recorded password.
     *
     * <p>Pairs with an account reset: clearing the hash and the recovery record
     * together means no orphaned copy of the old password is left behind.
     */
    static synchronized boolean forget(UUID playerId, String username) {
        load();
        List<VaultEntry> kept = new ArrayList<>(entries.size());
        boolean removed = false;
        for (VaultEntry entry : entries) {
            boolean samePlayer = entry.uuid().equals(playerId)
                || (username != null && entry.username() != null
                    && entry.username().equalsIgnoreCase(username));
            if (samePlayer) {
                removed = true;
            } else {
                kept.add(entry);
            }
        }
        if (removed) {
            entries = kept;
            save();
        }
        return removed;
    }

    /** Clears every recorded password. Irreversible - the hashes are untouched. */
    static synchronized boolean clear() {
        load();
        if (entries.isEmpty()) {
            return false;
        }
        entries = new ArrayList<>();
        save();
        return true;
    }

    // ---- Persistence -------------------------------------------------------

    /** Loads the vault once, creating an empty file when none exists yet. */
    private static void load() {
        if (loaded) {
            return;
        }
        loaded = true;

        if (!Files.exists(VAULT_FILE)) {
            // Create it now so the operator always has a file to look in, the
            // same way OPS.json appears on first run.
            entries = new ArrayList<>();
            save();
            return;
        }

        try {
            String content = Files.readString(VAULT_FILE);
            entries = parse(content);
            TrimKits.LOGGER.info("Loaded {} password vault entr{} from {}.",
                entries.size(), entries.size() == 1 ? "y" : "ies", VAULT_FILE);
        } catch (IOException | RuntimeException e) {
            // Read as empty, but leave the file exactly as it is: a parse error
            // must never destroy the operator's only recovery copy.
            TrimKits.LOGGER.warn(
                "Failed to read {} ({}), treating the vault as empty - the file was left untouched.",
                VAULT_FILE, e.getMessage());
            entries = new ArrayList<>();
        }
    }

    /** Parses the tolerant shapes people actually paste in. */
    private static List<VaultEntry> parse(String content) {
        List<VaultEntry> parsed = new ArrayList<>();
        if (content == null || content.isBlank()) {
            return parsed;
        }
        JsonElement rootElement = JsonParser.parseString(content);
        if (!rootElement.isJsonObject()) {
            return parsed;
        }
        JsonObject root = rootElement.getAsJsonObject();

        // The canonical shape nests under "players"; a bare top-level array is
        // accepted too, because that is what people hand-edit toward.
        JsonArray array = null;
        if (root.has("players") && root.get("players").isJsonArray()) {
            array = root.getAsJsonArray("players");
        } else if (root.has("passwords") && root.get("passwords").isJsonArray()) {
            array = root.getAsJsonArray("passwords");
        }
        if (array == null) {
            return parsed;
        }

        for (JsonElement element : array) {
            if (!element.isJsonObject()) {
                continue;
            }
            JsonObject obj = element.getAsJsonObject();
            String username = readString(obj, "username", "name", "player");
            UUID uuid = readUuid(obj, "uuid", "id");
            String password = readString(obj, "password", "pass", "pw");
            if (password == null || password.isEmpty()) {
                // A row without a password carries no information worth keeping.
                continue;
            }
            long updated = readLong(obj, "updated", "timestamp", "time");
            parsed.add(new VaultEntry(username, uuid, password, updated));
        }
        return parsed;
    }

    private static String readString(JsonObject obj, String... keys) {
        for (String key : keys) {
            if (obj.has(key) && obj.get(key).isJsonPrimitive()) {
                String value = obj.get(key).getAsString();
                if (value != null && !value.isEmpty()) {
                    return value;
                }
            }
        }
        return null;
    }

    private static UUID readUuid(JsonObject obj, String... keys) {
        for (String key : keys) {
            if (obj.has(key) && obj.get(key).isJsonPrimitive()) {
                try {
                    return UUID.fromString(obj.get(key).getAsString());
                } catch (IllegalArgumentException ignored) {
                    // Not a uuid under this key; try the next alias.
                }
            }
        }
        return null;
    }

    private static long readLong(JsonObject obj, String... keys) {
        for (String key : keys) {
            if (obj.has(key) && obj.get(key).isJsonPrimitive()) {
                try {
                    return obj.get(key).getAsLong();
                } catch (NumberFormatException ignored) {
                    // Not a number under this key; try the next alias.
                }
            }
        }
        return 0L;
    }

    /**
     * Writes the vault atomically.
     *
     * <p>Writes to a temp file first, then moves it over the real one, so an
     * interrupted write can never truncate the only copy of every password.
     */
    private static boolean save() {
        JsonObject root = new JsonObject();
        JsonArray players = new JsonArray();
        for (VaultEntry entry : entries) {
            JsonObject obj = new JsonObject();
            if (entry.username() != null) {
                obj.addProperty("username", entry.username());
            }
            if (entry.uuid() != null) {
                obj.addProperty("uuid", entry.uuid().toString());
            }
            obj.addProperty("password", entry.password() == null ? "" : entry.password());
            obj.addProperty("updated", entry.updated());
            players.add(obj);
        }
        root.add("players", players);

        Path temporaryFile = VAULT_FILE.resolveSibling("password-vault.tmp");
        try {
            Files.createDirectories(CONFIG_DIR);
            Files.writeString(temporaryFile, GSON.toJson(root));
            try {
                Files.move(temporaryFile, VAULT_FILE,
                    StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
            } catch (AtomicMoveNotSupportedException fallback) {
                Files.move(temporaryFile, VAULT_FILE, StandardCopyOption.REPLACE_EXISTING);
            }
            return true;
        } catch (IOException e) {
            TrimKits.LOGGER.warn("Failed to save password-vault.json: {}", e.getMessage());
            return false;
        }
    }
}
