package com.kodari.trimskits;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Persistent, per-player spawner state: two independent upgrade tracks and the
 * loot each spawner has produced but not yet collected.
 *
 * <p>State is keyed by {@code player + entity type} rather than by an individual
 * item instance. That is a deliberate choice with three payoffs:
 * <ul>
 *   <li><b>Splitting or merging stacks cannot corrupt anything.</b> A stack of
 *       100 zombie spawners split into 64 + 36 refers to the same one record,
 *       because the record belongs to the player, not to a stack.</li>
 *   <li><b>Nothing is stored in the item itself</b>, so spawners stay cleanly
 *       tradable — buying, selling and gifting a spawner never carries stale
 *       production data with it.</li>
 *   <li><b>Persistence is one small properties file</b>, written atomically and
 *       only when something actually changed, instead of being rewritten on
 *       every inventory click.</li>
 * </ul>
 *
 * <p>The two upgrade tracks are {@link #efficiency} (how fast the spawner
 * produces) and {@link #capacity} (how much it can hold before it must be
 * collected). Both are bought with real money through {@link MarketData}, so
 * they are a genuine economy sink rather than a number a GUI merely displays,
 * and both survive a restart.
 *
 * <p>Loot accumulates against a hard cap derived from the capacity track. When
 * a spawner is full it simply stops producing — it never discards, never
 * overflows and never writes past the cap, so a player who forgets to collect
 * for a week loses nothing and the server gains no unbounded memory.
 */
final class SpawnerState {

	private static final Logger LOGGER = LoggerFactory.getLogger("trimskits");
	private static final Path DATA_FILE = Path.of("config", "trimskits-spawners.properties");

	/** Highest level either upgrade track may reach. */
	static final int MAX_LEVEL = 10;

	/**
	 * player id -> entity id -> upgrade record.
	 * Written as {@code upgrade.<player>.<entity>} and
	 * {@code efficiency.<player>.<entity>} in the properties file.
	 */
	private static final Map<UUID, Map<String, Upgrade>> UPGRADES = new HashMap<>();
	/** player id -> entity id -> (item id -> count) of uncollected loot. */
	private static final Map<UUID, Map<String, Map<String, Long>>> LOOT = new HashMap<>();

	private static boolean loaded;
	private static boolean readable = true;
	/** Bumped on every mutation so the tick loop can persist cheaply. */
	private static int revision;

	private SpawnerState() {
	}

	record Upgrade(int efficiency, int capacity) {
		static final Upgrade NONE = new Upgrade(0, 0);

		boolean isMaxed() {
			return efficiency >= MAX_LEVEL && capacity >= MAX_LEVEL;
		}
	}

	// ---- Reads -------------------------------------------------------------

	/** The upgrade record for a player's spawner of this type. */
	static Upgrade upgradeOf(UUID playerId, String entityId) {
		load();
		Map<String, Upgrade> forPlayer = UPGRADES.get(playerId);
		if (forPlayer == null) {
			return Upgrade.NONE;
		}
		return forPlayer.getOrDefault(entityId, Upgrade.NONE);
	}

	/** Production multiplier from the efficiency track: 1.0 at level 0. */
	static double rateMultiplier(UUID playerId, String entityId) {
		return 1.0 + 0.25 * upgradeOf(playerId, entityId).efficiency();
	}

	/**
	 * Storage cap for this spawner, in items.
	 *
	 * <p>Scales with the capacity track so upgrading is visibly worth it, and is
	 * clamped to the configured ceiling so a config change can never produce a
	 * negative or absurd limit.
	 */
	static int capacity(UUID playerId, String entityId) {
		int base = Math.max(1, Config.getInt("spawners.max_stored_loot"));
		int level = upgradeOf(playerId, entityId).capacity();
		long scaled = (long) base * (level + 1L);
		// A hard ceiling keeps a maxed-out spawner from ever reaching sizes
		// that would make a single collection operation sluggish.
		return (int) Math.min(scaled, 2_000_000L);
	}

	/** Total items currently sitting in this spawner's storage. */
	static long storedTotal(UUID playerId, String entityId) {
		load();
		Map<String, Map<String, Long>> forPlayer = LOOT.get(playerId);
		if (forPlayer == null) {
			return 0;
		}
		Map<String, Long> table = forPlayer.get(entityId);
		if (table == null) {
			return 0;
		}
		long total = 0;
		for (long count : table.values()) {
			total += count;
		}
		return total;
	}

	/** An immutable snapshot of this spawner's stored loot, sorted by item id. */
	static Map<String, Long> stored(UUID playerId, String entityId) {
		load();
		Map<String, Map<String, Long>> forPlayer = LOOT.get(playerId);
		if (forPlayer == null) {
			return Map.of();
		}
		Map<String, Long> table = forPlayer.get(entityId);
		return table == null ? Map.of() : Map.copyOf(table);
	}

	/** Every entity type this player has any spawner state for (loot or upgrades). */
	static List<String> activeTypes(UUID playerId) {
		load();
		List<String> types = new ArrayList<>();
		Map<String, Upgrade> upgraded = UPGRADES.get(playerId);
		if (upgraded != null) {
			for (Map.Entry<String, Upgrade> entry : upgraded.entrySet()) {
				if (!entry.getValue().equals(Upgrade.NONE)) {
					types.add(entry.getKey());
				}
			}
		}
		Map<String, Map<String, Long>> lootForPlayer = LOOT.get(playerId);
		if (lootForPlayer != null) {
			for (Map.Entry<String, Map<String, Long>> entry : lootForPlayer.entrySet()) {
				if (!types.contains(entry.getKey()) && !entry.getValue().isEmpty()) {
					types.add(entry.getKey());
				}
			}
		}
		return types;
	}

	// ---- Writes ------------------------------------------------------------

	/**
	 * Adds produced loot, respecting the storage cap.
	 *
	 * @return how many items were actually accepted (may be less than asked)
	 */
	static synchronized long store(UUID playerId, String entityId,
			Map<String, Long> gains) {
		if (gains == null || gains.isEmpty()) {
			return 0;
		}
		load();
		long cap = capacity(playerId, entityId);
		long already = storedTotal(playerId, entityId);
		long room = Math.max(0, cap - already);
		if (room == 0) {
			return 0;
		}

		Map<String, Map<String, Long>> forPlayer =
			LOOT.computeIfAbsent(playerId, ignored -> new HashMap<>());
		Map<String, Long> table = forPlayer.computeIfAbsent(entityId, ignored -> new LinkedHashMap<>());

		long accepted = 0;
		for (Map.Entry<String, Long> gain : gains.entrySet()) {
			if (room <= 0) {
				break;
			}
			long amount = Math.min(gain.getValue(), room);
			if (amount <= 0) {
				continue;
			}
			table.merge(gain.getKey(), amount, Long::sum);
			room -= amount;
			accepted += amount;
		}
		if (accepted > 0) {
			revision++;
		}
		return accepted;
	}

	/**
	 * Removes stored loot, returning what was actually taken.
	 *
	 * <p>Used by both "collect" (which puts it in the inventory) and "sell all"
	 * (which converts it to money). The caller gets the amount that really left
	 * storage, so a full inventory or a failed sale can be reported honestly
	 * rather than assumed.
	 */
	static synchronized Map<String, Long> take(UUID playerId, String entityId,
			Map<String, Long> wanted) {
		load();
		Map<String, Map<String, Long>> forPlayer = LOOT.get(playerId);
		if (forPlayer == null) {
			return Map.of();
		}
		Map<String, Long> table = forPlayer.get(entityId);
		if (table == null || table.isEmpty()) {
			return Map.of();
		}

		Map<String, Long> taken = new LinkedHashMap<>();
		for (Map.Entry<String, Long> ask : wanted.entrySet()) {
			long available = table.getOrDefault(ask.getKey(), 0L);
			if (available <= 0) {
				continue;
			}
			long amount = Math.min(available, ask.getValue());
			if (amount <= 0) {
				continue;
			}
			long left = available - amount;
			if (left <= 0) {
				table.remove(ask.getKey());
			} else {
				table.put(ask.getKey(), left);
			}
			taken.put(ask.getKey(), amount);
		}
		if (table.isEmpty()) {
			forPlayer.remove(entityId);
		}
		if (!taken.isEmpty()) {
			revision++;
		}
		return taken;
	}

	/** Clears all stored loot for one spawner; returns what was there. */
	static Map<String, Long> takeAll(UUID playerId, String entityId) {
		return take(playerId, entityId, stored(playerId, entityId));
	}

	/**
	 * Buys one level on a track with real money.
	 *
	 * @param track 0 = efficiency, 1 = capacity
	 * @return null on success, or the reason it did not happen
	 */
	static synchronized String buyUpgrade(UUID playerId, SpawnerType.Spec type,
			int track, net.minecraft.core.RegistryAccess registries) {
		load();
		if (type == null) {
			return "That spawner type does not exist.";
		}
		if (!Config.getBoolean("spawners.upgrades_enabled")) {
			return "Spawner upgrades are disabled on this server.";
		}
		Upgrade current = upgradeOf(playerId, type.entityId());
		int level = track == 0 ? current.efficiency() : current.capacity();
		if (level >= MAX_LEVEL) {
			return "That upgrade is already maxed at level " + MAX_LEVEL + ".";
		}
		long cost = upgradeCost(track, level);
		// Money leaves first; if it cannot, nothing is granted. That ordering is
		// what makes the purchase incapable of creating value from thin air.
		if (!MarketData.debit(playerId, cost, registries)) {
			return "You need $" + TrimKits.formatMoney(cost) + " for that upgrade.";
		}
		Upgrade next = track == 0
			? new Upgrade(current.efficiency() + 1, current.capacity())
			: new Upgrade(current.efficiency(), current.capacity() + 1);
		UPGRADES.computeIfAbsent(playerId, ignored -> new HashMap<>())
			.put(type.entityId(), next);
		revision++;
		save();
		Ledger.record(playerId, -cost, "spawner-upgrade",
			(type.entityId() + " track=" + (track == 0 ? "efficiency" : "capacity")
				+ " level=" + (level + 1)));
		return null;
	}

	/**
	 * Cost of the next level on a track.
	 *
	 * <p>Quadratic in the current level, denominated in the millions, so early
	 * levels are an easy buy and the last few are a real decision — and so a
	 * legendary spawner's upgrades scale with its billion-dollar price tag.
	 */
	static long upgradeCost(int track, int level) {
		long base = track == 0 ? 5_000_000L : 3_000_000L;
		long step = Math.max(0, level) + 1L;
		try {
			return Math.multiplyExact(base, Math.multiplyExact(step, step));
		} catch (ArithmeticException overflow) {
			return Long.MAX_VALUE / 4;
		}
	}

	// ---- Persistence -------------------------------------------------------

	private static void load() {
		if (loaded) {
			return;
		}
		loaded = true;
		if (!Files.exists(DATA_FILE)) {
			return;
		}
		Properties properties = new Properties();
		try (InputStream input = Files.newInputStream(DATA_FILE)) {
			properties.load(input);
		} catch (IOException exception) {
			readable = false;
			LOGGER.warn("Could not read {}; spawner upgrades stay in memory only.", DATA_FILE);
			return;
		}

		// Collect levels into a mutable scratch first: Upgrade is an immutable
		// record, and the two halves of an upgrade arrive as separate keys.
		Map<String, int[]> scratch = new HashMap<>(); // "player|entity" -> [efficiency, capacity]
		for (String key : properties.stringPropertyNames()) {
			String value = properties.getProperty(key);
			try {
				if (key.startsWith("efficiency.")) {
					String[] parts = splitKey(key, "efficiency.");
					if (parts != null) {
						scratchOf(scratch, parts)[0] = clampLevel(parseInt(value));
					}
				} else if (key.startsWith("capacity.")) {
					String[] parts = splitKey(key, "capacity.");
					if (parts != null) {
						scratchOf(scratch, parts)[1] = clampLevel(parseInt(value));
					}
				} else if (key.startsWith("loot.")) {
					// loot.<player>.<entity>.<item id> = count
					String[] parts = splitLootKey(key);
					if (parts != null && parseLong(value) > 0) {
						LOOT.computeIfAbsent(UUID.fromString(parts[0]), ignored -> new HashMap<>())
							.computeIfAbsent(parts[1], ignored -> new LinkedHashMap<>())
							.put(parts[2], parseLong(value));
					}
				}
			} catch (RuntimeException ignored) {
				// Skip a damaged line rather than failing the whole load.
			}
		}

		// Fold the scratch into immutable records, grouped by player.
		for (Map.Entry<String, int[]> entry : scratch.entrySet()) {
			String[] halves = entry.getKey().split("\\|", 2);
			if (halves.length != 2) {
				continue;
			}
			try {
				UUID playerId = UUID.fromString(halves[0]);
				int[] levels = entry.getValue();
				UPGRADES.computeIfAbsent(playerId, ignored -> new HashMap<>())
					.put(halves[1], new Upgrade(levels[0], levels[1]));
			} catch (RuntimeException ignored) {
				// Malformed grouping; skip it.
			}
		}
	}

	/** {@code efficiency.<player>.<entity>} -> {player, entity}. */
	private static String[] splitKey(String key, String prefix) {
		String rest = key.substring(prefix.length());
		int dot = rest.indexOf('.');
		if (dot <= 0 || dot >= rest.length() - 1) {
			return null;
		}
		try {
			UUID.fromString(rest.substring(0, dot));
		} catch (IllegalArgumentException notAUuid) {
			return null;
		}
		return new String[] { rest.substring(0, dot), rest.substring(dot + 1) };
	}

	/**
	 * {@code loot.<player>.<entity>.<item>} -> {player, entity, item}.
	 *
	 * <p>The item id itself contains a colon, so only the first two separators
	 * are structural and the remainder is taken verbatim. {@link Properties}
	 * escapes colons and equals signs on write, so they round-trip safely.
	 */
	private static String[] splitLootKey(String key) {
		String rest = key.substring("loot.".length());
		int first = rest.indexOf('.');
		if (first <= 0) {
			return null;
		}
		String player = rest.substring(0, first);
		try {
			UUID.fromString(player);
		} catch (IllegalArgumentException notAUuid) {
			return null;
		}
		String tail = rest.substring(first + 1);
		int second = tail.indexOf('.');
		if (second <= 0 || second >= tail.length() - 1) {
			return null;
		}
		return new String[] { player, tail.substring(0, second), tail.substring(second + 1) };
	}

	/** Mutable {@code [efficiency, capacity]} scratch slot for a player/type pair. */
	private static int[] scratchOf(Map<String, int[]> scratch, String[] parts) {
		return scratch.computeIfAbsent(parts[0] + "|" + parts[1], ignored -> new int[2]);
	}

	private static int clampLevel(int level) {
		return Math.max(0, Math.min(level, MAX_LEVEL));
	}

	private static int parseInt(String text) {
		return (int) Long.parseLong(text.trim());
	}

	private static long parseLong(String text) {
		return Long.parseLong(text.trim());
	}

	private static boolean save() {
		if (!readable) {
			return false;
		}
		Properties properties = new Properties();
		for (Map.Entry<UUID, Map<String, Upgrade>> playerEntry : UPGRADES.entrySet()) {
			String player = playerEntry.getKey().toString();
			for (Map.Entry<String, Upgrade> typeEntry : playerEntry.getValue().entrySet()) {
				Upgrade upgrade = typeEntry.getValue();
				properties.setProperty("efficiency." + player + "." + typeEntry.getKey(),
					Integer.toString(upgrade.efficiency()));
				properties.setProperty("capacity." + player + "." + typeEntry.getKey(),
					Integer.toString(upgrade.capacity()));
			}
		}
		for (Map.Entry<UUID, Map<String, Map<String, Long>>> playerEntry : LOOT.entrySet()) {
			String player = playerEntry.getKey().toString();
			for (Map.Entry<String, Map<String, Long>> typeEntry : playerEntry.getValue().entrySet()) {
				for (Map.Entry<String, Long> itemEntry : typeEntry.getValue().entrySet()) {
					properties.setProperty(
						"loot." + player + "." + typeEntry.getKey() + "." + itemEntry.getKey(),
						Long.toString(itemEntry.getValue()));
				}
			}
		}

		Path temporaryFile = DATA_FILE.resolveSibling("trimskits-spawners.tmp");
		try {
			Files.createDirectories(DATA_FILE.getParent());
			try (OutputStream output = Files.newOutputStream(temporaryFile)) {
				properties.store(output, "Trim Kits spawner upgrades and stored loot");
			}
			try {
				Files.move(temporaryFile, DATA_FILE,
					StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
			} catch (AtomicMoveNotSupportedException exception) {
				Files.move(temporaryFile, DATA_FILE, StandardCopyOption.REPLACE_EXISTING);
			}
			return true;
		} catch (IOException exception) {
			LOGGER.warn("Could not save spawner state: {}", exception.getMessage());
			return false;
		}
	}

	/** Persists if anything changed since the last flush; returns whether it wrote. */
	static synchronized boolean saveIfDirty(int seenRevision) {
		if (seenRevision == revision || !readable) {
			return false;
		}
		return save();
	}

	/** Current revision, for the periodic-flush loop. */
	static int revision() {
		return revision;
	}

	/** Force a write now (server stop, admin reload). */
	static synchronized boolean flush() {
		return save();
	}
}
