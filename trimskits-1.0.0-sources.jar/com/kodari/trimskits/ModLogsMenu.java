package com.kodari.trimskits;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;

/**
 * The {@code /modlogs} review GUI: a list of submitted applications, and an
 * in-place detail view showing every question with the applicant's answer.
 * Accepting grants the rank, /sfmode and vanilla operator permissions, exactly
 * like {@code /gamemode} and every other server command need.
 *
 * <p>Both views live in the same menu and re-render in place (the SpawnerMenu
 * pattern) - no menu swaps, so there is no open/close race.
 */
final class ModLogsMenu extends ChestMenu {
	private static final int ROWS = 6;
	private static final int SIZE = ROWS * 9;

	// List view: one paper per submission across the middle four rows.
	private static final int LIST_START = 9;
	private static final int LIST_END = 44;
	private static final int LIST_TITLE = 0;
	private static final int LIST_CLOSE = 8;

	// Detail view: header row.
	private static final int DETAIL_BACK = 0;
	private static final int DETAIL_INFO = 1;
	private static final int DETAIL_CLOSE = 8;
	// Detail view: answers across the middle four rows (max 36 lines of Q/A).
	private static final int ANSWER_START = 9;
	private static final int ANSWER_END = 44;
	// Detail view: bottom control row.
	private static final int DETAIL_HINT = 45;
	private static final int DETAIL_ACCEPT = 47;
	private static final int DETAIL_REJECT = 49;
	private static final int DETAIL_REFRESH = 51;
	private static final int DETAIL_LIST = 53;

	/** Non-null when the detail view is showing this submission. */
	private Applications.Submission selected;

	private final ServerPlayer owner;
	private final SimpleContainer container;

	ModLogsMenu(int containerId, Inventory inventory, ServerPlayer owner) {
		super(MenuType.GENERIC_9x6, containerId, inventory, new SimpleContainer(SIZE), ROWS);
		this.owner = owner;
		this.container = (SimpleContainer) getContainer();
		render();
	}

	private boolean detail() {
		return selected != null;
	}

	// ---- Rendering ---------------------------------------------------------

	private void render() {
		for (int slot = 0; slot < SIZE; slot++) {
			container.setItem(slot, detail() ? detailPane(slot) : listPane(slot));
		}
		broadcastChanges();
	}

	// ---- List view ---------------------------------------------------------

	private ItemStack listPane(int slot) {
		if (slot == LIST_TITLE) {
			return info(Items.BOOK, "§6§lMod Logs",
				"§7Pending applications are shown",
				"§7first, newest on top.",
				"§7Waiting: §e" + Applications.pendingCount());
		}
		if (slot == LIST_CLOSE) {
			return info(Items.BARRIER, "§cClose", "§7Nothing here is taken from you.");
		}
		if (slot < LIST_START || slot > LIST_END) {
			return filler();
		}
		int index = slot - LIST_START;
		List<Applications.Submission> submissions = Applications.submissions();
		if (index >= submissions.size()) {
			return filler();
		}
		return submissionItem(submissions.get(index));
	}

	private ItemStack submissionItem(Applications.Submission submission) {
		Applications.Role role = Applications.role(submission.roleId());
		String roleLabel = role == null ? submission.roleId() : role.display();
		String statusLine = switch (submission.status()) {
			case "accepted" -> "§aAccepted";
			case "rejected" -> "§cRejected";
			default -> "§ePending";
		};
		ItemStack paper = new ItemStack(Items.PAPER);
		paper.set(DataComponents.CUSTOM_NAME, Component.literal(
			"§f" + submission.username() + " §7- §b" + roleLabel + " " + statusLine));
		paper.set(DataComponents.LORE, new ItemLore(List.of(
			Component.literal("§7Submitted: §f" + Applications.formatTime(submission.submittedAt())),
			Component.literal("§7Answers: §f" + submission.answers().size()),
			submission.reviewedBy() == null
				? Component.empty()
				: Component.literal("§7By: §f" + submission.reviewedBy()),
			Component.empty(),
			Component.literal("§eClick to review")
		)));
		return paper;
	}

	// ---- Detail view -------------------------------------------------------

	private ItemStack detailPane(int slot) {
		Applications.Submission submission = selected;
		if (submission == null) {
			return filler();
		}
		Applications.Role role = Applications.role(submission.roleId());
		String roleLabel = role == null ? submission.roleId() : role.display();
		boolean pending = "pending".equals(submission.status());

		if (slot == DETAIL_BACK) {
			return info(Items.ARROW, "§eBack to list");
		}
		if (slot == DETAIL_CLOSE) {
			return info(Items.BARRIER, "§cClose");
		}
		if (slot == DETAIL_INFO) {
			ItemStack info = new ItemStack(Items.PLAYER_HEAD);
			info.set(DataComponents.CUSTOM_NAME, Component.literal("§f" + submission.username()));
			List<Component> lore = new ArrayList<>();
			lore.add(Component.literal("§7Applying: §b" + roleLabel));
			lore.add(Component.literal("§7Status: " + (pending
				? "§ePending" : "accepted".equals(submission.status()) ? "§aAccepted" : "§cRejected")));
			lore.add(Component.literal("§7Submitted: §f" + Applications.formatTime(submission.submittedAt())));
			if (submission.reviewedBy() != null) {
				lore.add(Component.literal("§7Reviewed by: §f" + submission.reviewedBy()));
			}
			info.set(DataComponents.LORE, new ItemLore(lore));
			return info;
		}
		if (slot >= ANSWER_START && slot <= ANSWER_END) {
			int answerIndex = slot - ANSWER_START;
			List<Applications.QA> answers = submission.answers();
			if (answerIndex >= answers.size()) {
				return filler();
			}
			Applications.QA qa = answers.get(answerIndex);
			ItemStack book = new ItemStack(Items.WRITTEN_BOOK);
			book.set(DataComponents.CUSTOM_NAME, Component.literal("§eQ" + (answerIndex + 1) + ": " + qa.question()));
			book.set(DataComponents.LORE, new ItemLore(List.of(
				Component.literal("§f" + qa.answer())
			)));
			return book;
		}
		if (slot == DETAIL_HINT) {
			return info(Items.PAPER, "§7Instructions",
				"§7Accept grants the rank, /sfmode",
				"§7and full server commands.");
		}
		if (slot == DETAIL_ACCEPT) {
			if (!pending) {
				return filler();
			}
			return info(Items.EMERALD_BLOCK, "§a§lAccept", "§7Grant the rank and permissions.");
		}
		if (slot == DETAIL_REJECT) {
			if (!pending) {
				return filler();
			}
			return info(Items.REDSTONE_BLOCK, "§c§lReject", "§7Turn the application down.");
		}
		if (slot == DETAIL_REFRESH) {
			return info(Items.COMPASS, "§eRefresh", "§7Reload from disk.");
		}
		if (slot == DETAIL_LIST) {
			return info(Items.CHEST, "§eBack to list", "§7All applications.");
		}
		return filler();
	}

	// ---- Item helpers ------------------------------------------------------

	private static ItemStack filler() {
		ItemStack pane = new ItemStack(Compat.pickItem("STAINED_GLASS_PANE", DyeColor.GRAY));
		pane.set(DataComponents.CUSTOM_NAME, Component.literal(" "));
		return pane;
	}

	private static ItemStack info(Item item, String title, String... lore) {
		ItemStack stack = new ItemStack(item);
		stack.set(DataComponents.CUSTOM_NAME, Component.literal(title));
		if (lore.length > 0) {
			List<Component> lines = new ArrayList<>();
			for (String text : lore) {
				lines.add(text.isEmpty() ? Component.empty() : Component.literal(text));
			}
			stack.set(DataComponents.LORE, new ItemLore(lines));
		}
		return stack;
	}

	// ---- Interaction -------------------------------------------------------

	@Override
	public void clicked(int slotIndex, int buttonNum, ContainerInput containerInput, Player player) {
		if (slotIndex < 0 || slotIndex >= SIZE || !(player instanceof ServerPlayer serverPlayer)) {
			return;
		}
		// Defense in depth: only reviewers ever act here.
		if (!Applications.isReviewer(serverPlayer)) {
			serverPlayer.sendSystemMessage(Component.literal("§cYou are not authorized to review applications."));
			serverPlayer.closeContainer();
			return;
		}
		if (detail()) {
			handleDetail(slotIndex, serverPlayer);
		} else {
			handleList(slotIndex, serverPlayer);
		}
	}

	private void handleList(int slot, ServerPlayer player) {
		if (slot == LIST_CLOSE) {
			player.closeContainer();
			return;
		}
		if (slot < LIST_START || slot > LIST_END) {
			return;
		}
		int index = slot - LIST_START;
		List<Applications.Submission> submissions = Applications.submissions();
		if (index < 0 || index >= submissions.size()) {
			return;
		}
		selected = submissions.get(index);
		render();
	}

	private void handleDetail(int slot, ServerPlayer player) {
		Applications.Submission submission = selected;
		if (submission == null) {
			selected = null;
			render();
			return;
		}
		if (slot == DETAIL_BACK || slot == DETAIL_LIST) {
			selected = null;
			render();
			return;
		}
		if (slot == DETAIL_CLOSE) {
			player.closeContainer();
			return;
		}
		if (slot == DETAIL_REFRESH) {
			render();
			return;
		}
		MinecraftServer server = player.level().getServer();
		if (server == null) {
			return;
		}
		if (slot == DETAIL_ACCEPT) {
			String error = Applications.accept(submission.id(), player.getScoreboardName(), server);
			if (error != null) {
				player.sendSystemMessage(Component.literal("§c" + error));
			} else {
				player.sendSystemMessage(Component.literal(
					"§aAccepted §f" + submission.username() + "§a's application."));
			}
			// Refresh the record and stay on the detail view.
			selected = Applications.submission(submission.id());
			render();
			return;
		}
		if (slot == DETAIL_REJECT) {
			String error = Applications.reject(submission.id(), player.getScoreboardName(), server);
			if (error != null) {
				player.sendSystemMessage(Component.literal("§c" + error));
			} else {
				player.sendSystemMessage(Component.literal(
					"§cRejected §f" + submission.username() + "§c's application."));
			}
			selected = Applications.submission(submission.id());
			render();
		}
	}

	@Override
	public boolean stillValid(Player player) {
		return player == owner;
	}
}
