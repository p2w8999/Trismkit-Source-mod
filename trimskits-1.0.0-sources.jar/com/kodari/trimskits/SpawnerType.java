package com.kodari.trimskits;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;

/**
 * Every entity type a spawner can be, together with what it yields and what it
 * costs.
 *
 * <p>This is a code-defined table rather than a JSON one so the supported set,
 * the loot it produces and its price can never drift out of step — a loot entry
 * always names a real {@link Item}, and a type is only listed if it names a
 * real entity id. Types that cannot be spawned safely (currently only the
 * iron golem, with its heavy AI and collision footprint) are flagged
 * {@link #special()} and gated behind their own config switch instead of being
 * silently dropped or faked with a stand-in mob.
 *
 * <p>Rarity tiers (Basic → Advanced → Elite → Legendary) decide the price. The
 * prompt is explicit that rare spawners should be worth a great deal, so the
 * ladder runs from millions for a common passive mob up to a billion for an
 * iron golem.
 */
final class SpawnerType {

	/** Rarity tiers, cheapest first. */
	enum Tier {
		BASIC("Basic", 0xFF8080),
		ADVANCED("Advanced", 0x80BFFF),
		ELITE("Elite", 0xBF80FF),
		LEGENDARY("Legendary", 0xFFD700);

		final String label;
		final int colour;
		Tier(String label, int colour) {
			this.label = label;
			this.colour = colour;
		}

		/** Human-readable tier name, e.g. "Legendary". */
		String label() {
			return label;
		}
	}

	/**
	 * One supported type: its entity id, tier, loot yield and whether it needs
	 * an explicit safety gate.
	 *
	 * @param entityId    vanilla entity id, e.g. "minecraft:zombie"
	 * @param tier        rarity tier, which sets the price band
	 * @param price       base price of one spawner item, in dollars
	 * @param special     true when spawning needs a config opt-in (iron golem)
	 * @param loot        item id -> units yielded per production unit
	 */
	record Spec(String entityId, Tier tier, long price, boolean special,
			Map<String, Integer> loot) {
		/** The human name: "minecraft:zombie" -> "Zombie". */
		String label() {
			String path = entityId.contains(":") ? entityId.substring(entityId.indexOf(':') + 1) : entityId;
			StringBuilder out = new StringBuilder(path.length() + 4);
			for (String word : path.split("_")) {
				if (word.isEmpty()) {
					continue;
				}
				if (out.length() > 0) {
					out.append(' ');
				}
				out.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1));
			}
			return out.toString();
		}

		String spawnerName() {
			return label() + " Spawner";
		}

		/** Resolve an item id from the loot table to a real item, or null. */
		Item lootItem(String itemId) {
			return BuiltInRegistries.ITEM.getOptional(Identifier.tryParse(itemId)).orElse(null);
		}
	}

	/** Order matters: it is the order shown in the spawner picker. */
	private static final List<Spec> TYPES = new ArrayList<>();
	private static final Map<String, Spec> BY_ID = new LinkedHashMap<>();

	private SpawnerType() {
	}

	private static void add(String entityId, Tier tier, long price, boolean special,
			Map<String, Integer> loot) {
		// Register only if the entity actually exists in this build, so a type
		// we cannot spawn is never offered as a working spawner.
		Identifier id = Identifier.tryParse(entityId);
		if (id == null || BuiltInRegistries.ENTITY_TYPE.getOptional(id).isEmpty()) {
			TrimKits.LOGGER.warn("Skipping unsupported spawner type {}", entityId);
			return;
		}
		Spec type = new Spec(entityId, tier, price, special, Map.copyOf(loot));
		TYPES.add(type);
		BY_ID.put(entityId, type);
	}

	/** Compact loot helper: item path -> count (namespace defaults to minecraft). */
	private static Map<String, Integer> loot(Object... pairs) {
		Map<String, Integer> table = new LinkedHashMap<>();
		for (int index = 0; index + 1 < pairs.length; index += 2) {
			String item = (String) pairs[index];
			int count = (Integer) pairs[index + 1];
			table.put(item.contains(":") ? item : "minecraft:" + item, count);
		}
		return table;
	}

	static {
		// --- Basic: passive farm mobs, worth millions. ---
		add("minecraft:pig", Tier.BASIC, 1_000_000L, false, loot("porkchop", 2));
		add("minecraft:cow", Tier.BASIC, 1_000_000L, false, loot("beef", 2, "leather", 1));
		add("minecraft:sheep", Tier.BASIC, 1_200_000L, false, loot("mutton", 2, "white_wool", 1));
		add("minecraft:chicken", Tier.BASIC, 1_000_000L, false, loot("chicken", 1, "feather", 2));

		// --- Advanced: common hostiles, low tens of millions. ---
		add("minecraft:zombie", Tier.ADVANCED, 5_000_000L, false, loot("rotten_flesh", 2));
		add("minecraft:skeleton", Tier.ADVANCED, 5_000_000L, false, loot("bone", 2, "arrow", 2));
		add("minecraft:spider", Tier.ADVANCED, 5_000_000L, false, loot("string", 2, "spider_eye", 1));
		add("minecraft:cave_spider", Tier.ADVANCED, 8_000_000L, false, loot("string", 2, "spider_eye", 1));
		add("minecraft:husk", Tier.ADVANCED, 8_000_000L, false, loot("rotten_flesh", 3));
		add("minecraft:stray", Tier.ADVANCED, 8_000_000L, false, loot("bone", 2, "arrow", 3));
		add("minecraft:drowned", Tier.ADVANCED, 10_000_000L, false, loot("rotten_flesh", 2, "copper_ingot", 1));

		// --- Advanced+: mid tens of millions. ---
		add("minecraft:creeper", Tier.ADVANCED, 25_000_000L, false, loot("gunpowder", 3));
		add("minecraft:slime", Tier.ADVANCED, 40_000_000L, false, loot("slime_ball", 2));
		add("minecraft:magma_cube", Tier.ADVANCED, 45_000_000L, false, loot("magma_cream", 2));
		add("minecraft:witch", Tier.ADVANCED, 50_000_000L, false,
			loot("glowstone_dust", 2, "redstone", 2, "glass_bottle", 1));

		// --- Elite: hundreds of millions. ---
		add("minecraft:enderman", Tier.ELITE, 250_000_000L, false, loot("ender_pearl", 2));
		add("minecraft:blaze", Tier.ELITE, 500_000_000L, false, loot("blaze_rod", 2));

		// --- Legendary: a billion, and gated behind its own config switch. ---
		add("minecraft:iron_golem", Tier.LEGENDARY, 1_000_000_000L, true,
			loot("iron_ingot", 3, "poppy", 1));
	}

	/** Every supported type, in display order. */
	static List<Spec> all() {
		return List.copyOf(TYPES);
	}

	/** Lookup by exact entity id, or null when unsupported. */
	static Spec byId(String entityId) {
		if (entityId == null) {
			return null;
		}
		return BY_ID.get(entityId);
	}

	/**
	 * True when this type may be given/used right now — supported, and (for
	 * special types) switched on by config.
	 */
	static boolean usable(Spec type) {
		if (type == null) {
			return false;
		}
		if (!Config.getBoolean("spawners.enabled")) {
			return false;
		}
		return !type.special() || Config.getBoolean("spawners.iron_golem_enabled");
	}

	/** Types cleared for use, filtered by their config gates. */
	static List<Spec> available() {
		List<Spec> out = new ArrayList<>();
		for (Spec type : TYPES) {
			if (usable(type)) {
				out.add(type);
			}
		}
		return out;
	}

	/**
	 * Price of one spawner item of this type. Honours the global base price
	 * override so an admin can rebalance every spawner at once, while keeping
	 * the per-tier spread that makes a legendary spawner worth a billion.
	 */
	static long priceOf(Spec type) {
		if (type == null) {
			return 0;
		}
		long base = Config.getLong("spawners.base_price");
		// base_price == 0 means "use the per-type catalogue price".
		if (base <= 0) {
			return type.price();
		}
		// Scale the configured base by the type's tier weight so one knob
		// rescales the whole ladder without flattening it.
		double weight = switch (type.tier()) {
			case BASIC -> 1.0;
			case ADVANCED -> 5.0;
			case ELITE -> 25.0;
			case LEGENDARY -> 100.0;
		};
		return Math.max(1L, Math.round(base * weight));
	}

	/** Parse a type id a player/admin typed, tolerating the bare path form. */
	static Spec parse(String raw) {
		if (raw == null || raw.isBlank()) {
			return null;
		}
		String text = raw.trim().toLowerCase(Locale.ROOT);
		if (!text.contains(":")) {
			text = "minecraft:" + text;
		}
		return byId(text);
	}
}
