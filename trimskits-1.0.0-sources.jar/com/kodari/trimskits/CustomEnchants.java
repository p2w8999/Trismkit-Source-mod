package com.kodari.trimskits;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;

/**
 * Enchants this server invented.
 *
 * <p>They live in the item's lore rather than in the enchantment registry, and
 * that choice matters more than it looks. A mod that registered brand-new
 * enchantment objects would have to be installed on every client or vanilla
 * players would be kicked the moment they joined. Lore is data the client
 * already knows how to draw, so these work from a server-only install and
 * survive any client version.
 *
 * <p>The trade-off is that these do not appear in the vanilla enchanting table
 * or anvil - they are handed out here, and the effects are applied by
 * {@link TrimKits}.
 */
final class CustomEnchants {
	/** The line of lore that carries the enchant, e.g. "Smelter III". */
	private static final String MARK = "\u00a78\u2726 ";

	private CustomEnchants() {
	}

	/**
	 * Master switch for every custom enchant effect, from
	 * {@code custom_enchants.enabled}. The key shipped in the config for months
	 * without ever being read; now it actually turns the effects off.
	 */
	static boolean enabled() {
		return Config.getBoolean("custom_enchants.enabled");
	}

	/**
	 * The configured ceiling on enchant levels, from
	 * {@code custom_enchants.max_level}, never above the level the enchant
	 * itself allows. Read once: the config file is loaded a single time and
	 * does not change while the server is running.
	 */
	private static int configuredMaxLevel = -1;

	static int maxLevel(Type type) {
		if (configuredMaxLevel < 0) {
			configuredMaxLevel = Math.max(1, Config.getInt("custom_enchants.max_level"));
		}
		return Math.max(1, Math.min(type.maxLevel(), configuredMaxLevel));
	}

	enum Type {
		SMELTER("Smelter", ChatFormatting.GOLD,
			"Ores, stones and other drops come out of the ground already smelted",
			"I smelts every drop, II adds a 20% bonus, III adds 50%", 3),
		AUTO_REPAIR("Auto-Repair", ChatFormatting.AQUA,
			"The tool mends itself while you work with it",
			"I mends slowly, III mends quickly", 3),
		TELEKINESIS("Telekinesis", ChatFormatting.LIGHT_PURPLE,
			"Block drops land straight in your inventory",
			"There is only one level", 1),
		HASTE("Haste", ChatFormatting.YELLOW,
			"Holding this gives you the Haste effect",
			"Haste I, II or III while it is in your hand", 3),
		LUCKY("Lucky", ChatFormatting.GREEN,
			"Chance of extra drops when you break blocks",
			"I is 10%, II is 25%, III is 50%", 3),
		NIGHT_VISION("Night Vision", ChatFormatting.BLUE,
			"Holding this gives you Night Vision",
			"Always useful in a deepslate tunnel", 3);

		private final String displayName;
		private final ChatFormatting colour;
		private final String blurb;
		private final String detail;
		private final int maxLevel;

		Type(String name, ChatFormatting colour, String blurb, String detail, int maxLevel) {
			this.displayName = name;
			this.colour = colour;
			this.blurb = blurb;
			this.detail = detail;
			this.maxLevel = maxLevel;
		}

		String displayName() { return displayName; }

		ChatFormatting colour() {
			return colour;
		}

		String blurb() {
			return blurb;
		}

		String detail() {
			return detail;
		}

		int maxLevel() {
			return maxLevel;
		}

		/** Plain-language description of what this enchant can be applied to. */
		String appliesToText() {
			return switch (this) {
				case SMELTER, TELEKINESIS, LUCKY -> "pickaxes, shovels, hoes and axes";
				case AUTO_REPAIR -> "any tool or piece of armour";
				case HASTE, NIGHT_VISION -> "any item";
			};
		}
	}

	/** Stamps an enchant onto a stack, giving it the enchantment glint too. */
	static ItemStack apply(ItemStack stack, Type type, int level) {
		// A book never downgrades what it lands on; the better level stays.
		int wanted = Math.max(1, Math.min(maxLevel(type), level));
		int chosen = Math.max(wanted, levelOf(stack, type));
		List<Component> lines = new ArrayList<>();
		ItemLore existing = stack.get(DataComponents.LORE);
		if (existing != null) {
			for (Component line : existing.lines()) {
				// Drop any older copy of the same enchant so levels replace.
				if (!strip(line.getString()).contains(type.displayName())) {
					lines.add(line);
				}
			}
		}
		lines.add(Component.literal(type.displayName() + " " + roman(chosen)).withStyle(type.colour()));
		stack.set(DataComponents.LORE, new ItemLore(lines));
		stack.set(DataComponents.ENCHANTMENT_GLINT_OVERRIDE, Boolean.TRUE);
		return stack;
	}

	/** How many levels of this enchant the stack carries; 0 when it has none. */
	static int levelOf(ItemStack stack, Type type) {
		if (stack == null || stack.isEmpty()) {
			return 0;
		}
		ItemLore lore = stack.get(DataComponents.LORE);
		if (lore == null) {
			return 0;
		}
		for (Component line : lore.lines()) {
			String text = strip(line.getString());
			int at = text.indexOf(type.displayName());
			if (at < 0) {
				continue;
			}
			String suffix = text.substring(at + type.displayName().length()).trim();
			return Math.max(1, Math.min(maxLevel(type), fromRoman(suffix)));
		}
		return 0;
	}

	/** The enchant a custom book carries, or null when this stack is not one. */
	static Type bookType(ItemStack stack) {
		if (stack == null || stack.isEmpty() || stack.getItem() != Items.ENCHANTED_BOOK) {
			return null;
		}
		for (Type type : Type.values()) {
			if (levelOf(stack, type) > 0) {
				return type;
			}
		}
		return null;
	}

	/** Can this enchant be applied to the given stack? */
	static boolean compatible(Type type, ItemStack target) {
		if (type == null || target == null || target.isEmpty()) {
			return false;
		}
		return switch (type) {
			case SMELTER, TELEKINESIS, LUCKY -> isTool(target);
			case AUTO_REPAIR -> target.getMaxDamage() > 0;
			case HASTE, NIGHT_VISION -> true;
		};
	}

	/** A mining/tool item: any stack carrying a Tool component. */
	private static boolean isTool(ItemStack stack) {
		return stack.get(DataComponents.TOOL) != null;
	}

	/** Builds an enchanted-book carrying one of these enchants. */
	static ItemStack book(Type type, int level) {
		int clamped = Math.max(1, Math.min(maxLevel(type), level));
		ItemStack book = new ItemStack(Items.ENCHANTED_BOOK);
		apply(book, type, clamped);
		List<Component> lines = new ArrayList<>();
		ItemLore existing = book.get(DataComponents.LORE);
		if (existing != null) {
			lines.addAll(existing.lines());
		}
		lines.add(Component.empty());
		lines.add(Component.literal("Hold this with " + type.appliesToText()).withStyle(ChatFormatting.GRAY));
		lines.add(Component.literal("in your other hand, then right-click.").withStyle(ChatFormatting.GRAY));
		book.set(DataComponents.LORE, new ItemLore(lines));
		return book;
	}

	/** Drops formatting codes so a lore line can be compared as plain text. */
	static String strip(String text) {
		if (text == null) {
			return "";
		}
		StringBuilder clean = new StringBuilder(text.length());
		for (int index = 0; index < text.length(); index++) {
			char character = text.charAt(index);
			if (character == '\u00a7' && index + 1 < text.length()) {
				index++;
				continue;
			}
			clean.append(character);
		}
		return clean.toString();
	}

	static String roman(int level) {
		return switch (Math.max(1, Math.min(10, level))) {
			case 1 -> "I";
			case 2 -> "II";
			case 3 -> "III";
			case 4 -> "IV";
			case 5 -> "V";
			case 6 -> "VI";
			case 7 -> "VII";
			case 8 -> "VIII";
			case 9 -> "IX";
			default -> "X";
		};
	}

	/** @return the level written in roman numerals, or 1 when it is unreadable */
	static int fromRoman(String text) {
		String normalised = text.trim().toUpperCase(java.util.Locale.ROOT);
		int level = 0;
		for (int index = 0; index < normalised.length(); index++) {
			level += switch (normalised.charAt(index)) {
				case 'I' -> 1;
				case 'V' -> 5;
				case 'X' -> 10;
				default -> 0;
			};
		}
		return Math.max(1, level);
	}
}
