package com.kodari.trimskits;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;
import net.minecraft.world.item.component.CustomData;

/**
 * Creation, identification and stacking of the custom spawner items.
 *
 * <p>Every TrimKits spawner is a vanilla {@code minecraft:spawner} carrying two
 * extra data components: a {@code CUSTOM_DATA} record holding the entity id
 * (the one durable fact that decides what the spawner <em>is</em>) and a
 * {@code MAX_STACK_SIZE} override (the knob that decides how many may sit in a
 * single slot). Everything else — display name, lore — is cosmetic and derived
 * from those two, so two stacks of the same type are byte-for-byte identical
 * and therefore merge under vanilla stacking rules, while a zombie and a
 * skeleton spawner can never merge because their {@code CUSTOM_DATA} differs.
 *
 * <p>That gives the merge/split rules for free from vanilla:
 * <ul>
 *   <li>Compatible stacks combine up to the configured cap — no custom
 *       shift-click, drag or number-key handling to get wrong.</li>
 *   <li>Incompatible stacks refuse to combine, because
 *       {@code isSameItemSameComponents} sees different entity ids.</li>
 *   <li>Nothing can overflow silently: the count is clamped to
 *       {@code spawners.max_stack} whenever a stack is built or re-stamped.</li>
 * </ul>
 *
 * <p>The entity id is stored as a component rather than in a display name so a
 * rename, a lore edit or a locale change can never silently retype a spawner,
 * and an unsupported id is detected (and refused) instead of turning into an
 * ordinary spawner.
 */
final class SpawnerItem {

	/** Component key for the entity id inside {@code CUSTOM_DATA}. */
	private static final String KEY_TYPE = "trimskits_spawner";
	/** Component key for the schema version, so the format can migrate later. */
	private static final String KEY_VERSION = "trimskits_spawner_v";

	private SpawnerItem() {
	}

	// ---- Identity ---------------------------------------------------------

	/** The entity id stamped on this stack, or null when it is not a spawner. */
	static String entityIdOf(ItemStack stack) {
		if (stack == null || stack.isEmpty() || stack.getItem() != Items.SPAWNER) {
			return null;
		}
		CustomData data = stack.get(DataComponents.CUSTOM_DATA);
		if (data == null) {
			return null;
		}
		CompoundTag tag = data.copyTag();
		if (!tag.contains(KEY_TYPE)) {
			return null;
		}
		return tag.getString(KEY_TYPE).orElse(null);
	}

	/** True when this stack is a supported, currently-usable spawner. */
	static boolean isSpawner(ItemStack stack) {
		return SpawnerType.usable(SpawnerType.byId(entityIdOf(stack)));
	}

	/** True when this stack is a spawner of any kind, supported or not. */
	static boolean isAnySpawner(ItemStack stack) {
		return stack != null && !stack.isEmpty() && stack.getItem() == Items.SPAWNER
			&& entityIdOf(stack) != null;
	}

	/** Resolved type for a stack, or null. */
	static SpawnerType.Spec typeOf(ItemStack stack) {
		return SpawnerType.byId(entityIdOf(stack));
	}

	// ---- Construction -----------------------------------------------------

	/** Builds a spawner stack of the given count, clamped to the stack cap. */
	static ItemStack create(SpawnerType.Spec type, int count) {
		if (type == null || count <= 0) {
			return ItemStack.EMPTY;
		}
		ItemStack stack = new ItemStack(Items.SPAWNER);
		stamp(stack, type);
		stack.setCount(clampCount(count));
		return stack;
	}

	/**
	 * Applies the identity, cosmetics and stack cap to a spawner stack.
	 *
	 * <p>Called on build and again after any change that could have altered the
	 * count, so a stack can never sit above the configured maximum — a player
	 * can never end up with a 200-count spawner by merging, splitting or
	 * receiving items from an admin.
	 */
	private static void stamp(ItemStack stack, SpawnerType.Spec type) {
		CustomData.update(DataComponents.CUSTOM_DATA, stack, tag -> {
			tag.putString(KEY_TYPE, type.entityId());
			tag.putInt(KEY_VERSION, 1);
		});

		ChatFormatting colour = switch (type.tier()) {
			case BASIC -> ChatFormatting.GREEN;
			case ADVANCED -> ChatFormatting.AQUA;
			case ELITE -> ChatFormatting.LIGHT_PURPLE;
			case LEGENDARY -> ChatFormatting.GOLD;
		};
		stack.set(DataComponents.CUSTOM_NAME,
			Component.literal(type.spawnerName()).withStyle(colour));

		// Lore is deliberately static per type (no counts, no live rates) so
		// two identical stacks stay identical and merge under vanilla rules.
		List<Component> lore = new ArrayList<>();
		lore.add(Component.literal("§8" + type.tier().label() + " spawner"));
		lore.add(Component.empty());
		lore.add(Component.literal("§7Right-click to open the spawner menu."));
		lore.add(Component.literal("§7Hold more to produce faster."));
		lore.add(Component.empty());
		lore.add(Component.literal("§6Value: §e$" + TrimKits.formatMoney(SpawnerType.priceOf(type))));
		lore.add(Component.literal("§8" + type.entityId()));
		stack.set(DataComponents.LORE, new ItemLore(lore));

		stack.set(DataComponents.MAX_STACK_SIZE, stackCap());
	}

	/** Configured hard cap for a single spawner stack, clamped to sane bounds. */
	static int stackCap() {
		int cap = Config.getInt("spawners.max_stack");
		// 1 is the vanilla-safe floor; 64 is the vanilla ceiling. Allowing more
		// than 64 is a deliberate, config-gated feature (the spec's "100"
		// example), so the range is wide but never absurd.
		return Math.max(1, Math.min(cap, 1024));
	}

	/** Clamp a requested count so no build path can overflow the cap. */
	static int clampCount(int count) {
		return Math.max(1, Math.min(count, stackCap()));
	}

	/** Re-clamp an existing stack in place; returns true if it had to change. */
	static boolean normalise(ItemStack stack) {
		if (stack == null || stack.isEmpty() || entityIdOf(stack) == null) {
			return false;
		}
		int cap = stackCap();
		if (stack.getCount() > cap) {
			stack.setCount(cap);
			return true;
		}
		// Keep the cap component in step with config after a reload.
		Integer current = stack.get(DataComponents.MAX_STACK_SIZE);
		if (current == null || current != cap) {
			stack.set(DataComponents.MAX_STACK_SIZE, cap);
			return true;
		}
		return false;
	}

	// ---- Inventory accounting ---------------------------------------------

	/**
	 * Total spawner count per type held by an inventory.
	 *
	 * <p>Used both by the production tick and by the GUI's summary line, so the
	 * number the player is told always matches the number the engine acts on.
	 */
	static Map<String, Integer> countByType(Inventory inventory) {
		Map<String, Integer> counts = new LinkedHashMap<>();
		if (inventory == null) {
			return counts;
		}
		for (int slot = 0; slot < inventory.getContainerSize(); slot++) {
			ItemStack stack = inventory.getItem(slot);
			String id = entityIdOf(stack);
			if (id != null) {
				counts.merge(id, stack.getCount(), Integer::sum);
			}
		}
		return counts;
	}

	/** Total count of one specific type held, across the whole inventory. */
	static int countOf(Inventory inventory, String entityId) {
		int total = 0;
		if (inventory == null) {
			return 0;
		}
		for (int slot = 0; slot < inventory.getContainerSize(); slot++) {
			ItemStack stack = inventory.getItem(slot);
			if (entityId.equals(entityIdOf(stack))) {
				total += stack.getCount();
			}
		}
		return total;
	}

	/** Remove up to {@code amount} of a type from the inventory; true if any went. */
	static boolean remove(Player player, String entityId, int amount) {
		if (player == null || amount <= 0) {
			return false;
		}
		Inventory inventory = player.getInventory();
		int remaining = amount;
		for (int slot = 0; slot < inventory.getContainerSize() && remaining > 0; slot++) {
			ItemStack stack = inventory.getItem(slot);
			if (!entityId.equals(entityIdOf(stack))) {
				continue;
			}
			int take = Math.min(remaining, stack.getCount());
			stack.shrink(take);
			remaining -= take;
			if (stack.isEmpty()) {
				inventory.setItem(slot, ItemStack.EMPTY);
			}
		}
		return remaining < amount;
	}

	// ---- Sell support ------------------------------------------------------

	/**
	 * The sell price of one spawner stack, or null when it has none.
	 *
	 * <p>Spawners are deliberately excluded from the generic catalogue (they
	 * are custom, protected items), so they price off their own tier ladder
	 * rather than {@link ShopValues}.
	 */
	static Long sellPrice(ItemStack stack) {
		SpawnerType.Spec type = typeOf(stack);
		if (type == null || !SpawnerType.usable(type)) {
			return null;
		}
		long unit = SpawnerType.priceOf(type);
		if (unit <= 0) {
			return null;
		}
		try {
			return Math.multiplyExact(unit, (long) stack.getCount());
		} catch (ArithmeticException overflow) {
			return Long.MAX_VALUE;
		}
	}
}
